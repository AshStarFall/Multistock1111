# 🚀 MultiStock Setup Guide

## ⚠️ CRITICAL: Get Your Supabase Service Role Key

### Step 1: Get Service Role Key

1. **Go to Supabase Dashboard:**
   - Visit: https://app.supabase.com/project/beafmhdmhuqvuadvorlg/settings/api

2. **Copy the Service Role Key:**
   - Look for section: "Project API keys"
   - Find: `service_role` (secret)
   - Click "Reveal" button
   - Copy the entire key (starts with `eyJ...`)

3. **Update .env.local:**
   ```env
   SUPABASE_SERVICE_ROLE_KEY=<paste_your_key_here>
   ```

### Step 2: Restart Everything

```bash
# Stop the dev server (Ctrl+C)
# Then restart:
npm run dev
```

### Step 3: Seed Users

```bash
npm run seed
```

---

## 👥 User Credentials (After Seeding)

| Email | Password | Role |
|-------|----------|------|
| superadmin@gmail.com | 123 | SuperAdmin |
| admin@multistock.com | Admin@123 | Admin |
| manager@multistock.com | Manager@123 | Manager |
| employee@multistock.com | Employee@123 | Staff |
| customer@multistock.com | Customer@123 | Customer |

---

## 🧪 Testing Login

1. Go to: http://localhost:3000/auth/login
2. Use: `superadmin@gmail.com` / `123`
3. Check browser console (F12) for errors

---

## 🆘 Troubleshooting

### "Invalid API key" Error
- You need the **Service Role Key**, not the Anon Key
- Get it from Supabase Dashboard (see Step 1 above)

### "User not found" Error
- Run database schema first (see below)
- Then run `npm run seed`

### "Table doesn't exist" Error
- You need to run the database schema SQL

---

## 📊 Setup Database Schema

1. **Go to Supabase SQL Editor:**
   - Visit: https://app.supabase.com/project/beafmhdmhuqvuadvorlg/sql/new

2. **Run the schema:**
   - Open file: `database-schema.sql`
   - Copy all SQL
   - Paste in SQL Editor
   - Click "Run"

3. **Verify tables created:**
   - Check Table Editor for `users`, `products`, etc.

---

## ✅ Complete Setup Checklist

- [ ] Get Service Role Key from Supabase
- [ ] Update .env.local with the key
- [ ] Run database-schema.sql in Supabase
- [ ] Run `npm run seed`
- [ ] Test login at /auth/login
- [ ] Check for console errors

---

## 🔑 Current Environment Status

```env
✅ NEXT_PUBLIC_SUPABASE_URL - Configured
✅ NEXT_PUBLIC_SUPABASE_ANON_KEY - Configured
❌ SUPABASE_SERVICE_ROLE_KEY - NEEDS YOUR KEY
⚠️ NEXT_PUBLIC_RAZORPAY_KEY_ID - Not configured (optional)
⚠️ RAZORPAY_KEY_SECRET - Not configured (optional)
```

**Payments won't work until Razorpay keys are added (optional for now)**
