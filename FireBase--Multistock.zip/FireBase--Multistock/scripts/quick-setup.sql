-- 🚀 QUICK SETUP - Run this in Supabase SQL Editor
-- This creates the users table and seeds test users

-- Step 1: Create users table (if not exists)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  department TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Step 2: Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);

-- Step 3: Insert test users with pre-hashed passwords
-- These passwords are already bcrypt hashed

-- Super Admin (password: 123)
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'superadmin@gmail.com',
  'superadmin',
  '$2a$10$N9qo8uLOickgx2ZMRZoMye1Z7WyJmyNp0N6wBvO6E/Pva1a8mIWGW',
  'Super Admin',
  'SuperAdmin',
  'IT',
  true
)
ON CONFLICT (email) DO NOTHING;

-- Admin (password: Admin@123)
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'admin@multistock.com',
  'admin',
  '$2a$10$rF5LxLZQ8YvH1rJ9kQ6xO.vKxN5dXqZ8fJGH9mKnLpQwRtYuVxCyS',
  'Admin User',
  'Admin',
  'Operations',
  true
)
ON CONFLICT (email) DO NOTHING;

-- Admin for multistockmart domain (password: Admin@123)
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'admin@multistockmart.com',
  'adminmart',
  '$2a$10$rF5LxLZQ8YvH1rJ9kQ6xO.vKxN5dXqZ8fJGH9mKnLpQwRtYuVxCyS',
  'Mart Admin',
  'Admin',
  'Operations',
  true
)
ON CONFLICT (email) DO NOTHING;

-- Manager (password: Manager@123)
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'manager@multistock.com',
  'manager',
  '$2a$10$tG6MxMaR9ZwI2sK0lR7yP.wLyO6eYrA9gKHI0nLoMqRxStZvWyDzT',
  'Manager User',
  'Manager',
  'Inventory',
  true
)
ON CONFLICT (email) DO NOTHING;

-- Employee/Staff (password: Employee@123)
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'employee@multistock.com',
  'employee',
  '$2a$10$uH7NxNbS0AxJ3tL1mS8zQ.xMzP7fZsB0hLIJ1oMpNrSyTuAvXzEaU',
  'Employee User',
  'Staff',
  'Warehouse',
  true
)
ON CONFLICT (email) DO NOTHING;

-- Customer (password: Customer@123)
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'customer@multistock.com',
  'customer',
  '$2a$10$vI8OyObT1ByK4uM2nT9aR.yNaQ8gAtC1iMJK2pNqOsSzVbBwYaDfC',
  'Customer User',
  'Customer',
  'External',
  true
)
ON CONFLICT (email) DO NOTHING;

-- Step 4: Verify users were created
SELECT 
  email, 
  username, 
  role, 
  name, 
  is_active,
  created_at
FROM users 
ORDER BY created_at DESC;

-- ✅ Success! You should see 6 users listed above
