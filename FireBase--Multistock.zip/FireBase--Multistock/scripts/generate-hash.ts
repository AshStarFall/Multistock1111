import bcrypt from 'bcryptjs'

async function generateHash() {
  const passwords = [
    { label: 'superadmin', password: '123' },
    { label: 'admin', password: 'Admin@123' },
    { label: 'manager', password: 'Manager@123' },
    { label: 'employee', password: 'Employee@123' },
    { label: 'customer', password: 'Customer@123' }
  ]

  console.log('🔐 Generating bcrypt hashes...\n')

  for (const item of passwords) {
    const hash = await bcrypt.hash(item.password, 10)
    console.log(`${item.label}: ${item.password}`)
    console.log(`Hash: ${hash}\n`)
  }
  
  process.exit(0)
}

generateHash()