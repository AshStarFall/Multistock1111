require('dotenv').config({ path: '.env.local' })
import bcrypt from 'bcryptjs'
import { supabase } from '../lib/supabase'

async function resetPassword() {
  const email = 'superadmin@gmail.com'
  const newPassword = '123'
  
  console.log('🔐 Resetting password for:', email)
  
  // Hash the password
  const passwordHash = await bcrypt.hash(newPassword, 10)
  console.log('✅ Password hashed')
  
  // Update in database
  const { data, error } = await supabase
    .from('users')
    .update({ password_hash: passwordHash })
    .eq('email', email)
    .select()
  
  if (error) {
    console.error('❌ Error:', error)
  } else {
    console.log('✅ Password reset successfully!')
    console.log('📧 Email:', email)
    console.log('🔑 New Password:', newPassword)
  }
  
  process.exit(0)
}

resetPassword()