// Load environment variables FIRST
require('dotenv').config({ path: '.env.local' })

const { createClient } = require('@supabase/supabase-js')
const bcrypt = require('bcryptjs')

async function seedUsers() {
  console.log('🔍 Checking environment variables...')
  console.log('SUPABASE_URL:', process.env.NEXT_PUBLIC_SUPABASE_URL ? '✅ SET' : '❌ NOT SET')
  console.log('SUPABASE_KEY:', process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? '✅ SET' : '❌ NOT SET')
  console.log('')

  // Create Supabase client
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  
  if (!supabaseUrl || !supabaseKey) {
    console.error('❌ Missing Supabase configuration')
    process.exit(1)
  }

  const supabase = createClient(supabaseUrl, supabaseKey)

  const users = [
    {
      email: 'superadmin@gmail.com',
      username: 'superadmin',
      password: '123',
      name: 'Super Admin',
      role: 'SuperAdmin',
      department: 'IT'
    },
    {
      email: 'admin@multistock.com',
      username: 'admin',
      password: 'Admin@123',
      name: 'Admin User',
      role: 'Admin',
      department: 'Operations'
    },
    {
      email: 'manager@multistock.com',
      username: 'manager',
      password: 'Manager@123',
      name: 'Manager User',
      role: 'Manager',
      department: 'Inventory'
    },
    {
      email: 'employee@multistock.com',
      username: 'employee',
      password: 'Employee@123',
      name: 'Employee User',
      role: 'Staff',
      department: 'Warehouse'
    },
    {
      email: 'customer@multistock.com',
      username: 'customer',
      password: 'Customer@123',
      name: 'Customer User',
      role: 'Customer',
      department: 'External'
    }
  ]

  console.log('🌱 Starting to seed users...\n')

  for (const user of users) {
    try {
      // Hash password
      const passwordHash = await bcrypt.hash(user.password, 10)
      
      // Insert user
      const { data, error } = await supabase
        .from('users')
        .insert([
          {
            email: user.email,
            username: user.username,
            password_hash: passwordHash,
            name: user.name,
            role: user.role,
            department: user.department,
            is_active: true,
            created_at: new Date().toISOString()
          }
        ])
        .select()

      if (error) {
        if (error.message.includes('duplicate') || error.code === '23505') {
          console.log(`⚠️  Already exists: ${user.email}`)
        } else {
          console.log(`❌ Error: ${user.email} - ${error.message}`)
        }
      } else {
        console.log(`✅ Created: ${user.email} (${user.role})`)
      }
    } catch (error: any) {
      console.log(`❌ Error: ${user.email} - ${error.message}`)
    }
  }

  console.log('\n🎉 Seeding completed!')
  process.exit(0)
}

seedUsers().catch(error => {
  console.error('Fatal error:', error)
  process.exit(1)
})