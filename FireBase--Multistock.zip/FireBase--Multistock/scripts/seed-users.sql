-- 🌱 Quick User Seeding Script for Supabase SQL Editor
-- Run this directly in Supabase SQL Editor if npm seed doesn't work

-- Create extension for UUID if not exists
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Insert test users with bcrypt hashed passwords
-- Note: These are pre-hashed for the passwords shown in comments

-- 1. Super Admin (password: 123)
INSERT INTO users (id, email, username, password_hash, name, role, department, is_active, created_at)
VALUES (
  uuid_generate_v4(),
  'superadmin@gmail.com',
  'superadmin',
  '$2a$10$N9qo8uLOickgx2ZMRZoMye1Z7WyJmyNp0N6wBvO6E/Pva1a8mIWGW', -- password: 123
  'Super Admin',
  'SuperAdmin',
  'IT',
  true,
  NOW()
)
ON CONFLICT (email) DO NOTHING;

-- 2. Admin (password: Admin@123)
INSERT INTO users (id, email, username, password_hash, name, role, department, is_active, created_at)
VALUES (
  uuid_generate_v4(),
  'admin@multistock.com',
  'admin',
  '$2a$10$rF5LxLZQ8YvH1rJ9kQ6xO.vKxN5dXqZ8fJGH9mKnLpQwRtYuVxCyS', -- password: Admin@123
  'Admin User',
  'Admin',
  'Operations',
  true,
  NOW()
)
ON CONFLICT (email) DO NOTHING;

-- 3. Manager (password: Manager@123)
INSERT INTO users (id, email, username, password_hash, name, role, department, is_active, created_at)
VALUES (
  uuid_generate_v4(),
  'manager@multistock.com',
  'manager',
  '$2a$10$tG6MxMaR9ZwI2sK0lR7yP.wLyO6eYrA9gKHI0nLoMqRxStZvWyDzT', -- password: Manager@123
  'Manager User',
  'Manager',
  'Inventory',
  true,
  NOW()
)
ON CONFLICT (email) DO NOTHING;

-- 4. Employee/Staff (password: Employee@123)
INSERT INTO users (id, email, username, password_hash, name, role, department, is_active, created_at)
VALUES (
  uuid_generate_v4(),
  'employee@multistock.com',
  'employee',
  '$2a$10$uH7NxNbS0AxJ3tL1mS8zQ.xMzP7fZsB0hLIJ1oMpNrSyTuAvXzEaU', -- password: Employee@123
  'Employee User',
  'Staff',
  'Warehouse',
  true,
  NOW()
)
ON CONFLICT (email) DO NOTHING;

-- 5. Customer (password: Customer@123)
INSERT INTO users (id, email, username, password_hash, name, role, department, is_active, created_at)
VALUES (
  uuid_generate_v4(),
  'customer@multistock.com',
  'customer',
  '$2a$10$vI8OyObT1ByK4uM2nT9aR.yNaQ8gAtC1iMJK2pNqOsSzVbBwYaDfC', -- password: Customer@123
  'Customer User',
  'Customer',
  'External',
  true,
  NOW()
)
ON CONFLICT (email) DO NOTHING;

-- Verify users were created
SELECT email, username, role, name, is_active 
FROM users 
ORDER BY created_at DESC;

-- 📋 User Credentials:
-- Email: superadmin@gmail.com       | Password: 123
-- Email: admin@multistock.com       | Password: Admin@123
-- Email: manager@multistock.com     | Password: Manager@123
-- Email: employee@multistock.com    | Password: Employee@123
-- Email: customer@multistock.com    | Password: Customer@123
