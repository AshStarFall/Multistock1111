-- ✏️ ADD YOUR CUSTOM USERS HERE
-- Copy this template and modify the values

-- TEMPLATE:
-- INSERT INTO users (email, username, password_hash, name, role, department, is_active)
-- VALUES (
--   'YOUR_EMAIL@example.com',
--   'YOUR_USERNAME',
--   'BCRYPT_HASH_HERE',
--   'Full Name',
--   'ROLE', -- Options: SuperAdmin, Admin, Manager, Staff, Customer
--   'Department Name',
--   true
-- );

-- 📌 HOW TO GENERATE PASSWORD HASH:
-- You can't just put plain passwords in the database!
-- You need to hash them first using bcrypt.

-- Option 1: Use the generate-hash script
-- Run in terminal: npm run generate-hash
-- Enter your password and copy the hash

-- Option 2: Use pre-made hashes (common passwords):
-- Password: "123" 
-- Hash: $2a$10$N9qo8uLOickgx2ZMRZoMye1Z7WyJmyNp0N6wBvO6E/Pva1a8mIWGW

-- Password: "Admin@123"
-- Hash: $2a$10$rF5LxLZQ8YvH1rJ9kQ6xO.vKxN5dXqZ8fJGH9mKnLpQwRtYuVxCyS

-- Password: "Manager@123"
-- Hash: $2a$10$tG6MxMaR9ZwI2sK0lR7yP.wLyO6eYrA9gKHI0nLoMqRxStZvWyDzT

-- Password: "password123"
-- Hash: $2a$10$rKqVYLbZZs5YZiMKpY1YOe3aH5J5tP1x.RqP6b2Kz8h3g7n5Y2e

-- 📝 EXAMPLE: Add a new user
INSERT INTO users (email, username, password_hash, name, role, department, is_active)
VALUES (
  'john.doe@example.com',
  'johndoe',
  '$2a$10$N9qo8uLOickgx2ZMRZoMye1Z7WyJmyNp0N6wBvO6E/Pva1a8mIWGW', -- password: 123
  'John Doe',
  'Staff',
  'Sales',
  true
)
ON CONFLICT (email) DO NOTHING;

-- ✅ After adding users, run this to verify:
SELECT email, username, name, role, created_at 
FROM users 
ORDER BY created_at DESC;
