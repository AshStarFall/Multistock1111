import { useEffect, useRef, useState, useCallback } from 'react'

/**
 * Debounce hook for search inputs and API calls
 */
export function useDebounce<T>(value: T, delay: number = 500): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => {
      clearTimeout(handler)
    }
  }, [value, delay])

  return debouncedValue
}

/**
 * Throttle hook for scroll and resize events
 */
export function useThrottle<T>(value: T, interval: number = 500): T {
  const [throttledValue, setThrottledValue] = useState<T>(value)
  const lastExecuted = useRef<number>(Date.now())

  useEffect(() => {
    if (Date.now() >= lastExecuted.current + interval) {
      lastExecuted.current = Date.now()
      setThrottledValue(value)
    } else {
      const timerId = setTimeout(() => {
        lastExecuted.current = Date.now()
        setThrottledValue(value)
      }, interval)

      return () => clearTimeout(timerId)
    }
  }, [value, interval])

  return throttledValue
}

/**
 * Intersection Observer hook for lazy loading
 */
export function useIntersectionObserver(
  ref: React.RefObject<Element | null>,
  options: IntersectionObserverInit = {}
) {
  const [isIntersecting, setIntersecting] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      setIntersecting(entry.isIntersecting)
    }, options)

    const currentRef = ref.current
    if (currentRef) {
      observer.observe(currentRef)
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef)
      }
    }
  }, [ref, options])

  return isIntersecting
}

/**
 * Lazy load component hook
 */
export function useLazyLoad() {
  const [loaded, setLoaded] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const isVisible = useIntersectionObserver(ref, {
    threshold: 0.1,
    rootMargin: '50px',
  })

  useEffect(() => {
    if (isVisible && !loaded) {
      setLoaded(true)
    }
  }, [isVisible, loaded])

  return { ref, loaded }
}

/**
 * Cache hook for API responses
 */
interface CacheItem<T> {
  data: T
  timestamp: number
}

const cache = new Map<string, CacheItem<any>>()

export function useCache<T>(
  key: string,
  fetcher: () => Promise<T>,
  ttl: number = 5 * 60 * 1000 // 5 minutes default
) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  const fetchData = useCallback(async () => {
    const cached = cache.get(key)
    const now = Date.now()

    if (cached && now - cached.timestamp < ttl) {
      setData(cached.data)
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      const result = await fetcher()
      cache.set(key, { data: result, timestamp: now })
      setData(result)
      setError(null)
    } catch (err) {
      setError(err as Error)
    } finally {
      setLoading(false)
    }
  }, [key, fetcher, ttl])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const invalidate = useCallback(() => {
    cache.delete(key)
    fetchData()
  }, [key, fetchData])

  return { data, loading, error, invalidate }
}

/**
 * Clear all cache
 */
export function clearCache() {
  cache.clear()
}

/**
 * Remove specific cache entry
 */
export function removeCache(key: string) {
  cache.delete(key)
}

/**
 * Prefetch data for better UX
 */
export function prefetch<T>(key: string, fetcher: () => Promise<T>) {
  if (!cache.has(key)) {
    fetcher().then(data => {
      cache.set(key, { data, timestamp: Date.now() })
    })
  }
}

/**
 * Optimize image loading
 */
export function getOptimizedImageUrl(
  url: string,
  width?: number,
  quality: number = 75
): string {
  if (!url) return ''
  
  // For external URLs, return as is
  if (url.startsWith('http')) {
    return url
  }
  
  // For local images, use Next.js Image optimization
  const params = new URLSearchParams()
  if (width) params.append('w', width.toString())
  params.append('q', quality.toString())
  
  return `/_next/image?url=${encodeURIComponent(url)}&${params.toString()}`
}

/**
 * Batch multiple state updates
 */
export function useBatchedState<T>(initialState: T) {
  const [state, setState] = useState<T>(initialState)
  const pendingUpdates = useRef<Partial<T>>({})
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  const batchUpdate = useCallback((updates: Partial<T>) => {
    pendingUpdates.current = { ...pendingUpdates.current, ...updates }

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }

    timeoutRef.current = setTimeout(() => {
      setState(prev => ({ ...prev, ...pendingUpdates.current }))
      pendingUpdates.current = {}
    }, 10)
  }, [])

  return [state, batchUpdate] as const
}

/**
 * Virtual scrolling helper for large lists
 */
export function useVirtualScroll<T>(
  items: T[],
  itemHeight: number,
  containerHeight: number
) {
  const [scrollTop, setScrollTop] = useState(0)
  
  const startIndex = Math.floor(scrollTop / itemHeight)
  const endIndex = Math.min(
    startIndex + Math.ceil(containerHeight / itemHeight) + 1,
    items.length
  )
  
  const visibleItems = items.slice(startIndex, endIndex)
  const totalHeight = items.length * itemHeight
  const offsetY = startIndex * itemHeight

  return {
    visibleItems,
    totalHeight,
    offsetY,
    setScrollTop,
  }
}

/**
 * Memory leak prevention - cleanup on unmount
 */
export function useCleanup(cleanup: () => void) {
  useEffect(() => {
    return cleanup
  }, [cleanup])
}

/**
 * Performance monitoring
 */
export function usePerformanceMonitor(componentName: string) {
  useEffect(() => {
    const startTime = performance.now()

    return () => {
      const endTime = performance.now()
      const renderTime = endTime - startTime

      if (renderTime > 16) { // More than 1 frame (60fps)
        console.warn(
          `🐌 Slow render: ${componentName} took ${renderTime.toFixed(2)}ms`
        )
      }
    }
  })
}

/**
 * Network status hook
 */
export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  )

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  return isOnline
}
