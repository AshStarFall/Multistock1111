import { useCallback, useEffect, useState } from 'react'

// Hook to optimize performance by preloading critical resources
export function useOptimization() {
  const [isOptimized, setIsOptimized] = useState(false)

  // Preload critical resources
  const preloadResources = useCallback(() => {
    // Note: Fonts are already loaded via Next.js font optimization (Inter from next/font/google)
    // No need to preload them again to avoid console warnings
    
    // Preload critical images
    const images = [
      '/multistock-logo.svg'
    ]
    
    images.forEach(imageUrl => {
      const img = new Image()
      img.src = imageUrl
    })

    setIsOptimized(true)
  }, [])

  // Optimize scrolling performance
  const optimizeScrolling = useCallback(() => {
    // Add smooth scrolling behavior
    document.documentElement.style.scrollBehavior = 'smooth'
    
    // Optimize scroll performance
    let ticking = false
    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          // Optimize scroll-dependent animations here if needed
          ticking = false
        })
        ticking = true
      }
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true })
    
    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  // Optimize rendering performance
  const optimizeRendering = useCallback(() => {
    // Enable passive event listeners
    const supportsPassive = (() => {
      let supportsPassive = false
      try {
        const opts = Object.defineProperty({}, 'passive', {
          get() {
            supportsPassive = true
          }
        })
        window.addEventListener('testPassive', () => {}, opts)
        window.removeEventListener('testPassive', () => {}, opts)
      } catch (e) {}
      return supportsPassive
    })()
    
    // Optimize touch and wheel events
    const eventOptions = supportsPassive ? { passive: true } : false
    document.addEventListener('touchstart', () => {}, eventOptions)
    document.addEventListener('wheel', () => {}, eventOptions)
  }, [])

  useEffect(() => {
    // Run optimizations when component mounts
    preloadResources()
    optimizeScrolling()
    optimizeRendering()
    
    // Add performance monitoring
    if ('performance' in window) {
      window.addEventListener('load', () => {
        setTimeout(() => {
          const perfEntries = performance.getEntriesByType('navigation')
          if (perfEntries.length > 0) {
            const perfData = perfEntries[0] as PerformanceNavigationTiming
            console.log('Page Load Time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms')
          }
        }, 0)
      })
    }
  }, [preloadResources, optimizeScrolling, optimizeRendering])

  return { isOptimized }
}