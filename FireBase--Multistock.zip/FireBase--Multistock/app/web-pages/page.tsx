"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { toast } from "sonner"
import { 
  Plus, 
  Edit, 
  Eye, 
  EyeOff, 
  Trash2,
  RefreshCw
} from "lucide-react"
import Link from "next/link"

type WebPage = {
  id: string
  title: string
  slug: string
  meta_description: string | null
  is_published: boolean
  created_at: string
  updated_at: string
}

export default function WebPagesPage() {
  const [webPages, setWebPages] = useState<WebPage[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = getSupabaseBrowser()

  const fetchWebPages = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('web_pages')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      
      setWebPages(data || [])
    } catch (err) {
      console.error('Error fetching web pages:', err)
      setError('Failed to load web pages')
      toast.error('Failed to load web pages')
    } finally {
      setLoading(false)
    }
  }

  const togglePublishStatus = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('web_pages')
        .update({ 
          is_published: !currentStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)

      if (error) throw error

      // Update local state
      setWebPages(prev => 
        prev.map(page => 
          page.id === id 
            ? { ...page, is_published: !currentStatus, updated_at: new Date().toISOString() } 
            : page
        )
      )

      toast.success(`Page ${!currentStatus ? 'published' : 'unpublished'} successfully`)
    } catch (err) {
      console.error('Error updating page status:', err)
      toast.error('Failed to update page status')
    }
  }

  const deleteWebPage = async (id: string, title: string) => {
    if (!confirm(`Are you sure you want to delete the page "${title}"?`)) return

    try {
      const { error } = await supabase
        .from('web_pages')
        .delete()
        .eq('id', id)

      if (error) throw error

      // Update local state
      setWebPages(prev => prev.filter(page => page.id !== id))
      toast.success('Page deleted successfully')
    } catch (err) {
      console.error('Error deleting page:', err)
      toast.error('Failed to delete page')
    }
  }

  useEffect(() => {
    fetchWebPages()
  }, [])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] p-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-2">Error Loading Web Pages</h2>
          <p className="text-muted-foreground mb-4">{error}</p>
          <Button onClick={fetchWebPages}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            Web Pages
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage all web pages stored in the database
          </p>
        </div>
        <Button asChild>
          <Link href="/web-pages/create">
            <Plus className="w-4 h-4 mr-2" />
            Create New Page
          </Link>
        </Button>
      </div>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Web Pages</CardTitle>
          <CardDescription>
            All web pages stored in the database
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="mt-2 text-sm text-muted-foreground">Loading web pages...</p>
              </div>
            </div>
          ) : webPages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">No web pages found</h3>
                <p className="text-muted-foreground mb-4">Create your first web page to get started.</p>
                <Button asChild>
                  <Link href="/web-pages/create">
                    <Plus className="w-4 h-4 mr-2" />
                    Create New Page
                  </Link>
                </Button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Slug</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {webPages.map((page) => (
                    <TableRow key={page.id}>
                      <TableCell className="font-medium">{page.title}</TableCell>
                      <TableCell className="font-mono text-sm">/{page.slug}</TableCell>
                      <TableCell className="max-w-xs truncate text-muted-foreground">
                        {page.meta_description || "-"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={page.is_published ? "default" : "secondary"}>
                          {page.is_published ? "Published" : "Draft"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(page.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => togglePublishStatus(page.id, page.is_published)}
                            title={page.is_published ? "Unpublish" : "Publish"}
                          >
                            {page.is_published ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </Button>
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={`/web-pages/edit/${page.id}`} title="Edit">
                              <Edit className="w-4 h-4" />
                            </Link>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteWebPage(page.id, page.title)}
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}