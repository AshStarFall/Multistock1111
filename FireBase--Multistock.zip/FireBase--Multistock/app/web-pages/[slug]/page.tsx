"use client"

import { useEffect, useState } from "react"
import { notFound } from "next/navigation"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { toast } from "sonner"
import { RefreshCw } from "lucide-react"

type WebPage = {
  id: string
  title: string
  slug: string
  content: string | null
  meta_description: string | null
  is_published: boolean
  created_at: string
  updated_at: string
}

export default function WebPageView({ params }: { params: { slug: string } }) {
  const [webPage, setWebPage] = useState<WebPage | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = getSupabaseBrowser()

  const fetchWebPage = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const { data, error } = await supabase
        .from('web_pages')
        .select('*')
        .eq('slug', params.slug)
        .single()

      if (error) throw error
      
      if (!data) {
        notFound()
        return
      }

      // Check if page is published (unless in development)
      if (!data.is_published && process.env.NODE_ENV !== 'development') {
        notFound()
        return
      }

      setWebPage(data)
    } catch (err) {
      console.error('Error fetching web page:', err)
      setError('Failed to load page')
      toast.error('Failed to load page')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchWebPage()
  }, [params.slug])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] p-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-2">Error Loading Page</h2>
          <p className="text-muted-foreground mb-4">{error}</p>
          <Button onClick={fetchWebPage}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading page...</p>
        </div>
      </div>
    )
  }

  if (!webPage) {
    return notFound()
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="border-0 shadow-lg max-w-4xl mx-auto">
        <CardContent className="p-8">
          <div className="mb-6">
            <h1 className="text-4xl font-bold mb-4">{webPage.title}</h1>
            <div className="flex items-center text-sm text-muted-foreground">
              <span>
                Last updated: {new Date(webPage.updated_at).toLocaleDateString()}
              </span>
              {!webPage.is_published && (
                <span className="ml-4 px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">
                  Draft
                </span>
              )}
            </div>
          </div>
          
          <div className="prose prose-lg max-w-none">
            {webPage.content ? (
              <div className="whitespace-pre-wrap">{webPage.content}</div>
            ) : (
              <p className="text-muted-foreground italic">No content available for this page.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}