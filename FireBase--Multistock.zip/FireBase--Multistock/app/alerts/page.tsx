"use client"

import { GlobalAlerts } from "@/components/global-alerts"
import { AuthGuard } from "@/components/auth-guard"

export default function AlertsPage() {
  return (
    <AuthGuard roles={["employee", "team_leader", "manager", "subadmin", "admin"]}>
      <section className="space-y-4">
        <h1 className="text-xl font-semibold">Alerts & Notifications</h1>
        <GlobalAlerts />
        <div className="text-sm text-muted-foreground">Overdue rental alerts will appear on Rentals. Low-stock alerts are shown above.</div>
      </section>
    </AuthGuard>
  )
}


