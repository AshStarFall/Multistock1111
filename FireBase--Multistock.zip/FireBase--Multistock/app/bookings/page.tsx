"use client"

import { listBookings } from "@/lib/bookings"
import { AuthGuard } from "@/components/auth-guard"

export default function BookingsPage() {
  const rows = listBookings()
  return (
    <AuthGuard roles={["customer", "employee", "manager", "subadmin", "admin"]}>
      <section className="space-y-4">
        <h1 className="text-xl font-semibold">My Bookings</h1>
        <div className="overflow-auto rounded-md border">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left p-2">Type</th>
                <th className="text-left p-2">Title</th>
                <th className="text-left p-2">From</th>
                <th className="text-left p-2">To</th>
                <th className="text-left p-2">Created</th>
                <th className="text-left p-2">Subtotal</th>
                <th className="text-left p-2">Discount</th>
                <th className="text-left p-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="p-2">{r.type}</td>
                  <td className="p-2">{r.title}</td>
                  <td className="p-2">{r.startDate}</td>
                  <td className="p-2">{r.endDate}</td>
                  <td className="p-2">{new Date(r.createdAt).toLocaleString()}</td>
                  <td className="p-2">{r.subtotal ?? 0}</td>
                  <td className="p-2">{r.discount ?? 0}</td>
                  <td className="p-2">{r.total ?? 0}</td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td className="p-3 text-muted-foreground" colSpan={5}>No bookings yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </AuthGuard>
  )
}


