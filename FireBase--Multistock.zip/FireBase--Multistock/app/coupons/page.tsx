'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CouponCard } from '@/components/coupons/coupon-card';
import { CouponApply } from '@/components/coupons/coupon-apply';
import { Coupon, getAvailableCoupons } from '@/lib/coupons';
import { Tag, Search, Sparkles, TrendingUp, Clock, Gift } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [orderAmount, setOrderAmount] = useState(1000);

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/coupons');
      const data = await response.json();
      setCoupons(data);
    } catch (error) {
      console.error('Error fetching coupons:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCoupons = coupons.filter(
    (coupon) =>
      coupon.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coupon.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coupon.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const availableCoupons = getAvailableCoupons(filteredCoupons, orderAmount);
  const expiringSoon = availableCoupons.filter(
    (c) =>
      (new Date(c.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24) <= 3
  );
  const topCoupons = availableCoupons.filter((c) => c.isPublic).slice(0, 10);

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Tag className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-bold">Discount Coupons</h1>
        </div>
        <p className="text-muted-foreground">
          Save more with exclusive discount codes and offers
        </p>
      </div>

      {/* Test Coupon Application */}
      <div className="mb-6">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Test Coupon Application</h2>
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">
                Order Amount
              </label>
              <Input
                type="number"
                value={orderAmount}
                onChange={(e) => setOrderAmount(Number(e.target.value))}
                placeholder="Enter order amount"
              />
            </div>
          </div>
          <CouponApply orderAmount={orderAmount} />
        </Card>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search coupons..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">
            All ({filteredCoupons.length})
          </TabsTrigger>
          <TabsTrigger value="top">
            <Sparkles className="w-4 h-4 mr-2" />
            Top Deals
          </TabsTrigger>
          <TabsTrigger value="expiring">
            <Clock className="w-4 h-4 mr-2" />
            Expiring Soon
          </TabsTrigger>
          <TabsTrigger value="my-coupons">
            <Gift className="w-4 h-4 mr-2" />
            My Coupons
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-muted-foreground">Loading coupons...</p>
            </div>
          ) : filteredCoupons.length === 0 ? (
            <Card className="p-12 text-center">
              <Tag className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Coupons Found</h3>
              <p className="text-muted-foreground">
                Check back later for new discount offers
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCoupons.map((coupon) => (
                <CouponCard key={coupon.id} coupon={coupon} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="top">
          {topCoupons.length === 0 ? (
            <Card className="p-12 text-center">
              <Sparkles className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Top Deals</h3>
              <p className="text-muted-foreground">
                Stay tuned for amazing deals coming soon
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {topCoupons.map((coupon) => (
                <CouponCard key={coupon.id} coupon={coupon} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="expiring">
          {expiringSoon.length === 0 ? (
            <Card className="p-12 text-center">
              <Clock className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Expiring Coupons</h3>
              <p className="text-muted-foreground">
                All coupons are valid for more than 3 days
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {expiringSoon.map((coupon) => (
                <CouponCard key={coupon.id} coupon={coupon} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="my-coupons">
          <Card className="p-12 text-center">
            <Gift className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">My Coupons</h3>
            <p className="text-muted-foreground">
              Your earned and saved coupons will appear here
            </p>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
