"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/lib/auth-context"
import { toast } from "sonner"
import { 
  Search, 
  Filter, 
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Star,
  Truck,
  Package,
  Shield,
  CreditCard,
  CheckCircle,
  AlertCircle,
  Plus,
  Minus,
  Eye,
  CalendarDays,
  Phone,
  Mail,
  Grid3x3,
  List,
  SlidersHorizontal,
  TrendingUp,
  Heart,
  Share2,
  X,
  ChevronLeft,
  ChevronRight,
  Verified,
  ThumbsUp,
  ShoppingCart,
  Users
} from "lucide-react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { Breadcrumbs } from "@/components/breadcrumbs"

interface RentalItem {
  id: string
  name: string
  description: string
  category: string
  dailyRate: number
  weeklyRate: number
  monthlyRate: number
  image: string
  rating: number
  reviews: number
  available: boolean
  location: string
  features: string[]
  specifications: Record<string, string>
  provider: {
    name: string
    rating: number
    location: string
    phone: string
    email: string
  }
}

export default function RentalsPage() {
  const { user, isAuthenticated, isGuest } = useAuth()
  const [rentalItems, setRentalItems] = useState<RentalItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedItem, setSelectedItem] = useState<RentalItem | null>(null)
  const [rentalPeriod, setRentalPeriod] = useState("daily")
  const [startDate, setStartDate] = useState<Date | undefined>(new Date())
  const [endDate, setEndDate] = useState<Date | undefined>(new Date())
  const [quantity, setQuantity] = useState(1)
  
  // New E-commerce features
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [sortBy, setSortBy] = useState("popularity")
  const [priceRange, setPriceRange] = useState([0, 5000])
  const [minRating, setMinRating] = useState(0)
  const [showFilters, setShowFilters] = useState(false)
  const [wishlist, setWishlist] = useState<string[]>([])
  const [compareList, setCompareList] = useState<string[]>([])
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  // Mock rental data
  const mockRentals: RentalItem[] = [
    {
      id: "1",
      name: "Professional Camera Kit",
      description: "Complete DSLR camera kit with lenses, tripod, and accessories for professional photography",
      category: "Photography",
      dailyRate: 50,
      weeklyRate: 300,
      monthlyRate: 1000,
      image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=500&h=500&fit=crop",
      rating: 4.9,
      reviews: 45,
      available: true,
      location: "Mumbai, Maharashtra",
      features: ["Professional Lens", "Tripod Included", "Memory Cards", "Carrying Case"],
      specifications: {
        "Camera": "Canon EOS R5",
        "Lens": "24-70mm f/2.8",
        "Tripod": "Carbon Fiber",
        "Memory": "64GB SD Card",
        "Weight": "2.5kg"
      },
      provider: {
        name: "ProPhoto Rentals",
        rating: 4.9,
        location: "Mumbai, Maharashtra",
        phone: "+91 98765 43210",
        email: "contact@prophoto.com"
      }
    },
    {
      id: "2",
      name: "Gaming Laptop Setup",
      description: "High-performance gaming laptop with gaming mouse, keyboard, and headset",
      category: "Electronics",
      dailyRate: 75,
      weeklyRate: 450,
      monthlyRate: 1500,
      image: "https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=500&h=500&fit=crop",
      rating: 4.8,
      reviews: 32,
      available: true,
      location: "Bangalore, Karnataka",
      features: ["Gaming Mouse", "Mechanical Keyboard", "Gaming Headset", "Cooling Pad"],
      specifications: {
        "Laptop": "ASUS ROG Strix",
        "Graphics": "RTX 3070",
        "RAM": "16GB DDR4",
        "Storage": "1TB SSD",
        "Display": "15.6 inch 144Hz"
      },
      provider: {
        name: "GameTech Rentals",
        rating: 4.8,
        location: "Bangalore, Karnataka",
        phone: "+91 87654 32109",
        email: "rentals@gametech.com"
      }
    },
    {
      id: "3",
      name: "Audio Equipment Package",
      description: "Professional audio equipment including microphones, mixer, and speakers",
      category: "Audio",
      dailyRate: 100,
      weeklyRate: 600,
      monthlyRate: 2000,
      image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=500&h=500&fit=crop",
      rating: 4.7,
      reviews: 28,
      available: true,
      location: "Delhi, NCR",
      features: ["Wireless Microphones", "Audio Mixer", "Speakers", "Cables & Stands"],
      specifications: {
        "Microphones": "Wireless Shure",
        "Mixer": "16 Channel",
        "Speakers": "1000W Active",
        "Range": "100m Wireless",
        "Weight": "15kg"
      },
      provider: {
        name: "AudioPro Rentals",
        rating: 4.7,
        location: "Delhi, NCR",
        phone: "+91 76543 21098",
        email: "info@audiopro.com"
      }
    },
    {
      id: "4",
      name: "Construction Tools Set",
      description: "Complete set of construction tools including power tools, hand tools, and safety equipment",
      category: "Tools",
      dailyRate: 80,
      weeklyRate: 480,
      monthlyRate: 1600,
      image: "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=500&h=500&fit=crop",
      rating: 4.6,
      reviews: 41,
      available: true,
      location: "Chennai, Tamil Nadu",
      features: ["Power Drill", "Circular Saw", "Safety Gear", "Tool Box"],
      specifications: {
        "Drill": "18V Cordless",
        "Saw": "7.25 inch Blade",
        "Safety": "Hard Hat & Gloves",
        "Tools": "50+ Pieces",
        "Weight": "25kg"
      },
      provider: {
        name: "ToolMaster Rentals",
        rating: 4.6,
        location: "Chennai, Tamil Nadu",
        phone: "+91 65432 10987",
        email: "rentals@toolmaster.com"
      }
    }
  ]

  useEffect(() => {
    setRentalItems(mockRentals)
  }, [])

  // Enhanced filtering with price range and rating
  const filteredItems = rentalItems.filter(item => {
    const matchesSearch = searchQuery === "" || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory
    
    const matchesPrice = item.dailyRate >= priceRange[0] && item.dailyRate <= priceRange[1]
    
    const matchesRating = item.rating >= minRating
    
    return matchesSearch && matchesCategory && item.available && matchesPrice && matchesRating
  })

  // Sorting logic
  const sortedItems = [...filteredItems].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.dailyRate - b.dailyRate
      case "price-high":
        return b.dailyRate - a.dailyRate
      case "rating":
        return b.rating - a.rating
      case "reviews":
        return b.reviews - a.reviews
      case "name":
        return a.name.localeCompare(b.name)
      default: // popularity
        return (b.rating * b.reviews) - (a.rating * a.reviews)
    }
  })

  // Wishlist functions
  const toggleWishlist = (itemId: string) => {
    setWishlist(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    )
    toast.success(wishlist.includes(itemId) ? "Removed from wishlist" : "Added to wishlist")
  }

  // Compare function
  const toggleCompare = (itemId: string) => {
    if (compareList.includes(itemId)) {
      setCompareList(prev => prev.filter(id => id !== itemId))
      toast.success("Removed from comparison")
    } else if (compareList.length < 3) {
      setCompareList(prev => [...prev, itemId])
      toast.success("Added to comparison")
    } else {
      toast.error("You can only compare up to 3 items")
    }
  }

  const calculateTotalCost = (item: RentalItem, period: string, days: number) => {
    let rate = 0
    switch (period) {
      case "daily":
        rate = item.dailyRate
        break
      case "weekly":
        rate = item.weeklyRate
        break
      case "monthly":
        rate = item.monthlyRate
        break
    }
    return rate * days * quantity
  }

  const handleRentalRequest = (item: RentalItem) => {
    if (!isAuthenticated && !isGuest) {
      toast.error("Please sign in to request rentals")
      return
    }
    
    const days = Math.ceil((endDate!.getTime() - startDate!.getTime()) / (1000 * 60 * 60 * 24)) + 1
    const totalCost = calculateTotalCost(item, rentalPeriod, days)
    
    toast.success(`Rental request submitted! Total cost: ₹${totalCost}`)
    setSelectedItem(null)
  }

  const getRentalPeriodDays = () => {
    if (!startDate || !endDate) return 1
    return Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
  }

  return (
    <div className="space-y-6 p-6">
      <Breadcrumbs />

      {/* Hero Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-600 p-8 md:p-12 text-white shadow-2xl"
      >
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full -ml-32 -mb-32 blur-3xl" />
        
        <div className="relative z-10">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Badge className="mb-4 bg-white/20 backdrop-blur-sm border-white/30 text-white">
                <Truck className="w-4 h-4 mr-1" />
                Rental Marketplace
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Rent Premium Equipment
              </h1>
              <p className="text-blue-100 text-lg mb-6">
                Access professional-grade tools and equipment on-demand. Save costs, increase flexibility, and scale your operations effortlessly.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button size="lg" className="bg-white text-indigo-600 hover:bg-white/90 font-semibold">
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Browse Catalog
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-2 border-white bg-white/10 text-white hover:bg-white hover:text-indigo-600 backdrop-blur-sm font-semibold transition-all"
                >
                  <Package className="w-5 h-5 mr-2" />
                  How It Works
                </Button>
              </div>
            </div>
            <div className="hidden md:grid grid-cols-2 gap-4">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <Shield className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">100%</span>
                  </div>
                  <p className="text-sm text-blue-100">Insured Equipment</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <Users className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">5K+</span>
                  </div>
                  <p className="text-sm text-blue-100">Happy Customers</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <Star className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">4.9</span>
                  </div>
                  <p className="text-sm text-blue-100">Average Rating</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <TrendingUp className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">500+</span>
                  </div>
                  <p className="text-sm text-blue-100">Equipment Types</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div>
          <h2 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            Available Equipment
          </h2>
          <p className="text-muted-foreground mt-1">
            Browse our complete rental catalog
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="outline" className="flex items-center gap-1 hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors">
            <Shield className="w-4 h-4 text-green-600" />
            <span>Insured Equipment</span>
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
            <Truck className="w-4 h-4 text-blue-600" />
            <span>Free Delivery</span>
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors">
            <Clock className="w-4 h-4 text-purple-600" />
            <span>Flexible Duration</span>
          </Badge>
        </div>
      </motion.div>

      {/* Modern Search Bar with Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-4 border"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                placeholder="Search for equipment, cameras, laptops..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 text-base"
              />
            </div>
          </div>

          {/* Category */}
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full lg:w-48 h-12">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="Photography">📷 Photography</SelectItem>
              <SelectItem value="Electronics">💻 Electronics</SelectItem>
              <SelectItem value="Audio">🎵 Audio</SelectItem>
              <SelectItem value="Tools">🔧 Tools</SelectItem>
            </SelectContent>
          </Select>

          {/* Filters Button */}
          <Button
            variant={showFilters ? "default" : "outline"}
            onClick={() => setShowFilters(!showFilters)}
            className="h-12 px-6"
          >
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Filters
            {(minRating > 0 || priceRange[0] > 0 || priceRange[1] < 5000) && (
              <Badge className="ml-2 bg-white text-primary" variant="secondary">
                {(minRating > 0 ? 1 : 0) + (priceRange[0] > 0 || priceRange[1] < 5000 ? 1 : 0)}
              </Badge>
            )}
          </Button>
        </div>

        {/* Advanced Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <Separator className="my-4" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Price Range */}
                <div className="space-y-3">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    Price Range (Daily Rate)
                  </label>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    max={5000}
                    step={50}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>₹{priceRange[0]}</span>
                    <span>₹{priceRange[1]}</span>
                  </div>
                </div>

                {/* Rating Filter */}
                <div className="space-y-3">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    Minimum Rating
                  </label>
                  <div className="flex gap-2">
                    {[0, 3, 4, 4.5].map((rating) => (
                      <Button
                        key={rating}
                        variant={minRating === rating ? "default" : "outline"}
                        size="sm"
                        onClick={() => setMinRating(rating)}
                        className="flex-1"
                      >
                        {rating === 0 ? "All" : (
                          <>
                            {rating}
                            <Star className="w-3 h-3 ml-1 fill-current" />
                          </>
                        )}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Clear Filters */}
                <div className="flex items-end">
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setPriceRange([0, 5000])
                      setMinRating(0)
                      toast.success("Filters cleared")
                    }}
                    className="w-full"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Clear All Filters
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Toolbar: Results, Sort, View Mode */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg"
      >
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{sortedItems.length}</span> of{" "}
            <span className="font-semibold text-foreground">{rentalItems.length}</span> items
          </p>
          {compareList.length > 0 && (
            <Badge variant="secondary" className="ml-2">
              {compareList.length} items to compare
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Sort */}
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <TrendingUp className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="popularity">Popularity</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="reviews">Most Reviewed</SelectItem>
              <SelectItem value="name">Name (A-Z)</SelectItem>
            </SelectContent>
          </Select>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 bg-white dark:bg-slate-800 rounded-lg p-1 border">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="px-3"
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="px-3"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Products Grid/List */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className={viewMode === "grid" 
          ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          : "flex flex-col gap-4"
        }
      >
        {sortedItems.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05, duration: 0.3 }}
            layout
          >
          <Card className={`overflow-hidden hover:shadow-2xl transition-all duration-300 border-2 hover:border-primary/50 group ${
            viewMode === "list" ? "flex flex-row" : ""
          }`}>
            {/* Image Section */}
            <div className={`relative bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 ${
              viewMode === "grid" ? "aspect-square" : "w-64 h-64"
            }`}>
              {item.image ? (
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none'
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="w-16 h-16 text-muted-foreground" />
                </div>
              )}
              
              {/* Badges */}
              <div className="absolute top-2 left-2 flex flex-col gap-1">
                <Badge className="bg-green-500 hover:bg-green-600 shadow-lg">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Available
                </Badge>
                {item.rating >= 4.5 && (
                  <Badge className="bg-orange-500 hover:bg-orange-600 shadow-lg">
                    <Verified className="w-3 h-3 mr-1" />
                    Top Rated
                  </Badge>
                )}
              </div>

              {/* Action Buttons */}
              <div className="absolute top-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  size="icon"
                  variant="secondary"
                  className="h-9 w-9 rounded-full shadow-lg backdrop-blur-sm bg-white/90 hover:bg-white"
                  onClick={() => toggleWishlist(item.id)}
                >
                  <Heart className={`w-4 h-4 ${wishlist.includes(item.id) ? "fill-red-500 text-red-500" : ""}`} />
                </Button>
                <Button
                  size="icon"
                  variant="secondary"
                  className="h-9 w-9 rounded-full shadow-lg backdrop-blur-sm bg-white/90 hover:bg-white"
                  onClick={() => toggleCompare(item.id)}
                >
                  <Eye className={`w-4 h-4 ${compareList.includes(item.id) ? "text-primary" : ""}`} />
                </Button>
              </div>

              {/* Quick View */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="lg" className="shadow-xl" onClick={() => setSelectedItem(item)}>
                      <Eye className="w-5 h-5 mr-2" />
                      Quick View
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    {/* Dialog content will be added below */}
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Content Section */}
            <CardContent className={`p-4 ${viewMode === "list" ? "flex-1" : ""}`}>
              <div className="space-y-3">
                {/* Rating & Reviews */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(item.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                    <span className="text-sm font-medium ml-1">{item.rating}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    ({item.reviews} reviews)
                  </span>
                </div>

                {/* Title */}
                <h3 className="font-semibold text-lg leading-tight line-clamp-2 group-hover:text-primary transition-colors">
                  {item.name}
                </h3>

                {/* Category & Location */}
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Package className="w-3 h-3" />
                    {item.category}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {item.location.split(',')[0]}
                  </span>
                </div>

                {/* Description (list view only) */}
                {viewMode === "list" && (
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {item.description}
                  </p>
                )}

                {/* Features (list view only) */}
                {viewMode === "list" && (
                  <div className="flex flex-wrap gap-1">
                    {item.features.slice(0, 3).map((feature, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                )}

                <Separator />

                {/* Pricing */}
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-primary">
                      ₹{item.dailyRate}
                    </span>
                    <span className="text-sm text-muted-foreground">/day</span>
                  </div>
                  <div className="flex gap-3 text-xs text-muted-foreground">
                    <span>₹{item.weeklyRate}/week</span>
                    <span>•</span>
                    <span>₹{item.monthlyRate}/month</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="flex-1" size="lg" onClick={() => setSelectedItem(item)}>
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        Book Now
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl">
                      {/* Booking dialog will be added */}
                    </DialogContent>
                  </Dialog>
                  <Button variant="outline" size="lg" onClick={() => toggleCompare(item.id)}>
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Empty State */}
      {sortedItems.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No items found</h3>
          <p className="text-muted-foreground mb-6">
            Try adjusting your filters or search query
          </p>
          <Button
            onClick={() => {
              setSearchQuery("")
              setSelectedCategory("all")
              setPriceRange([0, 5000])
              setMinRating(0)
            }}
          >
            Clear All Filters
          </Button>
        </motion.div>
      )}

      {/* Rental Benefits */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8"
      >
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="font-semibold mb-2">Insured Equipment</h3>
            <p className="text-sm text-muted-foreground">All equipment is fully insured for your peace of mind</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
              <Truck className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="font-semibold mb-2">Free Delivery</h3>
            <p className="text-sm text-muted-foreground">Free pickup and delivery within city limits</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="font-semibold mb-2">24/7 Support</h3>
            <p className="text-sm text-muted-foreground">Round-the-clock customer support for all rentals</p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}