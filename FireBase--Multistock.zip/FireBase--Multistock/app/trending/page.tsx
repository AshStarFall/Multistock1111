'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingProductCard } from '@/components/trending/trending-product-card';
import { TrendingCarousel } from '@/components/trending/trending-carousel';
import { AnnouncementBanner } from '@/components/trending/announcement-banner';
import {
  TrendingProduct,
  Announcement,
  FilterOptions,
  filterTrendingProducts,
  getActiveAnnouncements,
  getTrendingCategories,
} from '@/lib/trending';
import {
  Search,
  TrendingUp,
  Flame,
  Filter,
  SlidersHorizontal,
  Sparkles,
  Tag,
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function TrendingPage() {
  const [products, setProducts] = useState<TrendingProduct[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterOptions>({
    sortBy: 'trending',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch trending products
      const productsRes = await fetch('/api/trending/products');
      const productsData = await productsRes.json();
      setProducts(productsData);

      // Fetch announcements
      const announcementsRes = await fetch('/api/trending/announcements');
      const announcementsData = await announcementsRes.json();
      setAnnouncements(getActiveAnnouncements(announcementsData));
    } catch (error) {
      console.error('Error fetching trending data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter products
  const filteredProducts = filterTrendingProducts(products, filters).filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const topTrendingProducts = filteredProducts.slice(0, 5);
  const hotDeals = filteredProducts.filter((p) => p.isHotDeal);
  const categories = getTrendingCategories(products);

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <TrendingUp className="w-8 h-8 text-purple-600" />
          <h1 className="text-4xl font-bold">Trending Sales</h1>
        </div>
        <p className="text-muted-foreground">
          Discover the hottest deals and most popular products right now
        </p>
      </div>

      {/* Announcements */}
      {announcements.length > 0 && (
        <div className="mb-6">
          <AnnouncementBanner announcements={announcements} />
        </div>
      )}

      {/* Top Trending Carousel */}
      {topTrendingProducts.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <h2 className="text-2xl font-bold">Top Trending Now</h2>
          </div>
          <TrendingCarousel products={topTrendingProducts} />
        </div>
      )}

      {/* Categories Overview */}
      {categories.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Trending Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {categories.map((cat) => (
              <Card
                key={cat.category}
                className="p-4 text-center hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() =>
                  setFilters({
                    ...filters,
                    category: filters.category === cat.category ? undefined : cat.category,
                  })
                }
              >
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Tag className="w-4 h-4 text-primary" />
                  <h3 className="font-semibold">{cat.category}</h3>
                </div>
                <p className="text-sm text-muted-foreground">{cat.count} products</p>
                {cat.avgDiscount > 0 && (
                  <Badge className="mt-2 bg-green-600 text-white">
                    {cat.avgDiscount}% avg off
                  </Badge>
                )}
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Search and Filters */}
      <div className="mb-6 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search trending products..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Select
          value={filters.sortBy || 'trending'}
          onValueChange={(value) =>
            setFilters({ ...filters, sortBy: value as FilterOptions['sortBy'] })
          }
        >
          <SelectTrigger className="w-full md:w-48">
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="trending">Trending Score</SelectItem>
            <SelectItem value="sales">Most Sales</SelectItem>
            <SelectItem value="discount">Highest Discount</SelectItem>
            <SelectItem value="price-low">Price: Low to High</SelectItem>
            <SelectItem value="price-high">Price: High to Low</SelectItem>
            <SelectItem value="newest">Newest First</SelectItem>
          </SelectContent>
        </Select>

        <Button
          variant={filters.onlyHotDeals ? 'default' : 'outline'}
          onClick={() =>
            setFilters({ ...filters, onlyHotDeals: !filters.onlyHotDeals })
          }
        >
          <Flame className="w-4 h-4 mr-2" />
          Hot Deals Only
        </Button>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">
            All Products ({filteredProducts.length})
          </TabsTrigger>
          <TabsTrigger value="hot-deals">
            <Flame className="w-4 h-4 mr-2" />
            Hot Deals ({hotDeals.length})
          </TabsTrigger>
          <TabsTrigger value="high-discount">High Discount</TabsTrigger>
          <TabsTrigger value="best-rated">Best Rated</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-muted-foreground">Loading trending products...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <Card className="p-12 text-center">
              <TrendingUp className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No trending products found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filters
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <TrendingProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="hot-deals">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {hotDeals.map((product) => (
              <TrendingProductCard key={product.id} product={product} />
            ))}
          </div>
          {hotDeals.length === 0 && (
            <Card className="p-12 text-center">
              <Flame className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No hot deals available</h3>
              <p className="text-muted-foreground">Check back soon for amazing deals!</p>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="high-discount">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts
              .filter((p) => (p.discount || 0) >= 30)
              .map((product) => (
                <TrendingProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="best-rated">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts
              .filter((p) => p.rating >= 4.5 && p.reviews >= 10)
              .map((product) => (
                <TrendingProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
