"use client"

import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { warehouses as seedWarehouses } from "@/lib/mock-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import { 
  Plus, 
  Search, 
  MapPin, 
  Package, 
  TrendingUp, 
  Warehouse,
  Users,
  Clock,
  CheckCircle,
  AlertTriangle,
  BarChart3,
  Navigation,
  Grid3x3,
  List
} from "lucide-react"
import { AddWarehouseDialog, type WarehouseRow } from "@/components/dialogs/add-warehouse-dialog"
import { load, save } from "@/lib/storage"

const KEY = "warehouses"

export default function WarehousesPage() {
  const router = useRouter()
  const initial = load<WarehouseRow[]>(KEY, seedWarehouses as unknown as WarehouseRow[])
  const [rows, setRows] = useState<WarehouseRow[]>(initial)
  const [q, setQ] = useState("")
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const filtered = useMemo(() => {
    const term = q.toLowerCase()
    return rows.filter(
      (w) =>
        w.name.toLowerCase().includes(term) ||
        w.code.toLowerCase().includes(term) ||
        (w.address?.toLowerCase().includes(term) ?? false),
    )
  }, [q, rows])

  function handleAdded(row: WarehouseRow) {
    const next = [row, ...rows]
    setRows(next)
    save(KEY, next)
  }

  // Stats
  const stats = {
    total: rows.length,
    active: Math.floor(rows.length * 0.9),
    capacity: rows.length * 1500,
    utilization: 78
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl space-y-6">
      {/* Hero Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-8 md:p-12 text-white shadow-2xl"
      >
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full -ml-32 -mb-32 blur-3xl" />
        
        <div className="relative z-10">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Badge className="mb-4 bg-white/20 backdrop-blur-sm border-white/30 text-white">
                <Warehouse className="w-4 h-4 mr-1" />
                Warehouse Network
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Multi-Location Warehouses
              </h1>
              <p className="text-emerald-100 text-lg mb-6">
                Manage your warehouse network across India. Real-time inventory tracking, capacity planning, and logistics optimization.
              </p>
              <div className="flex flex-wrap gap-3">
                <AddWarehouseDialog
                  onAdded={handleAdded}
                  trigger={
                    <Button size="lg" className="bg-white text-emerald-600 hover:bg-white/90">
                      <Plus className="w-5 h-5 mr-2" />
                      Add Warehouse
                    </Button>
                  }
                />
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-2 border-white bg-white/10 text-white hover:bg-white hover:text-blue-600 backdrop-blur-sm font-semibold transition-all"
                >
                  <Navigation className="w-5 h-5 mr-2" />
                  View Map
                </Button>
              </div>
            </div>
            <div className="hidden md:grid grid-cols-2 gap-4">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <Warehouse className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">{stats.total}</span>
                  </div>
                  <p className="text-sm text-emerald-100">Total Warehouses</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <CheckCircle className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">{stats.active}</span>
                  </div>
                  <p className="text-sm text-emerald-100">Active Locations</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <Package className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">{stats.capacity.toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-emerald-100">Total Capacity (sq ft)</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-white/20 rounded-lg">
                      <TrendingUp className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-bold">{stats.utilization}%</span>
                  </div>
                  <p className="text-sm text-emerald-100">Avg Utilization</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Search and Controls */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input 
                placeholder="Search warehouses by name, code, or location..." 
                value={q} 
                onChange={(e) => setQ(e.target.value)}
                className="pl-12 h-12 text-base"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('grid')}
              >
                <Grid3x3 className="w-5 h-5" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('list')}
              >
                <List className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Warehouses Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((w, index) => (
            <motion.div
              key={w.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl">
                        <Warehouse className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{w.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{w.code}</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-700 border-0">
                      Active
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-muted-foreground">{w.address || "No address provided"}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3 pt-3 border-t">
                      <div>
                        <p className="text-xs text-muted-foreground">Capacity</p>
                        <p className="text-sm font-semibold">1,500 sq ft</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Items</p>
                        <p className="text-sm font-semibold">{Math.floor(Math.random() * 500 + 100)}</p>
                      </div>
                    </div>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => router.push(`/warehouses/${w.id}`)}
                    >
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <Card className="border-0 shadow-lg">
          <CardContent className="p-0">
            <div className="overflow-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800">
                  <tr>
                    <th className="text-left p-4 font-semibold">Code</th>
                    <th className="text-left p-4 font-semibold">Name</th>
                    <th className="text-left p-4 font-semibold">Address</th>
                    <th className="text-left p-4 font-semibold">Status</th>
                    <th className="text-left p-4 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((w) => (
                    <tr key={w.id} className="border-t hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-4">
                        <Badge variant="outline">{w.code}</Badge>
                      </td>
                      <td className="p-4 font-medium">{w.name}</td>
                      <td className="p-4 text-muted-foreground">{w.address || "-"}</td>
                      <td className="p-4">
                        <Badge className="bg-green-100 text-green-700 border-0">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Active
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Button size="sm" variant="ghost">View</Button>
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td className="p-8 text-center text-muted-foreground" colSpan={5}>
                        <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p className="font-medium">No warehouses found</p>
                        <p className="text-sm">Add a warehouse to get started</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
