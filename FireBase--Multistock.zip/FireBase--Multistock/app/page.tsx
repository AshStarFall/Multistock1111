'use client'

import { useEffect, useLayoutEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'

export default function HomePage() {
  const router = useRouter()
  const { user, isAuthenticated, loading } = useAuth()

  // Use useLayoutEffect for faster redirect before render
  useLayoutEffect(() => {
    if (!loading) {
      if (isAuthenticated && user) {
        // Faster redirect logic - use switch with immediate navigation
        const destination = (() => {
          switch (user.role) {
            case 'SuperAdmin':
            case 'Admin':
              return '/admin'
            case 'SubAdmin':
            case 'SeniorStaff':
            case 'Staff':
              return '/dashboard'
            case 'Customer':
              return '/marketplace'
            default:
              return '/dashboard'
          }
        })()
        
        // Use replace for faster navigation without history entry
        router.replace(destination)
      } else {
        router.replace('/auth/login')
      }
    }
  }, [isAuthenticated, user, loading, router])

  // Minimal loading state - avoid heavy animations for faster perceived performance
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-2 text-xs text-muted-foreground">Loading...</p>
      </div>
    </div>
  )
}
