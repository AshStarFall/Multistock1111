"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { useAuth } from "@/lib/auth-context"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { FeaturedCarousel } from "@/components/featured-carousel"
import { DashboardCharts } from "@/components/dashboard-charts"
import { Warehouse3D } from "@/components/warehouse-3d"
import { PlatformFeatures } from "@/components/platform-features"
import Link from "next/link"
import { 
  TrendingUp, 
  TrendingDown, 
  Package, 
  Truck, 
  AlertTriangle, 
  CheckCircle,
  Users,
  DollarSign,
  Activity,
  ArrowUp,
  ArrowDown,
  ShoppingCart,
  Warehouse,
  BarChart3,
  Star,
  Shield,
  Zap,
  Target,
  Award,
  RefreshCw,
  Clock,
  TrendingUpIcon
} from "lucide-react"
import { LanguageSwitcher } from "@/components/language-switcher"
import { AnnouncementBanner } from "@/components/trending/announcement-banner"
import { PlatformGuide } from "@/components/platform-guide"
import { DevTeam } from "@/components/dev-team"
import { cn } from "@/lib/utils"

export default function DashboardPage() {
  const { user, isAuthenticated, getRole } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalProducts: 0,
    lowStock: 0,
    outOfStock: 0,
    totalValue: 0,
    totalUsers: 0
  })

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !loading) {
      router.push('/')
    }
  }, [isAuthenticated, loading, router])

  // Load dashboard stats
  useEffect(() => {
    loadDashboardStats()
  }, [])

  const loadDashboardStats = async () => {
    try {
      setLoading(true)
      
      // Get products stats
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('*')

      if (productsError) throw productsError

      const totalProducts = products?.length || 0
      const lowStock = products?.filter(p => p.stock_quantity <= p.reorder_point && p.stock_quantity > 0).length || 0
      const outOfStock = products?.filter(p => p.stock_quantity === 0).length || 0
      const totalValue = products?.reduce((sum, p) => sum + (p.stock_quantity * p.price), 0) || 0

      // Get users count (only for admins)
      let totalUsers = 0
      if (getRole() === 'Admin') {
        const { count, error: usersError } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
        
        if (!usersError) totalUsers = count || 0
      }

      setStats({
        totalProducts,
        lowStock,
        outOfStock,
        totalValue,
        totalUsers
      })
    } catch (error) {
      console.error('Error loading dashboard stats:', error)
    } finally {
      setLoading(false)
    }
  }

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-lg font-semibold text-slate-700 dark:text-slate-300">Loading Dashboard...</p>
        </div>
      </div>
    )
  }

  // Show login prompt if not authenticated
  if (!isAuthenticated) {
    return null
  }

  // Format currency
  const formatCurrency = (value: number) => {
    if (value >= 10000000) return `₹${(value / 10000000).toFixed(1)}Cr`
    if (value >= 100000) return `₹${(value / 100000).toFixed(1)}L`
    if (value >= 1000) return `₹${(value / 1000).toFixed(1)}K`
    return `₹${value.toFixed(0)}`
  }

  // Modern KPI metrics with real data
  const kpis = [
    {
      title: "Total Products",
      value: stats.totalProducts.toString(),
      change: "+12.5%",
      trend: "up",
      icon: Package,
      gradient: "from-emerald-500 to-teal-600",
      iconBg: "bg-emerald-100 dark:bg-emerald-900/30",
      iconColor: "text-emerald-600 dark:text-emerald-400",
      tooltip: "Total number of products in your inventory across all warehouses"
    },
    {
      title: "Low Stock Items",
      value: stats.lowStock.toString(),
      change: stats.lowStock > 0 ? "Needs Attention" : "All Good",
      trend: stats.lowStock > 0 ? "down" : "up",
      icon: AlertTriangle,
      gradient: "from-amber-500 to-orange-600",
      iconBg: "bg-amber-100 dark:bg-amber-900/30",
      iconColor: "text-amber-600 dark:text-amber-400",
      tooltip: "Products that have reached or fallen below their reorder point"
    },
    {
      title: "Inventory Value",
      value: formatCurrency(stats.totalValue),
      change: "+5.3%",
      trend: "up",
      icon: DollarSign,
      gradient: "from-violet-500 to-purple-600",
      iconBg: "bg-violet-100 dark:bg-violet-900/30",
      iconColor: "text-violet-600 dark:text-violet-400",
      tooltip: "Total monetary value of all inventory items (quantity × price)"
    },
    {
      title: "Out of Stock",
      value: stats.outOfStock.toString(),
      change: stats.outOfStock > 0 ? "Critical" : "All Good",
      trend: stats.outOfStock > 0 ? "down" : "up",
      icon: ShoppingCart,
      gradient: "from-red-500 to-red-600",
      iconBg: "bg-red-100 dark:bg-red-900/30",
      iconColor: "text-red-600 dark:text-red-400",
      tooltip: "Products with zero quantity - immediate restock required"
    }
  ]

  // Quick action cards
  const quickActions = [
    {
      title: "Create Order",
      description: "Place a new sales order",
      icon: ShoppingCart,
      href: "/sales-orders",
      color: "indigo"
    },
    {
      title: "Add Product",
      description: "Add new inventory item",
      icon: Package,
      href: "/admin/products",
      color: "violet"
    },
    {
      title: "View Reports",
      description: "Analytics & insights",
      icon: BarChart3,
      href: "/reports",
      color: "cyan"
    },
    {
      title: "Manage Users",
      description: "User access control",
      icon: Users,
      href: "/admin/role-access",
      color: "pink"
    }
  ]

  // Recent activity
  const recentActivity = [
    {
      action: "New order received",
      details: "Order #ORD-2024-1247",
      time: "2 minutes ago",
      type: "order",
      icon: ShoppingCart
    },
    {
      action: "Low stock alert",
      details: "Product: Laptop Pro 15",
      time: "15 minutes ago",
      type: "alert",
      icon: AlertTriangle
    },
    {
      action: "Shipment delivered",
      details: "Tracking #TRK-456789",
      time: "1 hour ago",
      type: "success",
      icon: CheckCircle
    },
    {
      action: "User registered",
      details: "john.doe@example.com",
      time: "2 hours ago",
      type: "info",
      icon: Users
    }
  ]

  const getWelcomeMessage = () => {
    if (!user) return "Welcome Back"
    
    const timeOfDay = new Date().getHours()
    const greeting = timeOfDay < 12 ? "Good Morning" : timeOfDay < 18 ? "Good Afternoon" : "Good Evening"
    
    return `${greeting}, ${user.name || user.email?.split('@')[0] || 'User'}!`
  }

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'order': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/30'
      case 'alert': return 'text-amber-600 bg-amber-100 dark:bg-amber-900/30'
      case 'success': return 'text-emerald-600 bg-emerald-100 dark:bg-emerald-900/30'
      default: return 'text-violet-600 bg-violet-100 dark:bg-violet-900/30'
    }
  }

  return (
    <div className="space-y-6">
      {/* Announcements */}
      <AnnouncementBanner
        announcements={[
          {
            id: 'ann-001',
            title: 'System maintenance scheduled',
            message: 'Maintenance window on Sunday 2:00 AM – 3:00 AM IST. Expect brief downtime.',
            type: 'warning',
            priority: 'high',
            startDate: new Date().toISOString(),
            endDate: undefined,
            link: undefined,
            linkText: undefined,
            isActive: true,
            createdAt: new Date().toISOString(),
          },
          {
            id: 'ann-002',
            title: 'New analytics module',
            message: 'Explore enhanced sales performance insights in Analytics → Overview.',
            type: 'promotion',
            priority: 'medium',
            startDate: new Date().toISOString(),
            endDate: undefined,
            link: '/analytics',
            linkText: 'Open analytics',
            isActive: true,
            createdAt: new Date().toISOString(),
          }
        ]}
      />
      {/* Project Guide Section - Added at the top of the dashboard */}
      <div className="bg-[#0A1F44] text-white rounded-2xl p-8 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="flex flex-col items-center">
            <div className="relative mb-6">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-2xl mx-auto">
                <img
                  src="/profile-photos/NishmithaMam.jpeg"
                  alt="Ms. Nishmitha"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const parent = e.currentTarget.parentElement;
                    if (parent) {
                      parent.innerHTML = '<div class="w-full h-full flex items-center justify-center bg-blue-700 text-white text-2xl font-bold">MN</div>';
                    }
                  }}
                />
              </div>
            </div>

            <div className="mt-6">
              <h4 className="text-2xl font-bold mb-2">Ms. Nishmitha</h4>
              <p className="text-lg font-medium mb-1">Project Guide</p>
              <Badge className="bg-blue-600 text-white mb-3 px-3 py-1 text-sm shadow-lg">
                Department Guide
              </Badge>
              <p className="text-base opacity-90">Computer Science & Engineering</p>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Header with Gradient */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-purple-600 p-8 text-white shadow-xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/10 rounded-full -ml-48 -mb-48 blur-3xl" />
          
          <div className="relative z-10">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold mb-2">{getWelcomeMessage()}</h1>
                <p className="text-indigo-100 text-lg">
                  Here's what's happening with your business today
                </p>
              </div>
              <div className="hidden md:flex items-center space-x-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                <button
                  onClick={loadDashboardStats}
                  className="text-sm px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 rounded-lg transition-colors flex items-center gap-2"
                >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Reload dashboard data (Ctrl+R)</p>
                  </TooltipContent>
                </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
              <Badge variant="secondary" className="text-sm px-4 py-2 bg-white/20 backdrop-blur-sm border-white/30 cursor-help">
                <Shield className="w-4 h-4 mr-2" />
                {user?.role || getRole() || 'User'}
              </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Your current role and access level</p>
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
              <Badge variant="secondary" className="text-sm px-4 py-2 bg-white/20 backdrop-blur-sm border-white/30 cursor-help">
                <Zap className="w-4 h-4 mr-2" />
                Live
              </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Real-time data updates enabled</p>
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="ml-2"><LanguageSwitcher /></div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Change language</p>
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="secondary" className="text-sm px-4 py-2 bg-white/20 backdrop-blur-sm border-white/30 cursor-help">
                    Ctrl+K Search
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Open command palette (Ctrl+K)</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
        {kpis.map((kpi, index) => (
          <div key={index}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Card className={cn(
                  "relative overflow-hidden border-0 shadow-lg transition-all duration-300 group cursor-help",
                  "bg-gradient-to-br",
                  kpi.trend === 'up' ? 'from-emerald-50 to-teal-100 dark:from-emerald-900/20 dark:to-teal-900/20' : 'from-red-50 to-orange-100 dark:from-red-900/20 dark:to-orange-900/20',
                  "hover:scale-[1.03] hover:shadow-2xl"
                )}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`${kpi.iconBg} p-3 rounded-xl`}>
                        <kpi.icon className={`w-6 h-6 ${kpi.iconColor}`} />
                      </div>
                      <div className={`flex items-center space-x-1 text-sm font-semibold ${
                        kpi.trend === 'up' ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {kpi.trend === 'up' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
                        <span>{kpi.change}</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">{kpi.title}</p>
                      <p className="text-3xl font-bold text-foreground">{kpi.value}</p>
                    </div>
                    <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${kpi.gradient}`} />
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                <p>{kpi.tooltip}</p>
              </TooltipContent>
            </Tooltip>
          </div>
        ))}
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Quick Actions */}
        <div className="lg:col-span-2">
          <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center">
                <Zap className="w-6 h-6 mr-2 text-indigo-600" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {quickActions.map((action, index) => (
                  <div key={index}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Link href={action.href} aria-label={`${action.title} - ${action.description}`}>
                          <div className="group relative overflow-hidden p-6 rounded-xl border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 cursor-pointer bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:scale-[1.03] hover:shadow-xl">
                            <div className="flex items-start space-x-4">
                              <div className={`p-3 rounded-xl bg-gradient-to-br from-${action.color}-500 to-${action.color}-600 text-white shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                                <action.icon className="w-6 h-6" />
                              </div>
                              <div className="flex-1">
                                <h3 className="font-semibold text-lg mb-1 group-hover:text-indigo-600 transition-colors">
                                  {action.title}
                                </h3>
                                <p className="text-sm text-muted-foreground">{action.description}</p>
                              </div>
                            </div>
                          </div>
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{action.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="flex flex-col items-end">
          <Card className="border-0 shadow-lg bg-white dark:bg-slate-900 w-full max-w-xs">
            <CardHeader>
              <CardTitle className="text-xl font-bold flex items-center">
                <Activity className="w-5 h-5 mr-2 text-violet-600" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                    <div className={`p-2 rounded-lg ${getActivityColor(activity.type)}`}>
                      <activity.icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-foreground truncate">
                        {activity.action}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">
                        {activity.details}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4">
                View All Activity
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Performance Overview */}
      <div
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-cyan-600" />
              Sales Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Monthly Target</span>
                <span className="font-semibold">₹50M</span>
              </div>
              <Progress value={75} className="h-3" />
              <p className="text-xs text-muted-foreground mt-2">75% achieved - ₹37.5M completed</p>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Orders Processed</span>
                <span className="font-semibold">1,247 / 1,500</span>
              </div>
              <Progress value={83} className="h-3" />
              <p className="text-xs text-muted-foreground mt-2">83% of monthly goal</p>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Customer Satisfaction</span>
                <span className="font-semibold flex items-center">
                  <Star className="w-4 h-4 text-amber-500 mr-1 fill-amber-500" />
                  4.8 / 5.0
                </span>
              </div>
              <Progress value={96} className="h-3" />
              <p className="text-xs text-muted-foreground mt-2">Excellent rating from 1,234 reviews</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center">
              <Award className="w-5 h-5 mr-2 text-amber-600" />
              Top Performing Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Laptop Pro 15", sales: "₹2.4M", growth: "+15%", stock: 45 },
                { name: "Smartphone X", sales: "₹1.8M", growth: "+12%", stock: 120 },
                { name: "Wireless Headphones", sales: "₹850K", growth: "+8%", stock: 89 },
                { name: "Smart Watch", sales: "₹620K", growth: "+22%", stock: 156 }
              ].map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white font-bold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{product.name}</p>
                      <p className="text-xs text-muted-foreground">Stock: {product.stock} units</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-sm">{product.sales}</p>
                    <p className="text-xs text-emerald-600 font-semibold">{product.growth}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 3D Warehouse Visualization */}
      <div
      >
      <Warehouse3D />
      </div>

      {/* Featured Services Carousel */}
      <div
      >
      <FeaturedCarousel />
      </div>

      {/* Analytics Charts */}
      <div
      >
      <DashboardCharts />
      </div>

      {/* Platform Project Guide */}
      <div>
        <PlatformGuide />
      </div>

      {/* Development Team */}
      <div>
        <DevTeam />
      </div>

      {/* Platform Features & Description */}
      <div
      >
      <PlatformFeatures />
      </div>
    </div>
  )
}

