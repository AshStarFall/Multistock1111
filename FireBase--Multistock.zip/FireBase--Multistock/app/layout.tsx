import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { AuthProvider } from '@/lib/auth-context'
import { NotificationProvider } from '@/lib/notifications-context'
import { AccessibilityProvider } from '@/components/accessibility/accessibility-context'
import { ThemeProvider } from '@/components/theme-provider'
import { SessionManager } from '@/components/session-manager'
import { AppLayout } from '@/components/app-layout'

const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap',
  preload: true,
})

export const metadata: Metadata = {
  title: 'MultiStock - Complete Logistics & Inventory Platform',
  description: 'Professional inventory, warehouse, and logistics management solution with rentals, storage, and marketplace features',
  keywords: 'inventory management, warehouse, logistics, rentals, storage, marketplace',
  authors: [{ name: 'MultiStock Team' }],
  creator: 'MultiStock',
  publisher: 'MultiStock',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'),
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#0f172a' }
  ],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        <AuthProvider>
          <NotificationProvider>
            <AccessibilityProvider>
              <ThemeProvider
                attribute="class"
                defaultTheme="system"
                enableSystem
                disableTransitionOnChange
              >
                <SessionManager />
                <AppLayout>
                  {children}
                </AppLayout>
              </ThemeProvider>
            </AccessibilityProvider>
          </NotificationProvider>
        </AuthProvider>
      </body>
    </html>
  )
}