"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AdjustmentForm, useAdjustments } from "@/components/adjustment-form"

export default function AdjustmentsPage() {
  const rows = useAdjustments()

  return (
    <section className="space-y-4">
      <h1 className="text-xl font-semibold text-balance">Adjustments</h1>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">New Adjustment</CardTitle>
        </CardHeader>
        <CardContent>
          <AdjustmentForm onCreated={() => location.reload()} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Recent Adjustments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-2">Date</th>
                  <th className="text-left p-2">SKU</th>
                  <th className="text-right p-2">Qty</th>
                  <th className="text-left p-2">Warehouse</th>
                  <th className="text-left p-2">Reason</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t">
                    <td className="p-2">{new Date(r.date).toLocaleString()}</td>
                    <td className="p-2">{r.sku}</td>
                    <td className="p-2 text-right">{r.qty}</td>
                    <td className="p-2">{r.warehouseId}</td>
                    <td className="p-2">{r.reason}</td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr>
                    <td className="p-3 text-muted-foreground" colSpan={5}>
                      No adjustments yet. Create your first one above.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
