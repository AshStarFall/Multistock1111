"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send,
  MessageCircle,
  Building,
  Users,
  Headphones,
  Calendar,
  CheckCircle,
  Globe,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Youtube
} from "lucide-react"

export default function ContactUsPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
    subject: "",
    inquiryType: "",
    message: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData(prev => ({ ...prev, inquiryType: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      toast.success("Message sent successfully! We'll get back to you within 24 hours.")
      setFormData({
        name: "",
        email: "",
        company: "",
        phone: "",
        subject: "",
        inquiryType: "",
        message: ""
      })
    } catch (error) {
      toast.error("Failed to send message. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const contactInfo = [
    {
      icon: MapPin,
      title: "Headquarters",
      details: ["123 Business Park", "Mumbai, Maharashtra 400001", "India"],
      color: "text-red-600"
    },
    {
      icon: Phone,
      title: "Phone Support",
      details: ["+91 98765 43210", "+91 87654 32109", "Mon-Fri 9AM-6PM IST"],
      color: "text-green-600"
    },
    {
      icon: Mail,
      title: "Email Support",
      details: ["support@multistock.com", "sales@multistock.com", "info@multistock.com"],
      color: "text-blue-600"
    },
    {
      icon: Clock,
      title: "Business Hours",
      details: ["Monday - Friday: 9:00 AM - 6:00 PM", "Saturday: 10:00 AM - 4:00 PM", "Sunday: Closed"],
      color: "text-purple-600"
    }
  ]

  const offices = [
    {
      city: "Mumbai",
      country: "India",
      address: "123 Business Park, Mumbai, Maharashtra 400001",
      phone: "+91 98765 43210",
      email: "mumbai@multistock.com"
    },
    {
      city: "Bangalore",
      country: "India", 
      address: "456 Tech Hub, Bangalore, Karnataka 560001",
      phone: "+91 87654 32109",
      email: "bangalore@multistock.com"
    },
    {
      city: "Delhi",
      country: "India",
      address: "789 Industrial Area, Delhi, NCR 110001",
      phone: "+91 76543 21098",
      email: "delhi@multistock.com"
    },
    {
      city: "Chennai",
      country: "India",
      address: "321 Business District, Chennai, Tamil Nadu 600001",
      phone: "+91 65432 10987",
      email: "chennai@multistock.com"
    }
  ]

  const departments = [
    {
      icon: Users,
      title: "Sales",
      description: "Get information about our products and pricing",
      contact: "sales@multistock.com",
      phone: "+91 98765 43210"
    },
    {
      icon: Headphones,
      title: "Customer Support",
      description: "Technical support and account assistance",
      contact: "support@multistock.com",
      phone: "+91 87654 32109"
    },
    {
      icon: Building,
      title: "Partnerships",
      description: "Business partnerships and collaborations",
      contact: "partnerships@multistock.com",
      phone: "+91 76543 21098"
    },
    {
      icon: MessageCircle,
      title: "Media & Press",
      description: "Press inquiries and media relations",
      contact: "press@multistock.com",
      phone: "+91 65432 10987"
    }
  ]

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl p-8 text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Get in Touch
            </h1>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              We're here to help! Reach out to us for any questions, support, or inquiries. 
              Our team is ready to assist you with your logistics and inventory management needs.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                <Clock className="w-4 h-4 mr-2" />
                24/7 Support Available
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                <CheckCircle className="w-4 h-4 mr-2" />
                Quick Response Time
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                <Globe className="w-4 h-4 mr-2" />
                Global Presence
              </Badge>
            </div>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
      </div>

      {/* Contact Information Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {contactInfo.map((info, index) => (
          <Card key={index} className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className={`w-12 h-12 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center`}>
                <info.icon className={`w-6 h-6 ${info.color}`} />
              </div>
              <h3 className="font-semibold mb-3">{info.title}</h3>
              <div className="space-y-1">
                {info.details.map((detail, idx) => (
                  <p key={idx} className="text-sm text-muted-foreground">{detail}</p>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Contact Form and Quick Contact */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Contact Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Send className="w-5 h-5 mr-2" />
              Send us a Message
            </CardTitle>
            <p className="text-muted-foreground">
              Fill out the form below and we'll get back to you as soon as possible.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="Enter your email"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="company">Company</Label>
                  <Input
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    placeholder="Enter your company name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="Enter your phone number"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="inquiryType">Inquiry Type *</Label>
                <Select value={formData.inquiryType} onValueChange={handleSelectChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select inquiry type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Inquiry</SelectItem>
                    <SelectItem value="sales">Sales & Pricing</SelectItem>
                    <SelectItem value="support">Technical Support</SelectItem>
                    <SelectItem value="partnership">Partnership</SelectItem>
                    <SelectItem value="media">Media & Press</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject *</Label>
                <Input
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  placeholder="Enter message subject"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message *</Label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Enter your message here..."
                  rows={5}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                <Send className="w-4 h-4 mr-2" />
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Quick Contact Options */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Contact Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Phone className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Call Us Now</h3>
                  <p className="text-sm text-muted-foreground">+91 98765 43210</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Mail className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">Email Support</h3>
                  <p className="text-sm text-muted-foreground">support@multistock.com</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium">Schedule a Demo</h3>
                  <p className="text-sm text-muted-foreground">Book a personalized demo</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-medium">Live Chat</h3>
                  <p className="text-sm text-muted-foreground">Chat with our support team</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Department Contacts */}
          <Card>
            <CardHeader>
              <CardTitle>Contact by Department</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {departments.map((dept, index) => (
                <div key={index} className="p-3 border rounded-lg">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <dept.icon className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{dept.title}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{dept.description}</p>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">{dept.contact}</p>
                        <p className="text-xs text-muted-foreground">{dept.phone}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Office Locations */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-2xl">Our Office Locations</CardTitle>
          <p className="text-center text-muted-foreground">
            Visit us at any of our offices across India
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {offices.map((office, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-red-500" />
                      <h3 className="font-semibold">{office.city}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">{office.country}</p>
                    <div className="space-y-2">
                      <p className="text-xs text-muted-foreground">{office.address}</p>
                      <div className="flex items-center space-x-1">
                        <Phone className="w-3 h-3 text-green-500" />
                        <p className="text-xs text-muted-foreground">{office.phone}</p>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Mail className="w-3 h-3 text-blue-500" />
                        <p className="text-xs text-muted-foreground">{office.email}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Social Media & Follow Us */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <CardTitle className="text-center text-2xl">Follow Us</CardTitle>
          <p className="text-center text-muted-foreground">
            Stay connected with us on social media for updates and news
          </p>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center space-x-4">
            <Button variant="outline" size="lg" className="flex items-center space-x-2">
              <Facebook className="w-5 h-5 text-blue-600" />
              <span>Facebook</span>
            </Button>
            <Button variant="outline" size="lg" className="flex items-center space-x-2">
              <Twitter className="w-5 h-5 text-blue-400" />
              <span>Twitter</span>
            </Button>
            <Button variant="outline" size="lg" className="flex items-center space-x-2">
              <Linkedin className="w-5 h-5 text-blue-700" />
              <span>LinkedIn</span>
            </Button>
            <Button variant="outline" size="lg" className="flex items-center space-x-2">
              <Instagram className="w-5 h-5 text-pink-600" />
              <span>Instagram</span>
            </Button>
            <Button variant="outline" size="lg" className="flex items-center space-x-2">
              <Youtube className="w-5 h-5 text-red-600" />
              <span>YouTube</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
