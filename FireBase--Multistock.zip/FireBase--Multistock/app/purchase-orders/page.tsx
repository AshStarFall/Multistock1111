"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { OrdersTable } from "@/components/orders-table"
import { purchaseOrders } from "@/lib/mock-orders"

export default function PurchaseOrdersPage() {
  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-balance">Purchase Orders</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">All Purchase Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <OrdersTable rows={purchaseOrders} kind="purchase" />
        </CardContent>
      </Card>
    </section>
  )
}
