'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ExpenseOverview } from '@/components/expenses/expense-overview';
import { ExpenseCharts } from '@/components/expenses/expense-charts';
import { BudgetTracker } from '@/components/expenses/budget-tracker';
import {
  ExpenseRecord,
  Budget,
  ExpenseSummary,
  calculateExpenseSummary,
  exportToCSV,
  downloadCSV,
  getDateRangePreset,
  getCategoryInfo,
} from '@/lib/expenses';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  TrendingUp,
  Download,
  Filter,
  Calendar,
  PieChart,
  Target,
  Receipt,
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [summary, setSummary] = useState<ExpenseSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'quarter' | 'year'>('month');

  useEffect(() => {
    fetchData();
  }, [dateRange]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      const range = getDateRangePreset(dateRange);
      
      const [expensesRes, budgetsRes] = await Promise.all([
        fetch(`/api/expenses?startDate=${range.startDate.toISOString()}&endDate=${range.endDate.toISOString()}`),
        fetch('/api/expenses/budgets'),
      ]);

      const expensesData = await expensesRes.json();
      const budgetsData = await budgetsRes.json();

      setExpenses(expensesData);
      setBudgets(budgetsData);
      setSummary(calculateExpenseSummary(expensesData));
    } catch (error) {
      console.error('Error fetching expense data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    const csv = exportToCSV(expenses);
    downloadCSV(csv, `expenses-${dateRange}-${new Date().toISOString().split('T')[0]}.csv`);
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-4xl font-bold">Expense Tracker</h1>
              <p className="text-muted-foreground">
                Monitor your expenses and manage budgets
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Select value={dateRange} onValueChange={(v: any) => setDateRange(v)}>
              <SelectTrigger className="w-40">
                <Calendar className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last 7 Days</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={handleExport}>
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">Loading expense data...</p>
        </div>
      ) : summary ? (
        <div className="space-y-6">
          <ExpenseOverview summary={summary} />

          <Tabs defaultValue="analytics" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="analytics">
                <PieChart className="w-4 h-4 mr-2" />
                Analytics
              </TabsTrigger>
              <TabsTrigger value="budgets">
                <Target className="w-4 h-4 mr-2" />
                Budgets
              </TabsTrigger>
              <TabsTrigger value="records">
                <Receipt className="w-4 h-4 mr-2" />
                Records ({expenses.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="analytics">
              <ExpenseCharts summary={summary} />
            </TabsContent>

            <TabsContent value="budgets">
              <BudgetTracker budgets={budgets} />
            </TabsContent>

            <TabsContent value="records">
              <Card className="p-6">
                <div className="space-y-3">
                  {expenses.length === 0 ? (
                    <div className="text-center py-12">
                      <Receipt className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No Expenses</h3>
                      <p className="text-muted-foreground">
                        No expenses recorded for this period
                      </p>
                    </div>
                  ) : (
                    expenses.map((expense, index) => {
                      const categoryInfo = getCategoryInfo(expense.category);
                      return (
                        <motion.div
                          key={expense.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-lg ${categoryInfo.color} bg-opacity-10`}>
                              <span className="text-xl">{categoryInfo.icon}</span>
                            </div>
                            <div>
                              <p className="font-medium">{expense.description}</p>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <span>{categoryInfo.label}</span>
                                <span>•</span>
                                <span>{new Date(expense.date).toLocaleDateString()}</span>
                                {expense.paymentMethod && (
                                  <>
                                    <span>•</span>
                                    <span>{expense.paymentMethod}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold">
                              ₹{expense.amount.toLocaleString()}
                            </p>
                          </div>
                        </motion.div>
                      );
                    })
                  )}
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      ) : null}
    </div>
  );
}
