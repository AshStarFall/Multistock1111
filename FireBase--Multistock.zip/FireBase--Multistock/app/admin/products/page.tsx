"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { toast } from "sonner"
import { 
  Package, 
  Plus, 
  Edit, 
  Trash2, 
  Image as ImageIcon,
  Eye,
  EyeOff,
  Upload,
  Search,
  Filter,
  RefreshCw,
  Download
} from "lucide-react"
import Image from "next/image"
import { motion } from "framer-motion"
import { TableSkeleton } from "@/components/ui/skeleton"
import { EmptyState } from "@/components/empty-state"
import { ConfirmDialog } from "@/components/confirm-dialog"
import { Breadcrumbs } from "@/components/breadcrumbs"
import { BulkActionsBar, useBulkSelection, BulkSelectCheckbox } from "@/components/bulk-actions-bar"
import { ExportDialog } from "@/components/dialogs/export-dialog"
import { exportProducts } from "@/lib/data-exporter"
import { useNotifications } from "@/lib/notifications-context"
import { useDebounce } from "@/hooks/use-performance"

interface Product {
  id: string
  sku: string
  name: string
  description: string
  category_id: string
  category?: {
    id: string
    name: string
    image_url: string
  }
  unit_cost: number
  reorder_point: number
  image_url: string
  brand: string
  weight: number
  dimensions: string
  created_at: string
  created_by: string
  stock_levels?: {
    id: string
    qty: number
    warehouse: {
      id: string
      name: string
    }
  }[]
}

interface Category {
  id: string
  name: string
  description: string
  image_url: string
}

export default function ProductManagementPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [productToDelete, setProductToDelete] = useState<string | null>(null)
  
  const { addNotification } = useNotifications()
  
  // Bulk selection hook
  const bulkSelection = useBulkSelection(products)
  
  const [formData, setFormData] = useState({
    sku: "",
    name: "",
    description: "",
    category_id: "",
    unit_cost: 0,
    reorder_point: 0,
    image_url: "",
    brand: "",
    weight: 0,
    dimensions: ""
  })

  const supabase = getSupabaseBrowser()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      await Promise.all([
        loadProducts(),
        loadCategories()
      ])
    } catch (error: any) {
      console.error('Error loading data:', error?.message || error)
      toast.error(error?.message || 'Failed to load data')
    } finally {
      setIsLoading(false)
    }
  }

  const loadProducts = async () => {
    const { data, error } = await supabase
      .from('products')
      .select(`
        *,
        category:categories(*),
        stock_levels(
          *,
          warehouse:warehouses(*)
        )
      `)
      .order('created_at', { ascending: false })

    if (error) throw error
    setProducts(data || [])
  }

  const loadCategories = async () => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('is_active', true)
      .order('name')

    if (error) throw error
    setCategories(data || [])
  }

  const handleSubmit = async () => {
    try {
      if (editingProduct) {
        // Update existing product
        const { error } = await supabase
          .from('products')
          .update({
            sku: formData.sku,
            name: formData.name,
            description: formData.description,
            category_id: formData.category_id || null,
            unit_cost: formData.unit_cost,
            reorder_point: formData.reorder_point,
            image_url: formData.image_url || null,
            brand: formData.brand,
            weight: formData.weight,
            dimensions: formData.dimensions
          })
          .eq('id', editingProduct.id)

        if (error) throw error
        toast.success('Product updated successfully')
      } else {
        // Create new product
        const { error } = await supabase
          .from('products')
          .insert({
            sku: formData.sku,
            name: formData.name,
            description: formData.description,
            category_id: formData.category_id || null,
            unit_cost: formData.unit_cost,
            reorder_point: formData.reorder_point,
            image_url: formData.image_url || null,
            brand: formData.brand,
            weight: formData.weight,
            dimensions: formData.dimensions
          })

        if (error) throw error
        toast.success('Product created successfully')
      }

      resetForm()
      await loadProducts()
    } catch (error) {
      console.error('Error saving product:', error)
      toast.error('Failed to save product')
    }
  }

  const handleEdit = (product: Product) => {
    setEditingProduct(product)
    setFormData({
      sku: product.sku,
      name: product.name,
      description: product.description || "",
      category_id: product.category_id || "",
      unit_cost: product.unit_cost,
      reorder_point: product.reorder_point,
      image_url: product.image_url || "",
      brand: product.brand || "",
      weight: product.weight || 0,
      dimensions: product.dimensions || ""
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (productId: string) => {
    setProductToDelete(productId)
    setDeleteConfirmOpen(true)
  }

  const confirmDelete = async () => {
    if (!productToDelete) return

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productToDelete)

      if (error) throw error

      await loadProducts()
      toast.success('Product deleted successfully')
      addNotification({
        type: 'success',
        title: 'Product Deleted',
        message: 'The product has been successfully removed',
      })
    } catch (error) {
      console.error('Error deleting product:', error)
      toast.error('Failed to delete product')
    } finally {
      setDeleteConfirmOpen(false)
      setProductToDelete(null)
    }
  }

  // Bulk operations
  const handleBulkDelete = async (items: Product[]) => {
    const ids = items.map(item => item.id)
    const { error } = await supabase
      .from('products')
      .delete()
      .in('id', ids)

    if (error) throw error
    
    await loadProducts()
    addNotification({
      type: 'success',
      title: 'Bulk Delete Complete',
      message: `${items.length} products have been deleted`,
    })
  }

  const handleBulkExport = async (items: Product[]) => {
    await exportProducts(items, 'excel')
  }

  const resetForm = () => {
    setFormData({
      sku: "",
      name: "",
      description: "",
      category_id: "",
      unit_cost: 0,
      reorder_point: 0,
      image_url: "",
      brand: "",
      weight: 0,
      dimensions: ""
    })
    setEditingProduct(null)
    setIsDialogOpen(false)
  }

  // Memoize expensive calculations
  const getTotalStock = useCallback((product: Product) => {
    return product.stock_levels?.reduce((total, level) => total + level.qty, 0) || 0
  }, [])

  const getStockStatus = useCallback((product: Product) => {
    const totalStock = getTotalStock(product)
    if (totalStock === 0) return { status: 'out', color: 'text-red-600', bg: 'bg-red-50' }
    if (totalStock <= product.reorder_point) return { status: 'low', color: 'text-amber-600', bg: 'bg-amber-50' }
    return { status: 'in', color: 'text-green-600', bg: 'bg-green-50' }
  }, [getTotalStock])

  // Debounced search for better performance
  const debouncedSearch = useDebounce(searchQuery, 300)

  // Memoize filtered products
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = debouncedSearch === "" || 
        product.name.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
        product.sku.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
        product.brand?.toLowerCase().includes(debouncedSearch.toLowerCase())
      
      const matchesCategory = selectedCategory === "all" || product.category_id === selectedCategory
      
      return matchesSearch && matchesCategory
    })
  }, [products, debouncedSearch, selectedCategory])

  if (isLoading) {
    return (
      <div className="space-y-6 p-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="h-8 w-64 bg-slate-200 dark:bg-slate-800 rounded animate-pulse mb-2" />
            <div className="h-4 w-96 bg-slate-200 dark:bg-slate-800 rounded animate-pulse" />
          </div>
        </div>
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <TableSkeleton rows={8} />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <section className="space-y-6 p-6">
      <Breadcrumbs />
      
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            Product Management
          </h1>
          <p className="text-muted-foreground mt-1">Manage your product catalog with photos and categories</p>
        </div>
        <div className="flex gap-3">
          <ExportDialog
            data={filteredProducts}
            exportFunction={async (format, onProgress) => {
              await exportProducts(filteredProducts, format, onProgress)
            }}
            title="Export Products"
            description="Export products to PDF, Excel, or CSV format"
          />
          <Button variant="outline" onClick={loadData}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                onClick={resetForm}
                id="add-product-btn"
                className="bg-gradient-to-r from-indigo-600 to-violet-600 hover:shadow-lg transition-all"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 'Edit Product' : 'Create New Product'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sku">SKU</Label>
                  <Input
                    id="sku"
                    value={formData.sku}
                    onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                    placeholder="Enter product SKU"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Product Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter product name"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter product description"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category_id">Category</Label>
                  <Select
                    value={formData.category_id}
                    onValueChange={(value) => setFormData({ ...formData, category_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="brand">Brand</Label>
                  <Input
                    id="brand"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    placeholder="Enter brand name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="unit_cost">Unit Cost</Label>
                  <Input
                    id="unit_cost"
                    type="number"
                    step="0.01"
                    value={formData.unit_cost}
                    onChange={(e) => setFormData({ ...formData, unit_cost: parseFloat(e.target.value) || 0 })}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reorder_point">Reorder Point</Label>
                  <Input
                    id="reorder_point"
                    type="number"
                    value={formData.reorder_point}
                    onChange={(e) => setFormData({ ...formData, reorder_point: parseInt(e.target.value) || 0 })}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    step="0.01"
                    value={formData.weight}
                    onChange={(e) => setFormData({ ...formData, weight: parseFloat(e.target.value) || 0 })}
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dimensions">Dimensions</Label>
                <Input
                  id="dimensions"
                  value={formData.dimensions}
                  onChange={(e) => setFormData({ ...formData, dimensions: e.target.value })}
                  placeholder="e.g., 10x5x3 cm"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="image_url">Image URL</Label>
                <Input
                  id="image_url"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  placeholder="Enter image URL"
                />
                <p className="text-xs text-muted-foreground">
                  You can use URLs from /product-photos/ directory or external URLs
                </p>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button onClick={handleSubmit}>
                  {editingProduct ? 'Update Product' : 'Create Product'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        </div>
      </motion.div>

      {/* Search and Filter */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Search & Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search products by name, SKU, or brand..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="sm:w-48">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Products Grid */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
      >
        {filteredProducts.map((product, index) => {
          const stockInfo = getStockStatus(product)
          const totalStock = getTotalStock(product)
          const isSelected = bulkSelection.isSelected(product.id)
          
          return (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className={`overflow-hidden hover:shadow-xl transition-all duration-300 border-0 shadow-lg group ${isSelected ? 'ring-2 ring-indigo-500' : ''}`}>
                <div className="aspect-square relative bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900">
                  {product.image_url ? (
                    <Image
                      src={product.image_url}
                      alt={product.name}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <Package className="w-12 h-12 text-muted-foreground" />
                    </div>
                  )}
                  <div className="absolute top-3 left-3">
                    <BulkSelectCheckbox
                      checked={isSelected}
                      onCheckedChange={() => bulkSelection.toggleItem(product.id)}
                    />
                  </div>
                  <div className="absolute top-3 right-3">
                    <Badge 
                      variant="secondary" 
                      className={`${stockInfo.bg} ${stockInfo.color} border-0 shadow-lg`}
                    >
                      {stockInfo.status === 'out' ? 'Out of Stock' : 
                       stockInfo.status === 'low' ? 'Low Stock' : 'In Stock'}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-5">
                  <div className="space-y-3">
                    <div>
                      <h3 className="font-semibold text-lg truncate group-hover:text-indigo-600 transition-colors">{product.name}</h3>
                      <p className="text-sm text-muted-foreground font-mono">{product.sku}</p>
                    </div>
                    
                    {product.category && (
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-xs">
                          {product.category.name}
                        </Badge>
                      </div>
                    )}
                    
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Stock:</span>
                        <span className="font-semibold">{totalStock} units</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Cost:</span>
                        <span className="font-semibold">₹{product.unit_cost.toFixed(2)}</span>
                      </div>
                      {product.brand && (
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Brand:</span>
                          <span className="font-medium">{product.brand}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 pt-3 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleEdit(product)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:bg-red-50 hover:text-red-700 dark:hover:bg-red-900/20"
                        onClick={() => handleDelete(product.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </motion.div>

      {filteredProducts.length === 0 && (
        <EmptyState
          icon={Package}
          title="No products found"
          description={
            searchQuery || selectedCategory !== "all" 
              ? "Try adjusting your search or filter criteria"
              : "Get started by adding your first product"
          }
          actionLabel={!searchQuery && selectedCategory === "all" ? "Add Product" : undefined}
          onAction={() => setIsDialogOpen(true)}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        onConfirm={confirmDelete}
        title="Delete Product"
        description="Are you sure you want to delete this product? This action cannot be undone and will remove all associated data."
        variant="destructive"
      />

      {/* Bulk Actions Bar */}
      <BulkActionsBar
        selectedItems={bulkSelection.selectedItems}
        onClearSelection={bulkSelection.clearSelection}
        onBulkDelete={handleBulkDelete}
        onBulkExport={handleBulkExport}
      />
    </section>
  )
}
