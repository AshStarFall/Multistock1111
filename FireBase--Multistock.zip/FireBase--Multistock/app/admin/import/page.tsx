'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Upload, Download, FileJson, AlertCircle, CheckCircle, Loader2 } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface ImportResult {
  success: boolean
  imported: number
  failed: number
  totalProcessed: number
  validationErrors?: Array<{ row: number; error: string }>
  importErrors?: Array<{ batch: number; error: string }>
  message: string
}

export default function BulkImportPage() {
  const [file, setFile] = useState<File | null>(null)
  const [jsonData, setJsonData] = useState('')
  const [result, setResult] = useState<ImportResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [method, setMethod] = useState<'file' | 'json'>('file')

  const handleImportCSV = async () => {
    if (!file) {
      alert('Please select a CSV file')
      return
    }

    try {
      setLoading(true)
      setResult(null)

      const formData = new FormData()
      formData.append('file', file)

      const response = await fetch('/api/products/import', {
        method: 'POST',
        body: formData
      })

      const data = await response.json()
      setResult(data)

      if (data.success) {
        setFile(null) // Clear on success
      }
    } catch (error: any) {
      setResult({
        success: false,
        imported: 0,
        failed: 0,
        totalProcessed: 0,
        message: error.message || 'Failed to import CSV'
      })
    } finally {
      setLoading(false)
    }
  }

  const handleImportJSON = async () => {
    if (!jsonData.trim()) {
      alert('Please enter JSON data')
      return
    }

    try {
      setLoading(true)
      setResult(null)

      const products = JSON.parse(jsonData)

      const response = await fetch('/api/products/bulk-import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ products })
      })

      const data = await response.json()
      setResult(data)

      if (data.success) {
        setJsonData('') // Clear on success
      }
    } catch (error: any) {
      setResult({
        success: false,
        imported: 0,
        failed: 0,
        totalProcessed: 0,
        message: error.message || 'Failed to parse JSON or import'
      })
    } finally {
      setLoading(false)
    }
  }

  const downloadTemplate = () => {
    // Download CSV template
    window.location.href = '/api/products/import'
  }

  const downloadJSONTemplate = () => {
    const template = [
      {
        name: 'Laptop Dell XPS 15',
        sku: 'LAP-001',
        price: 75000,
        stock_quantity: 50,
        reorder_point: 10,
        category: 'Electronics',
        description: 'High-performance laptop',
        barcode: '1234567890123',
        unit: 'pcs'
      },
      {
        name: 'Wireless Mouse',
        sku: 'MOU-001',
        price: 1500,
        stock_quantity: 200,
        reorder_point: 20,
        category: 'Accessories',
        description: 'Ergonomic wireless mouse',
        barcode: '1234567890124',
        unit: 'pcs'
      }
    ]

    const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'products-template.json'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Bulk Product Import</h1>
        <p className="text-muted-foreground">Import multiple products at once using CSV or JSON format</p>
      </div>

      {/* Method Selection */}
      <div className="flex gap-2">
        <Button
          variant={method === 'file' ? 'default' : 'outline'}
            onClick={() => setMethod('file')}
          >
            <Upload className="w-4 h-4 mr-2" />
            CSV File Upload
          </Button>
          <Button
            variant={method === 'json' ? 'default' : 'outline'}
            onClick={() => setMethod('json')}
          >
            <FileJson className="w-4 h-4 mr-2" />
            JSON Import
          </Button>
        </div>

        {/* CSV File Upload */}
        {method === 'file' && (
          <Card className="p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">CSV File Import</h2>
                <Button variant="outline" size="sm" onClick={downloadTemplate}>
                  <Download className="w-4 h-4 mr-2" />
                  Download CSV Template
                </Button>
              </div>

              <Alert>
                <AlertCircle className="w-4 h-4" />
                <AlertDescription>
                  Upload a CSV file with product data. Maximum 10,000 products per file.
                  <br />
                  Required columns: <code className="text-xs bg-muted px-1 py-0.5 rounded">name, sku, price, stock_quantity</code>
                </AlertDescription>
              </Alert>

              <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept=".csv"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  className="hidden"
                  id="csv-upload"
                />
                <label
                  htmlFor="csv-upload"
                  className="cursor-pointer flex flex-col items-center gap-3"
                >
                  <Upload className="w-12 h-12 text-muted-foreground" />
                  {file ? (
                    <div>
                      <p className="text-sm font-medium text-foreground">{file.name}</p>
                      <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(2)} KB</p>
                    </div>
                  ) : (
                    <div>
                      <p className="text-sm font-medium text-foreground">Click to upload CSV file</p>
                      <p className="text-xs text-muted-foreground">or drag and drop</p>
                    </div>
                  )}
                </label>
              </div>

              <Button
                onClick={handleImportCSV}
                disabled={loading || !file}
                className="w-full"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Import CSV File
                  </>
                )}
              </Button>
            </div>
          </Card>
        )}

        {/* JSON Import */}
        {method === 'json' && (
          <Card className="p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">JSON Data Import</h2>
                <Button variant="outline" size="sm" onClick={downloadJSONTemplate}>
                  <Download className="w-4 h-4 mr-2" />
                  Download JSON Template
                </Button>
              </div>

              <Alert>
                <AlertCircle className="w-4 h-4" />
                <AlertDescription>
                  Paste your JSON array below. Maximum 10,000 products per batch.
                  <br />
                  Required fields: <code className="text-xs bg-muted px-1 py-0.5 rounded">name, sku, price, stock_quantity</code>
                </AlertDescription>
              </Alert>

              <div>
                <label className="block text-sm font-medium mb-2">JSON Products Array</label>
                <textarea
                  value={jsonData}
                  onChange={(e) => setJsonData(e.target.value)}
                  placeholder={`[\n  {\n    "name": "Product Name",\n    "sku": "SKU-001",\n    "price": 99.99,\n    "stock_quantity": 100,\n    "reorder_point": 10,\n    "category": "Electronics"\n  }\n]`}
                  className="w-full h-64 p-4 font-mono text-sm bg-slate-50 dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <Button
                onClick={handleImportJSON}
                disabled={loading || !jsonData.trim()}
                className="w-full"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Import Products
                  </>
                )}
              </Button>
            </div>
          </Card>
        )}

        {/* Results */}
        {result && (
          <Card className={`p-6 ${result.success ? 'border-green-200 dark:border-green-800' : 'border-red-200 dark:border-red-800'}`}>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                {result.success ? (
                  <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                ) : (
                  <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                )}
                <div className="flex-1">
                  <h3 className={`text-lg font-semibold ${result.success ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>
                    {result.success ? 'Import Successful' : 'Import Failed'}
                  </h3>
                  <p className="text-muted-foreground mt-1">{result.message}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
                <div>
                  <div className="text-2xl font-bold text-foreground">{result.totalProcessed}</div>
                  <div className="text-sm text-muted-foreground">Total Processed</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">{result.imported}</div>
                  <div className="text-sm text-muted-foreground">Imported</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">{result.failed}</div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-indigo-600">
                    {result.totalProcessed > 0 ? Math.round((result.imported / result.totalProcessed) * 100) : 0}%
                  </div>
                  <div className="text-sm text-muted-foreground">Success Rate</div>
                </div>
              </div>

              {result.validationErrors && result.validationErrors.length > 0 && (
                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-2 text-red-700 dark:text-red-400">Validation Errors (First 20):</h4>
                  <div className="space-y-1 max-h-48 overflow-y-auto">
                    {result.validationErrors.map((err, i) => (
                      <div key={i} className="text-sm text-muted-foreground bg-red-50 dark:bg-red-900/20 p-2 rounded">
                        <span className="font-mono">Row {err.row}:</span> {err.error}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {result.importErrors && result.importErrors.length > 0 && (
                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-2 text-red-700 dark:text-red-400">Import Errors:</h4>
                  <div className="space-y-1">
                    {result.importErrors.map((err, i) => (
                      <div key={i} className="text-sm text-muted-foreground bg-red-50 dark:bg-red-900/20 p-2 rounded">
                        <span className="font-mono">Batch {err.batch}:</span> {err.error}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Card>
        )}

        {/* Instructions */}
        <Card className="p-6 bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/30 dark:to-violet-950/30">
          <h3 className="text-lg font-semibold mb-3">Import Instructions</h3>
          <div className="space-y-3 text-sm text-muted-foreground">
            <div>
              <strong className="text-foreground">CSV File Import:</strong>
              <ul className="list-disc list-inside ml-2 mt-1 space-y-1">
                <li>Download the CSV template to see the required format</li>
                <li>Fill in your product data in Excel or Google Sheets</li>
                <li>Save as CSV file and upload</li>
                <li>Maximum file size: 10MB (≈10,000 products)</li>
              </ul>
            </div>
            <div>
              <strong className="text-foreground">JSON Import:</strong>
              <ul className="list-disc list-inside ml-2 mt-1 space-y-1">
                <li>Download the JSON template or paste your data directly</li>
                <li>Ensure proper JSON array format</li>
                <li>Validate JSON before importing</li>
              </ul>
            </div>
            <div>
              <strong className="text-foreground">Required Fields:</strong>
              <p className="ml-2 mt-1">name, sku, price, stock_quantity</p>
            </div>
            <div>
              <strong className="text-foreground">Optional Fields:</strong>
              <p className="ml-2 mt-1">reorder_point, category, description, barcode, unit</p>
            </div>
            <div className="pt-2 border-t border-indigo-200 dark:border-indigo-800">
              <p><strong className="text-foreground">Note:</strong> SKU must be unique for each product. Duplicate SKUs will fail validation.</p>
            </div>
          </div>
        </Card>
      </div>
  )
}
