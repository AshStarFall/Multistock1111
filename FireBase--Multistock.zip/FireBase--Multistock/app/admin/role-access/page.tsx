"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { toast } from "sonner"
import { 
  Users, 
  Shield, 
  Plus, 
  Edit, 
  Trash2, 
  ArrowUp, 
  ArrowDown, 
  Mail,
  CheckCircle,
  XCircle,
  AlertCircle
} from "lucide-react"

interface User {
  id: string
  email: string
  name: string
  username: string
  department: string
  is_active: boolean
  role?: {
    id: string
    name: string
  }
  profile_photo?: {
    url: string
  }
}

interface Role {
  id: string
  name: string
  description: string
  is_system_role: boolean
}

interface Permission {
  id: string
  name: string
  description: string
  resource: string
  action: string
}

interface RolePermission {
  role_id: string
  permission_id: string
}

export default function RoleAccessManagementPage() {
  const [users, setUsers] = useState<User[]>([])
  const [roles, setRoles] = useState<Role[]>([])
  const [permissions, setPermissions] = useState<Permission[]>([])
  const [rolePermissions, setRolePermissions] = useState<RolePermission[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false)
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false)
  const [isAnnouncementDialogOpen, setIsAnnouncementDialogOpen] = useState(false)
  
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [selectedRole, setSelectedRole] = useState<Role | null>(null)
  const [announcementText, setAnnouncementText] = useState("")
  
  const [newRole, setNewRole] = useState({
    name: "",
    description: "",
    permissions: [] as string[]
  })

  const supabase = getSupabaseBrowser()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      await Promise.all([
        loadUsers(),
        loadRoles(),
        loadPermissions(),
        loadRolePermissions()
      ])
    } catch (error) {
      console.error('Error loading data:', error instanceof Error ? error.message : 'Unknown error')
      toast.error('Failed to load data. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const loadUsers = async () => {
    const { data, error } = await supabase
      .from('users')
      .select(`
        *,
        role:user_roles(*),
        profile_photo:profile_photos(*)
      `)
      .order('created_at', { ascending: false })

    if (error) throw error
    setUsers(data || [])
  }

  const loadRoles = async () => {
    const { data, error } = await supabase
      .from('user_roles')
      .select('*')
      .order('name')

    if (error) throw error
    setRoles(data || [])
  }

  const loadPermissions = async () => {
    const { data, error } = await supabase
      .from('permissions')
      .select('*')
      .order('resource, action')

    if (error) throw error
    setPermissions(data || [])
  }

  const loadRolePermissions = async () => {
    const { data, error } = await supabase
      .from('role_permissions')
      .select('*')

    if (error) throw error
    setRolePermissions(data || [])
  }

  const handleRoleChange = async (userId: string, newRoleId: string) => {
    try {
      const user = users.find(u => u.id === userId)
      const oldRole = user?.role
      const newRole = roles.find(r => r.id === newRoleId)

      if (!user || !oldRole || !newRole) return

      const { error } = await supabase
        .from('users')
        .update({ role_id: newRoleId })
        .eq('id', userId)

      if (error) throw error

      // Create announcement
      const isPromotion = getRoleHierarchy(newRole.name) > getRoleHierarchy(oldRole.name)
      const announcementText = `User ${user.name} has been ${isPromotion ? 'promoted' : 'demoted'} from ${oldRole.name} to ${newRole.name}.`

      const { error: announcementError } = await supabase
        .from('role_change_announcements')
        .insert({
          user_id: userId,
          old_role_id: oldRole.id,
          new_role_id: newRoleId,
          announcement_text: announcementText,
          is_promotion: isPromotion
        })

      if (announcementError) {
        console.error('Error creating announcement:', announcementError)
      }

      // Send email notification
      await sendRoleChangeEmail(user, oldRole.name, newRole.name, isPromotion)

      await loadUsers()
      toast.success(`Role updated for ${user.name}`)
    } catch (error) {
      console.error('Error updating role:', error)
      toast.error('Failed to update role')
    }
  }

  const getRoleHierarchy = (roleName: string): number => {
    const hierarchy = {
      'Admin': 4,
      'Manager': 3,
      'Employee': 2,
      'Viewer': 1
    }
    return (hierarchy as any)[roleName] || 0
  }

  const sendRoleChangeEmail = async (user: User, oldRole: string, newRole: string, isPromotion: boolean) => {
    try {
      const { error } = await supabase
        .from('email_logs')
        .insert({
          template_id: (await supabase.from('email_templates').select('id').eq('name', 'role_change_notification').single()).data?.id,
          recipient_email: user.email,
          recipient_name: user.name,
          subject: 'Your Role Has Been Updated',
          body_html: `
            <h2>Role Update Notification</h2>
            <p>Hello ${user.name},</p>
            <p>Your role has been ${isPromotion ? 'promoted' : 'demoted'} from ${oldRole} to ${newRole}.</p>
            <p>Please log in to see your updated permissions.</p>
            <p>Best regards,<br>Admin Team</p>
          `,
          body_text: `
            Role Update Notification
            
            Hello ${user.name},
            
            Your role has been ${isPromotion ? 'promoted' : 'demoted'} from ${oldRole} to ${newRole}.
            
            Please log in to see your updated permissions.
            
            Best regards,
            Admin Team
          `,
          status: 'sent',
          sent_at: new Date().toISOString()
        })

      if (error) {
        console.error('Error logging email:', error)
      }
    } catch (error) {
      console.error('Error sending email:', error)
    }
  }

  const handleCreateRole = async () => {
    try {
      const { data: role, error: roleError } = await supabase
        .from('user_roles')
        .insert({
          name: newRole.name,
          description: newRole.description,
          is_system_role: false
        })
        .select()
        .single()

      if (roleError) throw roleError

      // Add permissions to role
      if (newRole.permissions.length > 0) {
        const rolePermissionInserts = newRole.permissions.map(permissionId => ({
          role_id: role.id,
          permission_id: permissionId
        }))

        const { error: permissionError } = await supabase
          .from('role_permissions')
          .insert(rolePermissionInserts)

        if (permissionError) throw permissionError
      }

      setNewRole({ name: "", description: "", permissions: [] })
      setIsRoleDialogOpen(false)
      await loadRoles()
      await loadRolePermissions()
      toast.success('Role created successfully')
    } catch (error) {
      console.error('Error creating role:', error)
      toast.error('Failed to create role')
    }
  }

  const handleDeleteRole = async (roleId: string) => {
    try {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('id', roleId)

      if (error) throw error

      await loadRoles()
      toast.success('Role deleted successfully')
    } catch (error) {
      console.error('Error deleting role:', error)
      toast.error('Failed to delete role')
    }
  }

  const getPermissionsForRole = (roleId: string) => {
    return rolePermissions
      .filter(rp => rp.role_id === roleId)
      .map(rp => permissions.find(p => p.id === rp.permission_id))
      .filter(Boolean)
  }

  const groupedPermissions = permissions.reduce((acc, permission) => {
    if (!acc[permission.resource]) {
      acc[permission.resource] = []
    }
    acc[permission.resource].push(permission)
    return acc
  }, {} as Record<string, Permission[]>)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Role & Access Management</h1>
          <p className="text-muted-foreground">Manage user roles, permissions, and access levels</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isRoleDialogOpen} onOpenChange={setIsRoleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Role
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Role</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="role-name">Role Name</Label>
                  <Input
                    id="role-name"
                    value={newRole.name}
                    onChange={(e) => setNewRole({ ...newRole, name: e.target.value })}
                    placeholder="Enter role name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role-description">Description</Label>
                  <Textarea
                    id="role-description"
                    value={newRole.description}
                    onChange={(e) => setNewRole({ ...newRole, description: e.target.value })}
                    placeholder="Enter role description"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Permissions</Label>
                  <div className="max-h-60 overflow-y-auto space-y-2">
                    {Object.entries(groupedPermissions).map(([resource, perms]) => (
                      <div key={resource} className="space-y-1">
                        <h4 className="font-medium text-sm capitalize">{resource}</h4>
                        <div className="grid grid-cols-2 gap-2 ml-4">
                          {perms.map((permission) => (
                            <div key={permission.id} className="flex items-center space-x-2">
                              <Checkbox
                                id={permission.id}
                                checked={newRole.permissions.includes(permission.id)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setNewRole({
                                      ...newRole,
                                      permissions: [...newRole.permissions, permission.id]
                                    })
                                  } else {
                                    setNewRole({
                                      ...newRole,
                                      permissions: newRole.permissions.filter(p => p !== permission.id)
                                    })
                                  }
                                }}
                              />
                              <Label htmlFor={permission.id} className="text-sm">
                                {permission.action}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <Button onClick={handleCreateRole} className="w-full">
                  Create Role
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Users Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2" />
              Team Members
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {users.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={user.profile_photo?.url} alt={user.name} />
                      <AvatarFallback>
                        {user.name?.charAt(0)?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                      <p className="text-xs text-muted-foreground">{user.department}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Select
                      value={user.role?.id || ""}
                      onValueChange={(value) => handleRoleChange(user.id, value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map((role) => (
                          <SelectItem key={role.id} value={role.id}>
                            {role.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Badge variant={user.is_active ? "default" : "secondary"}>
                      {user.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Roles Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="w-5 h-5 mr-2" />
              Roles & Permissions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {roles.map((role) => (
                <div key={role.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="font-medium">{role.name}</h3>
                      <p className="text-sm text-muted-foreground">{role.description}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {role.is_system_role && (
                        <Badge variant="outline">System</Badge>
                      )}
                      {!role.is_system_role && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteRole(role.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-muted-foreground">Permissions:</p>
                    <div className="flex flex-wrap gap-1">
                      {getPermissionsForRole(role.id).map((permission) => (
                        <Badge key={permission?.id} variant="secondary" className="text-xs">
                          {permission?.resource}.{permission?.action}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Role Changes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertCircle className="w-5 h-5 mr-2" />
            Recent Role Changes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            Role changes and announcements will appear here. Team members will be notified via email when their roles are updated.
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
