"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { toast } from "sonner"
import { 
  FolderOpen, 
  Plus, 
  Edit, 
  Trash2, 
  Image as ImageIcon,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff
} from "lucide-react"

interface Category {
  id: string
  name: string
  description: string
  parent_id: string | null
  image_url: string | null
  is_active: boolean
  sort_order: number
  created_at: string
  created_by: string
  parent?: Category
  children?: Category[]
  product_count?: number
}

export default function CategoryManagementPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    parent_id: "",
    image_url: "",
    is_active: true,
    sort_order: 0
  })

  const supabase = getSupabaseBrowser()

  useEffect(() => {
    loadCategories()
  }, [])

  const loadCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select(`
          *,
          parent:categories!parent_id(*),
          children:categories!parent_id(*)
        `)
        .order('sort_order', { ascending: true })

      if (error) throw error

      // Get product counts for each category
      const categoriesWithCounts = await Promise.all(
        (data || []).map(async (category) => {
          const { count } = await supabase
            .from('products')
            .select('*', { count: 'exact', head: true })
            .eq('category_id', category.id)

          return {
            ...category,
            product_count: count || 0
          }
        })
      )

      setCategories(categoriesWithCounts)
    } catch (error) {
      console.error('Error loading categories:', error)
      toast.error('Failed to load categories')
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async () => {
    try {
      if (editingCategory) {
        // Update existing category
        const { error } = await supabase
          .from('categories')
          .update({
            name: formData.name,
            description: formData.description,
            parent_id: formData.parent_id || null,
            image_url: formData.image_url || null,
            is_active: formData.is_active,
            sort_order: formData.sort_order
          })
          .eq('id', editingCategory.id)

        if (error) throw error
        toast.success('Category updated successfully')
      } else {
        // Create new category
        const { error } = await supabase
          .from('categories')
          .insert({
            name: formData.name,
            description: formData.description,
            parent_id: formData.parent_id || null,
            image_url: formData.image_url || null,
            is_active: formData.is_active,
            sort_order: formData.sort_order
          })

        if (error) throw error
        toast.success('Category created successfully')
      }

      resetForm()
      await loadCategories()
    } catch (error) {
      console.error('Error saving category:', error)
      toast.error('Failed to save category')
    }
  }

  const handleEdit = (category: Category) => {
    setEditingCategory(category)
    setFormData({
      name: category.name,
      description: category.description || "",
      parent_id: category.parent_id || "",
      image_url: category.image_url || "",
      is_active: category.is_active,
      sort_order: category.sort_order
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (categoryId: string) => {
    if (!confirm('Are you sure you want to delete this category? This action cannot be undone.')) {
      return
    }

    try {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', categoryId)

      if (error) throw error

      await loadCategories()
      toast.success('Category deleted successfully')
    } catch (error) {
      console.error('Error deleting category:', error)
      toast.error('Failed to delete category')
    }
  }

  const handleToggleActive = async (category: Category) => {
    try {
      const { error } = await supabase
        .from('categories')
        .update({ is_active: !category.is_active })
        .eq('id', category.id)

      if (error) throw error

      await loadCategories()
      toast.success(`Category ${!category.is_active ? 'activated' : 'deactivated'}`)
    } catch (error) {
      console.error('Error updating category:', error)
      toast.error('Failed to update category')
    }
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      parent_id: "",
      image_url: "",
      is_active: true,
      sort_order: 0
    })
    setEditingCategory(null)
    setIsDialogOpen(false)
  }

  const getParentCategories = () => {
    return categories.filter(cat => !cat.parent_id)
  }

  const getCategoryHierarchy = (categories: Category[], parentId: string | null = null, level = 0): Category[] => {
    return categories
      .filter(cat => cat.parent_id === parentId)
      .map(cat => ({
        ...cat,
        children: getCategoryHierarchy(categories, cat.id, level + 1)
      }))
      .sort((a, b) => a.sort_order - b.sort_order)
  }

  const renderCategoryTree = (categories: Category[], level = 0) => {
    return categories.map((category) => (
      <div key={category.id} className="space-y-2">
        <div 
          className={`flex items-center justify-between p-3 border rounded-lg ${
            level > 0 ? 'ml-6 bg-muted/50' : 'bg-background'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              {level > 0 && <div className="w-4 h-4 border-l border-b border-muted-foreground/30"></div>}
              <FolderOpen className="w-4 h-4 text-muted-foreground" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-medium">{category.name}</h3>
                <Badge variant={category.is_active ? "default" : "secondary"}>
                  {category.is_active ? "Active" : "Inactive"}
                </Badge>
                {category.product_count !== undefined && (
                  <Badge variant="outline">{category.product_count} products</Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{category.description}</p>
              {category.image_url && (
                <div className="flex items-center space-x-1 mt-1">
                  <ImageIcon className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Has image</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleToggleActive(category)}
            >
              {category.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleEdit(category)}
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleDelete(category.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
        {category.children && category.children.length > 0 && (
          <div className="ml-4">
            {renderCategoryTree(category.children, level + 1)}
          </div>
        )}
      </div>
    ))
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading categories...</div>
      </div>
    )
  }

  const categoryHierarchy = getCategoryHierarchy(categories)

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Category Management</h1>
          <p className="text-muted-foreground">Organize your products with categories and subcategories</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingCategory ? 'Edit Category' : 'Create New Category'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Category Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter category name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sort_order">Sort Order</Label>
                  <Input
                    id="sort_order"
                    type="number"
                    value={formData.sort_order}
                    onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) || 0 })}
                    placeholder="0"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter category description"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="parent_id">Parent Category</Label>
                <Select
                  value={formData.parent_id}
                  onValueChange={(value) => setFormData({ ...formData, parent_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select parent category (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">No parent (root category)</SelectItem>
                    {getParentCategories().map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="image_url">Image URL</Label>
                <Input
                  id="image_url"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  placeholder="Enter image URL (optional)"
                />
                <p className="text-xs text-muted-foreground">
                  You can use URLs from /category-photos/ directory or external URLs
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                  className="rounded"
                />
                <Label htmlFor="is_active">Active</Label>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button onClick={handleSubmit}>
                  {editingCategory ? 'Update Category' : 'Create Category'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Category Tree */}
      <Card>
        <CardHeader>
          <CardTitle>Category Hierarchy</CardTitle>
        </CardHeader>
        <CardContent>
          {categoryHierarchy.length > 0 ? (
            <div className="space-y-2">
              {renderCategoryTree(categoryHierarchy)}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <FolderOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No categories found. Create your first category to get started.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Category Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FolderOpen className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm font-medium">Total Categories</p>
                <p className="text-2xl font-bold">{categories.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Eye className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm font-medium">Active Categories</p>
                <p className="text-2xl font-bold">{categories.filter(c => c.is_active).length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <EyeOff className="w-5 h-5 text-red-500" />
              <div>
                <p className="text-sm font-medium">Inactive Categories</p>
                <p className="text-2xl font-bold">{categories.filter(c => !c.is_active).length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
