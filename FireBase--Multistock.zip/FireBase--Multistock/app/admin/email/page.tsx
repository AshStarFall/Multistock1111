"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { toast } from "sonner"
import { 
  Mail, 
  Send, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle
} from "lucide-react"

interface EmailTemplate {
  id: string
  name: string
  subject: string
  body_html: string
  body_text: string
  variables: string[]
  is_active: boolean
}

interface EmailLog {
  id: string
  recipient_email: string
  recipient_name: string
  subject: string
  status: 'pending' | 'sent' | 'failed' | 'bounced'
  sent_at: string
  error_message: string
  created_at: string
  template?: EmailTemplate
}

export default function EmailManagementPage() {
  const [templates, setTemplates] = useState<EmailTemplate[]>([])
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false)
  const [isSendDialogOpen, setIsSendDialogOpen] = useState(false)
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null)
  
  const [templateForm, setTemplateForm] = useState({
    name: "",
    subject: "",
    body_html: "",
    body_text: "",
    variables: [] as string[],
    is_active: true
  })

  const [sendForm, setSendForm] = useState({
    template_name: "",
    recipient_email: "",
    recipient_name: "",
    variables: {} as Record<string, string>,
    subject: "",
    body_html: "",
    body_text: ""
  })

  const supabase = getSupabaseBrowser()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const response = await fetch('/api/email')
      const data = await response.json()
      
      if (response.ok) {
        setTemplates(data.templates)
        setEmailLogs(data.logs)
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      console.error('Error loading data:', error)
      toast.error('Failed to load email data')
    } finally {
      setIsLoading(false)
    }
  }

  const handleTemplateSubmit = async () => {
    try {
      if (editingTemplate) {
        const { error } = await supabase
          .from('email_templates')
          .update({
            name: templateForm.name,
            subject: templateForm.subject,
            body_html: templateForm.body_html,
            body_text: templateForm.body_text,
            variables: templateForm.variables,
            is_active: templateForm.is_active
          })
          .eq('id', editingTemplate.id)

        if (error) throw error
        toast.success('Template updated successfully')
      } else {
        const { error } = await supabase
          .from('email_templates')
          .insert({
            name: templateForm.name,
            subject: templateForm.subject,
            body_html: templateForm.body_html,
            body_text: templateForm.body_text,
            variables: templateForm.variables,
            is_active: templateForm.is_active
          })

        if (error) throw error
        toast.success('Template created successfully')
      }

      resetTemplateForm()
      await loadData()
    } catch (error) {
      console.error('Error saving template:', error)
      toast.error('Failed to save template')
    }
  }

  const handleSendEmail = async () => {
    try {
      const response = await fetch('/api/email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(sendForm),
      })

      const data = await response.json()

      if (response.ok) {
        toast.success('Email sent successfully')
        resetSendForm()
        await loadData()
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      console.error('Error sending email:', error)
      toast.error('Failed to send email')
    }
  }

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('Are you sure you want to delete this template?')) {
      return
    }

    try {
      const { error } = await supabase
        .from('email_templates')
        .delete()
        .eq('id', templateId)

      if (error) throw error

      await loadData()
      toast.success('Template deleted successfully')
    } catch (error) {
      console.error('Error deleting template:', error)
      toast.error('Failed to delete template')
    }
  }

  const resetTemplateForm = () => {
    setTemplateForm({
      name: "",
      subject: "",
      body_html: "",
      body_text: "",
      variables: [],
      is_active: true
    })
    setEditingTemplate(null)
    setIsTemplateDialogOpen(false)
  }

  const resetSendForm = () => {
    setSendForm({
      template_name: "",
      recipient_email: "",
      recipient_name: "",
      variables: {},
      subject: "",
      body_html: "",
      body_text: ""
    })
    setIsSendDialogOpen(false)
  }

  const handleEditTemplate = (template: EmailTemplate) => {
    setEditingTemplate(template)
    setTemplateForm({
      name: template.name,
      subject: template.subject,
      body_html: template.body_html,
      body_text: template.body_text,
      variables: template.variables,
      is_active: template.is_active
    })
    setIsTemplateDialogOpen(true)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      sent: 'default',
      failed: 'destructive',
      pending: 'secondary',
      bounced: 'outline'
    } as const

    return (
      <Badge variant={variants[status as keyof typeof variants] || 'outline'}>
        {status}
      </Badge>
    )
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Email Management</h1>
          <p className="text-muted-foreground">Manage email templates and view sending logs</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isSendDialogOpen} onOpenChange={setIsSendDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetSendForm}>
                <Send className="w-4 h-4 mr-2" />
                Send Email
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Send Email</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="send-template">Template</Label>
                  <Select
                    value={sendForm.template_name}
                    onValueChange={(value) => setSendForm({ ...sendForm, template_name: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select template (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.filter(t => t.is_active).map((template) => (
                        <SelectItem key={template.id} value={template.name}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="recipient-email">Recipient Email</Label>
                    <Input
                      id="recipient-email"
                      type="email"
                      value={sendForm.recipient_email}
                      onChange={(e) => setSendForm({ ...sendForm, recipient_email: e.target.value })}
                      placeholder="Enter recipient email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="recipient-name">Recipient Name</Label>
                    <Input
                      id="recipient-name"
                      value={sendForm.recipient_name}
                      onChange={(e) => setSendForm({ ...sendForm, recipient_name: e.target.value })}
                      placeholder="Enter recipient name"
                    />
                  </div>
                </div>

                {!sendForm.template_name && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="send-subject">Subject</Label>
                      <Input
                        id="send-subject"
                        value={sendForm.subject}
                        onChange={(e) => setSendForm({ ...sendForm, subject: e.target.value })}
                        placeholder="Enter email subject"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="send-body-html">HTML Body</Label>
                      <Textarea
                        id="send-body-html"
                        value={sendForm.body_html}
                        onChange={(e) => setSendForm({ ...sendForm, body_html: e.target.value })}
                        placeholder="Enter HTML email body"
                        rows={6}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="send-body-text">Text Body</Label>
                      <Textarea
                        id="send-body-text"
                        value={sendForm.body_text}
                        onChange={(e) => setSendForm({ ...sendForm, body_text: e.target.value })}
                        placeholder="Enter text email body"
                        rows={4}
                      />
                    </div>
                  </>
                )}

                <Button onClick={handleSendEmail} className="w-full">
                  Send Email
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" onClick={resetTemplateForm}>
                <Plus className="w-4 h-4 mr-2" />
                Create Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>
                  {editingTemplate ? 'Edit Template' : 'Create Email Template'}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="template-name">Template Name</Label>
                    <Input
                      id="template-name"
                      value={templateForm.name}
                      onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                      placeholder="Enter template name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="template-subject">Subject</Label>
                    <Input
                      id="template-subject"
                      value={templateForm.subject}
                      onChange={(e) => setTemplateForm({ ...templateForm, subject: e.target.value })}
                      placeholder="Enter email subject"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="template-body-html">HTML Body</Label>
                  <Textarea
                    id="template-body-html"
                    value={templateForm.body_html}
                    onChange={(e) => setTemplateForm({ ...templateForm, body_html: e.target.value })}
                    placeholder="Enter HTML email body"
                    rows={8}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="template-body-text">Text Body</Label>
                  <Textarea
                    id="template-body-text"
                    value={templateForm.body_text}
                    onChange={(e) => setTemplateForm({ ...templateForm, body_text: e.target.value })}
                    placeholder="Enter text email body"
                    rows={6}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="template-active"
                    checked={templateForm.is_active}
                    onChange={(e) => setTemplateForm({ ...templateForm, is_active: e.target.checked })}
                    className="rounded"
                  />
                  <Label htmlFor="template-active">Active</Label>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={resetTemplateForm}>
                    Cancel
                  </Button>
                  <Button onClick={handleTemplateSubmit}>
                    {editingTemplate ? 'Update Template' : 'Create Template'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Email Templates */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mail className="w-5 h-5 mr-2" />
              Email Templates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {templates.map((template) => (
                <div key={template.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="font-medium">{template.name}</h3>
                      <p className="text-sm text-muted-foreground">{template.subject}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={template.is_active ? "default" : "secondary"}>
                        {template.is_active ? "Active" : "Inactive"}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditTemplate(template)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteTemplate(template.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Variables: {template.variables.join(', ') || 'None'}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Email Logs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="w-5 h-5 mr-2" />
              Email Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {emailLogs.map((log) => (
                <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(log.status)}
                    <div>
                      <p className="text-sm font-medium">{log.recipient_email}</p>
                      <p className="text-xs text-muted-foreground">{log.subject}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(log.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusBadge(log.status)}
                    {log.template && (
                      <Badge variant="outline" className="text-xs">
                        {log.template.name}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
