"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { OrdersTable } from "@/components/orders-table"
import { salesOrders } from "@/lib/mock-orders"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function SalesOrdersPage() {
  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h1 className="text-3xl font-bold">Sales Orders</h1>
          <div className="flex gap-2">
            <Input placeholder="Search orders..." className="w-64" />
            <Button variant="outline">Filter</Button>
            <Button variant="default" className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg">
              Add Order
            </Button>
          </div>
        </div>
        <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
          <CardHeader>
            <CardTitle className="text-lg">All Sales Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <OrdersTable rows={salesOrders} kind="sales" />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
