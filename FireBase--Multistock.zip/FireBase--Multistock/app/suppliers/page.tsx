"use client"

import { useMemo, useState } from "react"
import { suppliers as seedSuppliers } from "@/lib/mock-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { AddSupplierDialog, type SupplierRow } from "@/components/dialogs/add-supplier-dialog"
import { load, save } from "@/lib/storage"

const KEY = "suppliers"

export default function SuppliersPage() {
  const initial = load<SupplierRow[]>(KEY, seedSuppliers as unknown as SupplierRow[])
  const [rows, setRows] = useState<SupplierRow[]>(initial)
  const [q, setQ] = useState("")

  const filtered = useMemo(() => {
    const term = q.toLowerCase()
    return rows.filter(
      (s) =>
        s.name.toLowerCase().includes(term) ||
        (s.email?.toLowerCase().includes(term) ?? false) ||
        (s.phone?.toLowerCase().includes(term) ?? false),
    )
  }, [q, rows])

  function handleAdded(row: SupplierRow) {
    const next = [row, ...rows]
    setRows(next)
    save(KEY, next)
  }

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-balance">Suppliers</h1>
        <AddSupplierDialog
          onAdded={handleAdded}
          trigger={
            <Button className="bg-primary text-primary-foreground hover:opacity-90">
              <Plus className="h-4 w-4 mr-1" aria-hidden="true" />
              New Supplier
            </Button>
          }
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm">Directory</CardTitle>
            <div className="w-64">
              <Input placeholder="Search suppliers..." value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-2">Name</th>
                  <th className="text-left p-2">Email</th>
                  <th className="text-left p-2">Phone</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr key={s.id} className="border-t">
                    <td className="p-2 font-medium">{s.name}</td>
                    <td className="p-2">{s.email ?? "-"}</td>
                    <td className="p-2">{s.phone ?? "-"}</td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td className="p-3 text-muted-foreground" colSpan={3}>
                      No suppliers. Add one to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
