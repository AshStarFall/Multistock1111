"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { Search, MessageCircle, Users, Plus } from 'lucide-react'
import ChatListItem from '@/components/chat/chat-list-item'
import ChatWindow from '@/components/chat/chat-window'
import { type Chat, type ChatMessage } from '@/lib/forum'

export default function ChatPage() {
  const { toast } = useToast()
  const [chats, setChats] = useState<Chat[]>([])
  const [activeChat, setActiveChat] = useState<Chat | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)
  
  const currentUserId = 'temp-user-id'

  useEffect(() => {
    loadChats()
  }, [])

  useEffect(() => {
    if (activeChat) {
      loadMessages(activeChat.id)
    }
  }, [activeChat])

  const loadChats = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/chat/conversations?userId=${currentUserId}`)
      if (!response.ok) throw new Error('Failed to load chats')
      const data = await response.json()
      setChats(data.chats || [])
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load chats",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const loadMessages = async (chatId: string) => {
    try {
      const response = await fetch(`/api/chat/messages?chatId=${chatId}`)
      if (!response.ok) throw new Error('Failed to load messages')
      const data = await response.json()
      setMessages(data.messages || [])
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load messages",
        variant: "destructive"
      })
    }
  }

  const handleSendMessage = async (content: string) => {
    if (!activeChat) return

    try {
      const response = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId: activeChat.id,
          senderId: currentUserId,
          content,
          type: 'text'
        })
      })

      if (!response.ok) throw new Error('Failed to send message')
      
      const data = await response.json()
      setMessages(prev => [...prev, data.message])
      
      // Update chat list
      await loadChats()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      })
    }
  }

  const handleSendFile = async (file: File) => {
    toast({
      title: "Uploading file...",
      description: file.name
    })
    // TODO: Implement file upload
  }

  const filteredChats = searchQuery
    ? chats.filter(chat => {
        const displayName = chat.type === 'group'
          ? chat.name || 'Group Chat'
          : chat.participants.find(p => p.userId !== currentUserId)?.userName || 'Unknown'
        return displayName.toLowerCase().includes(searchQuery.toLowerCase())
      })
    : chats

  return (
    <div className="h-screen bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto p-6 max-w-7xl h-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          {/* Chat List Sidebar */}
          <div className="lg:col-span-1 flex flex-col h-full">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-4"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-rose-600 rounded-xl flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">Messages</h1>
                  <p className="text-sm text-muted-foreground">
                    {chats.length} conversations
                  </p>
                </div>
              </div>

              {/* Search */}
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mb-4"
              />

              {/* New Chat Button */}
              <Button className="w-full mb-4">
                <Plus className="w-4 h-4 mr-2" />
                New Chat
              </Button>
            </motion.div>

            {/* Tabs */}
            <Tabs defaultValue="all" className="flex-1 flex flex-col min-h-0">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="all">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  All
                </TabsTrigger>
                <TabsTrigger value="groups">
                  <Users className="w-4 h-4 mr-2" />
                  Groups
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="flex-1 mt-4 overflow-hidden">
                <ScrollArea className="h-full">
                  {loading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin w-8 h-8 border-4 border-pink-600 border-t-transparent rounded-full mx-auto" />
                    </div>
                  ) : filteredChats.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No conversations yet</p>
                    </div>
                  ) : (
                    <div className="space-y-2 group">
                      {filteredChats.map((chat) => (
                        <ChatListItem
                          key={chat.id}
                          chat={chat}
                          currentUserId={currentUserId}
                          isActive={activeChat?.id === chat.id}
                          onClick={setActiveChat}
                        />
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              <TabsContent value="groups" className="flex-1 mt-4 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-2 group">
                    {filteredChats
                      .filter(chat => chat.type === 'group')
                      .map((chat) => (
                        <ChatListItem
                          key={chat.id}
                          chat={chat}
                          currentUserId={currentUserId}
                          isActive={activeChat?.id === chat.id}
                          onClick={setActiveChat}
                        />
                      ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>

          {/* Chat Window */}
          <div className="lg:col-span-2 h-full">
            {activeChat ? (
              <ChatWindow
                chat={activeChat}
                messages={messages}
                currentUserId={currentUserId}
                onSendMessage={handleSendMessage}
                onSendFile={handleSendFile}
              />
            ) : (
              <div className="h-full flex items-center justify-center border-2 border-dashed rounded-lg">
                <div className="text-center text-muted-foreground">
                  <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Select a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
