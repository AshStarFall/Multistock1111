"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { 
  Users, 
  Target, 
  Award, 
  Globe, 
  Shield, 
  TrendingUp, 
  Clock, 
  CheckCircle,
  Star,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Building,
  Truck,
  Package,
  BarChart3,
  Heart
} from "lucide-react"
import Image from "next/image"
import { motion } from "framer-motion"

export default function AboutUsPage() {
  const stats = [
    { icon: Users, label: "Team Members", value: "4", color: "text-blue-600" },
    { icon: Package, label: "Features Built", value: "50+", color: "text-green-600" },
    { icon: Calendar, label: "Project Started", value: "Aug 2025", color: "text-purple-600" },
    { icon: Award, label: "Technologies Used", value: "15+", color: "text-orange-600" }
  ]

  const values = [
    {
      icon: Shield,
      title: "Security First",
      description: "We prioritize the security of your data with enterprise-grade encryption and compliance standards."
    },
    {
      icon: Users,
      title: "Customer Centric",
      description: "Our customers are at the heart of everything we do. We listen, adapt, and deliver solutions that matter."
    },
    {
      icon: TrendingUp,
      title: "Innovation Driven",
      description: "We continuously innovate to provide cutting-edge solutions that keep you ahead of the competition."
    },
    {
      icon: CheckCircle,
      title: "Quality Assured",
      description: "Every product and service we deliver meets the highest standards of quality and reliability."
    }
  ]

  const team = [
    {
      name: "Ashish",
      role: "Lead Developer & System Architect",
      image: "/team/member1.jpg",
      description: "Expert in full-stack development, leading the system architecture and backend implementation.",
      skills: ["Next.js", "React", "PostgreSQL", "System Design"]
    },
    {
      name: "Harshitha",
      role: "Frontend Developer & UI/UX Designer",
      image: "/team/member2.jpg",
      description: "Passionate about creating beautiful and intuitive user experiences with modern design principles.",
      skills: ["React", "Tailwind CSS", "Framer Motion", "UI/UX Design"]
    },
    {
      name: "Avinash",
      role: "Backend Developer & Database Specialist",
      image: "/team/member3.jpg",
      description: "Database optimization expert specializing in scalable backend architectures and API development.",
      skills: ["Node.js", "PostgreSQL", "Supabase", "API Design"]
    },
    {
      name: "Ashray",
      role: "Full-stack Developer & DevOps Engineer",
      image: "/team/member4.jpg",
      description: "Specializes in deployment automation, cloud infrastructure, and full-stack development.",
      skills: ["DevOps", "Cloud", "CI/CD", "Full-stack Development"]
    }
  ]

  const milestones = [
    {
      year: "August 2025",
      title: "Project Inception",
      description: "MultiStock platform development began as a college project with a vision to revolutionize inventory management."
    },
    {
      year: "September 2025",
      title: "Core Features Development",
      description: "Implemented authentication, dashboard, inventory management, and multi-warehouse support."
    },
    {
      year: "October 2025",
      title: "Advanced Features Launch",
      description: "Released marketplace, rental system, payment integration, and real-time analytics."
    },
    {
      year: "Future",
      title: "AI & Automation",
      description: "Planning to introduce AI-powered inventory optimization and predictive analytics."
    }
  ]

  const guide = {
    name: "Dr. Professor Name",
    role: "Project Guide & Mentor",
    image: "/team/guide.jpg",
    description: "Experienced academic advisor guiding the team through the development lifecycle.",
    department: "Department of Computer Science"
  }

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl p-8 text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About MultiStock Platform
            </h1>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              A comprehensive inventory management platform developed by a dedicated team of students,
              combining modern technology with innovative solutions for efficient warehouse operations.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                <Calendar className="w-4 h-4 mr-2" />
                Started August 2025
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                <Users className="w-4 h-4 mr-2" />
                Student Project
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                <Globe className="w-4 h-4 mr-2" />
                Open Source
              </Badge>
            </div>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className={`w-12 h-12 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <h3 className="text-2xl font-bold mb-2">{stat.value}</h3>
              <p className="text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
          </motion.div>
        ))}
      </div>

      {/* Mission & Vision */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="flex items-center text-blue-800 dark:text-blue-400">
              <Target className="w-6 h-6 mr-2" />
              Our Mission
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-blue-700 dark:text-blue-300 leading-relaxed">
              To develop a comprehensive and user-friendly inventory management platform that demonstrates
              modern web technologies, scalable architecture, and practical solutions for real-world logistics
              challenges. Our goal is to create a system that bridges academic learning with industry applications.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-green-200 dark:border-green-800">
          <CardHeader>
            <CardTitle className="flex items-center text-green-800 dark:text-green-400">
              <Star className="w-6 h-6 mr-2" />
              Our Vision
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-green-700 dark:text-green-300 leading-relaxed">
              To showcase how modern technology can transform traditional inventory management into an
              intelligent, automated, and efficient system. We envision this project as a foundation for
              future innovations in logistics and supply chain management.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Core Values */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-2xl">Our Core Values</CardTitle>
          <p className="text-center text-muted-foreground">
            The principles that guide everything we do
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {values.map((value, index) => (
              <div key={index} className="flex items-start space-x-4 p-4 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <value.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">{value.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {value.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Team Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-2xl">Meet Our Team</CardTitle>
          <p className="text-center text-muted-foreground">
            The talented individuals behind MultiStock Platform
          </p>
        </CardHeader>
        <CardContent>
          {/* Project Guide */}
          <div className="mb-8 p-6 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-2 border-blue-200 dark:border-blue-800">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="relative">
                <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-blue-500">
                  <Image
                    src={guide.image}
                    alt={guide.name}
                    width={96}
                    height={96}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none'
                      const parent = e.currentTarget.parentElement
                      if (parent) {
                        parent.innerHTML = '<div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-500 text-white text-2xl font-bold">GP</div>'
                      }
                    }}
                  />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-2">
                  <Star className="w-4 h-4" fill="currentColor" />
                </div>
              </div>
              <div className="text-center md:text-left flex-1">
                <h3 className="text-xl font-bold mb-1">{guide.name}</h3>
                <p className="text-blue-600 dark:text-blue-400 font-medium mb-1">{guide.role}</p>
                <p className="text-sm text-muted-foreground mb-2">{guide.department}</p>
                <p className="text-sm text-muted-foreground">{guide.description}</p>
              </div>
            </div>
          </div>

          {/* Team Members */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-all hover:-translate-y-1 group">
                <CardContent className="p-6">
                  <div className="relative w-24 h-24 mx-auto mb-4">
                    <div className="w-full h-full rounded-full overflow-hidden ring-2 ring-muted group-hover:ring-primary transition-all">
                      <Image
                        src={member.image}
                        alt={member.name}
                        width={96}
                        height={96}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none'
                          const parent = e.currentTarget.parentElement
                          if (parent) {
                            const initials = member.name.split(' ').map(n => n[0]).join('')
                            parent.innerHTML = `<div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-500 text-white text-xl font-bold">${initials}</div>`
                          }
                        }}
                      />
                    </div>
                  </div>
                  <h3 className="font-semibold text-lg mb-1">{member.name}</h3>
                  <p className="text-sm text-primary mb-3 font-medium">{member.role}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed mb-3">
                    {member.description}
                  </p>
                  <div className="flex flex-wrap gap-1 justify-center">
                    {member.skills.map((skill, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Company Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-2xl">Our Journey</CardTitle>
          <p className="text-center text-muted-foreground">
            Key milestones in our project development
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant="outline" className="bg-primary/10 text-primary">
                      {milestone.year}
                    </Badge>
                    <h3 className="font-semibold">{milestone.title}</h3>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {milestone.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Technology Stack */}
      <Card className="bg-gradient-to-br from-gray-50 to-gray-100">
        <CardHeader>
          <CardTitle className="text-center text-2xl">Technology & Innovation</CardTitle>
          <p className="text-center text-muted-foreground">
            Built with cutting-edge technology for maximum performance
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">AI & Analytics</h3>
              <p className="text-sm text-muted-foreground">
                Machine learning algorithms for predictive analytics and intelligent inventory optimization.
              </p>
            </div>
            <div className="text-center p-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Security & Compliance</h3>
              <p className="text-sm text-muted-foreground">
                Enterprise-grade security with SOC 2 compliance and end-to-end encryption.
              </p>
            </div>
            <div className="text-center p-4">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Cloud Infrastructure</h3>
              <p className="text-sm text-muted-foreground">
                Scalable cloud architecture ensuring 99.9% uptime and global accessibility.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Transform Your Business?</h2>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Join thousands of satisfied customers who have revolutionized their inventory management 
            with MultiStock Logistics. Let's build the future of logistics together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="secondary" size="lg">
              <Users className="w-4 h-4 mr-2" />
              Get Started Today
            </Button>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Phone className="w-4 h-4 mr-2" />
              Contact Sales
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
