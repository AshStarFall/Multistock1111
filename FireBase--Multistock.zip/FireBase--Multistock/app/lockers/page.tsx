"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AuthGuard } from "@/components/auth-guard"
import { AppLayout } from "@/components/app-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Lock, 
  Thermometer, 
  Search, 
  Plus, 
  Package, 
  CheckCircle2, 
  XCircle,
  AlertCircle 
} from "lucide-react"

type LockerType = 'small' | 'medium' | 'large' | 'xl' | 'climate-controlled'
type LockerStatus = 'available' | 'in_use' | 'maintenance'

interface Locker {
  id: string
  type: LockerType
  status: LockerStatus
  location: string
  monthlyRate: number
  dimensions: string
  lastUpdate: string
  currentUser?: string
}

const lockers: Locker[] = [
  { id: "L-101", type: "small", status: "available", location: "Building A, Floor 1", monthlyRate: 500, dimensions: "12x12x18 in", lastUpdate: "2025-10-01" },
  { id: "L-102", type: "medium", status: "in_use", location: "Building A, Floor 1", monthlyRate: 800, dimensions: "18x18x24 in", lastUpdate: "2025-10-03", currentUser: "John Doe" },
  { id: "L-103", type: "large", status: "available", location: "Building A, Floor 2", monthlyRate: 1200, dimensions: "24x24x36 in", lastUpdate: "2025-09-28" },
  { id: "L-104", type: "xl", status: "in_use", location: "Building B, Floor 1", monthlyRate: 1800, dimensions: "36x36x48 in", lastUpdate: "2025-10-05", currentUser: "Jane Smith" },
  { id: "L-105", type: "climate-controlled", status: "available", location: "Building B, Floor 2", monthlyRate: 2500, dimensions: "24x24x36 in", lastUpdate: "2025-10-02" },
  { id: "L-106", type: "small", status: "maintenance", location: "Building A, Floor 1", monthlyRate: 500, dimensions: "12x12x18 in", lastUpdate: "2025-09-25" },
  { id: "L-107", type: "climate-controlled", status: "in_use", location: "Building B, Floor 2", monthlyRate: 2500, dimensions: "24x24x36 in", lastUpdate: "2025-10-04", currentUser: "Bob Wilson" },
  { id: "L-108", type: "medium", status: "available", location: "Building A, Floor 2", monthlyRate: 800, dimensions: "18x18x24 in", lastUpdate: "2025-10-01" },
]

export default function LockersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<LockerType | 'all'>('all')
  const [selectedStatus, setSelectedStatus] = useState<LockerStatus | 'all'>('all')

  const getTypeIcon = (type: LockerType) => {
    if (type === 'climate-controlled') return <Thermometer className="w-4 h-4" />
    return <Lock className="w-4 h-4" />
  }

  const getTypeColor = (type: LockerType) => {
    switch (type) {
      case 'small': return 'bg-blue-500'
      case 'medium': return 'bg-green-500'
      case 'large': return 'bg-purple-500'
      case 'xl': return 'bg-orange-500'
      case 'climate-controlled': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusIcon = (status: LockerStatus) => {
    switch (status) {
      case 'available': return <CheckCircle2 className="w-4 h-4 text-green-600" />
      case 'in_use': return <XCircle className="w-4 h-4 text-red-600" />
      case 'maintenance': return <AlertCircle className="w-4 h-4 text-yellow-600" />
    }
  }

  const getStatusBadge = (status: LockerStatus) => {
    switch (status) {
      case 'available': return <Badge variant="default" className="bg-green-600">Available</Badge>
      case 'in_use': return <Badge variant="destructive">In Use</Badge>
      case 'maintenance': return <Badge variant="secondary" className="bg-yellow-600">Maintenance</Badge>
    }
  }

  const filteredLockers = lockers.filter(locker => {
    const matchesSearch = locker.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         locker.location.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = selectedType === 'all' || locker.type === selectedType
    const matchesStatus = selectedStatus === 'all' || locker.status === selectedStatus
    return matchesSearch && matchesType && matchesStatus
  })

  const stats = {
    total: lockers.length,
    available: lockers.filter(l => l.status === 'available').length,
    in_use: lockers.filter(l => l.status === 'in_use').length,
    maintenance: lockers.filter(l => l.status === 'maintenance').length,
  }

  const router = useRouter()

  return (
    <AppLayout>
      <AuthGuard roles={["employee", "team_leader", "manager", "subadmin", "admin", "customer"]}>
        <div className="space-y-6">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold mb-2">Lockers</h1>
              <p className="text-muted-foreground">Manage storage lockers and access</p>
            </div>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Locker
            </Button>
          </div>

          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Lockers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-green-600">Available</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{stats.available}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-red-600">In Use</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{stats.in_use}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-yellow-600">Maintenance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">{stats.maintenance}</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                {/* Search */}
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by ID or location..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Type Filter */}
                <Tabs value={selectedType} onValueChange={(v) => setSelectedType(v as LockerType | 'all')}>
                  <TabsList>
                    <TabsTrigger value="all">All Types</TabsTrigger>
                    <TabsTrigger value="small">Small</TabsTrigger>
                    <TabsTrigger value="medium">Medium</TabsTrigger>
                    <TabsTrigger value="large">Large</TabsTrigger>
                    <TabsTrigger value="xl">XL</TabsTrigger>
                    <TabsTrigger value="climate-controlled">Climate</TabsTrigger>
                  </TabsList>
                </Tabs>

                {/* Status Filter */}
                <Tabs value={selectedStatus} onValueChange={(v) => setSelectedStatus(v as LockerStatus | 'all')}>
                  <TabsList>
                    <TabsTrigger value="all">All Status</TabsTrigger>
                    <TabsTrigger value="available">Available</TabsTrigger>
                    <TabsTrigger value="in_use">In Use</TabsTrigger>
                    <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardContent>
          </Card>

          {/* Lockers Grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredLockers.map((locker) => (
              <Card key={locker.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-lg ${getTypeColor(locker.type)} flex items-center justify-center text-white`}>
                        {getTypeIcon(locker.type)}
                      </div>
                      <CardTitle className="text-lg">{locker.id}</CardTitle>
                    </div>
                    {getStatusIcon(locker.status)}
                  </div>
                  <CardDescription className="text-xs capitalize">
                    {locker.type.replace('-', ' ')} locker
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Package className="w-3 h-3" />
                      <span>{locker.dimensions}</span>
                    </div>
                    <div className="text-muted-foreground">
                      {locker.location}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">₹{locker.monthlyRate}/month</span>
                      {getStatusBadge(locker.status)}
                    </div>
                    {locker.currentUser && (
                      <div className="text-xs text-muted-foreground">
                        User: {locker.currentUser}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 pt-2">
                    {locker.status === 'available' ? (
                      <Button 
                        className="w-full" 
                        size="sm"
                        onClick={() => router.push(`/lockers/${locker.id}/book`)}
                      >
                        Book Now
                      </Button>
                    ) : (
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        size="sm"
                        onClick={() => router.push(`/lockers/${locker.id}`)}
                      >
                        View Details
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredLockers.length === 0 && (
            <Card>
              <CardContent className="p-12 text-center">
                <Lock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No lockers found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search or filters
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </AuthGuard>
    </AppLayout>
  )
}


