"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { 
  Search, 
  HelpCircle, 
  BookOpen, 
  MessageCircle, 
  Phone, 
  Mail, 
  Clock, 
  CheckCircle,
  ChevronDown,
  ChevronRight,
  Video,
  FileText,
  Download,
  ExternalLink,
  Headphones,
  Settings,
  Shield,
  Zap,
  Users,
  BarChart3,
  Package,
  Truck,
  AlertCircle,
  Lightbulb,
  Star,
  ThumbsUp,
  ThumbsDown
} from "lucide-react"

export default function SupportHelpPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({})

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }))
  }

  const quickHelp = [
    {
      icon: Package,
      title: "Getting Started",
      description: "Learn the basics of inventory management",
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: Users,
      title: "User Management",
      description: "Manage users, roles, and permissions",
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      icon: BarChart3,
      title: "Reports & Analytics",
      description: "Generate and understand reports",
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      icon: Settings,
      title: "System Settings",
      description: "Configure your system preferences",
      color: "text-orange-600",
      bgColor: "bg-orange-50"
    }
  ]

  const faqCategories = [
    {
      title: "Account & Login",
      icon: Users,
      questions: [
        {
          question: "How do I reset my password?",
          answer: "To reset your password, click on 'Forgot Password' on the login page, enter your email address, and follow the instructions sent to your email. If you don't receive the email, check your spam folder or contact support."
        },
        {
          question: "How do I change my profile information?",
          answer: "Go to your Profile page from the sidebar menu. Click 'Edit Profile' to modify your personal information, including name, phone number, department, and bio. Remember to save your changes."
        },
        {
          question: "Can I have multiple user accounts?",
          answer: "Yes, you can have multiple user accounts with different roles and permissions. Contact your administrator to create additional accounts or manage existing ones."
        },
        {
          question: "What are the different user roles?",
          answer: "We have several user roles: Admin (full administrative access), Manager (management oversight), Team Leader (team coordination), Employee (basic operations), Customer (shopping features), and Guest (limited browsing)."
        }
      ]
    },
    {
      title: "Inventory Management",
      icon: Package,
      questions: [
        {
          question: "How do I add new products to my inventory?",
          answer: "Navigate to Admin > Product Management or Inventory > Products. Click 'Add Product' and fill in the required information including name, SKU, category, cost, and reorder point. You can also upload product images."
        },
        {
          question: "What is a reorder point?",
          answer: "A reorder point is the minimum stock level at which you should place a new order to avoid stockouts. The system will alert you when inventory falls below this level."
        },
        {
          question: "How do I track inventory movements?",
          answer: "All inventory movements are automatically tracked in the system. You can view detailed reports in the Reports section, including inbound, outbound, and transfer movements."
        },
        {
          question: "Can I import products from a spreadsheet?",
          answer: "Yes, you can import products using CSV files. Go to Products page and click 'Import Products'. Download the template, fill in your data, and upload the file."
        }
      ]
    },
    {
      title: "Orders & Fulfillment",
      icon: Truck,
      questions: [
        {
          question: "How do I create a new order?",
          answer: "Go to Orders section and click 'Create Order'. Select the customer, add products, specify quantities, and set delivery details. The system will automatically calculate totals and taxes."
        },
        {
          question: "How do I track order status?",
          answer: "Order status can be tracked in the Orders section. You'll see real-time updates including 'Pending', 'Processing', 'Shipped', and 'Delivered' statuses."
        },
        {
          question: "What happens when an order is placed?",
          answer: "When an order is placed, the system automatically reserves inventory, generates a confirmation, sends notifications to relevant parties, and updates stock levels."
        },
        {
          question: "Can I modify or cancel an order?",
          answer: "Orders can be modified or cancelled before they enter the 'Processing' status. After processing begins, contact support for assistance with order changes."
        }
      ]
    },
    {
      title: "Reports & Analytics",
      icon: BarChart3,
      questions: [
        {
          question: "What types of reports are available?",
          answer: "We offer comprehensive reports including inventory reports, sales reports, customer reports, financial reports, and custom analytics. All reports can be exported in various formats."
        },
        {
          question: "How do I generate custom reports?",
          answer: "Go to Reports section and select 'Custom Report'. Choose your data fields, filters, date ranges, and output format. Save your custom reports for future use."
        },
        {
          question: "Can I schedule automatic reports?",
          answer: "Yes, you can schedule reports to be generated and emailed automatically on a daily, weekly, or monthly basis. Set this up in the Reports settings."
        },
        {
          question: "How do I interpret the analytics dashboard?",
          answer: "The analytics dashboard shows key performance indicators, trends, and insights. Hover over charts for detailed information and use filters to analyze specific time periods or categories."
        }
      ]
    },
    {
      title: "Technical Support",
      icon: Settings,
      questions: [
        {
          question: "What browsers are supported?",
          answer: "We support all modern browsers including Chrome, Firefox, Safari, and Edge. For the best experience, we recommend using the latest version of Chrome."
        },
        {
          question: "Is there a mobile app?",
          answer: "Yes, we have mobile apps for both iOS and Android. Download from the App Store or Google Play Store. The mobile app provides core functionality for inventory management on the go."
        },
        {
          question: "How do I backup my data?",
          answer: "Your data is automatically backed up daily on our secure servers. You can also export your data manually from the Settings page. We maintain multiple backup copies for data protection."
        },
        {
          question: "What if I encounter technical issues?",
          answer: "For technical issues, contact our support team via email (support@multistock.com), phone (+91 98765 43210), or live chat. We provide 24/7 technical support."
        }
      ]
    }
  ]

  const supportChannels = [
    {
      icon: MessageCircle,
      title: "Live Chat",
      description: "Get instant help from our support team",
      availability: "24/7 Available",
      responseTime: "Instant",
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      icon: Phone,
      title: "Phone Support",
      description: "Speak directly with our experts",
      availability: "Mon-Fri 9AM-6PM IST",
      responseTime: "Immediate",
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: Mail,
      title: "Email Support",
      description: "Send detailed queries via email",
      availability: "24/7 Available",
      responseTime: "Within 4 hours",
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      icon: Video,
      title: "Video Call",
      description: "Schedule a screen sharing session",
      availability: "By Appointment",
      responseTime: "Scheduled",
      color: "text-orange-600",
      bgColor: "bg-orange-50"
    }
  ]

  const resources = [
    {
      icon: BookOpen,
      title: "User Manual",
      description: "Comprehensive guide to all features",
      type: "PDF Document",
      size: "2.5 MB",
      downloads: "1,234"
    },
    {
      icon: Video,
      title: "Getting Started Video",
      description: "Step-by-step video tutorial",
      type: "Video",
      size: "45 MB",
      downloads: "856"
    },
    {
      icon: FileText,
      title: "API Documentation",
      description: "Technical documentation for developers",
      type: "PDF Document",
      size: "1.8 MB",
      downloads: "567"
    },
    {
      icon: Download,
      title: "Import Templates",
      description: "Excel templates for data import",
      type: "Excel File",
      size: "0.5 MB",
      downloads: "2,345"
    }
  ]

  const filteredFAQs = faqCategories.map(category => ({
    ...category,
    questions: category.questions.filter(q => 
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.answer.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0)

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="space-y-6">
        {/* Announcement panel at top */}
        <Card className="rounded-xl shadow-md bg-gradient-to-br from-blue-50 to-white dark:from-blue-900 dark:to-slate-900 mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Announcements</CardTitle>
          </CardHeader>
          <CardContent>
            {/* ...existing code for announcements... */}
          </CardContent>
        </Card>
        {/* Ticket submission form */}
        <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Submit a Ticket</CardTitle>
          </CardHeader>
          <CardContent>
            {/* ...existing code for form... */}
          </CardContent>
        </Card>
        {/* FAQ and community section */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* ...existing code for FAQ and community... */}
        </div>
      </div>
    </div>
  )
}
