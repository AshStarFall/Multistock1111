"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { Search, MessageSquare, Plus, Filter } from 'lucide-react'
import ThreadCard from '@/components/forum/thread-card'
import { 
  type ForumCategory,
  type ForumThread,
  FORUM_CATEGORIES,
  getCategoryColor,
  sortThreads,
  searchThreads
} from '@/lib/forum'

export default function ForumPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState('all')
  const [categories, setCategories] = useState<ForumCategory[]>([])
  const [threads, setThreads] = useState<ForumThread[]>([])
  const [filteredThreads, setFilteredThreads] = useState<ForumThread[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState<'latest' | 'popular' | 'oldest' | 'replies'>('latest')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadCategories()
    loadThreads()
  }, [])

  useEffect(() => {
    filterAndSortThreads()
  }, [threads, activeTab, searchQuery, sortBy])

  const loadCategories = async () => {
    try {
      // TODO: Fetch from API
      setCategories(FORUM_CATEGORIES.map((cat, index) => ({
        ...cat,
        id: `cat-${index}`,
        threadCount: Math.floor(Math.random() * 100),
        postCount: Math.floor(Math.random() * 1000),
        createdAt: new Date()
      })))
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load categories",
        variant: "destructive"
      })
    }
  }

  const loadThreads = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/forum/threads')
      if (!response.ok) throw new Error('Failed to load threads')
      const data = await response.json()
      setThreads(data.threads || [])
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load threads",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const filterAndSortThreads = () => {
    let filtered = [...threads]

    // Filter by category
    if (activeTab !== 'all') {
      filtered = filtered.filter(t => t.categoryId === activeTab)
    }

    // Search
    if (searchQuery) {
      filtered = searchThreads(filtered, searchQuery)
    }

    // Sort
    filtered = sortThreads(filtered, sortBy)

    setFilteredThreads(filtered)
  }

  const handleThreadClick = (thread: ForumThread) => {
    window.location.href = `/forum/threads/${thread.id}`
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto p-6 max-w-7xl space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-teal-600 rounded-xl flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Community Forum</h1>
                <p className="text-muted-foreground">Connect, discuss, and share with the community</p>
              </div>
            </div>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Thread
            </Button>
          </div>
        </motion.div>

        {/* Search & Filters */}
        <div className="flex gap-4">
          <form onSubmit={handleSearch} className="flex-1 flex gap-2">
            <Input
              placeholder="Search threads..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Button type="submit">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </form>

          <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
            <SelectTrigger className="w-[180px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="latest">Latest Activity</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="replies">Most Replies</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Categories Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full grid grid-cols-4 lg:grid-cols-7 gap-2 h-auto p-2 bg-transparent">
            <TabsTrigger value="all" className="data-[state=active]:bg-slate-200 dark:data-[state=active]:bg-slate-800">
              All
            </TabsTrigger>
            {categories.map((category) => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="data-[state=active]:bg-slate-200 dark:data-[state=active]:bg-slate-800"
              >
                <span className="mr-1">{category.icon}</span>
                <span className="hidden lg:inline">{category.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4 mt-6">
            {/* Category Stats */}
            {activeTab !== 'all' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {categories
                  .filter(c => c.id === activeTab)
                  .map((category) => (
                    <motion.div
                      key={category.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="col-span-full"
                    >
                      <div className={`p-6 rounded-lg ${getCategoryColor(category.color)}`}>
                        <div className="flex items-center gap-3 mb-2">
                          <span className="text-3xl">{category.icon}</span>
                          <div>
                            <h2 className="text-2xl font-bold">{category.name}</h2>
                            <p className="text-sm opacity-90">{category.description}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 mt-4">
                          <div>
                            <div className="text-2xl font-bold">{category.threadCount}</div>
                            <div className="text-sm opacity-90">Threads</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold">{category.postCount}</div>
                            <div className="text-sm opacity-90">Posts</div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
              </div>
            )}

            {/* Threads List */}
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full mx-auto" />
                <p className="text-muted-foreground mt-4">Loading threads...</p>
              </div>
            ) : filteredThreads.length === 0 ? (
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 mx-auto text-muted-foreground opacity-50 mb-4" />
                <h3 className="text-xl font-semibold mb-2">No threads found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchQuery 
                    ? 'Try adjusting your search query'
                    : 'Be the first to start a discussion!'}
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Thread
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredThreads.map((thread) => (
                  <ThreadCard
                    key={thread.id}
                    thread={thread}
                    onClick={handleThreadClick}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
