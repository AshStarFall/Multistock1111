"use client"

import { load, save } from "@/lib/storage"
import { AuthGuard } from "@/components/auth-guard"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useState } from "react"

type Referral = { id: string; code: string; referredEmail: string; status: "pending" | "signed_up" }
const KEY = "msl-referrals"

export default function ReferralsPage() {
  const [items, setItems] = useState<Referral[]>(() => load<Referral[]>(KEY, []))
  const [email, setEmail] = useState("")
  const [code, setCode] = useState(() => (load<string>("msl-ref-code", "") || `REF${Math.random().toString(36).slice(2, 7)}`).toUpperCase())

  function sendInvite() {
    if (!email) return
    const next = [{ id: crypto.randomUUID(), code, referredEmail: email, status: "pending" }, ...items]
    setItems(next)
    save(KEY, next)
    setEmail("")
    save("msl-ref-code", code)
  }

  return (
    <AuthGuard roles={["customer", "employee", "manager", "subadmin", "admin"]}>
      <section className="space-y-4">
        <h1 className="text-xl font-semibold">Referrals</h1>
        <div className="flex gap-2 items-end">
          <div>
            <label className="block text-xs mb-1">Your code</label>
            <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} />
          </div>
          <div>
            <label className="block text-xs mb-1">Invite email</label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <Button onClick={sendInvite}>Send invite</Button>
        </div>
        <div className="overflow-auto rounded-md border">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left p-2">Email</th>
                <th className="text-left p-2">Code</th>
                <th className="text-left p-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="p-2">{r.referredEmail}</td>
                  <td className="p-2">{r.code}</td>
                  <td className="p-2">{r.status}</td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td className="p-3 text-muted-foreground" colSpan={3}>
                    No referrals yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </AuthGuard>
  )
}


