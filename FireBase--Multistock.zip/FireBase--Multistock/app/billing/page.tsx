"use client"

import { useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { usePersistentState } from "@/lib/persistence"

export default function BillingPage() {
  const [items, setItems] = usePersistentState<{ desc: string; qty: number; price: number }[]>(
    "billing-items",
    [
      { desc: "Rental - Forklift", qty: 2, price: 120 },
      { desc: "Storage - Pallet", qty: 5, price: 15 },
    ],
  )
  const [desc, setDesc] = useState("")
  const [qty, setQty] = useState(1)
  const [price, setPrice] = useState(0)
  const subtotal = useMemo(() => items.reduce((s, it) => s + it.qty * it.price, 0), [items])
  const tax = useMemo(() => subtotal * 0.1, [subtotal])
  const total = subtotal + tax

  function addItem() {
    if (!desc || qty <= 0 || price <= 0) return
    setItems([{ desc, qty, price }, ...items])
    setDesc("")
    setQty(1)
    setPrice(0)
  }

  function exportCSV() {
    const header = ["desc", "qty", "price", "amount"]
    const rows = items.map((it) => [it.desc, it.qty, it.price.toFixed(2), (it.qty * it.price).toFixed(2)])
    const summary = [
      [],
      ["subtotal", "", "", subtotal.toFixed(2)],
      ["tax", "", "", tax.toFixed(2)],
      ["total", "", "", total.toFixed(2)],
    ]
    const csv = [header, ...rows, ...summary].map((r) => r.join(",")).join("\n")
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "invoice.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  function printInvoice() {
    window.print()
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
        <h1 className="text-3xl font-bold">Billing</h1>
      </div>

      <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
        <CardHeader>
          <CardTitle className="text-lg">Invoice Builder</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
            <div>
              <label className="block text-xs mb-1">Description</label>
              <Input value={desc} onChange={(e) => setDesc(e.target.value)} />
            </div>
            <div>
              <label className="block text-xs mb-1">Qty</label>
              <Input type="number" value={qty} onChange={(e) => setQty(Number(e.target.value))} />
            </div>
            <div>
              <label className="block text-xs mb-1">Price</label>
              <Input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} />
            </div>
            <Button onClick={addItem} className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white">Add</Button>
          </div>
          <div className="overflow-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800">
                <tr>
                  <th className="text-left p-2">Item</th>
                  <th className="text-right p-2">Qty</th>
                  <th className="text-right p-2">Price</th>
                  <th className="text-right p-2">Amount</th>
                </tr>
              </thead>
              <tbody>
                {items.map((it, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-2">{it.desc}</td>
                    <td className="p-2 text-right">{it.qty}</td>
                    <td className="p-2 text-right">₹{it.price.toFixed(2)}</td>
                    <td className="p-2 text-right">₹{(it.qty * it.price).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex flex-col sm:flex-row sm:justify-end gap-3 text-sm">
            <div>Subtotal: ₹{subtotal.toFixed(2)}</div>
            <div>Tax (10%): ₹{tax.toFixed(2)}</div>
            <div className="font-medium">Total: ₹{total.toFixed(2)}</div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={exportCSV}>Export CSV</Button>
            <Button onClick={printInvoice} className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white">Print</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
        <CardHeader>
          <CardTitle className="text-lg">Checkout</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground mb-4">Demo checkout. Integrate gateway webhooks later.</div>
          <Button onClick={() => alert("Payment initiated (demo)")} className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white">
            Pay ₹{total.toFixed(2)}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}


