"use client"

import { useState, useEffect, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { useAuth } from "@/lib/auth-context"
import { toast } from "sonner"
import Image from "next/image"
import { 
  Search, 
  Filter, 
  MapPin,
  Clock,
  Shield,
  Package,
  Truck,
  CheckCircle,
  AlertCircle,
  Calendar as CalendarIcon,
  DollarSign,
  Ruler,
  Thermometer,
  Lock,
  Eye,
  Plus,
  Minus,
  Grid3x3,
  List,
  SlidersHorizontal,
  Heart,
  Star,
  TrendingUp,
  X,
  Zap
} from "lucide-react"

interface StorageSlot {
  id: string
  name: string
  type: string
  size: string
  location: string
  monthlyRate: number
  available: boolean
  features: string[]
  specifications: Record<string, string>
  warehouse: {
    name: string
    address: string
    phone: string
    email: string
    rating: number
    security: string[]
  }
}

export default function StoragePage() {
  const { user, isAuthenticated, isGuest } = useAuth()
  const [storageSlots, setStorageSlots] = useState<StorageSlot[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedLocation, setSelectedLocation] = useState("all")
  const [selectedSlot, setSelectedSlot] = useState<StorageSlot | null>(null)
  const [startDate, setStartDate] = useState<Date | undefined>(new Date())
  const [endDate, setEndDate] = useState<Date | undefined>(new Date())
  const [quantity, setQuantity] = useState(1)

  // E-commerce features
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState('price-low')
  const [priceRange, setPriceRange] = useState([0, 1000])
  const [minRating, setMinRating] = useState(0)
  const [showFilters, setShowFilters] = useState(false)
  const [wishlist, setWishlist] = useState<string[]>([])

  // Wishlist toggle
  const toggleWishlist = (slotId: string) => {
    setWishlist(prev => {
      if (prev.includes(slotId)) {
        toast.success("Removed from wishlist")
        return prev.filter(id => id !== slotId)
      } else {
        toast.success("Added to wishlist")
        return [...prev, slotId]
      }
    })
  }

  // Mock storage data
  const mockStorage: StorageSlot[] = [
    {
      id: "1",
      name: "Small Storage Unit",
      type: "Standard",
      size: "5x5x8 ft",
      location: "Mumbai, Maharashtra",
      monthlyRate: 150,
      available: true,
      features: ["Climate Controlled", "24/7 Access", "Security Cameras", "Insurance Included"],
      specifications: {
        "Dimensions": "5x5x8 ft",
        "Volume": "200 cubic ft",
        "Weight Limit": "1000 lbs",
        "Access": "24/7",
        "Security": "CCTV + Key Card"
      },
      warehouse: {
        name: "SecureStore Mumbai",
        address: "123 Business Park, Mumbai, Maharashtra 400001",
        phone: "+91 98765 43210",
        email: "mumbai@securestore.com",
        rating: 4.8,
        security: ["CCTV Surveillance", "Key Card Access", "Security Guards", "Fire Suppression"]
      }
    },
    {
      id: "2",
      name: "Medium Storage Unit",
      type: "Climate Controlled",
      size: "10x10x8 ft",
      location: "Bangalore, Karnataka",
      monthlyRate: 300,
      available: true,
      features: ["Climate Controlled", "24/7 Access", "Security Cameras", "Insurance Included", "Loading Dock"],
      specifications: {
        "Dimensions": "10x10x8 ft",
        "Volume": "800 cubic ft",
        "Weight Limit": "2000 lbs",
        "Temperature": "65-75°F",
        "Humidity": "45-55%"
      },
      warehouse: {
        name: "ClimateStore Bangalore",
        address: "456 Tech Hub, Bangalore, Karnataka 560001",
        phone: "+91 87654 32109",
        email: "bangalore@climatestore.com",
        rating: 4.9,
        security: ["CCTV Surveillance", "Biometric Access", "Security Guards", "Fire Suppression", "Climate Monitoring"]
      }
    },
    {
      id: "3",
      name: "Large Storage Unit",
      type: "Warehouse",
      size: "20x20x12 ft",
      location: "Delhi, NCR",
      monthlyRate: 600,
      available: true,
      features: ["Climate Controlled", "24/7 Access", "Security Cameras", "Insurance Included", "Loading Dock", "Forklift Access"],
      specifications: {
        "Dimensions": "20x20x12 ft",
        "Volume": "4800 cubic ft",
        "Weight Limit": "5000 lbs",
        "Access": "24/7",
        "Loading": "Forklift Available"
      },
      warehouse: {
        name: "MegaStore Delhi",
        address: "789 Industrial Area, Delhi, NCR 110001",
        phone: "+91 76543 21098",
        email: "delhi@megastore.com",
        rating: 4.7,
        security: ["CCTV Surveillance", "Key Card Access", "Security Guards", "Fire Suppression", "Perimeter Fencing"]
      }
    },
    {
      id: "4",
      name: "Cold Storage Unit",
      type: "Cold Storage",
      size: "8x8x8 ft",
      location: "Chennai, Tamil Nadu",
      monthlyRate: 400,
      available: true,
      features: ["Temperature Controlled", "24/7 Access", "Security Cameras", "Insurance Included", "Food Grade"],
      specifications: {
        "Dimensions": "8x8x8 ft",
        "Volume": "512 cubic ft",
        "Temperature": "32-40°F",
        "Weight Limit": "1500 lbs",
        "Grade": "Food Safe"
      },
      warehouse: {
        name: "ColdStore Chennai",
        address: "321 Food Park, Chennai, Tamil Nadu 600001",
        phone: "+91 65432 10987",
        email: "chennai@coldstore.com",
        rating: 4.8,
        security: ["CCTV Surveillance", "Temperature Monitoring", "Security Guards", "Fire Suppression", "Backup Power"]
      }
    }
  ]

  useEffect(() => {
    setStorageSlots(mockStorage)
  }, [])

  const filteredSlots = storageSlots.filter(slot => {
    const matchesSearch = searchQuery === "" || 
      slot.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      slot.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      slot.location.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesType = selectedType === "all" || slot.type === selectedType
    const matchesLocation = selectedLocation === "all" || slot.location === selectedLocation
    const matchesPrice = slot.monthlyRate >= priceRange[0] && slot.monthlyRate <= priceRange[1]
    const matchesRating = slot.warehouse.rating >= minRating
    
    return matchesSearch && matchesType && matchesLocation && matchesPrice && matchesRating && slot.available
  })

  // Sorting logic
  const sortedSlots = useMemo(() => {
    const sorted = [...filteredSlots]
    switch (sortBy) {
      case 'price-low':
        return sorted.sort((a, b) => a.monthlyRate - b.monthlyRate)
      case 'price-high':
        return sorted.sort((a, b) => b.monthlyRate - a.monthlyRate)
      case 'rating':
        return sorted.sort((a, b) => b.warehouse.rating - a.warehouse.rating)
      case 'name':
        return sorted.sort((a, b) => a.name.localeCompare(b.name))
      case 'size':
        return sorted.sort((a, b) => {
          const aSize = parseInt(a.size.split('x')[0])
          const bSize = parseInt(b.size.split('x')[0])
          return bSize - aSize
        })
      default:
        return sorted.sort((a, b) => b.warehouse.rating * 100 - a.warehouse.rating * 100)
    }
  }, [filteredSlots, sortBy])

  const calculateTotalCost = (slot: StorageSlot, months: number) => {
    return slot.monthlyRate * months * quantity
  }

  const handleStorageRequest = (slot: StorageSlot) => {
    if (!isAuthenticated && !isGuest) {
      toast.error("Please sign in to request storage")
      return
    }
    
    const months = Math.ceil((endDate!.getTime() - startDate!.getTime()) / (1000 * 60 * 60 * 24 * 30))
    const totalCost = calculateTotalCost(slot, months)
    
    toast.success(`Storage request submitted! Total cost: ₹${totalCost}`)
    setSelectedSlot(null)
  }

  const getStoragePeriodMonths = () => {
    if (!startDate || !endDate) return 1
    return Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 30))
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Cold Storage":
        return <Thermometer className="w-4 h-4" />
      case "Climate Controlled":
        return <Package className="w-4 h-4" />
      case "Warehouse":
        return <Truck className="w-4 h-4" />
      default:
        return <Package className="w-4 h-4" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Cold Storage":
        return "bg-blue-100 text-blue-800"
      case "Climate Controlled":
        return "bg-green-100 text-green-800"
      case "Warehouse":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
            Storage Solutions
          </h1>
          <p className="text-muted-foreground mt-1">
            Secure storage units for your belongings and business needs
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="flex items-center gap-1 bg-green-100 text-green-700 dark:bg-green-900/30">
            <Shield className="w-4 h-4" />
            Insured
          </Badge>
          <Badge className="flex items-center gap-1 bg-blue-100 text-blue-700 dark:bg-blue-900/30">
            <Lock className="w-4 h-4" />
            24/7 Security
          </Badge>
        </div>
      </motion.div>

      {/* Modern Search Bar with Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-4 border"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                placeholder="Search storage units by name, type, location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 text-base"
              />
            </div>
          </div>

          {/* Type */}
          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger className="w-full lg:w-48 h-12">
              <SelectValue placeholder="Storage Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Standard">📦 Standard</SelectItem>
              <SelectItem value="Climate Controlled">❄️ Climate Controlled</SelectItem>
              <SelectItem value="Cold Storage">🧊 Cold Storage</SelectItem>
              <SelectItem value="Warehouse">🏭 Warehouse</SelectItem>
            </SelectContent>
          </Select>

          {/* Location */}
          <Select value={selectedLocation} onValueChange={setSelectedLocation}>
            <SelectTrigger className="w-full lg:w-48 h-12">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="Mumbai, Maharashtra">📍 Mumbai</SelectItem>
              <SelectItem value="Bangalore, Karnataka">📍 Bangalore</SelectItem>
              <SelectItem value="Delhi NCR">📍 Delhi</SelectItem>
            </SelectContent>
          </Select>

          {/* Filters Button */}
          <Button
            variant={showFilters ? "default" : "outline"}
            onClick={() => setShowFilters(!showFilters)}
            className="h-12 px-6"
          >
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Filters
            {(minRating > 0 || priceRange[0] > 0 || priceRange[1] < 1000) && (
              <Badge className="ml-2 bg-white text-primary" variant="secondary">
                {(minRating > 0 ? 1 : 0) + (priceRange[0] > 0 || priceRange[1] < 1000 ? 1 : 0)}
              </Badge>
            )}
          </Button>
        </div>

        {/* Advanced Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <Separator className="my-4" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Price Range */}
                <div className="space-y-3">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Monthly Rate Range
                  </label>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    max={1000}
                    step={50}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>₹{priceRange[0]}</span>
                    <span>₹{priceRange[1]}</span>
                  </div>
                </div>

                {/* Rating Filter */}
                <div className="space-y-3">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    Minimum Rating
                  </label>
                  <div className="flex gap-2">
                    {[0, 3, 4, 4.5].map((rating) => (
                      <Button
                        key={rating}
                        variant={minRating === rating ? "default" : "outline"}
                        size="sm"
                        onClick={() => setMinRating(rating)}
                        className="flex-1"
                      >
                        {rating === 0 ? "All" : (
                          <>
                            {rating}
                            <Star className="w-3 h-3 ml-1 fill-current" />
                          </>
                        )}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Clear Filters */}
                <div className="flex items-end">
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setPriceRange([0, 1000])
                      setMinRating(0)
                      toast.success("Filters cleared")
                    }}
                    className="w-full"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Clear All Filters
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Toolbar: Results, Sort, View Mode */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg"
      >
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{sortedSlots.length}</span> of{" "}
            <span className="font-semibold text-foreground">{storageSlots.length}</span> storage units
          </p>
          {wishlist.length > 0 && (
            <Badge variant="secondary" className="ml-2">
              {wishlist.length} in wishlist
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Sort */}
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <TrendingUp className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="popularity">Popularity</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="size">Size: Largest First</SelectItem>
              <SelectItem value="name">Name (A-Z)</SelectItem>
            </SelectContent>
          </Select>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 bg-white dark:bg-slate-800 rounded-lg p-1 border">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="px-3"
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="px-3"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Storage Units Grid/List */}
      {sortedSlots.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No storage units found</h3>
          <p className="text-muted-foreground mb-6">
            Try adjusting your filters or search query
          </p>
          <Button
            onClick={() => {
              setSearchQuery("")
              setSelectedType("all")
              setSelectedLocation("all")
              setPriceRange([0, 1000])
              setMinRating(0)
            }}
          >
            Clear All Filters
          </Button>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className={viewMode === "grid" 
            ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
            : "flex flex-col gap-4"
          }
        >
          {sortedSlots.map((slot, index) => (
            <motion.div
              key={slot.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              layout
            >
              <Card className={`overflow-hidden hover:shadow-2xl transition-all duration-300 border-2 hover:border-primary/50 group ${
                viewMode === "list" ? "flex flex-row" : ""
              }`}>
                {/* Image/Icon Section */}
                <div className={`relative bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 flex items-center justify-center ${
                  viewMode === "grid" ? "aspect-square" : "w-64 h-64"
                }`}>
                  <div className="text-center p-8">
                    {getTypeIcon(slot.type)}
                    <div className="mt-4 text-6xl font-bold text-primary/20">{slot.size}</div>
                    <p className="mt-2 text-sm text-muted-foreground">{slot.type}</p>
                  </div>
                  
                  {/* Available Badge */}
                  <div className="absolute top-2 left-2">
                    <Badge className="bg-green-500 hover:bg-green-600">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Available
                    </Badge>
                  </div>

                  {/* Rating Badge */}
                  {slot.warehouse.rating >= 4.5 && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-orange-500 hover:bg-orange-600">
                        <Star className="w-3 h-3 mr-1 fill-current" />
                        Top Rated
                      </Badge>
                    </div>
                  )}

                  {/* Wishlist Button */}
                  <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      size="icon"
                      variant="secondary"
                      className="h-9 w-9 rounded-full shadow-lg backdrop-blur-sm bg-white/90 hover:bg-white"
                      onClick={() => toggleWishlist(slot.id)}
                    >
                      <Heart className={`w-4 h-4 ${wishlist.includes(slot.id) ? "fill-red-500 text-red-500" : ""}`} />
                    </Button>
                  </div>
                </div>

                {/* Content Section */}
                <CardContent className={`p-4 ${viewMode === "list" ? "flex-1" : ""}`}>
                  <div className="space-y-3">
                    {/* Rating & Warehouse */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(slot.warehouse.rating)
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                        <span className="text-sm font-medium ml-1">{slot.warehouse.rating}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {slot.warehouse.name}
                      </Badge>
                    </div>

                    {/* Title */}
                    <h3 className="font-semibold text-lg leading-tight group-hover:text-primary transition-colors">
                      {slot.name}
                    </h3>

                    {/* Location & Type */}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {slot.location.split(',')[0]}
                      </span>
                      <span className="flex items-center gap-1">
                        <Ruler className="w-3 h-3" />
                        {slot.size}
                      </span>
                    </div>

                    {/* Features (list view only) */}
                    {viewMode === "list" && (
                      <div className="flex flex-wrap gap-1">
                        {slot.features.slice(0, 3).map((feature, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <Separator />

                    {/* Pricing */}
                    <div className="space-y-1">
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-bold text-primary">
                          ₹{slot.monthlyRate}
                        </span>
                        <span className="text-sm text-muted-foreground">/month</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Secure, climate-controlled storage
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2 pt-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button className="flex-1" size="lg" onClick={() => setSelectedSlot(slot)}>
                            <CalendarIcon className="w-4 h-4 mr-2" />
                            Book Now
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>{slot.name}</DialogTitle>
                          </DialogHeader>
                          {/* Quick view content */}
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="font-medium">Type:</span> {slot.type}
                              </div>
                              <div>
                                <span className="font-medium">Size:</span> {slot.size}
                              </div>
                              <div>
                                <span className="font-medium">Location:</span> {slot.location}
                              </div>
                              <div>
                                <span className="font-medium">Monthly Rate:</span> ₹{slot.monthlyRate}
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium mb-2">Features:</p>
                              <div className="flex flex-wrap gap-2">
                                {slot.features.map((feature, idx) => (
                                  <Badge key={idx} variant="secondary">{feature}</Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                      <Button variant="outline" size="lg" onClick={() => toggleWishlist(slot.id)}>
                        <Heart className={`w-4 h-4 ${wishlist.includes(slot.id) ? "fill-red-500 text-red-500" : ""}`} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Benefits Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8"
      >
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="font-semibold mb-2">Fully Insured</h3>
            <p className="text-sm text-muted-foreground">All storage units come with insurance coverage</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
              <Lock className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="font-semibold mb-2">24/7 Security</h3>
            <p className="text-sm text-muted-foreground">Round-the-clock security and surveillance</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center">
              <Thermometer className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="font-semibold mb-2">Climate Control</h3>
            <p className="text-sm text-muted-foreground">Temperature and humidity controlled units</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md hover:shadow-xl transition-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
            <h3 className="font-semibold mb-2">Flexible Access</h3>
            <p className="text-sm text-muted-foreground">Access your storage anytime you need</p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}