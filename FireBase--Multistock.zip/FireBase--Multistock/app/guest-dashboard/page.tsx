"use client"

import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/lib/auth-context"
import Link from "next/link"
import { 
  Package, 
  ShoppingCart, 
  Warehouse, 
  Truck, 
  Boxes, 
  Search,
  Filter,
  Eye,
  LogIn,
  User,
  Star,
  TrendingUp,
  Clock,
  MapPin
} from "lucide-react"
import Image from "next/image"

export default function GuestDashboard() {
  const { user, isGuest } = useAuth()
  const router = useRouter()

  if (!isGuest) {
    return null
  }

  // Mock data for guest view
  const featuredProducts = [
    {
      id: 1,
      name: "Smartphone Pro Max",
      category: "Electronics",
      price: 899.99,
      image: "/product-photos/smartphone.jpg",
      rating: 4.8,
      reviews: 124
    },
    {
      id: 2,
      name: "Gaming Laptop",
      category: "Electronics", 
      price: 1299.99,
      image: "/product-photos/laptop.jpg",
      rating: 4.9,
      reviews: 89
    },
    {
      id: 3,
      name: "Wireless Headphones",
      category: "Electronics",
      price: 199.99,
      image: "/product-photos/headphones.jpg",
      rating: 4.7,
      reviews: 203
    },
    {
      id: 4,
      name: "Professional Camera",
      category: "Electronics",
      price: 1599.99,
      image: "/product-photos/camera.jpg",
      rating: 4.9,
      reviews: 67
    }
  ]

  const categories = [
    { name: "Electronics", count: 156, image: "/category-photos/electronics.jpg" },
    { name: "Clothing", count: 89, image: "/category-photos/clothing.jpg" },
    { name: "Home & Garden", count: 67, image: "/category-photos/home-garden.jpg" },
    { name: "Sports & Recreation", count: 45, image: "/category-photos/sports.jpg" },
    { name: "Books & Media", count: 123, image: "/category-photos/books-media.jpg" },
    { name: "Automotive", count: 34, image: "/category-photos/automotive.jpg" }
  ]

  const services = [
    {
      name: "Rental Services",
      description: "Rent equipment and tools for your projects",
      icon: Truck,
      href: "/rentals"
    },
    {
      name: "Storage Solutions",
      description: "Secure storage for your belongings",
      icon: Warehouse,
      href: "/storage"
    },
    {
      name: "Locker Services",
      description: "Convenient locker rentals",
      icon: Boxes,
      href: "/lockers"
    },
    {
      name: "Marketplace",
      description: "Buy and sell with other users",
      icon: ShoppingCart,
      href: "/marketplace"
    }
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-blue-900 mb-2">
                Welcome to MultiStock Logistics
              </h1>
              <p className="text-blue-700 mb-4">
                You're browsing as a guest. Sign in to access full features and manage your inventory.
              </p>
              <div className="flex space-x-3">
                <Button asChild>
                  <Link href="/login">
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign In
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/register">
                    <User className="w-4 h-4 mr-2" />
                    Create Account
                  </Link>
                </Button>
              </div>
            </div>
            <div className="hidden md:block">
              <Badge variant="outline" className="text-lg px-4 py-2">
                Guest Mode
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="w-5 h-5 mr-2" />
            Browse Products
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search products, categories, brands..."
                  className="pl-10"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.name} value={category.name}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button>
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Featured Products */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <Star className="w-5 h-5 mr-2" />
              Featured Products
            </div>
            <Button variant="outline" size="sm">
              View All
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-square relative bg-muted">
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h3 className="font-medium truncate">{product.name}</h3>
                    <p className="text-sm text-muted-foreground">{product.category}</p>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-lg">${product.price}</span>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm">{product.rating}</span>
                        <span className="text-xs text-muted-foreground">({product.reviews})</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => router.push(`/marketplace/${product.id}`)}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Browse by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Card key={category.name} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="aspect-square relative bg-muted">
                  <Image
                    src={category.image}
                    alt={category.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-3 text-center">
                  <h3 className="font-medium text-sm">{category.name}</h3>
                  <p className="text-xs text-muted-foreground">{category.count} items</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Services */}
      <Card>
        <CardHeader>
          <CardTitle>Our Services</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {services.map((service) => (
              <Card key={service.name} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <service.icon className="w-12 h-12 mx-auto mb-4 text-blue-600" />
                  <h3 className="font-medium mb-2">{service.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={service.href}>
                      Learn More
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="w-8 h-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">1,247</p>
                <p className="text-sm text-muted-foreground">Products</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-8 h-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold">98.5%</p>
                <p className="text-sm text-muted-foreground">Satisfaction</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-8 h-8 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">24/7</p>
                <p className="text-sm text-muted-foreground">Support</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MapPin className="w-8 h-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">50+</p>
                <p className="text-sm text-muted-foreground">Locations</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-6 text-center">
          <h2 className="text-xl font-bold mb-2">Ready to Get Started?</h2>
          <p className="text-muted-foreground mb-4">
            Join thousands of satisfied customers and start managing your inventory today.
          </p>
          <div className="flex justify-center space-x-3">
            <Button asChild>
              <Link href="/login">
                <LogIn className="w-4 h-4 mr-2" />
                Sign In Now
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/register">
                <User className="w-4 h-4 mr-2" />
                Create Account
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
