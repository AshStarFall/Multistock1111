"use client"

import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function ReceiptsPage() {
  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
        <h1 className="text-3xl font-bold">Receipts</h1>
      </div>
      <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
        <CardHeader>
          <CardTitle className="text-lg">Receipt Preview</CardTitle>
          <CardDescription>Static preview placeholder; use Print for PDF.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mt-1 border rounded p-4 bg-white text-black">
            <div className="flex items-center justify-between">
              <div className="font-semibold flex items-center gap-2">
                <img src="/multistock-logo.svg" alt="Logo" className="h-5 w-5" />
                <span className="indian-text">MultiStock Logistics - India</span>
              </div>
              <div>#1001</div>
            </div>
            <div className="text-xs mt-1">Bandra Kurla Complex, Mumbai, Maharashtra 400051</div>
            <div className="mt-3 text-sm">Bill To: Rajesh Kumar</div>
            <div className="mt-3 text-sm">Items:</div>
            <ul className="text-sm list-disc ml-5">
              <li>Laptop — ₹75,000.00</li>
              <li>Office Chair — ₹16,500.00</li>
              <li>Printer — ₹33,000.00</li>
            </ul>
            <div className="mt-3 text-sm">Tax (18%): ₹22,500.00</div>
            <div className="font-medium mt-1 indian-accent">Total: ₹1,30,000.00</div>
          </div>
          <div className="mt-4">
            <Button variant="outline" onClick={() => window.print()} className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white hover:from-indigo-700 hover:to-violet-700">
              Print
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}


