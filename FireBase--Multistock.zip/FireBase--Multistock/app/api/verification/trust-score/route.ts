import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { calculateTrustScore } from '@/lib/verification';

;

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const userId = request.headers.get('x-user-id') || 'user_1';

    // Fetch user data
    const { data: userData, error: userError } = await supabase
      .from('user_profiles')
      .select('*, verification_requests(*)')
      .eq('user_id', userId)
      .single();

    if (userError) throw userError;

    // Calculate account age
    const accountAge = Math.floor(
      (Date.now() - new Date(userData.created_at).getTime()) / (1000 * 60 * 60 * 24)
    );

    // Fetch transaction metrics
    const { data: transactions } = await supabase
      .from('transactions')
      .select('status')
      .eq('user_id', userId);

    const totalTransactions = transactions?.length || 0;
    const successfulTransactions =
      transactions?.filter((t) => t.status === 'completed').length || 0;

    // Fetch reviews
    const { data: reviews } = await supabase
      .from('reviews')
      .select('rating')
      .eq('seller_id', userId);

    const totalReviews = reviews?.length || 0;
    const averageRating =
      totalReviews > 0
        ? reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
        : 0;

    // Check verification status
    const isVerified =
      userData.verification_requests?.some((r: any) => r.status === 'approved') || false;

    // Calculate trust score
    const trustScore = calculateTrustScore({
      isVerified,
      accountAge,
      totalTransactions,
      successfulTransactions,
      averageRating,
      totalReviews,
      responseRate: 0.85, // Placeholder
      disputesCount: 0, // Placeholder
    });

    // Calculate component scores
    const verificationScore = isVerified ? 40 : 0;
    const activityScore = Math.min(
      20,
      (totalTransactions / 50) * 10 + (accountAge / 365) * 10
    );
    const reputationScore =
      totalReviews > 0
        ? (averageRating / 5) * 15 + Math.min(10, (totalReviews / 20) * 10)
        : 0;
    const consistencyScore =
      totalTransactions > 0
        ? (successfulTransactions / totalTransactions) * 10 + 0.85 * 5
        : 0;

    const trustScoreData = {
      userId,
      totalScore: trustScore,
      verificationScore: Math.round(verificationScore),
      activityScore: Math.round(activityScore),
      reputationScore: Math.round(reputationScore),
      consistencyScore: Math.round(consistencyScore),
      lastCalculated: new Date().toISOString(),
      badges: [],
    };

    return NextResponse.json(trustScoreData);
  } catch (error: any) {
    console.error('Error calculating trust score:', error);
    return NextResponse.json(
      { error: 'Failed to calculate trust score', details: error.message },
      { status: 500 }
    );
  }
}
