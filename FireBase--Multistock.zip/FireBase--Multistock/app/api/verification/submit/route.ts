import { NextRequest, NextResponse } from 'next/server';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/server';

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json();
    const { requestType, documents, businessName, businessType, taxId, website, notes } =
      body;

    // Get user ID from session (placeholder - implement proper auth)
    const userId = request.headers.get('x-user-id') || 'user_1';

    // Insert verification request
    const { data: verificationRequest, error } = await supabase
      .from('verification_requests')
      .insert({
        user_id: userId,
        request_type: requestType,
        status: 'pending',
        documents,
        business_name: businessName,
        business_type: businessType,
        tax_id: taxId,
        website,
        notes,
        trust_score: 0,
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(verificationRequest, { status: 201 });
  } catch (error: any) {
    console.error('Error submitting verification:', error);
    return NextResponse.json(
      { error: 'Submission failed', details: error.message },
      { status: 500 }
    );
  }
}
