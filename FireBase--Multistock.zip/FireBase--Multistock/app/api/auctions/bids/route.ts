import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// POST /api/auctions/bids - Place a bid
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { 
      auctionId, 
      bidderId, 
      amount, 
      isAutoBid = false, 
      maxAutoBid 
    } = body

    if (!auctionId || !bidderId || !amount) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Get auction details
    const { data: auction, error: auctionError } = await supabase
      .from('auctions')
      .select('*')
      .eq('id', auctionId)
      .single()

    if (auctionError || !auction) {
      return NextResponse.json(
        { success: false, error: 'Auction not found' },
        { status: 404 }
      )
    }

    // Validate bid amount
    const minimumBid = auction.current_price + auction.bid_increment
    if (amount < minimumBid) {
      return NextResponse.json(
        { success: false, error: `Minimum bid is ₹${minimumBid}` },
        { status: 400 }
      )
    }

    // Check if auction is active
    const now = new Date()
    const endTime = new Date(auction.end_time)
    if (now > endTime) {
      return NextResponse.json(
        { success: false, error: 'Auction has ended' },
        { status: 400 }
      )
    }

    // Get bidder name
    const { data: userData } = await supabase
      .from('users')
      .select('email, user_profiles(first_name, last_name)')
      .eq('id', bidderId)
      .single()

    const profile = Array.isArray(userData?.user_profiles) ? userData.user_profiles[0] : userData?.user_profiles
    const bidderName = profile 
      ? `${profile.first_name} ${profile.last_name}`.trim()
      : userData?.email || 'Anonymous'

    // Check for anti-sniping (bid in last 2 minutes)
    const timeRemaining = endTime.getTime() - now.getTime()
    let newEndTime = auction.end_time
    
    if (timeRemaining <= 2 * 60 * 1000) { // 2 minutes
      // Extend auction by 2 minutes
      const extendedEndTime = new Date(endTime)
      extendedEndTime.setMinutes(extendedEndTime.getMinutes() + 2)
      newEndTime = extendedEndTime.toISOString()
    }

    // Mark previous highest bid as outbid
    const { data: previousBids } = await supabase
      .from('bids')
      .select('*')
      .eq('auction_id', auctionId)
      .eq('status', 'winning')

    if (previousBids && previousBids.length > 0) {
      await supabase
        .from('bids')
        .update({ status: 'outbid' })
        .eq('auction_id', auctionId)
        .eq('status', 'winning')
    }

    // Insert new bid
    const { data: newBid, error: bidError } = await supabase
      .from('bids')
      .insert({
        auction_id: auctionId,
        bidder_id: bidderId,
        bidder_name: bidderName,
        amount,
        is_auto_bid: isAutoBid,
        max_auto_bid: maxAutoBid,
        status: 'winning',
        timestamp: new Date().toISOString()
      })
      .select()
      .single()

    if (bidError) throw bidError

    // Update auction
    const { data: uniqueBidders } = await supabase
      .from('bids')
      .select('bidder_id')
      .eq('auction_id', auctionId)

    const uniqueCount = new Set(uniqueBidders?.map(b => b.bidder_id)).size

    await supabase
      .from('auctions')
      .update({
        current_price: amount,
        total_bids: auction.total_bids + 1,
        unique_bidders: uniqueCount,
        end_time: newEndTime,
        updated_at: new Date().toISOString()
      })
      .eq('id', auctionId)

    // TODO: Send notifications to outbid users
    // TODO: Send notifications to watchers

    return NextResponse.json({ 
      success: true, 
      bid: newBid,
      extendedTime: newEndTime !== auction.end_time
    })
  } catch (error) {
    console.error('Error placing bid:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to place bid' },
      { status: 500 }
    )
  }
}

// GET /api/auctions/bids - Get bids for an auction
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const auctionId = searchParams.get('auctionId')

    if (!auctionId) {
      return NextResponse.json(
        { success: false, error: 'Auction ID required' },
        { status: 400 }
      )
    }

    const { data: bids, error } = await supabase
      .from('bids')
      .select('*')
      .eq('auction_id', auctionId)
      .order('amount', { ascending: false })

    if (error) throw error

    const transformedBids = bids?.map(bid => ({
      id: bid.id,
      auctionId: bid.auction_id,
      bidderId: bid.bidder_id,
      bidderName: bid.bidder_name,
      amount: bid.amount,
      timestamp: bid.timestamp,
      status: bid.status,
      isAutoBid: bid.is_auto_bid,
      maxAutoBid: bid.max_auto_bid
    })) || []

    return NextResponse.json({ success: true, bids: transformedBids })
  } catch (error) {
    console.error('Error fetching bids:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch bids' },
      { status: 500 }
    )
  }
}
