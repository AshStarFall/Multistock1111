import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET /api/auctions - Fetch all auctions
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const category = searchParams.get('category')
    const sellerId = searchParams.get('sellerId')

    let query = supabase
      .from('auctions')
      .select(`
        *,
        seller:users!auctions_seller_id_fkey (
          id,
          email,
          user_profiles (
            first_name,
            last_name,
            avatar_url
          )
        )
      `)
      .order('end_time', { ascending: true })

    if (status) {
      query = query.eq('status', status)
    }

    if (category) {
      query = query.eq('category', category)
    }

    if (sellerId) {
      query = query.eq('seller_id', sellerId)
    }

    const { data, error } = await query

    if (error) throw error

    // Transform data
    const auctions = data?.map((auction: any) => ({
      id: auction.id,
      sellerId: auction.seller_id,
      sellerName: auction.seller.user_profiles 
        ? `${auction.seller.user_profiles.first_name} ${auction.seller.user_profiles.last_name}`.trim() || 'Anonymous'
        : 'Anonymous',
      sellerRating: auction.seller_rating || 0,
      sellerVerified: auction.seller_verified || false,
      title: auction.title,
      description: auction.description,
      category: auction.category,
      images: auction.images || [],
      condition: auction.condition,
      startingPrice: auction.starting_price,
      currentPrice: auction.current_price,
      reservePrice: auction.reserve_price,
      buyNowPrice: auction.buy_now_price,
      bidIncrement: auction.bid_increment,
      status: auction.status,
      startTime: auction.start_time,
      endTime: auction.end_time,
      duration: auction.duration,
      totalBids: auction.total_bids || 0,
      uniqueBidders: auction.unique_bidders || 0,
      views: auction.views || 0,
      watchers: auction.watchers || 0,
      location: auction.location,
      shippingAvailable: auction.shipping_available || false,
      shippingCost: auction.shipping_cost,
      createdAt: auction.created_at,
      updatedAt: auction.updated_at
    })) || []

    return NextResponse.json({ success: true, auctions })
  } catch (error) {
    console.error('Error fetching auctions:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch auctions' },
      { status: 500 }
    )
  }
}

// POST /api/auctions - Create new auction
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      sellerId,
      title,
      description,
      category,
      images,
      condition,
      startingPrice,
      reservePrice,
      buyNowPrice,
      duration, // in hours
      location,
      shippingAvailable,
      shippingCost
    } = body

    // Validate required fields
    if (!sellerId || !title || !description || !category || !startingPrice || !duration || !location) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Calculate bid increment based on starting price
    const bidIncrement = startingPrice < 1000 ? 50 :
                        startingPrice < 5000 ? 100 :
                        startingPrice < 10000 ? 250 :
                        startingPrice < 50000 ? 500 :
                        startingPrice < 100000 ? 1000 : 2500

    // Calculate start and end times
    const startTime = new Date()
    const endTime = new Date(startTime.getTime() + duration * 60 * 60 * 1000)

    // Create auction
    const { data: auction, error } = await supabase
      .from('auctions')
      .insert({
        seller_id: sellerId,
        title,
        description,
        category,
        images,
        condition,
        starting_price: startingPrice,
        current_price: startingPrice,
        reserve_price: reservePrice,
        buy_now_price: buyNowPrice,
        bid_increment: bidIncrement,
        status: 'active',
        start_time: startTime.toISOString(),
        end_time: endTime.toISOString(),
        duration,
        total_bids: 0,
        unique_bidders: 0,
        views: 0,
        watchers: 0,
        location,
        shipping_available: shippingAvailable || false,
        shipping_cost: shippingCost,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, auction })
  } catch (error) {
    console.error('Error creating auction:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create auction' },
      { status: 500 }
    )
  }
}
