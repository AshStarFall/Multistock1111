import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { calculateBudgetUtilization } from '@/lib/expenses';

;

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const userId = request.headers.get('x-user-id') || 'user_1';

    const { data: budgets, error } = await supabase
      .from('budgets')
      .select('*')
      .eq('user_id', userId)
      .eq('is_active', true)
      .order('created_at', { ascending: false });

    if (error) throw error;

    // Calculate spent and remaining for each budget
    const budgetsWithCalculations = await Promise.all(
      (budgets || []).map(async (budget) => {
        // Fetch expenses for this budget period and category
        const { data: expenses } = await supabase
          .from('expenses')
          .select('amount')
          .eq('user_id', userId)
          .eq('category', budget.category)
          .gte('date', budget.start_date)
          .lte('date', budget.end_date);

        const spent = expenses?.reduce((sum, exp) => sum + exp.amount, 0) || 0;
        const remaining = budget.budget_limit - spent;

        return {
          ...budget,
          limit: budget.budget_limit,
          spent,
          remaining,
        };
      })
    );

    return NextResponse.json(budgetsWithCalculations);
  } catch (error: any) {
    console.error('Error fetching budgets:', error);
    return NextResponse.json(
      { error: 'Failed to fetch budgets', details: error.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json();
    const userId = request.headers.get('x-user-id') || 'user_1';
    
    const { category, limit, period, startDate, endDate } = body;

    if (!category || !limit || !period || !startDate || !endDate) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const { data: budget, error } = await supabase
      .from('budgets')
      .insert({
        user_id: userId,
        category,
        budget_limit: limit,
        period,
        start_date: startDate,
        end_date: endDate,
        spent: 0,
        remaining: limit,
        is_active: true,
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(budget, { status: 201 });
  } catch (error: any) {
    console.error('Error creating budget:', error);
    return NextResponse.json(
      { error: 'Failed to create budget', details: error.message },
      { status: 500 }
    );
  }
}
