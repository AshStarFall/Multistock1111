import { NextRequest, NextResponse } from 'next/server';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/server';

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      );
    }

    const { searchParams } = new URL(request.url);
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const userId = request.headers.get('x-user-id') || 'user_1';

    let query = supabase
      .from('expenses')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });

    if (startDate && endDate) {
      query = query.gte('date', startDate).lte('date', endDate);
    }

    const { data: expenses, error } = await query;

    if (error) throw error;

    return NextResponse.json(expenses || []);
  } catch (error: any) {
    console.error('Error fetching expenses:', error);
    return NextResponse.json(
      { error: 'Failed to fetch expenses', details: error.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      );
    }

    const body = await request.json();
    const userId = request.headers.get('x-user-id') || 'user_1';
    
    const {
      category,
      amount,
      description,
      date,
      paymentMethod,
      receiptUrl,
      tags,
    } = body;

    if (!category || !amount || !description || !date) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const { data: expense, error } = await supabase
      .from('expenses')
      .insert({
        user_id: userId,
        category,
        amount,
        description,
        date,
        payment_method: paymentMethod,
        receipt_url: receiptUrl,
        tags,
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(expense, { status: 201 });
  } catch (error: any) {
    console.error('Error creating expense:', error);
    return NextResponse.json(
      { error: 'Failed to create expense', details: error.message },
      { status: 500 }
    );
  }
}
