import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET /api/forum/threads - Fetch threads
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const categoryId = searchParams.get('categoryId')
    const status = searchParams.get('status')

    let query = supabase
      .from('forum_threads')
      .select(`
        *,
        category:forum_categories!forum_threads_category_id_fkey (id, name),
        author:users!forum_threads_author_id_fkey (
          id,
          email,
          user_profiles (first_name, last_name, avatar_url)
        )
      `)
      .order('is_pinned', { ascending: false })
      .order('updated_at', { ascending: false })

    if (categoryId) {
      query = query.eq('category_id', categoryId)
    }

    if (status) {
      query = query.eq('status', status)
    }

    const { data, error } = await query

    if (error) throw error

    const threads = data?.map((thread: any) => ({
      id: thread.id,
      categoryId: thread.category_id,
      categoryName: thread.category?.name || 'Unknown',
      authorId: thread.author_id,
      authorName: thread.author.user_profiles
        ? `${thread.author.user_profiles.first_name} ${thread.author.user_profiles.last_name}`.trim()
        : thread.author.email,
      authorAvatar: thread.author.user_profiles?.avatar_url,
      title: thread.title,
      content: thread.content,
      status: thread.status,
      isPinned: thread.is_pinned,
      isLocked: thread.is_locked,
      views: thread.views || 0,
      replies: thread.replies || 0,
      likes: thread.likes || 0,
      tags: thread.tags || [],
      lastReplyAt: thread.last_reply_at,
      lastReplyBy: thread.last_reply_by,
      createdAt: thread.created_at,
      updatedAt: thread.updated_at
    })) || []

    return NextResponse.json({ success: true, threads })
  } catch (error) {
    console.error('Error fetching threads:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch threads' },
      { status: 500 }
    )
  }
}

// POST /api/forum/threads - Create thread
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { categoryId, authorId, title, content, tags } = body

    if (!categoryId || !authorId || !title || !content) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const { data: thread, error } = await supabase
      .from('forum_threads')
      .insert({
        category_id: categoryId,
        author_id: authorId,
        title,
        content,
        tags: tags || [],
        status: 'active',
        is_pinned: false,
        is_locked: false,
        views: 0,
        replies: 0,
        likes: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, thread })
  } catch (error) {
    console.error('Error creating thread:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create thread' },
      { status: 500 }
    )
  }
}
