import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { calculateTrendingScore } from '@/lib/trending';

;

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Fetch products with sales and view metrics
    const { data: products, error } = await supabase
      .from('products')
      .select(`
        *,
        user_profiles:user_id (
          full_name,
          company_name
        )
      `)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) throw error;

    // Calculate trending scores and format response
    const trendingProducts = products.map((product) => {
      const salesCount = product.sales_count || 0;
      const viewsCount = product.views_count || 0;
      const rating = product.rating || 0;
      const reviews = product.reviews_count || 0;

      const trendingScore = calculateTrendingScore({
        salesCount,
        viewsCount,
        rating,
        reviews,
        createdAt: product.created_at,
      });

      const seller = Array.isArray(product.user_profiles)
        ? product.user_profiles[0]
        : product.user_profiles;

      return {
        id: product.id,
        name: product.name,
        description: product.description || '',
        price: product.price,
        originalPrice: product.original_price,
        discount: product.discount_percentage || 0,
        image: product.images?.[0] || '/placeholder-product.jpg',
        category: product.category || 'General',
        seller: seller?.company_name || seller?.full_name || 'Unknown Seller',
        sellerId: product.user_id,
        rating,
        reviews,
        salesCount,
        viewsCount,
        trendingScore,
        isHotDeal: product.is_hot_deal || false,
        dealEndsAt: product.deal_ends_at,
        stock: product.stock_quantity || 0,
        tags: product.tags || [],
      };
    });

    // Sort by trending score
    trendingProducts.sort((a, b) => b.trendingScore - a.trendingScore);

    return NextResponse.json(trendingProducts);
  } catch (error: any) {
    console.error('Error fetching trending products:', error);
    return NextResponse.json(
      { error: 'Failed to fetch trending products', details: error.message },
      { status: 500 }
    );
  }
}
