import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// GET /api/notifications/preferences - Get user preferences
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') || 'temp-user-id'

    const { data, error } = await supabase
      .from('notification_preferences')
      .select('*')
      .eq('user_id', userId)
      .single()

    if (error && error.code !== 'PGRST116') throw error // Ignore "not found" error

    if (!data) {
      // Return default preferences
      return NextResponse.json({
        preferences: {
          userId,
          emailNotifications: true,
          pushNotifications: true,
          smsNotifications: false,
          categories: {
            orders: true,
            payments: true,
            shipping: true,
            marketing: false,
            auctions: true,
            messages: true,
            system: true
          },
          quietHours: {
            enabled: false,
            start: '22:00',
            end: '08:00'
          }
        }
      })
    }

    return NextResponse.json({
      preferences: {
        userId: data.user_id,
        emailNotifications: data.email_notifications,
        pushNotifications: data.push_notifications,
        smsNotifications: data.sms_notifications,
        categories: data.categories,
        quietHours: data.quiet_hours
      }
    })
  } catch (error: any) {
    console.error('Error fetching preferences:', error)
    return NextResponse.json(
      { error: 'Failed to fetch preferences', details: error.message },
      { status: 500 }
    )
  }
}

// POST /api/notifications/preferences - Save user preferences
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const {
      userId,
      emailNotifications,
      pushNotifications,
      smsNotifications,
      categories,
      quietHours
    } = body

    const { data, error } = await supabase
      .from('notification_preferences')
      .upsert({
        user_id: userId,
        email_notifications: emailNotifications,
        push_notifications: pushNotifications,
        sms_notifications: smsNotifications,
        categories,
        quiet_hours: quietHours,
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, preferences: data })
  } catch (error: any) {
    console.error('Error saving preferences:', error)
    return NextResponse.json(
      { error: 'Failed to save preferences', details: error.message },
      { status: 500 }
    )
  }
}
