import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// GET /api/notifications - Fetch user notifications
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') || 'temp-user-id' // TODO: Get from session
    const unreadOnly = searchParams.get('unreadOnly') === 'true'
    const limit = parseInt(searchParams.get('limit') || '50')

    let query = supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .eq('archived', false)

    if (unreadOnly) {
      query = query.eq('read', false)
    }

    query = query
      .order('created_at', { ascending: false })
      .limit(limit)

    const { data, error } = await query

    if (error) throw error

    // Transform to match frontend interface
    const notifications = data?.map(notif => ({
      id: notif.id,
      userId: notif.user_id,
      type: notif.type,
      priority: notif.priority,
      title: notif.title,
      message: notif.message,
      icon: notif.icon,
      imageUrl: notif.image_url,
      link: notif.link,
      actionLabel: notif.action_label,
      actionUrl: notif.action_url,
      read: notif.read,
      archived: notif.archived,
      createdAt: new Date(notif.created_at),
      readAt: notif.read_at ? new Date(notif.read_at) : undefined,
      expiresAt: notif.expires_at ? new Date(notif.expires_at) : undefined,
      metadata: notif.metadata
    }))

    return NextResponse.json({ notifications })
  } catch (error: any) {
    console.error('Error fetching notifications:', error)
    return NextResponse.json(
      { error: 'Failed to fetch notifications', details: error.message },
      { status: 500 }
    )
  }
}

// POST /api/notifications - Create a new notification
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const {
      userId,
      type,
      priority = 'medium',
      title,
      message,
      icon,
      imageUrl,
      link,
      actionLabel,
      actionUrl,
      expiresAt,
      metadata
    } = body

    const { data, error } = await supabase
      .from('notifications')
      .insert({
        user_id: userId,
        type,
        priority,
        title,
        message,
        icon,
        image_url: imageUrl,
        link,
        action_label: actionLabel,
        action_url: actionUrl,
        read: false,
        archived: false,
        created_at: new Date().toISOString(),
        expires_at: expiresAt,
        metadata
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, notification: data })
  } catch (error: any) {
    console.error('Error creating notification:', error)
    return NextResponse.json(
      { error: 'Failed to create notification', details: error.message },
      { status: 500 }
    )
  }
}

// DELETE /api/notifications - Delete notification
export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'Notification ID is required' },
        { status: 400 }
      )
    }

    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', id)

    if (error) throw error

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Error deleting notification:', error)
    return NextResponse.json(
      { error: 'Failed to delete notification', details: error.message },
      { status: 500 }
    )
  }
}
