import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// POST /api/notifications/[id]/archive - Archive notification
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const notificationId = params.id

    const { error } = await supabase
      .from('notifications')
      .update({ archived: true })
      .eq('id', notificationId)

    if (error) throw error

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Error archiving notification:', error)
    return NextResponse.json(
      { error: 'Failed to archive', details: error.message },
      { status: 500 }
    )
  }
}
