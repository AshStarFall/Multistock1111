import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// POST /api/reviews/[id]/not-helpful - Mark review as not helpful
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const reviewId = params.id

    const { data, error } = await supabase
      .from('reviews')
      .select('not_helpful')
      .eq('id', reviewId)
      .single()

    if (error) throw error

    const { error: updateError } = await supabase
      .from('reviews')
      .update({ not_helpful: (data.not_helpful || 0) + 1 })
      .eq('id', reviewId)

    if (updateError) throw updateError

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Error marking review as not helpful:', error)
    return NextResponse.json(
      { error: 'Failed to update review', details: error.message },
      { status: 500 }
    )
  }
}
