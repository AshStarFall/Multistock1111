import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// POST /api/reviews/[id]/helpful - Mark review as helpful
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const reviewId = params.id

    // TODO: Track user votes to prevent duplicate voting
    // For now, just increment the counter

    const { data, error } = await supabase
      .from('reviews')
      .select('helpful')
      .eq('id', reviewId)
      .single()

    if (error) throw error

    const { error: updateError } = await supabase
      .from('reviews')
      .update({ helpful: (data.helpful || 0) + 1 })
      .eq('id', reviewId)

    if (updateError) throw updateError

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Error marking review as helpful:', error)
    return NextResponse.json(
      { error: 'Failed to update review', details: error.message },
      { status: 500 }
    )
  }
}
