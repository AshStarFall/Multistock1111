import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// POST /api/reviews/[id]/report - Report a review
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const reviewId = params.id
    const body = await request.json()
    const { reason, userId } = body

    // Create a report entry
    const { error } = await supabase
      .from('review_reports')
      .insert({
        review_id: reviewId,
        user_id: userId || 'anonymous',
        reason: reason || 'Inappropriate content',
        created_at: new Date().toISOString()
      })

    if (error) throw error

    return NextResponse.json({ 
      success: true, 
      message: 'Review reported successfully. Our team will review it.' 
    })
  } catch (error: any) {
    console.error('Error reporting review:', error)
    return NextResponse.json(
      { error: 'Failed to report review', details: error.message },
      { status: 500 }
    )
  }
}
