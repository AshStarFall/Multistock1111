import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

// GET /api/reviews - Fetch reviews for a product
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const productId = searchParams.get('productId')
    const status = searchParams.get('status') || 'approved'

    if (!productId) {
      return NextResponse.json(
        { error: 'Product ID is required' },
        { status: 400 }
      )
    }

    let query = supabase
      .from('reviews')
      .select('*')
      .eq('product_id', productId)

    if (status !== 'all') {
      query = query.eq('status', status)
    }

    query = query.order('created_at', { ascending: false })

    const { data, error } = await query

    if (error) throw error

    // Transform to match frontend interface
    const reviews = data?.map(review => ({
      id: review.id,
      productId: review.product_id,
      userId: review.user_id,
      userName: review.user_name,
      userAvatar: review.user_avatar,
      rating: review.rating,
      title: review.title,
      comment: review.comment,
      images: review.images || [],
      verifiedPurchase: review.verified_purchase,
      helpful: review.helpful || 0,
      notHelpful: review.not_helpful || 0,
      status: review.status,
      moderatedBy: review.moderated_by,
      moderationNote: review.moderation_note,
      createdAt: new Date(review.created_at),
      updatedAt: new Date(review.updated_at)
    }))

    return NextResponse.json({ reviews })
  } catch (error: any) {
    console.error('Error fetching reviews:', error)
    return NextResponse.json(
      { error: 'Failed to fetch reviews', details: error.message },
      { status: 500 }
    )
  }
}

// POST /api/reviews - Create a new review
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const formData = await request.formData()
    const productId = formData.get('productId') as string
    const rating = parseInt(formData.get('rating') as string)
    const title = formData.get('title') as string
    const comment = formData.get('comment') as string
    const verifiedPurchase = formData.get('verifiedPurchase') === 'true'

    // Get user from session (TODO: Implement proper auth)
    const userId = formData.get('userId') as string || 'temp-user-id'
    const userName = formData.get('userName') as string || 'Anonymous User'

    // Handle image uploads (TODO: Implement actual file upload to storage)
    const images: string[] = []
    let imageIndex = 0
    while (formData.get(`image_${imageIndex}`)) {
      const imageFile = formData.get(`image_${imageIndex}`) as File
      // In production, upload to Supabase Storage or S3
      // For now, store placeholder URLs
      images.push(`/uploads/reviews/${Date.now()}-${imageIndex}.jpg`)
      imageIndex++
    }

    const { data, error } = await supabase
      .from('reviews')
      .insert({
        product_id: productId,
        user_id: userId,
        user_name: userName,
        user_avatar: null,
        rating,
        title,
        comment,
        images,
        verified_purchase: verifiedPurchase,
        helpful: 0,
        not_helpful: 0,
        status: 'pending', // Reviews need moderation by default
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ 
      success: true, 
      review: data,
      message: 'Review submitted successfully. It will be published after moderation.'
    })
  } catch (error: any) {
    console.error('Error creating review:', error)
    return NextResponse.json(
      { error: 'Failed to create review', details: error.message },
      { status: 500 }
    )
  }
}

// PATCH /api/reviews - Update review status (moderation)
export async function PATCH(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { reviewId, status, moderationNote } = body

    // TODO: Check if user has moderation permissions

    const { data, error } = await supabase
      .from('reviews')
      .update({
        status,
        moderation_note: moderationNote,
        moderated_by: 'admin-user-id', // TODO: Get from session
        updated_at: new Date().toISOString()
      })
      .eq('id', reviewId)
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, review: data })
  } catch (error: any) {
    console.error('Error updating review:', error)
    return NextResponse.json(
      { error: 'Failed to update review', details: error.message },
      { status: 500 }
    )
  }
}

// DELETE /api/reviews - Delete a review
export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const reviewId = searchParams.get('id')

    if (!reviewId) {
      return NextResponse.json(
        { error: 'Review ID is required' },
        { status: 400 }
      )
    }

    // TODO: Check if user has permission to delete

    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', reviewId)

    if (error) throw error

    return NextResponse.json({ success: true, message: 'Review deleted' })
  } catch (error: any) {
    console.error('Error deleting review:', error)
    return NextResponse.json(
      { error: 'Failed to delete review', details: error.message },
      { status: 500 }
    )
  }
}
