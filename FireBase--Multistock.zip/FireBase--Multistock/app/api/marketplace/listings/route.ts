import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET /api/marketplace/listings - Fetch all listings
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const sellerId = searchParams.get('sellerId')
    const status = searchParams.get('status')
    const type = searchParams.get('type')

    let query = supabase
      .from('marketplace_listings')
      .select(`
        *,
        seller:users!marketplace_listings_seller_id_fkey (
          id,
          email,
          user_profiles (
            first_name,
            last_name,
            avatar_url
          )
        )
      `)
      .order('created_at', { ascending: false })

    if (sellerId) {
      query = query.eq('seller_id', sellerId)
    }

    if (status) {
      query = query.eq('status', status)
    } else {
      query = query.eq('status', 'active')
    }

    if (type) {
      query = query.eq('type', type)
    }

    const { data, error } = await query

    if (error) throw error

    // Transform data
    const listings = data?.map((listing: any) => ({
      id: listing.id,
      sellerId: listing.seller_id,
      sellerName: listing.seller.user_profiles 
        ? `${listing.seller.user_profiles.first_name} ${listing.seller.user_profiles.last_name}`.trim() || 'Anonymous'
        : 'Anonymous',
      sellerTier: listing.seller_tier || 'free',
      sellerRating: listing.seller_rating || 0,
      sellerVerified: listing.seller_verified || false,
      title: listing.title,
      description: listing.description,
      category: listing.category,
      type: listing.type,
      status: listing.status,
      condition: listing.condition,
      price: listing.price,
      currency: listing.currency || 'INR',
      images: listing.images || [],
      rentalPeriod: listing.rental_period,
      rentalDeposit: listing.rental_deposit,
      quantity: listing.quantity || 1,
      location: listing.location,
      tags: listing.tags || [],
      views: listing.views || 0,
      favorites: listing.favorites || 0,
      createdAt: listing.created_at,
      updatedAt: listing.updated_at,
      expiresAt: listing.expires_at,
      featuredUntil: listing.featured_until
    })) || []

    return NextResponse.json({ success: true, listings })
  } catch (error) {
    console.error('Error fetching listings:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch listings' },
      { status: 500 }
    )
  }
}

// POST /api/marketplace/listings - Create new listing
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      sellerId,
      title,
      description,
      category,
      type,
      condition,
      price,
      rentalPeriod,
      rentalDeposit,
      quantity,
      location,
      tags,
      images
    } = body

    // Validate required fields
    if (!sellerId || !title || !description || !category || !type || !condition || !price || !location) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check seller subscription limits
    const { data: subscription } = await supabase
      .from('seller_subscriptions')
      .select('*')
      .eq('user_id', sellerId)
      .eq('status', 'active')
      .single()

    if (!subscription) {
      return NextResponse.json(
        { success: false, error: 'No active subscription found' },
        { status: 403 }
      )
    }

    // Check if can create listing
    if (subscription.listings_limit !== -1) {
      const { count } = await supabase
        .from('marketplace_listings')
        .select('*', { count: 'exact', head: true })
        .eq('seller_id', sellerId)
        .in('status', ['active', 'pending_review'])

      if (count && count >= subscription.listings_limit) {
        return NextResponse.json(
          { success: false, error: 'Listing limit reached. Please upgrade your plan.' },
          { status: 403 }
        )
      }
    }

    // Create listing
    const { data: listing, error } = await supabase
      .from('marketplace_listings')
      .insert({
        seller_id: sellerId,
        title,
        description,
        category,
        type,
        condition,
        price,
        rental_period: rentalPeriod,
        rental_deposit: rentalDeposit,
        quantity,
        location,
        tags,
        images,
        status: 'pending_review',
        seller_tier: subscription.tier,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, listing })
  } catch (error) {
    console.error('Error creating listing:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create listing' },
      { status: 500 }
    )
  }
}

// PUT /api/marketplace/listings - Update listing
export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, sellerId, ...updates } = body

    if (!id || !sellerId) {
      return NextResponse.json(
        { success: false, error: 'Listing ID and seller ID required' },
        { status: 400 }
      )
    }

    // Verify ownership
    const { data: existing } = await supabase
      .from('marketplace_listings')
      .select('seller_id')
      .eq('id', id)
      .single()

    if (!existing || existing.seller_id !== sellerId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 403 }
      )
    }

    // Update listing
    const { data: listing, error } = await supabase
      .from('marketplace_listings')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ success: true, listing })
  } catch (error) {
    console.error('Error updating listing:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update listing' },
      { status: 500 }
    )
  }
}

// DELETE /api/marketplace/listings - Delete listing
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    const sellerId = searchParams.get('sellerId')

    if (!id || !sellerId) {
      return NextResponse.json(
        { success: false, error: 'Listing ID and seller ID required' },
        { status: 400 }
      )
    }

    // Verify ownership
    const { data: existing } = await supabase
      .from('marketplace_listings')
      .select('seller_id')
      .eq('id', id)
      .single()

    if (!existing || existing.seller_id !== sellerId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 403 }
      )
    }

    // Soft delete - mark as removed
    const { error } = await supabase
      .from('marketplace_listings')
      .update({ 
        status: 'removed',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)

    if (error) throw error

    return NextResponse.json({ success: true, message: 'Listing deleted' })
  } catch (error) {
    console.error('Error deleting listing:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete listing' },
      { status: 500 }
    )
  }
}
