import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"

// Mock data for now - replace with Supabase client
const listings = [
  {
    id: "ls-1",
    title: "Premium Storage Slot",
    description: "Cold storage L size",
    imageUrl: "/placeholder.jpg",
    sellerId: "user-1",
    verified: true,
    status: "active",
    bids: [],
    acceptedBidId: null,
    createdAt: new Date().toISOString(),
  },
  {
    id: "ls-2",
    title: "Forklift hourly",
    description: "3T capacity",
    imageUrl: "/placeholder.jpg",
    sellerId: "user-2",
    verified: false,
    status: "active",
    bids: [
      {
        id: "bid-1",
        bidderId: "user-3",
        amount: 150,
        status: "active",
        createdAt: new Date().toISOString(),
      }
    ],
    acceptedBidId: null,
    createdAt: new Date().toISOString(),
  },
]

const ListingSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  imageUrl: z.string().url().optional(),
  sellerId: z.string().min(1),
  verified: z.boolean().default(false),
  status: z.enum(["active", "sold", "expired"]).default("active"),
})

const BidSchema = z.object({
  listingId: z.string().min(1),
  bidderId: z.string().min(1),
  amount: z.number().min(0),
})

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const verified = searchParams.get("verified")
    const search = searchParams.get("search")

    let filtered = listings

    if (status) {
      filtered = filtered.filter(l => l.status === status)
    }

    if (verified !== null) {
      filtered = filtered.filter(l => l.verified === (verified === "true"))
    }

    if (search) {
      const query = search.toLowerCase()
      filtered = filtered.filter(l => 
        l.title.toLowerCase().includes(query) || 
        l.description?.toLowerCase().includes(query)
      )
    }

    return NextResponse.json({
      success: true,
      data: filtered,
      total: filtered.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Failed to fetch listings" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const validated = ListingSchema.parse(body)

    const newListing = {
      id: `ls-${Date.now()}`,
      ...validated,
      bids: [],
      acceptedBidId: null,
      createdAt: new Date().toISOString(),
    }

    // In real implementation, save to Supabase
    listings.push(newListing)

    return NextResponse.json({
      success: true,
      data: newListing
    }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to create listing" },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")
    
    if (!id) {
      return NextResponse.json(
        { success: false, error: "Listing ID required" },
        { status: 400 }
      )
    }

    const body = await request.json()
    const validated = ListingSchema.partial().parse(body)

    const index = listings.findIndex(l => l.id === id)
    if (index === -1) {
      return NextResponse.json(
        { success: false, error: "Listing not found" },
        { status: 404 }
      )
    }

    listings[index] = {
      ...listings[index],
      ...validated,
    }

    return NextResponse.json({
      success: true,
      data: listings[index]
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to update listing" },
      { status: 500 }
    )
  }
}

// Place bid endpoint
export async function PATCH(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const validated = BidSchema.parse(body)

    const listing = listings.find(l => l.id === validated.listingId)
    if (!listing) {
      return NextResponse.json(
        { success: false, error: "Listing not found" },
        { status: 404 }
      )
    }

    const newBid = {
      id: `bid-${Date.now()}`,
      bidderId: validated.bidderId,
      amount: validated.amount,
      status: "active" as const,
      createdAt: new Date().toISOString(),
    }

    listing.bids.push(newBid)

    return NextResponse.json({
      success: true,
      data: newBid
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to place bid" },
      { status: 500 }
    )
  }
}
