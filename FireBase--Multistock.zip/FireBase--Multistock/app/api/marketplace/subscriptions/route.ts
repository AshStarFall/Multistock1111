import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET /api/marketplace/subscriptions - Get user's subscription
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'User ID required' },
        { status: 400 }
      )
    }

    const { data: subscription, error } = await supabase
      .from('seller_subscriptions')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active')
      .single()

    if (error && error.code !== 'PGRST116') {
      throw error
    }

    // If no subscription, return free tier defaults
    if (!subscription) {
      return NextResponse.json({
        success: true,
        subscription: {
          id: null,
          userId,
          tier: 'free',
          listingsLimit: 3,
          listingsUsed: 0,
          featuredListingsLimit: 0,
          featuredListingsUsed: 0,
          commissionRate: 15,
          features: ['Up to 3 listings', '15% commission'],
          startDate: new Date(),
          endDate: null,
          autoRenew: false,
          status: 'active'
        }
      })
    }

    return NextResponse.json({
      success: true,
      subscription: {
        id: subscription.id,
        userId: subscription.user_id,
        tier: subscription.tier,
        listingsLimit: subscription.listings_limit,
        listingsUsed: subscription.listings_used,
        featuredListingsLimit: subscription.featured_listings_limit,
        featuredListingsUsed: subscription.featured_listings_used,
        commissionRate: subscription.commission_rate,
        features: subscription.features,
        startDate: subscription.start_date,
        endDate: subscription.end_date,
        autoRenew: subscription.auto_renew,
        status: subscription.status
      }
    })
  } catch (error) {
    console.error('Error fetching subscription:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch subscription' },
      { status: 500 }
    )
  }
}

// POST /api/marketplace/subscriptions - Create or upgrade subscription
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, tier, billingPeriod } = body

    if (!userId || !tier) {
      return NextResponse.json(
        { success: false, error: 'User ID and tier required' },
        { status: 400 }
      )
    }

    // Get plan details
    const plans: any = {
      free: {
        listings_limit: 3,
        featured_listings_limit: 0,
        commission_rate: 15,
        features: ['Up to 3 listings', '15% commission']
      },
      basic: {
        listings_limit: 15,
        featured_listings_limit: 2,
        commission_rate: 10,
        features: ['Up to 15 listings', '10% commission', '2 featured listings']
      },
      premium: {
        listings_limit: 50,
        featured_listings_limit: 10,
        commission_rate: 5,
        features: ['Up to 50 listings', '5% commission', '10 featured listings']
      },
      enterprise: {
        listings_limit: -1,
        featured_listings_limit: -1,
        commission_rate: 3,
        features: ['Unlimited listings', '3% commission', 'Unlimited featured']
      }
    }

    const plan = plans[tier]
    if (!plan) {
      return NextResponse.json(
        { success: false, error: 'Invalid tier' },
        { status: 400 }
      )
    }

    // Calculate end date
    const startDate = new Date()
    const endDate = new Date()
    if (billingPeriod === 'yearly') {
      endDate.setFullYear(endDate.getFullYear() + 1)
    } else {
      endDate.setMonth(endDate.getMonth() + 1)
    }

    // Cancel existing subscriptions
    await supabase
      .from('seller_subscriptions')
      .update({ status: 'cancelled', updated_at: new Date().toISOString() })
      .eq('user_id', userId)
      .eq('status', 'active')

    // Create new subscription
    const { data: subscription, error } = await supabase
      .from('seller_subscriptions')
      .insert({
        user_id: userId,
        tier,
        listings_limit: plan.listings_limit,
        listings_used: 0,
        featured_listings_limit: plan.featured_listings_limit,
        featured_listings_used: 0,
        commission_rate: plan.commission_rate,
        features: plan.features,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        auto_renew: true,
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: 'Subscription activated successfully',
      subscription
    })
  } catch (error) {
    console.error('Error creating subscription:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create subscription' },
      { status: 500 }
    )
  }
}
