import { NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'
import { getCached, cache } from '@/lib/cache'

/**
 * GET /api/dashboard-stats
 * Returns dashboard statistics with caching
 */
export async function GET() {
  try {
    // Use cached data for 5 minutes
    const stats = await getCached(
      'dashboard-stats',
      async () => {
        // Fetch all data in parallel for better performance
        const [productsRes, ordersRes, customersRes] = await Promise.all([
          supabase.from('products').select('stock_quantity, price, reorder_point'),
          supabase.from('sales_orders').select('total, status, created_at'),
          supabase.from('customers').select('id'),
        ])

        const products = productsRes.data || []
        const orders = ordersRes.data || []
        const customers = customersRes.data || []

        // Calculate statistics
        const totalProducts = products.length
        const lowStock = products.filter(p => p.stock_quantity < p.reorder_point).length
        const outOfStock = products.filter(p => p.stock_quantity === 0).length
        const totalValue = products.reduce((sum, p) => sum + (p.stock_quantity * p.price), 0)

        // Calculate revenue (last 30 days)
        const thirtyDaysAgo = new Date()
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
        const recentOrders = orders.filter(o => 
          new Date(o.created_at) >= thirtyDaysAgo && 
          o.status === 'Fulfilled'
        )
        const revenue = recentOrders.reduce((sum, o) => sum + o.total, 0)

        // Calculate orders
        const pendingOrders = orders.filter(o => o.status === 'Open' || o.status === 'Partially Fulfilled').length
        const totalOrders = orders.length

        return {
          totalProducts,
          lowStock,
          outOfStock,
          totalValue,
          revenue,
          pendingOrders,
          totalOrders,
          totalCustomers: customers.length,
          lastUpdated: new Date().toISOString(),
        }
      },
      300 // Cache for 5 minutes
    )

    return NextResponse.json(stats)
  } catch (error) {
    console.error('Error fetching dashboard stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch dashboard statistics' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/dashboard-stats
 * Clear dashboard stats cache
 */
export async function DELETE() {
  try {
    cache.clear('dashboard-stats')
    return NextResponse.json({ success: true, message: 'Cache cleared' })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to clear cache' },
      { status: 500 }
    )
  }
}
