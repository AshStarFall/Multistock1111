import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"

// Mock data for now - replace with Supabase client
const rentals = [
  {
    id: "r1",
    name: "Drill Machine",
    status: "available",
    rentedTo: "",
    returnDate: "",
    imageUrl: "/placeholder.jpg",
    pricePerDay: 50,
    category: "Power Tools",
    serialNumber: "DM-001",
  },
  {
    id: "r2",
    name: "Hammer Drill",
    status: "in_use",
    rentedTo: "Acme Ltd",
    returnDate: "2025-10-10",
    imageUrl: "/placeholder.jpg",
    pricePerDay: 75,
    category: "Power Tools",
    serialNumber: "HD-002",
  },
  {
    id: "r3",
    name: "Forklift",
    status: "overdue",
    rentedTo: "Beta Inc",
    returnDate: "2025-10-01",
    imageUrl: "/placeholder.jpg",
    pricePerDay: 200,
    category: "Lifting",
    serialNumber: "FL-003",
  },
]

const RentalSchema = z.object({
  name: z.string().min(1),
  category: z.string().optional(),
  imageUrl: z.string().url().optional(),
  pricePerDay: z.number().min(0),
  serialNumber: z.string().optional(),
  status: z.enum(["available", "in_use", "overdue", "maintenance"]).default("available"),
})

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const category = searchParams.get("category")
    const search = searchParams.get("search")

    let filtered = rentals

    if (status) {
      filtered = filtered.filter(r => r.status === status)
    }

    if (category) {
      filtered = filtered.filter(r => r.category === category)
    }

    if (search) {
      const query = search.toLowerCase()
      filtered = filtered.filter(r => 
        r.name.toLowerCase().includes(query) || 
        r.serialNumber?.toLowerCase().includes(query)
      )
    }

    return NextResponse.json({
      success: true,
      data: filtered,
      total: filtered.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Failed to fetch rentals" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const validated = RentalSchema.parse(body)

    const newRental = {
      id: `r-${Date.now()}`,
      ...validated,
      rentedTo: "",
      returnDate: "",
    }

    // In real implementation, save to Supabase
    rentals.push(newRental)

    return NextResponse.json({
      success: true,
      data: newRental
    }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to create rental" },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")
    
    if (!id) {
      return NextResponse.json(
        { success: false, error: "Rental ID required" },
        { status: 400 }
      )
    }

    const body = await request.json()
    const validated = RentalSchema.partial().parse(body)

    const index = rentals.findIndex(r => r.id === id)
    if (index === -1) {
      return NextResponse.json(
        { success: false, error: "Rental not found" },
        { status: 404 }
      )
    }

    rentals[index] = {
      ...rentals[index],
      ...validated,
    }

    return NextResponse.json({
      success: true,
      data: rentals[index]
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to update rental" },
      { status: 500 }
    )
  }
}
