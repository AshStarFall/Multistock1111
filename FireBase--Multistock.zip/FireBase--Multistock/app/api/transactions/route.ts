import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'



// GET: Fetch user transactions
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') || 'temp-user-id'
    const type = searchParams.get('type')
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '100')

    let query = supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (type) {
      query = query.eq('type', type)
    }

    if (status) {
      query = query.eq('status', status)
    }

    const { data, error } = await query

    if (error) throw error

    // Transform to frontend interface
    const transactions = data.map((t: any) => ({
      id: t.id,
      userId: t.user_id,
      type: t.type,
      status: t.status,
      amount: t.amount,
      currency: t.currency,
      paymentMethod: t.payment_method,
      orderId: t.order_id,
      description: t.description,
      referenceNumber: t.reference_number,
      receiptUrl: t.receipt_url,
      metadata: t.metadata,
      createdAt: t.created_at,
      updatedAt: t.updated_at,
      completedAt: t.completed_at
    }))

    return NextResponse.json({ transactions })
  } catch (error) {
    console.error('Error fetching transactions:', error)
    return NextResponse.json(
      { error: 'Failed to fetch transactions' },
      { status: 500 }
    )
  }
}

// POST: Create new transaction
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const {
      userId,
      type,
      amount,
      currency = 'INR',
      paymentMethod,
      orderId,
      description,
      metadata
    } = body

    // Generate reference number
    const referenceNumber = `TXN${Date.now()}${Math.random().toString(36).substr(2, 9).toUpperCase()}`

    const { data, error } = await supabase
      .from('transactions')
      .insert({
        user_id: userId,
        type,
        status: 'pending',
        amount,
        currency,
        payment_method: paymentMethod,
        order_id: orderId,
        description,
        reference_number: referenceNumber,
        metadata,
        created_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      transaction: {
        id: data.id,
        userId: data.user_id,
        type: data.type,
        status: data.status,
        amount: data.amount,
        currency: data.currency,
        paymentMethod: data.payment_method,
        orderId: data.order_id,
        description: data.description,
        referenceNumber: data.reference_number,
        metadata: data.metadata,
        createdAt: data.created_at
      }
    })
  } catch (error) {
    console.error('Error creating transaction:', error)
    return NextResponse.json(
      { error: 'Failed to create transaction' },
      { status: 500 }
    )
  }
}

// PATCH: Update transaction status
export async function PATCH(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { transactionId, status, receiptUrl } = body

    const updateData: any = {
      status,
      updated_at: new Date().toISOString()
    }

    if (status === 'completed') {
      updateData.completed_at = new Date().toISOString()
    }

    if (receiptUrl) {
      updateData.receipt_url = receiptUrl
    }

    const { data, error } = await supabase
      .from('transactions')
      .update(updateData)
      .eq('id', transactionId)
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      transaction: {
        id: data.id,
        status: data.status,
        receiptUrl: data.receipt_url,
        completedAt: data.completed_at
      }
    })
  } catch (error) {
    console.error('Error updating transaction:', error)
    return NextResponse.json(
      { error: 'Failed to update transaction' },
      { status: 500 }
    )
  }
}

// DELETE: Remove transaction
export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const transactionId = searchParams.get('id')

    if (!transactionId) {
      return NextResponse.json(
        { error: 'Transaction ID is required' },
        { status: 400 }
      )
    }

    const { error } = await supabase
      .from('transactions')
      .delete()
      .eq('id', transactionId)

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: 'Transaction deleted successfully'
    })
  } catch (error) {
    console.error('Error deleting transaction:', error)
    return NextResponse.json(
      { error: 'Failed to delete transaction' },
      { status: 500 }
    )
  }
}
