import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET: Get transaction statistics
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId') || 'temp-user-id'
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    let query = supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)

    if (startDate) {
      query = query.gte('created_at', startDate)
    }

    if (endDate) {
      query = query.lte('created_at', endDate)
    }

    const { data, error } = await query

    if (error) throw error

    // Calculate statistics
    const totalTransactions = data.length
    const successfulTransactions = data.filter(t => t.status === 'completed').length
    const failedTransactions = data.filter(t => t.status === 'failed').length
    const pendingTransactions = data.filter(t => 
      t.status === 'pending' || t.status === 'processing'
    ).length
    
    const totalAmount = data
      .filter(t => t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0)
    
    const averageAmount = successfulTransactions > 0 
      ? totalAmount / successfulTransactions 
      : 0

    // Group by type
    const byType = data.reduce((acc: any, t) => {
      acc[t.type] = (acc[t.type] || 0) + 1
      return acc
    }, {})

    // Group by payment method
    const byPaymentMethod = data.reduce((acc: any, t) => {
      acc[t.payment_method] = (acc[t.payment_method] || 0) + 1
      return acc
    }, {})

    // Monthly breakdown (last 6 months)
    const monthlyData: any[] = []
    const now = new Date()
    
    for (let i = 5; i >= 0; i--) {
      const month = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthStart = month.toISOString()
      const monthEnd = new Date(month.getFullYear(), month.getMonth() + 1, 0, 23, 59, 59).toISOString()
      
      const monthTransactions = data.filter(t => {
        const createdAt = new Date(t.created_at)
        return createdAt >= new Date(monthStart) && createdAt <= new Date(monthEnd)
      })
      
      const monthTotal = monthTransactions
        .filter(t => t.status === 'completed')
        .reduce((sum, t) => sum + t.amount, 0)
      
      monthlyData.push({
        month: month.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        transactions: monthTransactions.length,
        amount: monthTotal
      })
    }

    return NextResponse.json({
      totalTransactions,
      successfulTransactions,
      failedTransactions,
      pendingTransactions,
      totalAmount,
      averageAmount,
      byType,
      byPaymentMethod,
      monthlyData
    })
  } catch (error) {
    console.error('Error fetching transaction statistics:', error)
    return NextResponse.json(
      { error: 'Failed to fetch statistics' },
      { status: 500 }
    )
  }
}
