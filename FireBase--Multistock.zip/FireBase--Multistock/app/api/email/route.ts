import { NextRequest, NextResponse } from 'next/server'
import { supabase, isSupabaseConfigured } from '@/lib/supabase/server'
import { createEmailService } from '@/lib/email-service'

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const emailService = createEmailService(supabase)

    const body = await request.json()
    const { 
      template_name, 
      recipient_email, 
      recipient_name, 
      variables = {},
      subject,
      body_html,
      body_text
    } = body

    // Validate required fields
    if (!recipient_email) {
      return NextResponse.json(
        { error: 'Recipient email is required' },
        { status: 400 }
      )
    }

    let success = false

    if (template_name) {
      // Send using template
      success = await emailService.sendTemplateEmail(
        template_name,
        recipient_email,
        variables
      )
    } else if (subject && (body_html || body_text)) {
      // Send custom email
      success = await emailService.sendEmail({
        recipient_email,
        recipient_name,
        subject,
        body_html,
        body_text
      })
    } else {
      return NextResponse.json(
        { error: 'Either template_name or subject with body is required' },
        { status: 400 }
      )
    }

    if (success) {
      return NextResponse.json({ 
        success: true, 
        message: 'Email sent successfully' 
      })
    } else {
      return NextResponse.json(
        { error: 'Failed to send email' },
        { status: 500 }
      )
    }
  } catch (error) {
    console.error('Email API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const emailService = createEmailService(supabase)

    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '50')

    const logs = await emailService.getEmailLogs(limit)
    const templates = await emailService.getEmailTemplates()

    return NextResponse.json({
      logs,
      templates
    })
  } catch (error) {
    console.error('Email API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
