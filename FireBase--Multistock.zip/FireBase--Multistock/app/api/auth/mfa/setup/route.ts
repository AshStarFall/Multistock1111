import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { generateMFASecret, verifyMFAToken } from "@/lib/mfa"
import { requireAuth } from "@/lib/auth-server"

const SetupMFASchema = z.object({
  secret: z.string().optional(),
  token: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const user = requireAuth(request)
    const body = await request.json()
    const { secret, token } = SetupMFASchema.parse(body)

    if (!secret) {
      // Generate new MFA secret
      const mfaSecret = generateMFASecret(user.email)
      
      return NextResponse.json({
        success: true,
        secret: mfaSecret.secret,
        qrCodeUrl: mfaSecret.qrCodeUrl,
        message: "Scan QR code with authenticator app"
      })
    }

    if (!token) {
      return NextResponse.json(
        { success: false, error: "MFA token required for verification" },
        { status: 400 }
      )
    }

    // Verify MFA token
    if (!verifyMFAToken(secret, token)) {
      return NextResponse.json(
        { success: false, error: "Invalid MFA token" },
        { status: 400 }
      )
    }

    // In production, save MFA secret to database
    // await updateUserMFA(user.id, secret)

    return NextResponse.json({
      success: true,
      message: "MFA setup completed successfully"
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "MFA setup failed" },
      { status: 500 }
    )
  }
}
