import { NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

// POST /api/admin/switch-user
// Allows SuperAdmin to switch/impersonate another user
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { targetUserId, adminUserId } = await request.json()

    // Verify the requesting user is SuperAdmin
    const { data: adminUser, error: adminError } = await supabase
      .from('users')
      .select('*')
      .eq('id', adminUserId)
      .eq('role', 'SuperAdmin')
      .single()

    if (adminError || !adminUser) {
      return NextResponse.json(
        { success: false, error: "Unauthorized - Only SuperAdmin can switch users" },
        { status: 403 }
      )
    }

    // Get target user details
    const { data: targetUser, error: targetError } = await supabase
      .from('users')
      .select('*')
      .eq('id', targetUserId)
      .eq('is_active', true)
      .single()

    if (targetError || !targetUser) {
      return NextResponse.json(
        { success: false, error: "Target user not found or inactive" },
        { status: 404 }
      )
    }

    // Prevent switching to another SuperAdmin (security)
    if (targetUser.role === 'SuperAdmin' && targetUser.id !== adminUser.id) {
      return NextResponse.json(
        { success: false, error: "Cannot impersonate another SuperAdmin" },
        { status: 403 }
      )
    }

    // Log the impersonation for audit trail
    await supabase
      .from('audit_logs')
      .insert({
        user_id: adminUserId,
        action: 'user_impersonation_start',
        details: {
          target_user_id: targetUserId,
          target_user_email: targetUser.email,
          target_user_role: targetUser.role,
          timestamp: new Date().toISOString()
        }
      })

    return NextResponse.json({
      success: true,
      message: "User switch initiated successfully",
      user: {
        id: targetUser.id,
        email: targetUser.email,
        name: targetUser.name,
        role: targetUser.role,
        department: targetUser.department,
        isImpersonated: true,
        originalAdmin: {
          id: adminUser.id,
          email: adminUser.email,
          name: adminUser.name
        }
      }
    })

  } catch (error) {
    console.error('Switch user error:', error)
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/switch-user
// Stop impersonation and return to original SuperAdmin
export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { adminUserId, targetUserId } = await request.json()

    // Log the end of impersonation
    await supabase
      .from('audit_logs')
      .insert({
        user_id: adminUserId,
        action: 'user_impersonation_end',
        details: {
          target_user_id: targetUserId,
          timestamp: new Date().toISOString()
        }
      })

    return NextResponse.json({
      success: true,
      message: "Impersonation ended successfully"
    })

  } catch (error) {
    console.error('End impersonation error:', error)
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 }
    )
  }
}