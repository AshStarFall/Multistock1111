import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'



// POST: Update user profile
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const formData = await request.formData()
    const userId = formData.get('userId') as string
    const profileDataStr = formData.get('profileData') as string
    const profileData = JSON.parse(profileDataStr)
    const avatarFile = formData.get('avatar') as File | null

    let avatarUrl = profileData.avatar

    // Handle avatar upload
    if (avatarFile) {
      // TODO: Upload to storage (Supabase Storage, S3, etc.)
      // For now, we'll use a placeholder
      // const { data, error } = await supabase.storage
      //   .from('avatars')
      //   .upload(`${userId}/${avatarFile.name}`, avatarFile)
      
      // avatarUrl = data?.path
      console.log('Avatar upload pending:', avatarFile.name)
    }

    // Update user profile in database
    const { data, error } = await supabase
      .from('user_profiles')
      .upsert({
        user_id: userId,
        first_name: profileData.firstName,
        last_name: profileData.lastName,
        email: profileData.email,
        phone: profileData.phone,
        address: profileData.address,
        city: profileData.city,
        state: profileData.state,
        zip_code: profileData.zipCode,
        country: profileData.country,
        company: profileData.company,
        bio: profileData.bio,
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: 'Profile updated successfully',
      profile: data
    })
  } catch (error) {
    console.error('Error updating profile:', error)
    return NextResponse.json(
      { error: 'Failed to update profile' },
      { status: 500 }
    )
  }
}

// GET: Fetch user profile
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('user_id', userId)
      .single()

    if (error && error.code !== 'PGRST116') throw error

    // Return default profile if not found
    if (!data) {
      return NextResponse.json({
        profile: {
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          address: '',
          city: '',
          state: '',
          zipCode: '',
          country: 'India',
          company: '',
          bio: '',
          avatar: ''
        }
      })
    }

    return NextResponse.json({
      profile: {
        firstName: data.first_name,
        lastName: data.last_name,
        email: data.email,
        phone: data.phone,
        address: data.address,
        city: data.city,
        state: data.state,
        zipCode: data.zip_code,
        country: data.country,
        company: data.company,
        bio: data.bio,
        avatar: data.avatar_url
      }
    })
  } catch (error) {
    console.error('Error fetching profile:', error)
    return NextResponse.json(
      { error: 'Failed to fetch profile' },
      { status: 500 }
    )
  }
}
