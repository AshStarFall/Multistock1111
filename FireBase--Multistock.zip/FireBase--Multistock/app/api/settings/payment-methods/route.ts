import { NextRequest, NextResponse } from 'next/server'
import { supabase, isSupabaseConfigured } from '@/lib/supabase/server'

// GET: Fetch payment methods
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const { data, error } = await supabase
      .from('payment_methods')
      .select('*')
      .eq('user_id', userId)
      .order('is_default', { ascending: false })
      .order('created_at', { ascending: false })

    if (error) throw error

    const methods = data.map((m: any) => ({
      id: m.id,
      type: m.type,
      last4: m.last4,
      cardBrand: m.card_brand,
      expiryMonth: m.expiry_month,
      expiryYear: m.expiry_year,
      upiId: m.upi_id,
      bankName: m.bank_name,
      accountLast4: m.account_last4,
      isDefault: m.is_default,
      createdAt: m.created_at
    }))

    return NextResponse.json({ methods })
  } catch (error) {
    console.error('Error fetching payment methods:', error)
    return NextResponse.json(
      { error: 'Failed to fetch payment methods' },
      { status: 500 }
    )
  }
}

// POST: Add payment method
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { userId, type, cardNumber, cardName, expiryMonth, expiryYear, upiId, bankName, accountNumber, ifscCode } = body

    let methodData: any = {
      user_id: userId,
      type,
      is_default: false,
      created_at: new Date().toISOString()
    }

    if (type === 'credit_card' || type === 'debit_card') {
      // Extract last 4 digits and detect brand
      const last4 = cardNumber.replace(/\s/g, '').slice(-4)
      const cardBrand = detectCardBrand(cardNumber)
      
      methodData = {
        ...methodData,
        last4,
        card_brand: cardBrand,
        card_name: cardName,
        expiry_month: parseInt(expiryMonth),
        expiry_year: parseInt(expiryYear)
        // CVV should never be stored
      }
    } else if (type === 'upi') {
      methodData.upi_id = upiId
    } else if (type === 'bank_account') {
      const accountLast4 = accountNumber.slice(-4)
      methodData = {
        ...methodData,
        bank_name: bankName,
        account_last4: accountLast4,
        ifsc_code: ifscCode
        // Full account number should never be stored
      }
    }

    const { data, error } = await supabase
      .from('payment_methods')
      .insert(methodData)
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      method: {
        id: data.id,
        type: data.type,
        last4: data.last4,
        cardBrand: data.card_brand,
        expiryMonth: data.expiry_month,
        expiryYear: data.expiry_year,
        upiId: data.upi_id,
        bankName: data.bank_name,
        accountLast4: data.account_last4,
        isDefault: data.is_default,
        createdAt: data.created_at
      }
    })
  } catch (error) {
    console.error('Error adding payment method:', error)
    return NextResponse.json(
      { error: 'Failed to add payment method' },
      { status: 500 }
    )
  }
}

// DELETE: Remove payment method
export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'Payment method ID is required' },
        { status: 400 }
      )
    }

    const { error } = await supabase
      .from('payment_methods')
      .delete()
      .eq('id', id)

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: 'Payment method removed'
    })
  } catch (error) {
    console.error('Error deleting payment method:', error)
    return NextResponse.json(
      { error: 'Failed to delete payment method' },
      { status: 500 }
    )
  }
}

// Helper function to detect card brand
function detectCardBrand(cardNumber: string): string {
  const cleaned = cardNumber.replace(/\s/g, '')
  
  if (/^4/.test(cleaned)) return 'Visa'
  if (/^5[1-5]/.test(cleaned)) return 'Mastercard'
  if (/^3[47]/.test(cleaned)) return 'American Express'
  if (/^6(?:011|5)/.test(cleaned)) return 'Discover'
  if (/^35/.test(cleaned)) return 'JCB'
  if (/^62/.test(cleaned)) return 'UnionPay'
  if (/^(?:5018|5020|5038|6304|6759|6761|6763)/.test(cleaned)) return 'Maestro'
  if (/^(?:2131|1800|3088)/.test(cleaned)) return 'RuPay'
  
  return 'Unknown'
}
