import { NextRequest, NextResponse } from 'next/server'
import { supabase, isSupabaseConfigured } from '@/lib/supabase/server'

// GET: Fetch privacy settings
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const { data, error } = await supabase
      .from('privacy_settings')
      .select('*')
      .eq('user_id', userId)
      .single()

    if (error && error.code !== 'PGRST116') throw error

    // Return defaults if not found
    if (!data) {
      return NextResponse.json({
        settings: {
          profileVisibility: true,
          showEmail: false,
          showPhone: false,
          showAddress: false,
          activityTracking: true,
          marketingEmails: false,
          thirdPartySharing: false
        }
      })
    }

    return NextResponse.json({
      settings: {
        profileVisibility: data.profile_visibility,
        showEmail: data.show_email,
        showPhone: data.show_phone,
        showAddress: data.show_address,
        activityTracking: data.activity_tracking,
        marketingEmails: data.marketing_emails,
        thirdPartySharing: data.third_party_sharing
      }
    })
  } catch (error) {
    console.error('Error fetching privacy settings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch privacy settings' },
      { status: 500 }
    )
  }
}

// POST: Update privacy settings
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { userId, settings } = body

    const { error } = await supabase
      .from('privacy_settings')
      .upsert({
        user_id: userId,
        profile_visibility: settings.profileVisibility,
        show_email: settings.showEmail,
        show_phone: settings.showPhone,
        show_address: settings.showAddress,
        activity_tracking: settings.activityTracking,
        marketing_emails: settings.marketingEmails,
        third_party_sharing: settings.thirdPartySharing,
        updated_at: new Date().toISOString()
      })

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: 'Privacy settings updated'
    })
  } catch (error) {
    console.error('Error updating privacy settings:', error)
    return NextResponse.json(
      { error: 'Failed to update privacy settings' },
      { status: 500 }
    )
  }
}
