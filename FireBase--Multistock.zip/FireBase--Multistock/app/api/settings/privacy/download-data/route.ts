import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'



// GET: Download all user data
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Fetch all user data from various tables
    const [
      { data: profile },
      { data: transactions },
      { data: orders },
      { data: reviews },
      { data: notifications },
      { data: privacySettings }
    ] = await Promise.all([
      supabase.from('user_profiles').select('*').eq('user_id', userId).single(),
      supabase.from('transactions').select('*').eq('user_id', userId),
      supabase.from('orders').select('*').eq('user_id', userId),
      supabase.from('reviews').select('*').eq('user_id', userId),
      supabase.from('notifications').select('*').eq('user_id', userId),
      supabase.from('privacy_settings').select('*').eq('user_id', userId).single()
    ])

    const userData = {
      userId,
      exportDate: new Date().toISOString(),
      profile: profile || {},
      transactions: transactions || [],
      orders: orders || [],
      reviews: reviews || [],
      notifications: notifications || [],
      privacySettings: privacySettings || {}
    }

    const jsonData = JSON.stringify(userData, null, 2)

    return new NextResponse(jsonData, {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="user-data-${userId}-${new Date().toISOString().split('T')[0]}.json"`
      }
    })
  } catch (error) {
    console.error('Error downloading user data:', error)
    return NextResponse.json(
      { error: 'Failed to download user data' },
      { status: 500 }
    )
  }
}
