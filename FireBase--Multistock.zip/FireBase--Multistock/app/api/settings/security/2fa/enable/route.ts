import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'
import { authenticator } from 'otplib'
import QRCode from 'qrcode'



// POST: Enable 2FA
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { userId } = body

    // Generate secret
    const secret = authenticator.generateSecret()

    // Generate QR code
    const otpauth = authenticator.keyuri(userId, 'MultiStock', secret)
    const qrCode = await QRCode.toDataURL(otpauth)

    // Store secret temporarily (not enabled yet)
    const { error } = await supabase
      .from('user_2fa')
      .upsert({
        user_id: userId,
        secret,
        enabled: false,
        created_at: new Date().toISOString()
      })

    if (error) throw error

    return NextResponse.json({
      success: true,
      qrCode,
      secret // Send for backup codes
    })
  } catch (error) {
    console.error('Error enabling 2FA:', error)
    return NextResponse.json(
      { error: 'Failed to enable 2FA' },
      { status: 500 }
    )
  }
}
