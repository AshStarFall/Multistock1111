import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'



// POST: Disable 2FA
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { userId } = body

    // Disable 2FA
    const { error } = await supabase
      .from('user_2fa')
      .update({
        enabled: false,
        disabled_at: new Date().toISOString()
      })
      .eq('user_id', userId)

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: '2FA disabled successfully'
    })
  } catch (error) {
    console.error('Error disabling 2FA:', error)
    return NextResponse.json(
      { error: 'Failed to disable 2FA' },
      { status: 500 }
    )
  }
}
