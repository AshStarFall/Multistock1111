import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'
import { authenticator } from 'otplib'



// POST: Verify 2FA code and enable
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { userId, code } = body

    // Fetch secret
    const { data: twoFAData, error: fetchError } = await supabase
      .from('user_2fa')
      .select('secret')
      .eq('user_id', userId)
      .single()

    if (fetchError) throw fetchError

    // Verify code
    const isValid = authenticator.verify({
      token: code,
      secret: twoFAData.secret
    })

    if (!isValid) {
      return NextResponse.json(
        { error: 'Invalid verification code' },
        { status: 401 }
      )
    }

    // Enable 2FA
    const { error: updateError } = await supabase
      .from('user_2fa')
      .update({
        enabled: true,
        verified_at: new Date().toISOString()
      })
      .eq('user_id', userId)

    if (updateError) throw updateError

    return NextResponse.json({
      success: true,
      message: '2FA enabled successfully'
    })
  } catch (error) {
    console.error('Error verifying 2FA:', error)
    return NextResponse.json(
      { error: 'Failed to verify 2FA code' },
      { status: 500 }
    )
  }
}
