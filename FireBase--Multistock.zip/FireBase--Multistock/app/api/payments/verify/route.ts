import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'
import { supabase } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      orderData,
    } = body

    // Verify signature
    const secret = process.env.RAZORPAY_KEY_SECRET || 'rzp_test_secret'
    const generated_signature = crypto
      .createHmac('sha256', secret)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex')

    if (generated_signature !== razorpay_signature) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Invalid signature' 
        },
        { status: 400 }
      )
    }

    // Store payment transaction in database
    const { data: transaction, error: transactionError } = await supabase
      .from('payment_transactions')
      .insert({
        order_id: razorpay_order_id,
        payment_id: razorpay_payment_id,
        signature: razorpay_signature,
        amount: orderData?.amount || 0,
        currency: orderData?.currency || 'INR',
        status: 'success',
        customer_email: orderData?.email || null,
        customer_name: orderData?.name || null,
        order_details: orderData || {},
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (transactionError) {
      console.error('Error storing transaction:', transactionError)
      // Don't fail the payment verification even if storage fails
    }

    return NextResponse.json({
      success: true,
      verified: true,
      transaction,
    })
  } catch (error: any) {
    console.error('Error verifying payment:', error)
    return NextResponse.json(
      { 
        success: false,
        error: 'Payment verification failed',
        message: error.message 
      },
      { status: 500 }
    )
  }
}
