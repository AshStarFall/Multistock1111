import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET /api/chat/conversations - Fetch user's chats
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'User ID required' },
        { status: 400 }
      )
    }

    const { data: chatParticipants, error } = await supabase
      .from('chat_participants')
      .select(`
        chat_id,
        chats (
          id,
          type,
          name,
          avatar,
          created_at,
          updated_at
        )
      `)
      .eq('user_id', userId)

    if (error) throw error

    const chatIds = chatParticipants?.map(cp => cp.chat_id) || []

    if (chatIds.length === 0) {
      return NextResponse.json({ success: true, chats: [] })
    }

    // Get all participants for these chats
    const { data: allParticipants } = await supabase
      .from('chat_participants')
      .select(`
        *,
        user:users (
          id,
          email,
          user_profiles (first_name, last_name, avatar_url)
        )
      `)
      .in('chat_id', chatIds)

    // Get last messages
    const { data: lastMessages } = await supabase
      .from('chat_messages')
      .select('*')
      .in('chat_id', chatIds)
      .order('created_at', { ascending: false })

    // Group participants by chat
    const participantsByChat = allParticipants?.reduce((acc: any, p: any) => {
      if (!acc[p.chat_id]) acc[p.chat_id] = []
      acc[p.chat_id].push({
        userId: p.user_id,
        userName: p.user.user_profiles
          ? `${p.user.user_profiles.first_name} ${p.user.user_profiles.last_name}`.trim()
          : p.user.email,
        userAvatar: p.user.user_profiles?.avatar_url,
        role: p.role,
        joinedAt: p.joined_at,
        lastSeenAt: p.last_seen_at
      })
      return acc
    }, {})

    // Build chat objects
    const chats = chatParticipants?.map((cp: any) => {
      const chat = cp.chats
      const lastMsg = lastMessages?.find(m => m.chat_id === chat.id)
      
      return {
        id: chat.id,
        type: chat.type,
        name: chat.name,
        avatar: chat.avatar,
        participants: participantsByChat?.[chat.id] || [],
        lastMessage: lastMsg ? {
          id: lastMsg.id,
          content: lastMsg.content,
          type: lastMsg.type,
          createdAt: lastMsg.created_at
        } : undefined,
        unreadCount: 0, // TODO: Calculate unread
        createdAt: chat.created_at,
        updatedAt: chat.updated_at
      }
    }) || []

    return NextResponse.json({ success: true, chats })
  } catch (error) {
    console.error('Error fetching conversations:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch conversations' },
      { status: 500 }
    )
  }
}

// POST /api/chat/conversations - Create new chat
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { type, name, participants } = body

    if (!type || !participants || participants.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Create chat
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .insert({
        type,
        name: type === 'group' ? name : null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (chatError) throw chatError

    // Add participants
    const participantRecords = participants.map((userId: string) => ({
      chat_id: chat.id,
      user_id: userId,
      role: 'member',
      joined_at: new Date().toISOString()
    }))

    const { error: participantsError } = await supabase
      .from('chat_participants')
      .insert(participantRecords)

    if (participantsError) throw participantsError

    return NextResponse.json({ success: true, chat })
  } catch (error) {
    console.error('Error creating chat:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create chat' },
      { status: 500 }
    )
  }
}
