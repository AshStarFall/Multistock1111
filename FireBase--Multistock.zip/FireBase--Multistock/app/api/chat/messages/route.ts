import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'



// GET /api/chat/messages - Fetch messages for a chat
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const chatId = searchParams.get('chatId')

    if (!chatId) {
      return NextResponse.json(
        { success: false, error: 'Chat ID required' },
        { status: 400 }
      )
    }

    const { data: messages, error } = await supabase
      .from('chat_messages')
      .select(`
        *,
        sender:users!chat_messages_sender_id_fkey (
          id,
          email,
          user_profiles (first_name, last_name, avatar_url)
        )
      `)
      .eq('chat_id', chatId)
      .order('created_at', { ascending: true })

    if (error) throw error

    const transformedMessages = messages?.map((msg: any) => ({
      id: msg.id,
      chatId: msg.chat_id,
      senderId: msg.sender_id,
      senderName: msg.sender.user_profiles
        ? `${msg.sender.user_profiles.first_name} ${msg.sender.user_profiles.last_name}`.trim()
        : msg.sender.email,
      senderAvatar: msg.sender.user_profiles?.avatar_url,
      type: msg.type,
      content: msg.content,
      fileUrl: msg.file_url,
      fileName: msg.file_name,
      fileSize: msg.file_size,
      replyTo: msg.reply_to,
      isRead: msg.is_read,
      readBy: msg.read_by || [],
      createdAt: msg.created_at,
      updatedAt: msg.updated_at
    })) || []

    return NextResponse.json({ success: true, messages: transformedMessages })
  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch messages' },
      { status: 500 }
    )
  }
}

// POST /api/chat/messages - Send a message
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { chatId, senderId, content, type = 'text', fileUrl, fileName, fileSize, replyTo } = body

    if (!chatId || !senderId || !content) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Get sender info
    const { data: userData } = await supabase
      .from('users')
      .select('email, user_profiles(first_name, last_name, avatar_url)')
      .eq('id', senderId)
      .single()

    const profile = Array.isArray(userData?.user_profiles) 
      ? userData.user_profiles[0] 
      : userData?.user_profiles

    const senderName = profile
      ? `${profile.first_name} ${profile.last_name}`.trim()
      : userData?.email || 'Unknown'

    // Insert message
    const { data: message, error } = await supabase
      .from('chat_messages')
      .insert({
        chat_id: chatId,
        sender_id: senderId,
        sender_name: senderName,
        type,
        content,
        file_url: fileUrl,
        file_name: fileName,
        file_size: fileSize,
        reply_to: replyTo,
        is_read: false,
        read_by: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error

    // Update chat's updated_at
    await supabase
      .from('chats')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', chatId)

    // TODO: Send real-time notification to other participants
    // TODO: Send push notification if user is offline

    return NextResponse.json({ success: true, message })
  } catch (error) {
    console.error('Error sending message:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to send message' },
      { status: 500 }
    )
  }
}
