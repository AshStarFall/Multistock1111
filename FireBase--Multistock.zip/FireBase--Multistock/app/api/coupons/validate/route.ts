import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { validateCoupon } from '@/lib/coupons';

;

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json();
    const { code, orderAmount } = body;
    const userId = request.headers.get('x-user-id') || 'user_1';

    if (!code || !orderAmount) {
      return NextResponse.json(
        { valid: false, error: 'Code and order amount are required' },
        { status: 400 }
      );
    }

    // Fetch coupon from database
    const { data: coupon, error } = await supabase
      .from('coupons')
      .select('*')
      .eq('code', code.toUpperCase())
      .single();

    if (error || !coupon) {
      return NextResponse.json({
        valid: false,
        error: 'Invalid coupon code',
      });
    }

    // Check user usage count
    const { data: usages } = await supabase
      .from('coupon_usages')
      .select('id')
      .eq('coupon_id', coupon.id)
      .eq('user_id', userId);

    const userUsageCount = usages?.length || 0;

    // Validate coupon
    const validation = validateCoupon(
      {
        ...coupon,
        usageLimit: coupon.usage_limit,
        usageCount: coupon.usage_count,
        perUserLimit: coupon.per_user_limit,
        minPurchaseAmount: coupon.min_purchase_amount,
        maxDiscountAmount: coupon.max_discount_amount,
        startDate: coupon.start_date,
        endDate: coupon.end_date,
        applicableProducts: coupon.applicable_products,
        applicableCategories: coupon.applicable_categories,
        excludedProducts: coupon.excluded_products,
        isPublic: coupon.is_public,
        createdBy: coupon.created_by,
        createdAt: coupon.created_at,
      },
      orderAmount,
      userId,
      userUsageCount
    );

    return NextResponse.json(validation);
  } catch (error: any) {
    console.error('Error validating coupon:', error);
    return NextResponse.json(
      { valid: false, error: 'Validation failed', details: error.message },
      { status: 500 }
    );
  }
}
