import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"

// Mock data for now - replace with Supabase client
const lockers = [
  { id: "L-101", status: "available", lastUpdate: "2025-10-01", passwordHash: null },
  { id: "L-102", status: "in_use", lastUpdate: "2025-10-03", passwordHash: "hashed_password_123" },
  { id: "L-103", status: "maintenance", lastUpdate: "2025-09-28", passwordHash: null },
]

const LockerSchema = z.object({
  lockerNumber: z.string().min(1),
  status: z.enum(["available", "in_use", "maintenance"]).default("available"),
  customerId: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")

    let filtered = lockers

    if (status) {
      filtered = filtered.filter(l => l.status === status)
    }

    return NextResponse.json({
      success: true,
      data: filtered,
      total: filtered.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Failed to fetch lockers" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const validated = LockerSchema.parse(body)

    const newLocker = {
      id: `L-${Date.now()}`,
      ...validated,
      lastUpdate: new Date().toISOString(),
      passwordHash: null,
    }

    // In real implementation, save to Supabase
    lockers.push(newLocker)

    return NextResponse.json({
      success: true,
      data: newLocker
    }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to create locker" },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")
    
    if (!id) {
      return NextResponse.json(
        { success: false, error: "Locker ID required" },
        { status: 400 }
      )
    }

    const body = await request.json()
    const validated = LockerSchema.partial().parse(body)

    const index = lockers.findIndex(l => l.id === id)
    if (index === -1) {
      return NextResponse.json(
        { success: false, error: "Locker not found" },
        { status: 404 }
      )
    }

    lockers[index] = {
      ...lockers[index],
      ...validated,
      lastUpdate: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: lockers[index]
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to update locker" },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")
    
    if (!id) {
      return NextResponse.json(
        { success: false, error: "Locker ID required" },
        { status: 400 }
      )
    }

    const index = lockers.findIndex(l => l.id === id)
    if (index === -1) {
      return NextResponse.json(
        { success: false, error: "Locker not found" },
        { status: 404 }
      )
    }

    lockers.splice(index, 1)

    return NextResponse.json({
      success: true,
      message: "Locker deleted successfully"
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Failed to delete locker" },
      { status: 500 }
    )
  }
}
