import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { supabase } from "@/lib/supabase"
import { getCached, cache } from "@/lib/cache"

const ProductSchema = z.object({
  sku: z.string().min(1),
  name: z.string().min(1),
  category: z.string().optional(),
  unit: z.string().default("pcs"),
  price: z.number().min(0),
  stock_quantity: z.number().int().min(0).optional().default(0),
  reorder_point: z.number().min(0).optional().default(10),
  description: z.string().optional(),
  barcode: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const limit = searchParams.get("limit")

    // Create cache key based on query params
    const cacheKey = `products:list:${category || 'all'}:${search || 'none'}:${limit || 'all'}`

    // Get cached data or fetch from database
    const products = await getCached(
      cacheKey,
      async () => {
        let query = supabase.from('products').select('*')

        // Apply filters
        if (category) {
          query = query.eq('category', category)
        }

        if (search) {
          query = query.or(`name.ilike.%${search}%,sku.ilike.%${search}%`)
        }

        if (limit) {
          query = query.limit(parseInt(limit))
        }

        // Order by created_at descending
        query = query.order('created_at', { ascending: false })

        const { data, error } = await query

        if (error) throw error

        return data || []
      },
      300 // Cache for 5 minutes
    )

    return NextResponse.json(products)
  } catch (error: any) {
    console.error("Error fetching products:", error)
    return NextResponse.json(
      { error: "Failed to fetch products", details: error.message },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const validated = ProductSchema.parse(body)

    const { data, error } = await supabase
      .from('products')
      .insert([validated])
      .select()
      .single()

    if (error) throw error

    // Clear product cache
    cache.clearPattern('products:*')
    cache.clear('dashboard-stats')

    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }
    console.error("Error creating product:", error)
    return NextResponse.json(
      { error: "Failed to create product" },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { id, ...updates } = body

    if (!id) {
      return NextResponse.json(
        { error: "Product ID is required" },
        { status: 400 }
      )
    }

    const validated = ProductSchema.partial().parse(updates)

    const { data, error } = await supabase
      .from('products')
      .update(validated)
      .eq('id', id)
      .select()
      .single()

    if (error) throw error

    // Clear product cache
    cache.clearPattern('products:*')
    cache.clear('dashboard-stats')

    return NextResponse.json(data)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation failed", details: error.errors },
        { status: 400 }
      )
    }
    console.error("Error updating product:", error)
    return NextResponse.json(
      { error: "Failed to update product" },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json(
        { error: "Product ID is required" },
        { status: 400 }
      )
    }

    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id)

    if (error) throw error

    // Clear product cache
    cache.clearPattern('products:*')
    cache.clear('dashboard-stats')

    return NextResponse.json({ success: true, message: "Product deleted" })
  } catch (error: any) {
    console.error("Error deleting product:", error)
    return NextResponse.json(
      { error: "Failed to delete product", details: error.message },
      { status: 500 }
    )
  }
}