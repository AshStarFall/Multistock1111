import { NextRequest, NextResponse } from 'next/server'
import { parse } from 'csv-parse/sync'
import { supabase } from '@/lib/supabase'
import { cache } from '@/lib/cache'
import { z } from 'zod'

// Validation schema for CSV imports
const ProductSchema = z.object({
  name: z.string().min(1).max(255),
  sku: z.string().min(1).max(100),
  price: z.coerce.number().positive(),
  stock_quantity: z.coerce.number().int().min(0),
  reorder_point: z.coerce.number().int().min(0).optional().default(10),
  category: z.string().min(1).max(100).optional(),
  description: z.string().optional(),
  barcode: z.string().optional(),
  unit: z.string().optional().default('pcs'),
})

/**
 * POST /api/products/import
 * Import products from CSV file
 */
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const formData = await request.formData()
    const file = formData.get('file') as File

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      )
    }

    // Check file type
    if (!file.name.endsWith('.csv')) {
      return NextResponse.json(
        { error: 'Only CSV files are supported' },
        { status: 400 }
      )
    }

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        { error: 'File size exceeds 10MB limit' },
        { status: 400 }
      )
    }

    // Read file content
    const content = await file.text()

    // Parse CSV
    let records
    try {
      records = parse(content, {
        columns: true,
        skip_empty_lines: true,
        trim: true,
        cast: false, // We'll handle type conversion with Zod
      })
    } catch (error: any) {
      return NextResponse.json(
        { error: 'Invalid CSV format', details: error.message },
        { status: 400 }
      )
    }

    if (!Array.isArray(records) || records.length === 0) {
      return NextResponse.json(
        { error: 'No valid records found in CSV' },
        { status: 400 }
      )
    }

    if (records.length > 10000) {
      return NextResponse.json(
        { error: 'Maximum 10,000 products per import' },
        { status: 400 }
      )
    }

    // Validate each record
    const validProducts = []
    const errors: Array<{ row: number; error: string }> = []

    for (let i = 0; i < records.length; i++) {
      try {
        const validated = ProductSchema.parse(records[i])
        validProducts.push(validated)
      } catch (error) {
        if (error instanceof z.ZodError) {
          errors.push({
            row: i + 2, // +2 because row 1 is header and arrays start at 0
            error: error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
          })
        } else {
          errors.push({
            row: i + 2,
            error: 'Validation failed'
          })
        }
      }
    }

    if (validProducts.length === 0) {
      return NextResponse.json(
        {
          success: false,
          imported: 0,
          failed: errors.length,
          errors: errors.slice(0, 20),
          message: 'No valid products to import'
        },
        { status: 400 }
      )
    }

    // Batch insert (Supabase supports up to 1000 rows per insert)
    const batchSize = 1000
    const imported = []
    const importErrors: Array<{ batch: number; error: string }> = []

    for (let i = 0; i < validProducts.length; i += batchSize) {
      const batch = validProducts.slice(i, i + batchSize)
      const batchNumber = Math.floor(i / batchSize) + 1

      try {
        const { data, error } = await supabase
          .from('products')
          .insert(batch)
          .select()

        if (error) {
          console.error(`Error inserting batch ${batchNumber}:`, error)
          importErrors.push({
            batch: batchNumber,
            error: error.message
          })
        } else if (data) {
          imported.push(...data)
        }
      } catch (error: any) {
        importErrors.push({
          batch: batchNumber,
          error: error.message || 'Unknown error'
        })
      }
    }

    // Clear product cache
    cache.clearPattern('products:*')
    cache.clear('dashboard-stats')

    return NextResponse.json({
      success: true,
      imported: imported.length,
      failed: errors.length,
      totalProcessed: records.length,
      validationErrors: errors.slice(0, 20),
      importErrors,
      message: `Successfully imported ${imported.length} products${errors.length > 0 ? `, ${errors.length} failed validation` : ''}`
    })
  } catch (error: any) {
    console.error('CSV import error:', error)
    return NextResponse.json(
      {
        error: 'Import failed',
        details: error.message
      },
      { status: 500 }
    )
  }
}

/**
 * GET /api/products/import
 * Get CSV template
 */
export async function GET() {
  const csvTemplate = `name,sku,price,stock_quantity,reorder_point,category,description,barcode,unit
Laptop Dell XPS 15,LAP-001,75000,50,10,Electronics,High-performance laptop,1234567890123,pcs
Wireless Mouse,MOU-001,1500,200,20,Accessories,Ergonomic wireless mouse,1234567890124,pcs
Office Chair,CHR-001,15000,30,5,Furniture,Comfortable office chair,1234567890125,pcs`

  return new NextResponse(csvTemplate, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="products-template.csv"'
    }
  })
}
