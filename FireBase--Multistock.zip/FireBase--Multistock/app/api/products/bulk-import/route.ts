import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'
import { cache } from '@/lib/cache'
import { z } from 'zod'

// Validation schema for products
const ProductSchema = z.object({
  name: z.string().min(1).max(255),
  sku: z.string().min(1).max(100),
  price: z.number().positive(),
  stock_quantity: z.number().int().min(0),
  reorder_point: z.number().int().min(0).optional().default(10),
  category: z.string().min(1).max(100).optional(),
  description: z.string().optional(),
  barcode: z.string().optional(),
  unit: z.string().optional().default('pcs'),
})

type ProductInput = z.infer<typeof ProductSchema>

/**
 * POST /api/products/bulk-import
 * Bulk import products from JSON array
 */
export async function POST(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    const body = await request.json()
    const { products } = body

    // Validate input
    if (!Array.isArray(products)) {
      return NextResponse.json(
        { error: 'Products must be an array' },
        { status: 400 }
      )
    }

    if (products.length === 0) {
      return NextResponse.json(
        { error: 'Products array is empty' },
        { status: 400 }
      )
    }

    if (products.length > 10000) {
      return NextResponse.json(
        { error: 'Maximum 10,000 products per batch' },
        { status: 400 }
      )
    }

    // Validate each product
    const validProducts: ProductInput[] = []
    const errors: Array<{ row: number; error: string }> = []

    for (let i = 0; i < products.length; i++) {
      try {
        const validated = ProductSchema.parse(products[i])
        validProducts.push(validated)
      } catch (error) {
        if (error instanceof z.ZodError) {
          errors.push({
            row: i + 1,
            error: error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
          })
        } else {
          errors.push({
            row: i + 1,
            error: 'Validation failed'
          })
        }
      }
    }

    if (validProducts.length === 0) {
      return NextResponse.json(
        {
          success: false,
          imported: 0,
          failed: errors.length,
          errors: errors.slice(0, 20), // Return first 20 errors
          message: 'No valid products to import'
        },
        { status: 400 }
      )
    }

    // Batch insert (Supabase supports up to 1000 rows per insert)
    const batchSize = 1000
    const imported: any[] = []
    const importErrors: Array<{ batch: number; error: string }> = []

    for (let i = 0; i < validProducts.length; i += batchSize) {
      const batch = validProducts.slice(i, i + batchSize)
      const batchNumber = Math.floor(i / batchSize) + 1

      try {
        const { data, error } = await supabase
          .from('products')
          .insert(batch)
          .select()

        if (error) {
          console.error(`Error inserting batch ${batchNumber}:`, error)
          importErrors.push({
            batch: batchNumber,
            error: error.message
          })
        } else if (data) {
          imported.push(...data)
        }
      } catch (error: any) {
        importErrors.push({
          batch: batchNumber,
          error: error.message || 'Unknown error'
        })
      }
    }

    // Clear product cache
    cache.clearPattern('products:*')
    cache.clear('dashboard-stats')

    return NextResponse.json({
      success: true,
      imported: imported.length,
      failed: errors.length,
      totalProcessed: products.length,
      validationErrors: errors.slice(0, 20),
      importErrors,
      message: `Successfully imported ${imported.length} products${errors.length > 0 ? `, ${errors.length} failed validation` : ''}`
    })
  } catch (error: any) {
    console.error('Bulk import error:', error)
    return NextResponse.json(
      {
        error: 'Import failed',
        details: error.message
      },
      { status: 500 }
    )
  }
}

/**
 * GET /api/products/bulk-import
 * Get import template and instructions
 */
export async function GET() {
  const template = [
    {
      name: 'Example Product',
      sku: 'SKU-001',
      price: 99.99,
      stock_quantity: 100,
      reorder_point: 10,
      category: 'Electronics',
      description: 'Product description here',
      barcode: '1234567890123',
      unit: 'pcs'
    }
  ]

  const instructions = {
    message: 'Bulk Import API',
    method: 'POST',
    endpoint: '/api/products/bulk-import',
    contentType: 'application/json',
    maxBatchSize: 10000,
    template,
    requiredFields: ['name', 'sku', 'price', 'stock_quantity'],
    optionalFields: ['reorder_point', 'category', 'description', 'barcode', 'unit'],
    example: {
      products: template
    }
  }

  return NextResponse.json(instructions)
}
