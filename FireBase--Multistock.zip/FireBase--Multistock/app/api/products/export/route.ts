import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'
import { stringify } from 'csv-stringify/sync'

/**
 * GET /api/products/export
 * Export all products as CSV file
 */
export async function GET(request: NextRequest) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: 'Database configuration missing. Please check environment variables.' },
        { status: 500 }
      )
    }

    // Get query parameters for filtering
    const searchParams = request.nextUrl.searchParams
    const category = searchParams.get('category')
    const warehouse = searchParams.get('warehouse')

    // Build query
    let query = supabase.from('products').select('*')

    // Apply filters if provided
    if (category) {
      query = query.eq('category', category)
    }
    if (warehouse) {
      query = query.eq('warehouse_id', warehouse)
    }

    // Fetch products
    const { data: products, error } = await query

    if (error) {
      console.error('Error fetching products for export:', error)
      return NextResponse.json(
        { error: 'Failed to fetch products' },
        { status: 500 }
      )
    }

    if (!products || products.length === 0) {
      return NextResponse.json(
        { error: 'No products found to export' },
        { status: 404 }
      )
    }

    // Transform data for CSV
    const csvData = products.map(product => ({
      name: product.name || '',
      sku: product.sku || '',
      price: product.price || 0,
      stock_quantity: product.stock_quantity || 0,
      reorder_point: product.reorder_point || 0,
      category: product.category || '',
      description: product.description || '',
      barcode: product.barcode || '',
      unit: product.unit || 'pcs',
      created_at: product.created_at || '',
    }))

    // Convert to CSV
    const csv = stringify(csvData, {
      header: true,
      columns: [
        'name',
        'sku',
        'price',
        'stock_quantity',
        'reorder_point',
        'category',
        'description',
        'barcode',
        'unit',
        'created_at'
      ]
    })

    // Generate filename with timestamp
    const timestamp = new Date().toISOString().split('T')[0]
    const filename = `products_export_${timestamp}.csv`

    return new NextResponse(csv, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': Buffer.byteLength(csv).toString(),
      },
    })
  } catch (error: any) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'Export failed', details: error.message },
      { status: 500 }
    )
  }
}
