"use client"

import { useState, useEffect, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { 
  Plus, 
  Upload, 
  Download, 
  Search, 
  Filter,
  Package,
  AlertTriangle,
  CheckCircle,
  TrendingDown,
  Edit,
  Trash2,
  Eye,
  BarChart3,
  RefreshCw,
  Grid3x3,
  List,
  SlidersHorizontal,
  Heart,
  Share2,
  X,
  Star,
  TrendingUp,
  ShoppingCart,
  Zap
} from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { supabase } from "@/lib/supabase"
import { toast } from "@/hooks/use-toast"
import Image from "next/image"
import { AdvancedSearchFilter } from "@/components/inventory/advanced-search-filter"

interface Product {
  id: string
  name: string
  sku: string
  category: string
  description: string
  cost: number
  price: number
  stock_quantity: number
  reorder_point: number
  warehouse_id: string
  image_url?: string
  is_active: boolean
  created_at: string
}

export default function InventoryPage() {
  const { user, getRole } = useAuth()
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [showAddDialog, setShowAddDialog] = useState(false)
  
  // E-commerce features
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState('name')
  const [priceRange, setPriceRange] = useState([0, 10000])
  const [showFilters, setShowFilters] = useState(false)
  const [wishlist, setWishlist] = useState<string[]>([])
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  // Load products from Supabase
  useEffect(() => {
    loadProducts()
  }, [])

  const loadProducts = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setProducts(data || [])
    } catch (error) {
      console.error('Error loading products:', error)
    } finally {
      setLoading(false)
    }
  }

  // Handle advanced search
  const handleAdvancedSearch = (filters: any) => {
    setSearchQuery(filters.query)
    setCategoryFilter(filters.category)
    setStatusFilter(filters.status)
    setPriceRange([filters.minPrice, filters.maxPrice])
    setSortBy(filters.sortBy)
    // Additional filters can be implemented here
  }

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchQuery.toLowerCase())
      
      const matchesCategory = categoryFilter === "all" || product.category === categoryFilter
      
      const matchesStatus = 
        statusFilter === "all" ||
        (statusFilter === "low" && product.stock_quantity <= product.reorder_point) ||
        (statusFilter === "out" && product.stock_quantity === 0) ||
        (statusFilter === "in" && product.stock_quantity > product.reorder_point)
      
      // Price range filter
      const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]

      return matchesSearch && matchesCategory && matchesStatus && matchesPrice
    })
  }, [products, searchQuery, categoryFilter, statusFilter, priceRange])

  // Sort products
  const sortedProducts = useMemo(() => {
    const sorted = [...filteredProducts]
    
    switch (sortBy) {
      case 'price-low':
        return sorted.sort((a, b) => a.price - b.price)
      case 'price-high':
        return sorted.sort((a, b) => b.price - a.price)
      case 'stock-low':
        return sorted.sort((a, b) => a.stock_quantity - b.stock_quantity)
      case 'stock-high':
        return sorted.sort((a, b) => b.stock_quantity - a.stock_quantity)
      case 'name':
        return sorted.sort((a, b) => a.name.localeCompare(b.name))
      case 'sku':
        return sorted.sort((a, b) => a.sku.localeCompare(b.sku))
      default:
        return sorted
    }
  }, [filteredProducts, sortBy])

  // Wishlist toggle
  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      if (prev.includes(productId)) {
        toast({ title: "Removed from wishlist" })
        return prev.filter(id => id !== productId)
      } else {
        toast({ title: "Added to wishlist" })
        return [...prev, productId]
      }
    })
  }

  // Get unique categories
  const categories = useMemo(() => {
    return Array.from(new Set(products.map(p => p.category)))
  }, [products])

  // Calculate stats
  const stats = useMemo(() => {
    const total = products.length
    const lowStock = products.filter(p => p.stock_quantity <= p.reorder_point && p.stock_quantity > 0).length
    const outOfStock = products.filter(p => p.stock_quantity === 0).length
    const totalValue = products.reduce((sum, p) => sum + (p.stock_quantity * p.price), 0)

    return { total, lowStock, outOfStock, totalValue }
  }, [products])

  const getStockStatus = (product: Product) => {
    if (product.stock_quantity === 0) return { label: "Out of Stock", color: "destructive", icon: AlertTriangle }
    if (product.stock_quantity <= product.reorder_point) return { label: "Low Stock", color: "warning", icon: TrendingDown }
    return { label: "In Stock", color: "success", icon: CheckCircle }
  }

  const handleExportCSV = () => {
    const headers = ["SKU", "Name", "Category", "Stock", "Reorder Point", "Cost", "Price"]
    const rows = filteredProducts.map(p => [
      p.sku,
      p.name,
      p.category,
      p.stock_quantity,
      p.reorder_point,
      p.cost,
      p.price
    ])

    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `inventory-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h1 className="text-3xl font-bold">Products Inventory</h1>
          <div className="flex gap-2">
            <Input placeholder="Search products..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-64" />
            <Button variant="outline">Filter</Button>
            <Button variant="default" className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg">Add Product</Button>
          </div>
        </div>
        <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
          <CardHeader>
            <CardTitle className="text-lg">Product List</CardTitle>
          </CardHeader>
          <CardContent>
            {/* Table/grid layout here, responsive with horizontal scroll on mobile */}
            {/* ...existing code for table/grid... */}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}