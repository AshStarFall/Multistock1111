import { NotificationPreferencesPage } from '@/components/notification-preferences'

export default function NotificationSettingsPage() {
  // TODO: Get userId from session
  const userId = 'temp-user-id'

  return (
    <NotificationPreferencesPage
      userId={userId}
    />
  )
}
