"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { load, save } from "@/lib/storage"

type Coupon = { id: string; code: string; percentOff: number; active: boolean }

const KEY = "msl-coupons"

export default function CouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>(() => load<Coupon[]>(KEY, []))
  const [code, setCode] = useState("")
  const [off, setOff] = useState(10)

  function add() {
    if (!code) return
    const next = [{ id: crypto.randomUUID(), code: code.toUpperCase(), percentOff: off, active: true }, ...coupons]
    setCoupons(next)
    save(KEY, next)
    setCode("")
  }

  function toggle(id: string) {
    const next = coupons.map((c) => (c.id === id ? { ...c, active: !c.active } : c))
    setCoupons(next)
    save(KEY, next)
  }

  function remove(id: string) {
    const next = coupons.filter((c) => c.id !== id)
    setCoupons(next)
    save(KEY, next)
  }

  return (
    <section className="space-y-4">
      <h1 className="text-xl font-semibold">Coupons & Discounts</h1>

      <div className="flex gap-2 items-end">
        <div>
          <label className="block text-xs mb-1">Code</label>
          <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="SUMMER10" />
        </div>
        <div>
          <label className="block text-xs mb-1">% Off</label>
          <Input type="number" min={1} max={100} value={off} onChange={(e) => setOff(Number(e.target.value))} />
        </div>
        <Button onClick={add}>Add</Button>
      </div>

      <div className="overflow-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left p-2">Code</th>
              <th className="text-left p-2">Percent</th>
              <th className="text-left p-2">Active</th>
              <th className="text-left p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {coupons.map((c) => (
              <tr key={c.id} className="border-t">
                <td className="p-2 font-medium">{c.code}</td>
                <td className="p-2">{c.percentOff}%</td>
                <td className="p-2">{c.active ? "Yes" : "No"}</td>
                <td className="p-2">
                  <button className="underline mr-3" onClick={() => toggle(c.id)}>
                    {c.active ? "Disable" : "Enable"}
                  </button>
                  <button className="underline" onClick={() => remove(c.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {coupons.length === 0 && (
              <tr>
                <td className="p-3 text-muted-foreground" colSpan={4}>
                  No coupons yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  )
}


