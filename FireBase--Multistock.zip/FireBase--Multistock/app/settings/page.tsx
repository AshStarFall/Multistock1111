"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  User, 
  Shield, 
  CreditCard, 
  Eye, 
  Bell
} from 'lucide-react'
import ProfileSettings from '@/components/settings/profile-settings'
import SecuritySettings from '@/components/settings/security-settings'
import PaymentMethods from '@/components/settings/payment-methods'
import PrivacySettings from '@/components/settings/privacy-settings'
import { NotificationPreferencesPage } from '@/components/notification-preferences'
import { Card } from '@/components/ui/card'

export default function SettingsPage() {
  // TODO: Get from session
  const userId = 'temp-user-id'

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h1 className="text-3xl font-bold">Settings</h1>
          <div className="flex gap-2">
            {/* Theme and language toggles here */}
          </div>
        </div>
        <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 p-8">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <User className="w-4 h-4" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Security
              </TabsTrigger>
              <TabsTrigger value="payment" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                Payment
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="privacy" className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Privacy
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <ProfileSettings userId={userId} />
            </TabsContent>

            <TabsContent value="security">
              <SecuritySettings userId={userId} />
            </TabsContent>

            <TabsContent value="payment">
              <PaymentMethods userId={userId} />
            </TabsContent>

            <TabsContent value="notifications">
              <NotificationPreferencesPage userId={userId} />
            </TabsContent>

            <TabsContent value="privacy">
              <PrivacySettings userId={userId} />
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  )
}
