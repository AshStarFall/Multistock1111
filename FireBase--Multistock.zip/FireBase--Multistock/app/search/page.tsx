"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AppLayout } from "@/components/app-layout"
import { Package, Boxes, MapPin, Lock, Search, Loader2 } from "lucide-react"

interface SearchResult {
  id: string
  name: string
  type: 'product' | 'rental' | 'storage' | 'locker'
  description: string
  location?: string
  price?: number
  status?: string
  available?: boolean
}

export default function SearchPage() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get('q') || ''
  
  const [query, setQuery] = useState(initialQuery)
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('all')

  useEffect(() => {
    if (initialQuery) {
      performSearch(initialQuery)
    }
  }, [initialQuery])

  const performSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    setLoading(true)
    
    // Simulate search - Replace with actual API calls
    setTimeout(() => {
      const mockResults: SearchResult[] = [
        {
          id: '1',
          name: 'Laptop Dell XPS 15',
          type: 'product' as const,
          description: 'High-performance laptop for business',
          price: 45000,
          status: 'In Stock'
        },
        {
          id: '2',
          name: 'Conference Room',
          type: 'rental' as const,
          description: 'Large conference room with projector',
          price: 2000,
          available: true
        },
        {
          id: '3',
          name: 'Warehouse Section A',
          type: 'storage' as const,
          description: '500 sq ft storage space',
          location: 'Mumbai Warehouse',
          price: 15000
        },
        {
          id: '4',
          name: 'Locker #45',
          type: 'locker' as const,
          description: 'Medium size locker',
          location: 'Building B, Floor 2',
          available: true
        }
      ].filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
      
      setResults(mockResults)
      setLoading(false)
    }, 500)
  }

  const handleSearch = () => {
    performSearch(query)
  }

  const filteredResults = activeTab === 'all' 
    ? results 
    : results.filter(r => r.type === activeTab)

  const getIcon = (type: string) => {
    switch (type) {
      case 'product': return <Package className="w-4 h-4" />
      case 'rental': return <Boxes className="w-4 h-4" />
      case 'storage': return <MapPin className="w-4 h-4" />
      case 'locker': return <Lock className="w-4 h-4" />
      default: return <Package className="w-4 h-4" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'product': return 'bg-blue-500'
      case 'rental': return 'bg-green-500'
      case 'storage': return 'bg-purple-500'
      case 'locker': return 'bg-orange-500'
      default: return 'bg-gray-500'
    }
  }

  const getHref = (item: SearchResult) => {
    switch (item.type) {
      case 'product': return `/inventory`
      case 'rental': return `/rentals`
      case 'storage': return `/storage`
      case 'locker': return `/lockers`
      default: return '#'
    }
  }

  return (
    <AppLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Search</h1>
          <p className="text-muted-foreground">
            Search across products, rentals, storage, and lockers
          </p>
        </div>

        {/* Search Bar */}
        <Card>
          <CardContent className="p-6">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="pl-10"
                />
              </div>
              <Button onClick={handleSearch} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-5 w-full max-w-2xl">
            <TabsTrigger value="all">
              All ({results.length})
            </TabsTrigger>
            <TabsTrigger value="product">
              Products ({results.filter(r => r.type === 'product').length})
            </TabsTrigger>
            <TabsTrigger value="rental">
              Rentals ({results.filter(r => r.type === 'rental').length})
            </TabsTrigger>
            <TabsTrigger value="storage">
              Storage ({results.filter(r => r.type === 'storage').length})
            </TabsTrigger>
            <TabsTrigger value="locker">
              Lockers ({results.filter(r => r.type === 'locker').length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4 mt-6">
            {loading ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Loader2 className="w-8 h-8 mx-auto mb-4 animate-spin text-primary" />
                  <p className="text-muted-foreground">Searching...</p>
                </CardContent>
              </Card>
            ) : filteredResults.length > 0 ? (
              <div className="grid gap-4">
                {filteredResults.map((result) => (
                  <Link key={result.id} href={getHref(result)}>
                    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <div className={`w-8 h-8 rounded-lg ${getTypeColor(result.type)} flex items-center justify-center text-white`}>
                                {getIcon(result.type)}
                              </div>
                              <div>
                                <h3 className="font-semibold text-lg">{result.name}</h3>
                                <p className="text-sm text-muted-foreground capitalize">{result.type}</p>
                              </div>
                            </div>
                            <p className="text-muted-foreground mb-3">{result.description}</p>
                            <div className="flex flex-wrap items-center gap-3 text-sm">
                              {result.location && (
                                <div className="flex items-center gap-1 text-muted-foreground">
                                  <MapPin className="w-3 h-3" />
                                  {result.location}
                                </div>
                              )}
                              {result.price && (
                                <Badge variant="secondary">
                                  ₹{result.price.toLocaleString()}
                                </Badge>
                              )}
                              {result.status && (
                                <Badge variant="outline">{result.status}</Badge>
                              )}
                              {result.available !== undefined && (
                                <Badge variant={result.available ? "default" : "destructive"}>
                                  {result.available ? 'Available' : 'Unavailable'}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : query ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No results found</h3>
                  <p className="text-muted-foreground">
                    Try searching with different keywords
                  </p>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">Start searching</h3>
                  <p className="text-muted-foreground">
                    Enter a search query to find products, rentals, storage, or lockers
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  )
}
