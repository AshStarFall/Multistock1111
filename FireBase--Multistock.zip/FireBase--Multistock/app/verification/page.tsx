'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { VerificationForm } from '@/components/verification/verification-form';
import { TrustScoreDisplay } from '@/components/verification/trust-badge';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  VerificationRequest,
  TrustScore,
  getStatusColor,
  getStatusLabel,
} from '@/lib/verification';
import { Shield, Clock, CheckCircle, XCircle, FileText, Award } from 'lucide-react';

export default function VerificationPage() {
  const [requests, setRequests] = useState<VerificationRequest[]>([]);
  const [trustScore, setTrustScore] = useState<TrustScore | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);

      const [requestsRes, scoreRes] = await Promise.all([
        fetch('/api/verification/requests'),
        fetch('/api/verification/trust-score'),
      ]);

      const requestsData = await requestsRes.json();
      const scoreData = await scoreRes.json();

      setRequests(requestsData);
      setTrustScore(scoreData);
    } catch (error) {
      console.error('Error fetching verification data:', error);
    } finally {
      setLoading(false);
    }
  };

  const hasActiveRequest = requests.some(
    (r) => r.status === 'pending' || r.status === 'under_review'
  );

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-bold">Account Verification</h1>
        </div>
        <p className="text-muted-foreground">
          Get verified to build trust and unlock premium features
        </p>
      </div>

      <Tabs defaultValue="verify" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="verify">
            <Shield className="w-4 h-4 mr-2" />
            Get Verified
          </TabsTrigger>
          <TabsTrigger value="status">
            <Clock className="w-4 h-4 mr-2" />
            Status
          </TabsTrigger>
          <TabsTrigger value="trust-score">
            <Award className="w-4 h-4 mr-2" />
            Trust Score
          </TabsTrigger>
        </TabsList>

        <TabsContent value="verify">
          {hasActiveRequest ? (
            <Alert>
              <Clock className="h-4 w-4" />
              <AlertDescription>
                You already have a pending verification request. Check the "Status" tab
                for updates.
              </AlertDescription>
            </Alert>
          ) : (
            <VerificationForm />
          )}
        </TabsContent>

        <TabsContent value="status">
          {loading ? (
            <Card className="p-12 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-muted-foreground">Loading requests...</p>
            </Card>
          ) : requests.length === 0 ? (
            <Card className="p-12 text-center">
              <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Verification Requests</h3>
              <p className="text-muted-foreground">
                Start your verification process in the "Get Verified" tab
              </p>
            </Card>
          ) : (
            <div className="space-y-4">
              {requests.map((request) => (
                <Card key={request.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold capitalize">
                          {request.requestType} Verification
                        </h3>
                        <Badge className={getStatusColor(request.status)}>
                          {getStatusLabel(request.status)}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Submitted on{' '}
                        {new Date(request.submittedAt).toLocaleDateString()}
                      </p>
                    </div>

                    {request.status === 'approved' ? (
                      <CheckCircle className="w-8 h-8 text-green-600" />
                    ) : request.status === 'rejected' ? (
                      <XCircle className="w-8 h-8 text-red-600" />
                    ) : (
                      <Clock className="w-8 h-8 text-yellow-600" />
                    )}
                  </div>

                  {request.businessName && (
                    <div className="mb-4">
                      <p className="text-sm text-muted-foreground">Business Name</p>
                      <p className="font-medium">{request.businessName}</p>
                    </div>
                  )}

                  <div className="mb-4">
                    <p className="text-sm text-muted-foreground mb-2">
                      Documents Uploaded ({request.documents.length})
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {request.documents.map((doc) => (
                        <Badge key={doc.id} variant="outline">
                          {doc.type.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {request.reviewerComments && (
                    <Alert>
                      <AlertDescription>
                        <strong>Reviewer Notes:</strong> {request.reviewerComments}
                      </AlertDescription>
                    </Alert>
                  )}

                  {request.status === 'approved' && request.verifiedAt && (
                    <div className="mt-4 p-3 bg-green-50 dark:bg-green-950/20 rounded-md">
                      <p className="text-sm text-green-700 dark:text-green-300">
                        ✓ Verified on{' '}
                        {new Date(request.verifiedAt).toLocaleDateString()}
                        {request.expiresAt &&
                          ` • Expires on ${new Date(request.expiresAt).toLocaleDateString()}`}
                      </p>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="trust-score">
          {loading ? (
            <Card className="p-12 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
              <p className="text-muted-foreground">Calculating trust score...</p>
            </Card>
          ) : trustScore ? (
            <Card className="p-6">
              <TrustScoreDisplay trustScore={trustScore} />

              <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                <h4 className="font-semibold mb-2">How to Improve Your Score</h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Complete account verification (+40 points)</li>
                  <li>• Maintain high transaction success rate</li>
                  <li>• Respond quickly to inquiries</li>
                  <li>• Earn positive reviews and ratings</li>
                  <li>• Stay active and complete transactions</li>
                  <li>• Avoid disputes and maintain good standing</li>
                </ul>
              </div>
            </Card>
          ) : (
            <Card className="p-12 text-center">
              <Award className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Trust Score Yet</h3>
              <p className="text-muted-foreground">
                Complete transactions and get verified to build your trust score
              </p>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
