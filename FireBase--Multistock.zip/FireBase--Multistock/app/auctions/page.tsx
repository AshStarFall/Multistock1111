"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { Search, Gavel, Clock, TrendingUp, Trophy } from 'lucide-react'
import AuctionCard from '@/components/auctions/auction-card'
import { 
  type Auction, 
  type AuctionFilters,
  filterAuctions,
  getAuctionStatus
} from '@/lib/auctions'

export default function AuctionsPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState('all')
  const [auctions, setAuctions] = useState<Auction[]>([])
  const [filters, setFilters] = useState<AuctionFilters>({ sortBy: 'ending_soon' })
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadAuctions()
  }, [])

  const loadAuctions = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/auctions')
      if (!response.ok) throw new Error('Failed to load auctions')
      const data = await response.json()
      setAuctions(data.auctions || [])
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load auctions",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setFilters(prev => ({ ...prev, search: searchQuery || undefined }))
  }

  const handleViewAuction = (auction: Auction) => {
    // TODO: Navigate to auction details page
    window.location.href = `/auctions/${auction.id}`
  }

  const handleQuickBid = (auctionId: string) => {
    window.location.href = `/auctions/${auctionId}#bid`
  }

  // Filter auctions by tab
  const getFilteredAuctions = () => {
    let filtered = filterAuctions(auctions, filters)
    
    switch (activeTab) {
      case 'active':
        filtered = filtered.filter(a => {
          const status = getAuctionStatus(a)
          return status === 'active' || status === 'ending_soon'
        })
        break
      case 'ending_soon':
        filtered = filtered.filter(a => getAuctionStatus(a) === 'ending_soon')
        break
      case 'ended':
        filtered = filtered.filter(a => getAuctionStatus(a) === 'ended')
        break
    }
    
    return filtered
  }

  const filteredAuctions = getFilteredAuctions()
  
  // Count auctions by status
  const counts = {
    all: auctions.length,
    active: auctions.filter(a => {
      const status = getAuctionStatus(a)
      return status === 'active' || status === 'ending_soon'
    }).length,
    ending_soon: auctions.filter(a => getAuctionStatus(a) === 'ending_soon').length,
    ended: auctions.filter(a => getAuctionStatus(a) === 'ended').length
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto p-6 max-w-7xl space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center">
                <Gavel className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Live Auctions</h1>
                <p className="text-muted-foreground">Bid on amazing items and win great deals</p>
              </div>
            </div>
            <Button>
              <Gavel className="w-4 h-4 mr-2" />
              Create Auction
            </Button>
          </div>
        </motion.div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex gap-2">
          <Input
            placeholder="Search auctions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
          />
          <Button type="submit">
            <Search className="w-4 h-4 mr-2" />
            Search
          </Button>
        </form>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">
              <TrendingUp className="w-4 h-4 mr-2" />
              All ({counts.all})
            </TabsTrigger>
            <TabsTrigger value="active">
              <Gavel className="w-4 h-4 mr-2" />
              Active ({counts.active})
            </TabsTrigger>
            <TabsTrigger value="ending_soon">
              <Clock className="w-4 h-4 mr-2" />
              Ending Soon ({counts.ending_soon})
            </TabsTrigger>
            <TabsTrigger value="ended">
              <Trophy className="w-4 h-4 mr-2" />
              Ended ({counts.ended})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-6 mt-6">
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full mx-auto" />
                <p className="text-muted-foreground mt-4">Loading auctions...</p>
              </div>
            ) : filteredAuctions.length === 0 ? (
              <div className="text-center py-12">
                <Gavel className="w-16 h-16 mx-auto text-muted-foreground opacity-50 mb-4" />
                <h3 className="text-xl font-semibold mb-2">No auctions found</h3>
                <p className="text-muted-foreground mb-4">
                  {activeTab === 'ending_soon' 
                    ? 'No auctions ending soon'
                    : activeTab === 'ended'
                    ? 'No ended auctions'
                    : 'Try adjusting your filters or check back later'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredAuctions.map((auction) => (
                  <AuctionCard
                    key={auction.id}
                    auction={auction}
                    onView={handleViewAuction}
                    onQuickBid={handleQuickBid}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
