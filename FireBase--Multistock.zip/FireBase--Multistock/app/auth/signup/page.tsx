import { redirect } from "next/navigation"

export default function SignupPage() {
  // Disable legacy signup; route to main login for unified auth
  redirect("/login")
}


