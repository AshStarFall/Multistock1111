export default function LoginLoading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo skeleton */}
        <div className="flex justify-center mb-8">
          <div className="w-32 h-12 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse"></div>
        </div>
        
        {/* Card skeleton */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl p-8 space-y-6">
          {/* Title skeleton */}
          <div className="space-y-2">
            <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded-lg w-3/4 animate-pulse"></div>
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/2 animate-pulse"></div>
          </div>
          
          {/* Input skeletons */}
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/4 animate-pulse"></div>
              <div className="h-12 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse"></div>
            </div>
            
            <div className="space-y-2">
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/4 animate-pulse"></div>
              <div className="h-12 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse"></div>
            </div>
          </div>
          
          {/* Button skeleton */}
          <div className="h-12 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse"></div>
          
          {/* Divider */}
          <div className="flex items-center gap-4">
            <div className="flex-1 h-px bg-slate-200 dark:bg-slate-700"></div>
            <div className="h-4 w-8 bg-slate-200 dark:bg-slate-700 rounded animate-pulse"></div>
            <div className="flex-1 h-px bg-slate-200 dark:bg-slate-700"></div>
          </div>
          
          {/* Social button skeletons */}
          <div className="grid grid-cols-2 gap-4">
            <div className="h-12 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse"></div>
            <div className="h-12 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse"></div>
          </div>
        </div>
        
        {/* Bottom text skeleton */}
        <div className="flex justify-center mt-6">
          <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-48 animate-pulse"></div>
        </div>
      </div>
    </div>
  )
}
