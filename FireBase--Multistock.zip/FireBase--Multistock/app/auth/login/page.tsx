"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuth } from "@/lib/auth-context"
import { SocialLogin } from "@/components/auth/social-login"
import { AuthFooter } from "@/components/auth/auth-footer"
import { Lock, Mail, ArrowRight, Eye, EyeOff, Shield, CheckCircle } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()
  const { login, user } = useAuth()
  const [identifier, setIdentifier] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [isMounted, setIsMounted] = useState(false)
  const [validationErrors, setValidationErrors] = useState<{identifier?: string, password?: string}>({})

  // Mark component as mounted
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Redirect if already logged in - only once on mount
  useEffect(() => {
    if (isMounted && user) {
      const destination = (() => {
        switch (user.role) {
          case 'SuperAdmin':
          case 'Admin':
            return '/admin'
          case 'SubAdmin':
          case 'SeniorStaff':
          case 'Staff':
            return '/dashboard'
          case 'Customer':
            return '/marketplace'
          default:
            return '/dashboard'
        }
      })()
      router.replace(destination)
    }
  }, [isMounted]) // Only run once when mounted

  // Load saved credentials on mount
  useEffect(() => {
    if (!isMounted) return

    const savedIdentifier = localStorage.getItem('rememberedIdentifier')
    const savedRememberMe = localStorage.getItem('rememberMe') === 'true'
    
    if (savedRememberMe && savedIdentifier) {
      setIdentifier(savedIdentifier)
      setRememberMe(true)
    }
  }, [isMounted])

  // Validate form fields
  const validateForm = useCallback(() => {
    const errors: {identifier?: string, password?: string} = {}
    
    if (!identifier.trim()) {
      errors.identifier = "Email or username is required"
    } else if (identifier.includes('@') && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier)) {
      errors.identifier = "Please enter a valid email address"
    }
    
    if (!password) {
      errors.password = "Password is required"
    } else if (password.length < 6) {
      errors.password = "Password must be at least 6 characters"
    }
    
    setValidationErrors(errors)
    return Object.keys(errors).length === 0
  }, [identifier, password])

  // Optimized submit handler
  const onSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate form before submission
    if (!validateForm()) {
      return
    }
    
    setError("")
    setLoading(true)
    
    try {
      // Save or clear remember me preferences
      if (rememberMe) {
        localStorage.setItem('rememberedIdentifier', identifier)
        localStorage.setItem('rememberMe', 'true')
      } else {
        localStorage.removeItem('rememberedIdentifier')
        localStorage.removeItem('rememberMe')
      }
      
      await login(identifier, password)
    } catch (error: any) {
      setError(error.message || 'Invalid credentials. Please try again.')
      setLoading(false)
    }
  }, [identifier, password, rememberMe, login, validateForm])

  // Handle input changes with validation
  const handleIdentifierChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIdentifier(e.target.value)
    if (validationErrors.identifier) {
      setValidationErrors(prev => ({ ...prev, identifier: undefined }))
    }
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value)
    if (validationErrors.password) {
      setValidationErrors(prev => ({ ...prev, password: undefined }))
    }
  }

  // Don't render anything if user is already authenticated
  if (user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-0 bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl">
        <CardHeader className="text-center space-y-2 pb-4 pt-8">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Welcome Back
          </CardTitle>
          <CardDescription className="text-base">
            Sign in to your MultiStock account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pb-8">
          {error && (
            <Alert variant="destructive" className="animate-in slide-in-from-top-4 duration-300">
              <AlertDescription className="flex items-center">
                <Shield className="w-4 h-4 mr-2" />
                {error}
              </AlertDescription>
            </Alert>
          )}
          
          <form onSubmit={onSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="identifier" className="text-sm font-medium">
                Email or Username
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="identifier"
                  type="text"
                  placeholder="Enter your email or username"
                  value={identifier}
                  onChange={handleIdentifierChange}
                  className={`pl-10 h-12 rounded-xl border-slate-200 dark:border-slate-700 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all ${
                    validationErrors.identifier ? "border-red-500" : ""
                  }`}
                  required
                  disabled={loading}
                  autoComplete="username"
                />
              </div>
              {validationErrors.identifier && (
                <p className="text-sm text-red-500 flex items-center">
                  <Shield className="w-4 h-4 mr-1" />
                  {validationErrors.identifier}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-sm font-medium">
                  Password
                </Label>
                <Link 
                  href="/auth/forgot-password" 
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium transition-colors"
                >
                  Forgot?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={handlePasswordChange}
                  className={`pl-10 pr-10 h-12 rounded-xl border-slate-200 dark:border-slate-700 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all ${
                    validationErrors.password ? "border-red-500" : ""
                  }`}
                  required
                  disabled={loading}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  disabled={loading}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {validationErrors.password && (
                <p className="text-sm text-red-500 flex items-center">
                  <Shield className="w-4 h-4 mr-1" />
                  {validationErrors.password}
                </p>
              )}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  disabled={loading}
                />
                <Label htmlFor="remember" className="text-sm cursor-pointer">
                  Remember me
                </Label>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold h-12 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
              disabled={loading}
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Signing in...
                </>
              ) : (
                <>
                  Sign In
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </form>

          <div className="relative my-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-700"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white dark:bg-slate-800 px-2 text-slate-500">
                Or continue with
              </span>
            </div>
          </div>

          <SocialLogin mode="login" />

          <AuthFooter mode="login" />

          <div className="text-center text-xs text-muted-foreground mt-4">
            By signing in, you agree to our{' '}
            <Link href="/terms" className="underline hover:text-foreground transition-colors">Terms of Service</Link>
            {' '}and{' '}
            <Link href="/privacy" className="underline hover:text-foreground transition-colors">Privacy Policy</Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}