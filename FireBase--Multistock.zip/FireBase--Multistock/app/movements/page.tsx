import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MovementsTable } from "@/components/movements-table"
import { movements } from "@/lib/mock-orders"

export default function MovementsPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-balance">Stock Movements</CardTitle>
      </CardHeader>
      <CardContent>
        <MovementsTable rows={movements} />
      </CardContent>
    </Card>
  )
}
