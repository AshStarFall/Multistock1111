"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth-context"
import { toast } from "sonner"
import { User, Mail, Phone, Building, Edit, Save, X, Shield } from "lucide-react"

const defaultProfilePhotos = [
  "/profile-photos/avatar-1.jpg",
  "/profile-photos/avatar-2.jpg",
  "/profile-photos/avatar-3.jpg",
  "/profile-photos/avatar-4.jpg",
  "/profile-photos/avatar-5.jpg",
]

const adminProfilePhotos = [
  "/profile-photos/admin-crown.jpg",
  "/profile-photos/admin-shield.jpg",
  "/profile-photos/admin-star.jpg",
]

export default function UserProfilePage() {
  const { user, isAuthenticated, getRole } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isPhotoDialogOpen, setIsPhotoDialogOpen] = useState(false)
  
  const [formData, setFormData] = useState({
    name: "",
    username: "",
    bio: "",
    phone: "",
    department: "",
    profilePhoto: ""
  })

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || "",
        username: user.email || "",
        bio: "",
        phone: "",
        department: user.department || "",
        profilePhoto: "/placeholder-user.jpg"
      })
    }
  }, [user])

  const handleSave = async () => {
    if (!user) return

    setIsSaving(true)
    try {
      // Simulate API call - in real app, this would update the database
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      toast.success('Profile updated successfully')
      setIsEditing(false)
    } catch (error) {
      console.error('Error updating profile:', error)
      toast.error('Failed to update profile')
    } finally {
      setIsSaving(false)
    }
  }

  const handlePhotoChange = (photoUrl: string) => {
    setFormData({ ...formData, profilePhoto: photoUrl })
    setIsPhotoDialogOpen(false)
    toast.success('Profile photo updated')
  }

  const getAvailablePhotos = () => {
    if (!user) return defaultProfilePhotos
    return getRole() === 'Admin' 
      ? [...defaultProfilePhotos, ...adminProfilePhotos]
      : defaultProfilePhotos
  }

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Please Sign In</h2>
          <p className="text-muted-foreground">You need to be signed in to view your profile.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 p-8">
        <CardHeader className="flex flex-col items-center">
          <Avatar className="w-24 h-24 mb-4">
            <AvatarImage src={formData.profilePhoto} alt={formData.name} />
            <AvatarFallback>{formData.name?.[0] || "U"}</AvatarFallback>
          </Avatar>
          <CardTitle className="text-2xl font-bold mb-2">{formData.name}</CardTitle>
          <Badge className="mb-2">{getRole()}</Badge>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="flex flex-col gap-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" value={formData.name} disabled={!isEditing} />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" value={formData.username} disabled />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="department">Department</Label>
              <Input id="department" value={formData.department} disabled={!isEditing} />
            </div>
            <div className="flex gap-4 justify-end">
              <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
              <Button variant="default" className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg" onClick={handleSave} disabled={isSaving}>Save</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}