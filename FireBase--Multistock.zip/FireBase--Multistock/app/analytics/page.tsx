"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { supabase } from '@/lib/supabase'
import { AdvancedAnalytics } from '@/components/analytics/advanced-analytics'
import { 
  TrendingUp, 
  TrendingDown,
  Users, 
  Package, 
  ShoppingCart, 
  DollarSign,
  Activity,
  Warehouse,
  Target,
  Award,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Download,
  Calendar,
  Clock,
  CheckCircle,
  AlertTriangle
} from 'lucide-react'
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts'
import { motion } from 'framer-motion'
import { PageHeader } from '@/components/page-header'

export default function AnalyticsPage() {
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState('7d') // 7d, 30d, 90d, 1y
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0,
    activeUsers: 0,
    lowStockProducts: 0,
    pendingOrders: 0,
    completedOrders: 0,
  })
  
  const [growthData, setGrowthData] = useState({
    usersGrowth: 0,
    productsGrowth: 0,
    ordersGrowth: 0,
    revenueGrowth: 0,
  })

  const [chartData, setChartData] = useState<{
    revenue: Array<{ date: string; revenue: number; orders: number }>
    orders: Array<{ date: string; revenue: number; orders: number }>
    products: Array<{ date: string; revenue: number; orders: number; products: number }>
    categories: Array<{ name: string; value: number }>
  }>({
    revenue: [],
    orders: [],
    products: [],
    categories: []
  })

  useEffect(() => {
    loadAnalytics()
  }, [timeRange])

  const loadAnalytics = async () => {
    try {
      setLoading(true)

      // Fetch all data in parallel
      const [
        usersRes,
        productsRes,
        ordersRes,
        categoriesRes
      ] = await Promise.all([
        supabase.from('users').select('*'),
        supabase.from('products').select('*'),
        supabase.from('sales_orders').select('*'),
        supabase.from('categories').select('*')
      ])

      const users = usersRes.data || []
      const products = productsRes.data || []
      const orders = ordersRes.data || []
      const categories = categoriesRes.data || []

      // Calculate basic stats
      const totalUsers = users.length
      const totalProducts = products.length
      const totalOrders = orders.length
      const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0)
      
      const lowStockProducts = products.filter(p => 
        p.stock_quantity <= p.reorder_point && p.stock_quantity > 0
      ).length
      
      const pendingOrders = orders.filter(o => 
        o.status === 'Open' || o.status === 'Partially Fulfilled'
      ).length
      
      const completedOrders = orders.filter(o => 
        o.status === 'Fulfilled'
      ).length

      setStats({
        totalUsers,
        totalProducts,
        totalOrders,
        totalRevenue,
        activeUsers: Math.floor(totalUsers * 0.7), // Mock active users
        lowStockProducts,
        pendingOrders,
        completedOrders,
      })

      // Calculate growth (mock data for demo)
      setGrowthData({
        usersGrowth: 12.5,
        productsGrowth: 8.3,
        ordersGrowth: 15.7,
        revenueGrowth: 23.4,
      })

      // Prepare chart data
      const last7Days = getLast7Days()
      const revenueData = last7Days.map(date => ({
        date,
        revenue: Math.floor(Math.random() * 50000) + 10000,
        orders: Math.floor(Math.random() * 50) + 10,
      }))

      const categoryData = categories.slice(0, 5).map(cat => ({
        name: cat.name,
        value: Math.floor(Math.random() * 100) + 20,
      }))

      setChartData({
        revenue: revenueData,
        orders: revenueData,
        products: revenueData.map(d => ({ ...d, products: Math.floor(Math.random() * 20) + 5 })),
        categories: categoryData,
      })

    } catch (error) {
      console.error('Error loading analytics:', error)
    } finally {
      setLoading(false)
    }
  }

  const getLast7Days = () => {
    const days = []
    for (let i = 6; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }))
    }
    return days
  }

  const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#06b6d4', '#10b981']

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl space-y-6">
      <PageHeader
        title="Analytics & Overview"
        description="Complete insights into your business performance"
        titleClassName="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent"
        actions={
          <>
            <div className="flex gap-2">
              {['7d', '30d', '90d', '1y'].map((range) => (
                <Button
                  key={range}
                  variant={timeRange === range ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTimeRange(range)}
                >
                  {range === '7d' && '7 Days'}
                  {range === '30d' && '30 Days'}
                  {range === '90d' && '90 Days'}
                  {range === '1y' && '1 Year'}
                </Button>
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={loadAnalytics}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button size="sm" className="bg-gradient-to-r from-indigo-600 to-violet-600">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </>
        }
      />

        {/* Key Metrics */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {[
            {
              title: 'Total Revenue',
              value: `₹${stats.totalRevenue.toLocaleString()}`,
              change: growthData.revenueGrowth,
              icon: DollarSign,
              color: 'from-green-500 to-emerald-600',
              bgColor: 'bg-green-50 dark:bg-green-900/20'
            },
            {
              title: 'Total Orders',
              value: stats.totalOrders,
              change: growthData.ordersGrowth,
              icon: ShoppingCart,
              color: 'from-blue-500 to-cyan-600',
              bgColor: 'bg-blue-50 dark:bg-blue-900/20'
            },
            {
              title: 'Total Products',
              value: stats.totalProducts,
              change: growthData.productsGrowth,
              icon: Package,
              color: 'from-violet-500 to-purple-600',
              bgColor: 'bg-violet-50 dark:bg-violet-900/20'
            },
            {
              title: 'Total Users',
              value: stats.totalUsers,
              change: growthData.usersGrowth,
              icon: Users,
              color: 'from-pink-500 to-rose-600',
              bgColor: 'bg-pink-50 dark:bg-pink-900/20'
            },
          ].map((metric, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl ${metric.bgColor}`}>
                      <metric.icon className={`w-6 h-6 bg-gradient-to-r ${metric.color} bg-clip-text text-transparent`} />
                    </div>
                    <Badge className={`bg-gradient-to-r ${metric.color} text-white border-0`}>
                      <ArrowUp className="w-3 h-3 mr-1" />
                      {metric.change}%
                    </Badge>
                  </div>
                  <h3 className="text-2xl font-bold mb-1">{metric.value}</h3>
                  <p className="text-sm text-muted-foreground">{metric.title}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue Chart */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Revenue Overview</span>
                <Badge variant="outline">Last 7 Days</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={chartData.revenue}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="revenue" stroke="#6366f1" fillOpacity={1} fill="url(#colorRevenue)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Orders Chart */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Orders Trend</span>
                <Badge variant="outline">Last 7 Days</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData.orders}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="orders" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Product Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={chartData.categories}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({name, percent}: any) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {chartData.categories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Quick Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: 'Active Users', value: stats.activeUsers, icon: Activity, color: 'text-green-600' },
                { label: 'Pending Orders', value: stats.pendingOrders, icon: Clock, color: 'text-yellow-600' },
                { label: 'Completed Orders', value: stats.completedOrders, icon: CheckCircle, color: 'text-blue-600' },
                { label: 'Low Stock Alert', value: stats.lowStockProducts, icon: AlertTriangle, color: 'text-red-600' },
              ].map((stat, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="flex items-center gap-3">
                    <stat.icon className={`w-5 h-5 ${stat.color}`} />
                    <span className="font-medium">{stat.label}</span>
                  </div>
                  <Badge variant="secondary" className="text-lg font-bold">
                    {stat.value}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/30 dark:to-violet-950/30">
            <CardContent className="p-6">
              <Target className="w-12 h-12 mb-4 text-indigo-600" />
              <h3 className="text-2xl font-bold mb-2">{stats.totalOrders > 0 ? ((stats.completedOrders / stats.totalOrders) * 100).toFixed(1) : 0}%</h3>
              <p className="text-sm text-muted-foreground">Order Completion Rate</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
            <CardContent className="p-6">
              <Award className="w-12 h-12 mb-4 text-green-600" />
              <h3 className="text-2xl font-bold mb-2">₹{stats.totalOrders > 0 ? (stats.totalRevenue / stats.totalOrders).toFixed(0) : 0}</h3>
              <p className="text-sm text-muted-foreground">Average Order Value</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30">
            <CardContent className="p-6">
              <Warehouse className="w-12 h-12 mb-4 text-blue-600" />
              <h3 className="text-2xl font-bold mb-2">₹{stats.totalProducts > 0 ? (stats.totalRevenue / stats.totalProducts).toFixed(0) : 0}</h3>
              <p className="text-sm text-muted-foreground">Revenue Per Product</p>
            </CardContent>
          </Card>
        </div>

        {/* Advanced Analytics Section */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Advanced Analytics Dashboard</h2>
            <Badge variant="outline" className="text-lg px-4 py-2">Power BI Style</Badge>
          </div>
          <AdvancedAnalytics />
        </div>
    </div>
  )
}


