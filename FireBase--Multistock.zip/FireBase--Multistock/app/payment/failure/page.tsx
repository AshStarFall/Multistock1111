'use client'

import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { XCircle, Home, RefreshCw, HelpCircle } from 'lucide-react'
import Link from 'next/link'
import { motion } from 'framer-motion'

export default function PaymentFailurePage() {
  const searchParams = useSearchParams()
  const [error, setError] = useState('')

  useEffect(() => {
    setError(searchParams.get('error') || 'Payment failed due to an unknown error')
  }, [searchParams])

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="max-w-lg w-full border-0 shadow-2xl">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mb-4">
                <XCircle className="w-12 h-12 text-red-600" />
              </div>
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
                Payment Failed
              </CardTitle>
              <p className="text-muted-foreground mt-2">
                We couldn't process your payment
              </p>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Error Details */}
              <div className="bg-red-50 dark:bg-red-900/20 rounded-xl p-6 space-y-3">
                <div className="text-center">
                  <p className="text-sm text-red-800 dark:text-red-300 font-medium">
                    {error}
                  </p>
                </div>
              </div>

              {/* Help Message */}
              <div className="text-center p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg space-y-2">
                <p className="text-sm text-amber-800 dark:text-amber-300 font-medium">
                  Common reasons for payment failure:
                </p>
                <ul className="text-xs text-amber-700 dark:text-amber-400 space-y-1">
                  <li>• Insufficient balance</li>
                  <li>• Incorrect card details</li>
                  <li>• Payment declined by bank</li>
                  <li>• Network connectivity issues</li>
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" asChild>
                  <Link href="/dashboard">
                    <Home className="w-4 h-4 mr-2" />
                    Dashboard
                  </Link>
                </Button>
                <Button className="bg-gradient-to-r from-indigo-600 to-violet-600" onClick={() => window.history.back()}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
              </div>

              <Button variant="ghost" className="w-full" asChild>
                <Link href="/support">
                  <HelpCircle className="w-4 h-4 mr-2" />
                  Contact Support
                </Link>
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
  )
}
