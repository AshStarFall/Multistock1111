'use client'

import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CheckCircle, Download, Home, Receipt } from 'lucide-react'
import Link from 'next/link'
import { motion } from 'framer-motion'

export default function PaymentSuccessPage() {
  const searchParams = useSearchParams()
  const [paymentId, setPaymentId] = useState('')
  const [orderId, setOrderId] = useState('')

  useEffect(() => {
    setPaymentId(searchParams.get('payment_id') || '')
    setOrderId(searchParams.get('order_id') || '')
  }, [searchParams])

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="max-w-lg w-full border-0 shadow-2xl">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                Payment Successful!
              </CardTitle>
              <p className="text-muted-foreground mt-2">
                Your payment has been processed successfully
              </p>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Payment Details */}
              <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Payment ID:</span>
                  <span className="font-mono text-sm font-semibold">{paymentId}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Order ID:</span>
                  <span className="font-mono text-sm font-semibold">{orderId}</span>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-sm text-muted-foreground">Status:</span>
                  <span className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-full text-xs font-semibold">
                    Completed
                  </span>
                </div>
              </div>

              {/* Confirmation Message */}
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  A confirmation email has been sent to your registered email address
                </p>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" asChild>
                  <Link href="/dashboard">
                    <Home className="w-4 h-4 mr-2" />
                    Dashboard
                  </Link>
                </Button>
                <Button className="bg-gradient-to-r from-indigo-600 to-violet-600" asChild>
                  <Link href="/payments">
                    <Receipt className="w-4 h-4 mr-2" />
                    View Transactions
                  </Link>
                </Button>
              </div>

              <Button variant="ghost" className="w-full" onClick={() => window.print()}>
                <Download className="w-4 h-4 mr-2" />
                Download Receipt
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
  )
}
