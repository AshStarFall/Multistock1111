"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TopSkusChart } from "@/components/charts/top-skus-chart"
import { OrderStatusChart } from "@/components/charts/order-status-chart"
import { movements } from "@/lib/mock-orders"
import { purchaseOrders, salesOrders } from "@/lib/mock-orders"
import { exportProductsCSV, exportBookingsCSV, downloadFile } from "@/lib/reporting"
import { t } from "@/lib/i18n"
import { useState } from "react"

const top = Object.values(
  movements.reduce<Record<string, number>>((acc, m) => {
    acc[m.sku] = (acc[m.sku] ?? 0) + Math.abs(m.qty)
    return acc
  }, {}),
)
  .map((qty, i) => ({ sku: `SKU-${i + 1}`, qty }))
  .slice(0, 8)

const statusData = (() => {
  const all = [...purchaseOrders, ...salesOrders]
  const map = new Map<string, number>()
  all.forEach((o) => map.set(o.status, (map.get(o.status) ?? 0) + 1))
  return Array.from(map.entries()).map(([status, count]) => ({ status, count }))
})()

export default function ReportsPage() {
  const [rentalsStart, setRentalsStart] = useState<string>("")
  const [rentalsEnd, setRentalsEnd] = useState<string>("")

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">{t("reports")}</h1>
        <Card className="rounded-xl shadow-md bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
          <CardHeader>
            <CardTitle className="text-lg">Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <TopSkusChart data={top} />
              <OrderStatusChart data={statusData} />
            </div>
          </CardContent>
        </Card>
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">{t("sales_report")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <button className="underline text-sm">{t("download_csv")}</button>
                <button className="underline text-sm">{t("download_pdf")}</button>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">{t("stock_report")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <button className="underline text-sm" onClick={() => downloadFile("products.csv", exportProductsCSV())}>{t("download_csv")}</button>
                <button className="underline text-sm">{t("download_pdf")}</button>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">{t("storage_report")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <button className="underline text-sm">{t("download_csv")}</button>
                <button className="underline text-sm">{t("download_pdf")}</button>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">{t("rentals_report")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-3">
                <div className="flex gap-2 items-center">
                  <label className="text-xs" htmlFor="rentals-start">{t("start_date")}</label>
                  <input
                    id="rentals-start"
                    type="date"
                    className="border rounded-md text-sm h-9 px-2 bg-background"
                    value={rentalsStart}
                    onChange={(e) => setRentalsStart(e.target.value)}
                  />
                  <label className="text-xs" htmlFor="rentals-end">{t("end_date")}</label>
                  <input
                    id="rentals-end"
                    type="date"
                    className="border rounded-md text-sm h-9 px-2 bg-background"
                    value={rentalsEnd}
                    onChange={(e) => setRentalsEnd(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    className="underline text-sm"
                    onClick={() => downloadFile("bookings.csv", exportBookingsCSV(rentalsStart || undefined, rentalsEnd || undefined))}
                  >
                    {t("download_csv")}
                  </button>
                  <button className="underline text-sm">{t("download_pdf")}</button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
