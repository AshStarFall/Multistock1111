"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Package, Warehouse, ClipboardList, ShoppingCart, Truck, LineChart, Settings, Users } from "lucide-react"
import { cn } from "@/lib/utils"

const items = [
  { href: "/dashboard", label: "Dashboard", icon: LineChart },
  { href: "/inventory/products", label: "Products", icon: Package },
  { href: "/inventory/adjustments", label: "Adjustments", icon: Truck },
  { href: "/suppliers", label: "Suppliers", icon: ClipboardList },
  { href: "/purchase-orders", label: "Purchase Orders", icon: Truck },
  { href: "/sales-orders", label: "Sales Orders", icon: ShoppingCart },
  { href: "/warehouses", label: "Warehouses", icon: Warehouse },
  { href: "/reports", label: "Reports", icon: LineChart },
  { href: "/settings", label: "Settings", icon: Settings },
]

export function Sidebar() {
  const pathname = usePathname()
  return (
    <div className="p-4 w-64 shrink-0 border-r bg-background md:sticky md:top-0 md:h-screen overflow-y-auto">
      <div className="px-2 py-3 font-semibold text-lg flex items-center gap-2">
        <img src="/multistock-logo.svg" alt="Logo" className="h-6 w-6" />
        <span className="indian-text">MultiStock Logistics - India</span>
      </div>
      <nav className="flex flex-col gap-1" role="navigation" aria-label="Main">
        {items.map((item) => {
          const Icon = item.icon
          const active = pathname === item.href || pathname.startsWith(`${item.href}/`)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
              aria-current={active ? "page" : undefined}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          )
        })}
      </nav>
      <div className="mt-6 border-t pt-4">
        <div className="text-xs text-muted-foreground px-2">Admin</div>
        <Link
          href="/settings"
          className="mt-2 flex items-center gap-3 px-3 py-2 rounded-md text-sm text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Users className="h-4 w-4" />
          Users & Roles
        </Link>
      </div>
    </div>
  )
}
