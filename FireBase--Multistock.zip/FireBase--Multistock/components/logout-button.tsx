"use client"

import { useState } from "react"
import { LogOut, Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { Button } from "@/components/ui/button"

export function LogoutButton({ collapsed = false }: { collapsed?: boolean }) {
  const [isLoading, setIsLoading] = useState(false)
  const { logout } = useAuth()
  const router = useRouter()

  const handleLogout = async () => {
    setIsLoading(true)
    try {
      await logout()
      // Use router.push for better SPA navigation instead of window.location.href
      router.push("/auth/login")
    } catch (error) {
      console.error("Logout error:", error)
      // Even if there's an error, redirect to login page
      router.push("/auth/login")
    } finally {
      setIsLoading(false)
    }
  }

  const buttonContent = (
    <Button
      onClick={handleLogout}
      disabled={isLoading}
      variant="ghost"
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 w-full justify-start",
        "hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600 dark:text-red-400",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        collapsed && "justify-center px-2"
      )}
    >
      {isLoading ? (
        <Loader2 className="w-5 h-5 shrink-0 animate-spin" />
      ) : (
        <LogOut className="w-5 h-5 shrink-0" />
      )}
      {!collapsed && (
        <span className="font-medium text-sm">
          {isLoading ? "Logging out..." : "Logout"}
        </span>
      )}
    </Button>
  )

  if (collapsed) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            {buttonContent}
          </TooltipTrigger>
          <TooltipContent side="right" className="ml-2">
            <p>{isLoading ? "Logging out..." : "Logout"}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return buttonContent
}