"use client"

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Edit, Trash2, Plus, Save, X } from 'lucide-react'

interface AdminEditControlsProps {
  contentType: 'text' | 'heading' | 'button' | 'image' | 'link' | 'list'
  currentValue: string
  onSave: (newValue: string) => void
  onDelete?: () => void
  label?: string
  className?: string
}

export function AdminEditControls({
  contentType,
  currentValue,
  onSave,
  onDelete,
  label = 'Content',
  className = ''
}: AdminEditControlsProps) {
  const { user, getRole } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [editValue, setEditValue] = useState(currentValue)

  // Only show for superadmin and admin roles
  const canEdit = getRole() === 'Admin' || user?.email?.includes('superadmin')

  if (!canEdit) {
    return null
  }

  const handleSave = () => {
    onSave(editValue)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditValue(currentValue)
    setIsEditing(false)
  }

  return (
    <>
      {/* Edit Button Overlay */}
      <div className={`admin-edit-controls group ${className}`}>
        <div className="absolute top-0 right-0 z-50 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex gap-1 bg-blue-600 rounded-bl-lg rounded-tr-lg p-1 shadow-lg">
            <Button
              size="icon"
              variant="ghost"
              className="h-6 w-6 text-white hover:bg-blue-700"
              onClick={() => setIsEditing(true)}
            >
              <Edit className="h-3 w-3" />
            </Button>
            {onDelete && (
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6 text-white hover:bg-red-600"
                onClick={onDelete}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-blue-600 text-white">
                Admin Edit
              </Badge>
              Edit {label}
            </DialogTitle>
            <DialogDescription>
              Make changes to this content. Changes will be saved locally.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="content">
                {contentType === 'text' && 'Text Content'}
                {contentType === 'heading' && 'Heading Text'}
                {contentType === 'button' && 'Button Label'}
                {contentType === 'image' && 'Image URL'}
                {contentType === 'link' && 'Link URL'}
                {contentType === 'list' && 'List Items (one per line)'}
              </Label>
              
              {(contentType === 'text' || contentType === 'list') ? (
                <Textarea
                  id="content"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  rows={contentType === 'list' ? 8 : 4}
                  className="resize-none"
                  placeholder="Enter content..."
                />
              ) : (
                <Input
                  id="content"
                  type="text"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  placeholder="Enter content..."
                />
              )}
            </div>

            <div className="text-xs text-muted-foreground bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-3">
              <strong>Note:</strong> Changes are saved locally in your browser. To persist changes across sessions,
              you'll need to update the actual component files.
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={handleCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

// Editable Text Component
interface EditableTextProps {
  id: string
  defaultValue: string
  contentType?: 'text' | 'heading' | 'button' | 'link'
  as?: 'p' | 'h1' | 'h2' | 'h3' | 'h4' | 'span' | 'button' | 'a'
  className?: string
  children?: React.ReactNode
}

export function EditableText({
  id,
  defaultValue,
  contentType = 'text',
  as: Component = 'p',
  className = '',
  children
}: EditableTextProps) {
  const [value, setValue] = useState(() => {
    // Try to load from localStorage
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(`editable-${id}`)
      return saved || defaultValue
    }
    return defaultValue
  })

  const handleSave = (newValue: string) => {
    setValue(newValue)
    if (typeof window !== 'undefined') {
      localStorage.setItem(`editable-${id}`, newValue)
    }
  }

  return (
    <div className="relative group">
      <Component className={className}>
        {children || value}
      </Component>
      <AdminEditControls
        contentType={contentType}
        currentValue={value}
        onSave={handleSave}
        label={contentType}
      />
    </div>
  )
}

// Admin Panel Button (floating button to toggle admin mode)
export function AdminPanelButton() {
  const { user, getRole } = useAuth()
  const [adminMode, setAdminMode] = useState(false)

  const canEdit = getRole() === 'Admin' || user?.email?.includes('superadmin')

  if (!canEdit) {
    return null
  }

  return (
    <div className="fixed bottom-24 right-6 z-50">
      <Button
        onClick={() => setAdminMode(!adminMode)}
        className={`rounded-full shadow-2xl transition-all ${
          adminMode 
            ? 'bg-red-600 hover:bg-red-700' 
            : 'bg-blue-600 hover:bg-blue-700'
        }`}
        size="lg"
      >
        {adminMode ? 'Exit Edit Mode' : 'Edit Mode'}
      </Button>
      
      {adminMode && (
        <style jsx global>{`
          .admin-edit-controls {
            outline: 2px dashed rgba(59, 130, 246, 0.5);
            outline-offset: 2px;
          }
        `}</style>
      )}
    </div>
  )
}
