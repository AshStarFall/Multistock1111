"use client"

import { useMemo, useState } from "react"
import type { Movement, MovementType } from "@/lib/mock-orders"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

function TypeBadge({ t }: { t: MovementType }) {
  if (t === "inbound") return <Badge className="bg-secondary text-secondary-foreground">Inbound</Badge>
  if (t === "outbound") return <Badge className="bg-primary/15 text-primary">Outbound</Badge>
  if (t === "transfer") return <Badge className="bg-accent text-accent-foreground">Transfer</Badge>
  return <Badge variant="destructive">Adjustment</Badge>
}

export function MovementsTable({ rows }: { rows: Movement[] }) {
  const [q, setQ] = useState("")
  const [type, setType] = useState<"all" | MovementType>("all")

  const filtered = useMemo(() => {
    return rows.filter((m) => {
      const matchesQ = [m.sku, m.reference ?? "", m.from ?? "", m.to ?? ""]
        .join(" ")
        .toLowerCase()
        .includes(q.toLowerCase())
      const typeOk = type === "all" ? true : m.type === type
      return matchesQ && typeOk
    })
  }, [rows, q, type])

  return (
    <div className="space-y-3">
      <div
        role="region"
        aria-label="Movements toolbar"
        className="flex flex-col md:flex-row gap-2 items-stretch md:items-center justify-between"
      >
        <div className="flex flex-wrap items-center gap-2">
          <Input
            placeholder="Search SKU, ref, warehouse"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-64"
          />
          <select
            aria-label="Filter type"
            className="border rounded-md text-sm h-9 px-2 bg-background"
            value={type}
            onChange={(e) => setType(e.target.value as any)}
          >
            <option value="all">All Types</option>
            {["inbound", "outbound", "transfer", "adjustment"].map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="overflow-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left p-2">Date</th>
              <th className="text-left p-2">Type</th>
              <th className="text-left p-2">SKU</th>
              <th className="text-right p-2">Qty</th>
              <th className="text-left p-2">From</th>
              <th className="text-left p-2">To</th>
              <th className="text-left p-2">Reference</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((m) => (
              <tr key={m.id} className="border-t">
                <td className="p-2">{new Date(m.date).toLocaleString()}</td>
                <td className="p-2">
                  <TypeBadge t={m.type} />
                </td>
                <td className="p-2">{m.sku}</td>
                <td className="p-2 text-right">{m.qty}</td>
                <td className="p-2">{m.from ?? "-"}</td>
                <td className="p-2">{m.to ?? "-"}</td>
                <td className="p-2">{m.reference ?? "-"}</td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td className="p-3 text-muted-foreground" colSpan={7}>
                  No movements found for current filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-muted-foreground">Movements update automatically as orders are processed.</p>
    </div>
  )
}
