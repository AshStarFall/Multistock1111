"use client"

import type React from "react"
import { useAuth } from "@/lib/auth-context"
import { useMemo } from "react"
import Link from "next/link"

type Role = string

export function AuthGuard({ roles, children }: { roles: Role[]; children: React.ReactNode }) {
  const { user, isAuthenticated, loading } = useAuth()

  const allowed = useMemo(() => {
    if (loading) return null as boolean | null
    if (!isAuthenticated) return false
    if (!roles || roles.length === 0) return true
    // Handle internal API user format
    let userRole = ""
    if (user && 'role' in user) {
      userRole = user.role as string
    } else {
      // Handle Supabase user format
      userRole = (user?.user_metadata?.role as string) || (user?.app_metadata?.role as string) || ""
    }
    // roles incoming in some pages are lowercase (e.g., 'admin') and elsewhere Title Case.
    const norm = (s: string) => (s || "").toLowerCase()
    return roles.map(norm).includes(norm(userRole))
  }, [loading, isAuthenticated, roles, user])

  if (allowed === null) return null
  if (!allowed) {
    return (
      <div className="p-6 text-center space-y-4">
        <div className="text-xl font-semibold">Access Denied</div>
        <div className="text-sm text-muted-foreground">You do not have permission to view this page.</div>
        <div className="flex items-center justify-center gap-2">
          <Link href="/dashboard" className="underline">Go to dashboard</Link>
        </div>
      </div>
    )
  }

  return <>{children}</>
}


