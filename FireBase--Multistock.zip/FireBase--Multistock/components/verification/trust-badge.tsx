'use client';

import { Badge } from '@/components/ui/badge';
import { getTrustBadge, TrustScore } from '@/lib/verification';
import { Shield, CheckCircle, Award } from 'lucide-react';
import { motion } from 'framer-motion';

export function TrustBadge({
  score,
  size = 'md',
  showLabel = true,
  showScore = false,
}: {
  score: number;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  showScore?: boolean;
}) {
  const badge = getTrustBadge(score);

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-2',
  };

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
  };

  if (score < 40) {
    return null; // Don't show badge for unverified users
  }

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.2 }}
    >
      <Badge
        className={`${badge.color} text-white flex items-center gap-1.5 ${sizeClasses[size]}`}
      >
        <Shield className={iconSizes[size]} />
        {showLabel && <span>{badge.name}</span>}
        {showScore && <span>({score})</span>}
      </Badge>
    </motion.div>
  );
}

export function TrustScoreDisplay({ trustScore }: { trustScore: TrustScore }) {
  const badge = getTrustBadge(trustScore.totalScore);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Trust Score</h3>
          <p className="text-sm text-muted-foreground">
            Based on verification and activity
          </p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-primary">
            {trustScore.totalScore}
          </div>
          <div className="text-sm text-muted-foreground">out of 100</div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Verification</span>
          <span className="font-medium">{trustScore.verificationScore}/40</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-blue-600"
            initial={{ width: 0 }}
            animate={{ width: `${(trustScore.verificationScore / 40) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Activity</span>
          <span className="font-medium">{trustScore.activityScore}/20</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-green-600"
            initial={{ width: 0 }}
            animate={{ width: `${(trustScore.activityScore / 20) * 100}%` }}
            transition={{ duration: 0.5, delay: 0.1 }}
          />
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Reputation</span>
          <span className="font-medium">{trustScore.reputationScore}/25</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-yellow-600"
            initial={{ width: 0 }}
            animate={{ width: `${(trustScore.reputationScore / 25) * 100}%` }}
            transition={{ duration: 0.5, delay: 0.2 }}
          />
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Consistency</span>
          <span className="font-medium">{trustScore.consistencyScore}/15</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-purple-600"
            initial={{ width: 0 }}
            animate={{ width: `${(trustScore.consistencyScore / 15) * 100}%` }}
            transition={{ duration: 0.5, delay: 0.3 }}
          />
        </div>
      </div>

      {trustScore.badges.length > 0 && (
        <div className="pt-4 border-t">
          <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
            <Award className="w-4 h-4" />
            Earned Badges
          </h4>
          <div className="flex flex-wrap gap-2">
            {trustScore.badges.map((b) => (
              <Badge key={b.id} variant="secondary" className="flex items-center gap-1">
                <span>{b.icon}</span>
                <span>{b.name}</span>
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
