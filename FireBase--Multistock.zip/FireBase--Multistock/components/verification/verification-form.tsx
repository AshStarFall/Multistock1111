'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DOCUMENT_TYPES,
  validateDocument,
  formatFileSize,
  DocumentType,
} from '@/lib/verification';
import { Upload, X, FileText, CheckCircle, AlertCircle, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

type UploadedFile = {
  type: DocumentType;
  file: File;
  preview?: string;
};

export function VerificationForm() {
  const { toast } = useToast();
  const [requestType, setRequestType] = useState<'individual' | 'business'>('individual');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [formData, setFormData] = useState({
    businessName: '',
    businessType: '',
    taxId: '',
    website: '',
    notes: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const handleFileUpload = (type: DocumentType, file: File) => {
    const validation = validateDocument(file);

    if (!validation.valid) {
      toast({
        title: 'Invalid File',
        description: validation.error,
        variant: 'destructive',
      });
      return;
    }

    // Check if this document type already uploaded
    if (uploadedFiles.some((f) => f.type === type)) {
      toast({
        title: 'Document Already Uploaded',
        description: 'Please remove the existing file first',
        variant: 'destructive',
      });
      return;
    }

    // Create preview for images
    let preview: string | undefined;
    if (file.type.startsWith('image/')) {
      preview = URL.createObjectURL(file);
    }

    setUploadedFiles([...uploadedFiles, { type, file, preview }]);
    toast({
      title: 'File Uploaded',
      description: `${file.name} has been added`,
    });
  };

  const removeFile = (index: number) => {
    const newFiles = [...uploadedFiles];
    if (newFiles[index].preview) {
      URL.revokeObjectURL(newFiles[index].preview!);
    }
    newFiles.splice(index, 1);
    setUploadedFiles(newFiles);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Check required documents
    const requiredDocs = DOCUMENT_TYPES.filter((d) => d.required);
    const uploadedTypes = uploadedFiles.map((f) => f.type);
    const missingDocs = requiredDocs.filter((d) => !uploadedTypes.includes(d.value));

    if (missingDocs.length > 0) {
      toast({
        title: 'Missing Required Documents',
        description: `Please upload: ${missingDocs.map((d) => d.label).join(', ')}`,
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);

    try {
      // Upload files first
      const uploadPromises = uploadedFiles.map(async (item) => {
        const formData = new FormData();
        formData.append('file', item.file);
        formData.append('type', item.type);

        const response = await fetch('/api/verification/upload', {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) throw new Error('File upload failed');

        return response.json();
      });

      const uploadedDocuments = await Promise.all(uploadPromises);

      // Submit verification request
      const response = await fetch('/api/verification/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestType,
          documents: uploadedDocuments,
          ...formData,
        }),
      });

      if (!response.ok) throw new Error('Submission failed');

      toast({
        title: 'Verification Submitted!',
        description: 'Your request will be reviewed within 2-3 business days',
      });

      // Reset form
      setUploadedFiles([]);
      setFormData({
        businessName: '',
        businessType: '',
        taxId: '',
        website: '',
        notes: '',
      });
    } catch (error) {
      toast({
        title: 'Submission Failed',
        description: 'Please try again later',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-6 h-6 text-primary" />
          <div>
            <h2 className="text-2xl font-bold">Verification Request</h2>
            <p className="text-sm text-muted-foreground">
              Complete verification to earn trust badges
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <Label>Verification Type</Label>
            <Select
              value={requestType}
              onValueChange={(value: 'individual' | 'business') =>
                setRequestType(value)
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="individual">Individual Account</SelectItem>
                <SelectItem value="business">Business Account</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {requestType === 'business' && (
            <>
              <div>
                <Label htmlFor="businessName">Business Name *</Label>
                <Input
                  id="businessName"
                  required
                  value={formData.businessName}
                  onChange={(e) =>
                    setFormData({ ...formData, businessName: e.target.value })
                  }
                />
              </div>

              <div>
                <Label htmlFor="businessType">Business Type</Label>
                <Select
                  value={formData.businessType}
                  onValueChange={(value) =>
                    setFormData({ ...formData, businessType: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sole-proprietorship">Sole Proprietorship</SelectItem>
                    <SelectItem value="partnership">Partnership</SelectItem>
                    <SelectItem value="private-limited">Private Limited</SelectItem>
                    <SelectItem value="public-limited">Public Limited</SelectItem>
                    <SelectItem value="llp">LLP</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="taxId">GST/Tax ID</Label>
                <Input
                  id="taxId"
                  placeholder="e.g., 22AAAAA0000A1Z5"
                  value={formData.taxId}
                  onChange={(e) => setFormData({ ...formData, taxId: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="website">Website (Optional)</Label>
                <Input
                  id="website"
                  type="url"
                  placeholder="https://example.com"
                  value={formData.website}
                  onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                />
              </div>
            </>
          )}

          <div>
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any additional information..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Upload Documents</h3>

        <div className="space-y-4">
          {DOCUMENT_TYPES.map((docType) => (
            <div key={docType.value} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <Label className="flex items-center gap-2">
                  {docType.label}
                  {docType.required && <Badge variant="destructive">Required</Badge>}
                </Label>
              </div>

              {uploadedFiles.some((f) => f.type === docType.value) ? (
                <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-950/20 rounded-md">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div className="flex-1">
                    <p className="font-medium text-sm">
                      {
                        uploadedFiles.find((f) => f.type === docType.value)?.file
                          .name
                      }
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(
                        uploadedFiles.find((f) => f.type === docType.value)?.file
                          .size || 0
                      )}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() =>
                      removeFile(
                        uploadedFiles.findIndex((f) => f.type === docType.value)
                      )
                    }
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <label className="flex items-center justify-center gap-2 p-4 border-2 border-dashed rounded-md cursor-pointer hover:border-primary transition-colors">
                  <Upload className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    Click to upload (Max 5MB, JPG/PNG/PDF)
                  </span>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/jpeg,image/jpg,image/png,image/webp,application/pdf"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(docType.value, file);
                    }}
                  />
                </label>
              )}
            </div>
          ))}
        </div>
      </Card>

      <Button type="submit" size="lg" className="w-full" disabled={submitting}>
        {submitting ? (
          <>
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
            Submitting...
          </>
        ) : (
          <>
            <Shield className="w-4 h-4 mr-2" />
            Submit Verification Request
          </>
        )}
      </Button>
    </form>
  );
}
