"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { 
  CreditCard, 
  Plus, 
  Trash2,
  Check,
  Loader2,
  Shield
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface PaymentMethod {
  id: string
  type: 'credit_card' | 'debit_card' | 'upi' | 'bank_account'
  last4?: string
  cardBrand?: string
  expiryMonth?: number
  expiryYear?: number
  upiId?: string
  bankName?: string
  accountLast4?: string
  isDefault: boolean
  createdAt: Date
}

interface PaymentMethodsProps {
  userId: string
  methods?: PaymentMethod[]
}

export default function PaymentMethods({ userId, methods = [] }: PaymentMethodsProps) {
  const { toast } = useToast()
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(methods)
  const [loading, setLoading] = useState(false)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null)

  const [newMethodData, setNewMethodData] = useState<{
    type: 'credit_card' | 'debit_card' | 'upi' | 'bank_account'
    cardNumber: string
    cardName: string
    expiryMonth: string
    expiryYear: string
    cvv: string
    upiId: string
    bankName: string
    accountNumber: string
    ifscCode: string
  }>({
    type: 'credit_card',
    cardNumber: '',
    cardName: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    upiId: '',
    bankName: '',
    accountNumber: '',
    ifscCode: ''
  })

  const handleAddMethod = async () => {
    setLoading(true)
    try {
      // Validate based on type
      if (newMethodData.type === 'credit_card' || newMethodData.type === 'debit_card') {
        if (!newMethodData.cardNumber || !newMethodData.cardName || 
            !newMethodData.expiryMonth || !newMethodData.expiryYear || !newMethodData.cvv) {
          throw new Error('Please fill in all card details')
        }
      } else if (newMethodData.type === 'upi') {
        if (!newMethodData.upiId) {
          throw new Error('Please enter UPI ID')
        }
      } else if (newMethodData.type === 'bank_account') {
        if (!newMethodData.bankName || !newMethodData.accountNumber || !newMethodData.ifscCode) {
          throw new Error('Please fill in all bank details')
        }
      }

      const response = await fetch('/api/settings/payment-methods', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          ...newMethodData
        })
      })

      if (!response.ok) throw new Error('Failed to add payment method')

      const data = await response.json()
      setPaymentMethods([...paymentMethods, data.method])
      setShowAddDialog(false)
      
      // Reset form
      setNewMethodData({
        type: 'credit_card',
        cardNumber: '',
        cardName: '',
        expiryMonth: '',
        expiryYear: '',
        cvv: '',
        upiId: '',
        bankName: '',
        accountNumber: '',
        ifscCode: ''
      })

      toast({
        title: "Payment method added",
        description: "Your payment method has been saved successfully"
      })
    } catch (error: any) {
      console.error('Error adding payment method:', error)
      toast({
        title: "Error",
        description: error.message || "Failed to add payment method",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSetDefault = async (methodId: string) => {
    setLoading(true)
    try {
      const response = await fetch('/api/settings/payment-methods/default', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, methodId })
      })

      if (!response.ok) throw new Error('Failed to set default')

      setPaymentMethods(paymentMethods.map(m => ({
        ...m,
        isDefault: m.id === methodId
      })))

      toast({
        title: "Default payment method updated",
        description: "This payment method will be used by default"
      })
    } catch (error) {
      console.error('Error setting default:', error)
      toast({
        title: "Error",
        description: "Failed to set default payment method",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteMethod = async (methodId: string) => {
    if (!confirm('Are you sure you want to remove this payment method?')) return

    setLoading(true)
    try {
      const response = await fetch(`/api/settings/payment-methods?id=${methodId}`, {
        method: 'DELETE'
      })

      if (!response.ok) throw new Error('Failed to delete')

      setPaymentMethods(paymentMethods.filter(m => m.id !== methodId))
      toast({
        title: "Payment method removed",
        description: "The payment method has been deleted"
      })
    } catch (error) {
      console.error('Error deleting payment method:', error)
      toast({
        title: "Error",
        description: "Failed to remove payment method",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const formatCardNumber = (value: string) => {
    const cleaned = value.replace(/\D/g, '')
    const formatted = cleaned.match(/.{1,4}/g)?.join(' ') || cleaned
    return formatted.slice(0, 19) // 16 digits + 3 spaces
  }

  const getCardBrandIcon = (brand?: string) => {
    // In production, use actual card brand SVGs
    return '💳'
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Payment Methods
            </CardTitle>
            <CardDescription>
              Manage your saved payment methods for faster checkout
            </CardDescription>
          </div>
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Method
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <AnimatePresence>
          {paymentMethods.length === 0 ? (
            <div className="text-center py-12">
              <CreditCard className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No payment methods</h3>
              <p className="text-muted-foreground mb-4">
                Add a payment method to make purchases faster and easier
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Method
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {paymentMethods.map((method) => (
                <motion.div
                  key={method.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="p-4 border rounded-lg hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-3xl">
                        {method.type === 'upi' ? '📱' : 
                         method.type === 'bank_account' ? '🏦' : 
                         getCardBrandIcon(method.cardBrand)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium capitalize">
                            {method.type.replace('_', ' ')}
                          </span>
                          {method.isDefault && (
                            <Badge variant="default" className="text-xs">
                              <Check className="w-3 h-3 mr-1" />
                              Default
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {method.type === 'upi' ? method.upiId :
                           method.type === 'bank_account' ? 
                             `${method.bankName} •••• ${method.accountLast4}` :
                             `${method.cardBrand} •••• ${method.last4}`}
                        </p>
                        {method.expiryMonth && method.expiryYear && (
                          <p className="text-xs text-muted-foreground">
                            Expires {method.expiryMonth}/{method.expiryYear}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {!method.isDefault && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSetDefault(method.id)}
                          disabled={loading}
                        >
                          Set Default
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteMethod(method.id)}
                        disabled={loading}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </AnimatePresence>

        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-blue-800 dark:text-blue-200">
                Your payment information is secure
              </p>
              <p className="text-blue-700 dark:text-blue-300 mt-1">
                All payment details are encrypted and stored securely. We never share your information with third parties.
              </p>
            </div>
          </div>
        </div>
      </CardContent>

      {/* Add Payment Method Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Payment Method</DialogTitle>
            <DialogDescription>
              Add a new payment method to your account
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Payment Type */}
            <div className="space-y-2">
              <Label>Payment Type</Label>
              <Select
                value={newMethodData.type}
                onValueChange={(value: any) => 
                  setNewMethodData({ ...newMethodData, type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="credit_card">💳 Credit Card</SelectItem>
                  <SelectItem value="debit_card">💳 Debit Card</SelectItem>
                  <SelectItem value="upi">📱 UPI</SelectItem>
                  <SelectItem value="bank_account">🏦 Bank Account</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Card Details */}
            {(newMethodData.type === 'credit_card' || newMethodData.type === 'debit_card') && (
              <>
                <div className="space-y-2">
                  <Label>Card Number</Label>
                  <Input
                    value={newMethodData.cardNumber}
                    onChange={(e) => setNewMethodData({
                      ...newMethodData,
                      cardNumber: formatCardNumber(e.target.value)
                    })}
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Cardholder Name</Label>
                  <Input
                    value={newMethodData.cardName}
                    onChange={(e) => setNewMethodData({
                      ...newMethodData,
                      cardName: e.target.value
                    })}
                    placeholder="John Doe"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Month</Label>
                    <Input
                      value={newMethodData.expiryMonth}
                      onChange={(e) => setNewMethodData({
                        ...newMethodData,
                        expiryMonth: e.target.value.replace(/\D/g, '').slice(0, 2)
                      })}
                      placeholder="MM"
                      maxLength={2}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Year</Label>
                    <Input
                      value={newMethodData.expiryYear}
                      onChange={(e) => setNewMethodData({
                        ...newMethodData,
                        expiryYear: e.target.value.replace(/\D/g, '').slice(0, 4)
                      })}
                      placeholder="YYYY"
                      maxLength={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>CVV</Label>
                    <Input
                      type="password"
                      value={newMethodData.cvv}
                      onChange={(e) => setNewMethodData({
                        ...newMethodData,
                        cvv: e.target.value.replace(/\D/g, '').slice(0, 4)
                      })}
                      placeholder="123"
                      maxLength={4}
                    />
                  </div>
                </div>
              </>
            )}

            {/* UPI Details */}
            {newMethodData.type === 'upi' && (
              <div className="space-y-2">
                <Label>UPI ID</Label>
                <Input
                  value={newMethodData.upiId}
                  onChange={(e) => setNewMethodData({
                    ...newMethodData,
                    upiId: e.target.value
                  })}
                  placeholder="yourname@upi"
                />
              </div>
            )}

            {/* Bank Account Details */}
            {newMethodData.type === 'bank_account' && (
              <>
                <div className="space-y-2">
                  <Label>Bank Name</Label>
                  <Input
                    value={newMethodData.bankName}
                    onChange={(e) => setNewMethodData({
                      ...newMethodData,
                      bankName: e.target.value
                    })}
                    placeholder="State Bank of India"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Account Number</Label>
                  <Input
                    value={newMethodData.accountNumber}
                    onChange={(e) => setNewMethodData({
                      ...newMethodData,
                      accountNumber: e.target.value.replace(/\D/g, '')
                    })}
                    placeholder="1234567890"
                  />
                </div>
                <div className="space-y-2">
                  <Label>IFSC Code</Label>
                  <Input
                    value={newMethodData.ifscCode}
                    onChange={(e) => setNewMethodData({
                      ...newMethodData,
                      ifscCode: e.target.value.toUpperCase()
                    })}
                    placeholder="SBIN0001234"
                    maxLength={11}
                  />
                </div>
              </>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddMethod} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Adding...
                </>
              ) : (
                'Add Method'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
