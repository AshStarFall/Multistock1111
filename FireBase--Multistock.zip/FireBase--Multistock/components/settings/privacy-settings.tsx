"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { 
  Eye, 
  EyeOff, 
  Download,
  Trash2,
  AlertTriangle,
  Shield,
  Loader2
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface PrivacySettingsProps {
  userId: string
  initialSettings?: {
    profileVisibility: boolean
    showEmail: boolean
    showPhone: boolean
    showAddress: boolean
    activityTracking: boolean
    marketingEmails: boolean
    thirdPartySharing: boolean
  }
}

export default function PrivacySettings({ 
  userId, 
  initialSettings 
}: PrivacySettingsProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showDataDialog, setShowDataDialog] = useState(false)

  const [settings, setSettings] = useState(initialSettings || {
    profileVisibility: true,
    showEmail: false,
    showPhone: false,
    showAddress: false,
    activityTracking: true,
    marketingEmails: false,
    thirdPartySharing: false
  })

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }))
    setSaved(false)
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/settings/privacy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, settings })
      })

      if (!response.ok) throw new Error('Failed to save settings')

      setSaved(true)
      toast({
        title: "Privacy settings updated",
        description: "Your preferences have been saved successfully"
      })

      setTimeout(() => setSaved(false), 3000)
    } catch (error) {
      console.error('Error saving privacy settings:', error)
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadData = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/settings/privacy/download-data?userId=${userId}`)
      
      if (!response.ok) throw new Error('Failed to download data')

      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `my-data-${new Date().toISOString().split('T')[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast({
        title: "Data downloaded",
        description: "Your data has been downloaded successfully"
      })
      setShowDataDialog(false)
    } catch (error) {
      console.error('Error downloading data:', error)
      toast({
        title: "Error",
        description: "Failed to download data. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteAccount = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/settings/privacy/delete-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      })

      if (!response.ok) throw new Error('Failed to delete account')

      toast({
        title: "Account deleted",
        description: "Your account has been permanently deleted"
      })

      // Redirect to home page after 2 seconds
      setTimeout(() => {
        window.location.href = '/'
      }, 2000)
    } catch (error) {
      console.error('Error deleting account:', error)
      toast({
        title: "Error",
        description: "Failed to delete account. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Profile Visibility */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Profile Visibility
          </CardTitle>
          <CardDescription>
            Control who can see your profile and information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Public Profile</Label>
              <p className="text-sm text-muted-foreground">
                Make your profile visible to other users
              </p>
            </div>
            <Switch
              checked={settings.profileVisibility}
              onCheckedChange={() => handleToggle('profileVisibility')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Show Email Address</Label>
              <p className="text-sm text-muted-foreground">
                Display your email on your public profile
              </p>
            </div>
            <Switch
              checked={settings.showEmail}
              onCheckedChange={() => handleToggle('showEmail')}
              disabled={!settings.profileVisibility}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Show Phone Number</Label>
              <p className="text-sm text-muted-foreground">
                Display your phone number on your public profile
              </p>
            </div>
            <Switch
              checked={settings.showPhone}
              onCheckedChange={() => handleToggle('showPhone')}
              disabled={!settings.profileVisibility}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Show Address</Label>
              <p className="text-sm text-muted-foreground">
                Display your address on your public profile
              </p>
            </div>
            <Switch
              checked={settings.showAddress}
              onCheckedChange={() => handleToggle('showAddress')}
              disabled={!settings.profileVisibility}
            />
          </div>
        </CardContent>
      </Card>

      {/* Data & Privacy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Data & Privacy
          </CardTitle>
          <CardDescription>
            Manage how your data is collected and used
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Activity Tracking</Label>
              <p className="text-sm text-muted-foreground">
                Allow us to track your activity for personalized recommendations
              </p>
            </div>
            <Switch
              checked={settings.activityTracking}
              onCheckedChange={() => handleToggle('activityTracking')}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Marketing Emails</Label>
              <p className="text-sm text-muted-foreground">
                Receive promotional emails and special offers
              </p>
            </div>
            <Switch
              checked={settings.marketingEmails}
              onCheckedChange={() => handleToggle('marketingEmails')}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Third-Party Data Sharing</Label>
              <p className="text-sm text-muted-foreground">
                Allow sharing anonymized data with trusted partners
              </p>
            </div>
            <Switch
              checked={settings.thirdPartySharing}
              onCheckedChange={() => handleToggle('thirdPartySharing')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
          <CardDescription>
            Download or delete your account data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                Download Your Data
              </Label>
              <p className="text-sm text-muted-foreground">
                Get a copy of all your account data in JSON format
              </p>
            </div>
            <Button variant="outline" onClick={() => setShowDataDialog(true)}>
              Download
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 border border-red-200 dark:border-red-800 rounded-lg bg-red-50 dark:bg-red-900/20">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <Trash2 className="w-4 h-4" />
                Delete Account
              </Label>
              <p className="text-sm text-red-600 dark:text-red-400">
                Permanently delete your account and all associated data
              </p>
            </div>
            <Button 
              variant="destructive" 
              onClick={() => setShowDeleteDialog(true)}
            >
              Delete
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex items-center gap-3">
        <Button onClick={handleSave} disabled={loading || saved}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : saved ? (
            'Saved'
          ) : (
            'Save Privacy Settings'
          )}
        </Button>
        {saved && (
          <motion.span
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-sm text-green-600 dark:text-green-400"
          >
            Settings saved successfully!
          </motion.span>
        )}
      </div>

      {/* Download Data Dialog */}
      <Dialog open={showDataDialog} onOpenChange={setShowDataDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Download Your Data</DialogTitle>
            <DialogDescription>
              This will download all your account data in JSON format
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm">
              Your download will include:
            </p>
            <ul className="text-sm space-y-2 list-disc list-inside text-muted-foreground">
              <li>Profile information</li>
              <li>Transaction history</li>
              <li>Order history</li>
              <li>Reviews and ratings</li>
              <li>Settings and preferences</li>
              <li>Activity logs</li>
            </ul>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDataDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleDownloadData} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Preparing...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Delete Account
            </DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete your account.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <p className="text-sm font-medium text-red-800 dark:text-red-200 mb-2">
                All of the following will be permanently deleted:
              </p>
              <ul className="text-sm space-y-1 list-disc list-inside text-red-700 dark:text-red-300">
                <li>Your profile and personal information</li>
                <li>All transaction records</li>
                <li>Order history and receipts</li>
                <li>Reviews and ratings</li>
                <li>Saved payment methods</li>
                <li>All settings and preferences</li>
              </ul>
            </div>
            <p className="text-sm text-muted-foreground">
              Are you absolutely sure you want to delete your account?
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteAccount}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete My Account'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
