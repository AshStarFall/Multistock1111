"use client"

import { useState, useEffect, useMemo } from "react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Footer } from "@/components/footer"
import { ThemeToggle } from "@/components/theme-toggle"
import { NotificationCenter } from "@/components/notification-center"
import { AppSidebar } from "@/components/app-sidebar"
import { Logo } from "@/components/logo"
import { Chatbot } from "@/components/chatbot"
import { useAuth } from "@/lib/auth-context"
import { useOptimization } from "@/hooks/use-optimization"
import { SkipToContent } from "@/components/accessibility/skip-to-content"
import { AccessibilityToolbar } from "@/components/accessibility/accessibility-toolbar"
import {
  Menu,
  X,
  Home,
  Package,
  Warehouse,
  Store,
  Boxes,
  MapPin,
  Lock,
  LogOut,
  User,
  Settings,
  Search,
  PanelLeftClose,
  PanelLeft
} from "lucide-react"

interface AppLayoutProps {
  children: React.ReactNode
  showNav?: boolean
  showFooter?: boolean
  showSidebar?: boolean
}

export function AppLayout({ children, showNav = true, showFooter = true, showSidebar = true }: AppLayoutProps) {
  const { user, logout, isAuthenticated, getRole } = useAuth()
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  
  // Use optimization hook for better performance
  const { isOptimized } = useOptimization()

  // Memoize navigation items to prevent re-renders
  const navigationItems = useMemo(() => [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Dashboard', href: '/dashboard', icon: Home },
    { name: 'Products', href: '/inventory', icon: Package },
    { name: 'Warehouses', href: '/warehouses', icon: Warehouse },
    { name: 'Rentals', href: '/rentals', icon: Boxes },
    { name: 'Storage', href: '/storage', icon: MapPin },
    { name: 'Lockers', href: '/lockers', icon: Lock },
    { name: 'Marketplace', href: '/marketplace', icon: Store },
  ], [])

  // Handle client-side hydration - mark component as mounted
  useEffect(() => {
    setMounted(true)
    
    // Set initial sidebar state based on screen size
    const isDesktop = window.innerWidth >= 1024
    setSidebarOpen(isDesktop)
  }, [])

  // Auto-collapse sidebar on mobile/desktop resize
  useEffect(() => {
    if (!mounted) return

    const handleResize = () => {
      const isDesktop = window.innerWidth >= 1024
      setSidebarOpen(isDesktop)
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [mounted])

  // Memoize conditions to prevent re-renders
  const shouldShowNav = useMemo(() => 
    showNav && !pathname?.startsWith('/auth') && !pathname?.startsWith('/register'), 
    [showNav, pathname]
  )
  
  const shouldShowFooter = useMemo(() => 
    showFooter && !pathname?.startsWith('/auth') && !pathname?.startsWith('/register'), 
    [showFooter, pathname]
  )
  
  const shouldShowSidebar = useMemo(() => 
    showSidebar && isAuthenticated && !pathname?.startsWith('/auth') && !pathname?.startsWith('/register'), 
    [showSidebar, isAuthenticated, pathname]
  )

  const getUserInitials = useMemo(() => {
    return () => {
      if (!user?.name) return 'U'
      return user.name
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2)
    }
  }, [user?.name])

  const handleLogout = () => {
    logout()
  }

  // Prevent hydration mismatch - don't render layout-dependent content until mounted
  if (!mounted) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        {children}
      </div>
    )
  }

  return (
    <div key="app-layout-mounted" className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950" suppressHydrationWarning>
      {/* Accessibility Components */}
      <SkipToContent />
      <AccessibilityToolbar />
      
      {/* Top Navigation Bar - Sticky positioning */}
      {shouldShowNav && (
        <header 
          key="main-header"
          className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800 shadow-sm"
          suppressHydrationWarning
        >
          <div className="h-16 px-4 flex items-center justify-between gap-4">
            {/* Left: Logo */}
            <div className="flex items-center gap-4 min-w-[200px]">
              <Logo size="md" showTagline={false} href="/" />
            </div>

            {/* Center: Search Bar */}
            <div className="hidden md:flex flex-1 max-w-2xl">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search stock, rentals, storage, lockers..."
                  className="w-full h-10 pl-10 pr-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 focus:outline-none focus:ring-2 focus:ring-primary transition-all text-sm"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const query = (e.target as HTMLInputElement).value
                      if (query) window.location.href = `/search?q=${encodeURIComponent(query)}`
                    }
                  }}
                  aria-label="Search"
                />
              </div>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2">
              {/* Notifications */}
              {isAuthenticated && <NotificationCenter />}

              {/* Theme Toggle */}
              <ThemeToggle />

              {/* User Menu */}
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="gap-2 px-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white text-xs font-semibold">
                          {getUserInitials()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="hidden lg:flex flex-col items-start">
                        <span className="text-sm font-medium line-clamp-1">{user?.name || 'User'}</span>
                        <Badge variant="secondary" className="text-xs h-4">
                          {getRole()}
                        </Badge>
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/profile" className="cursor-pointer">
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/settings" className="cursor-pointer">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer">
                      <LogOut className="w-4 h-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex items-center gap-2">
                  <Link href="/auth/login">
                    <Button variant="ghost" size="sm">Login</Button>
                  </Link>
                  <Link href="/register">
                    <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600">
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}

              {/* Mobile Menu Toggle */}
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </header>
      )}

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />

          {/* Mobile Menu */}
          <nav
            className="fixed top-16 left-0 bottom-0 w-[280px] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shadow-xl z-50 lg:hidden overflow-y-auto scrollbar-thin scrollbar-thumb-primary scrollbar-track-transparent"
            aria-label="Main navigation"
          >
            <div className="p-4 space-y-2">
              {navigationItems.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href
                return (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Button
                      variant={isActive ? "default" : "ghost"}
                      className={`w-full justify-start gap-3 ${isActive ? 'shadow-md' : ''}`}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{item.name}</span>
                    </Button>
                  </Link>
                )
              })}
            </div>
          </nav>
        </>
      )}

      {/* Main Content Area with Flexbox Layout */}
      <div className="flex flex-1 min-h-0 relative" suppressHydrationWarning>
        {/* Sidebar - Positioned between header and footer, not fixed */}
        {shouldShowSidebar && (
          <>
            <div 
              className={cn(
                "hidden lg:block flex-shrink-0 transition-all duration-300 ease-in-out border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg rounded-r-xl",
                sidebarOpen ? "translate-x-0" : "-translate-x-full",
                sidebarCollapsed ? "w-16" : "w-64"
              )}
            >
              <AppSidebar 
                open={sidebarOpen} 
                onClose={() => setSidebarOpen(false)} 
                collapsed={sidebarCollapsed}
                onToggleOpen={() => setSidebarOpen(!sidebarOpen)}
                onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
                userRole={user?.role || "Staff"}
              />
            </div>
            
            {/* Floating Open Button when sidebar is closed */}
            {!sidebarOpen && (
              <div className="hidden lg:block absolute top-4 left-4 z-10">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 bg-white dark:bg-slate-900 shadow-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
                  onClick={() => setSidebarOpen(true)}
                  title="Open sidebar"
                  aria-label="Open sidebar"
                >
                  <PanelLeft className="w-5 h-5" />
                </Button>
              </div>
            )}
          </>
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-h-0 min-w-0 overflow-hidden">
          {/* Scrollable Content Area */}
          <main 
            className="flex-1 overflow-y-auto overflow-x-hidden bg-slate-50/50 dark:bg-slate-900/50"
            tabIndex={-1}
            id="main-content"
          >
            <div className="p-4 sm:p-6 lg:p-8 max-w-full min-h-full">
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-6 min-h-full">
                {children}
              </div>
            </div>
          </main>

          {/* Footer - Always at bottom and takes full width */}
          {shouldShowFooter && (
            <div className="flex-shrink-0 w-full">
              <Footer />
            </div>
          )}
        </div>
      </div>

      {/* Chatbot */}
      <Chatbot />
    </div>
  )
}
