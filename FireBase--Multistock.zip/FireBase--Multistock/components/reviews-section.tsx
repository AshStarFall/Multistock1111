"use client"

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ReviewCard } from '@/components/review-card'
import { ReviewStatsDisplay } from '@/components/review-stats-display'
import { WriteReviewDialog } from '@/components/dialogs/write-review-dialog'
import { Star, Filter, ImageIcon, ShieldCheck, TrendingUp } from 'lucide-react'
import { type Review, type ReviewFilters, calculateReviewStats, filterReviews } from '@/lib/reviews'
import { Skeleton } from '@/components/ui/skeleton'

interface ReviewsSectionProps {
  productId: string
  productName: string
  userHasPurchased?: boolean
  showWriteReview?: boolean
}

export function ReviewsSection({
  productId,
  productName,
  userHasPurchased = false,
  showWriteReview = true
}: ReviewsSectionProps) {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [writeReviewOpen, setWriteReviewOpen] = useState(false)
  const [filters, setFilters] = useState<ReviewFilters>({
    sortBy: 'recent'
  })

  // Fetch reviews
  useEffect(() => {
    fetchReviews()
  }, [productId])

  const fetchReviews = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/reviews?productId=${productId}`)
      const data = await response.json()
      setReviews(data.reviews || [])
    } catch (error) {
      console.error('Failed to fetch reviews:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitReview = async (reviewData: {
    rating: number
    title: string
    comment: string
    images: File[]
  }) => {
    const formData = new FormData()
    formData.append('productId', productId)
    formData.append('rating', reviewData.rating.toString())
    formData.append('title', reviewData.title)
    formData.append('comment', reviewData.comment)
    formData.append('verifiedPurchase', userHasPurchased.toString())

    reviewData.images.forEach((image, index) => {
      formData.append(`image_${index}`, image)
    })

    const response = await fetch('/api/reviews', {
      method: 'POST',
      body: formData
    })

    if (!response.ok) {
      throw new Error('Failed to submit review')
    }

    // Refresh reviews
    await fetchReviews()
  }

  const handleHelpful = async (reviewId: string) => {
    await fetch(`/api/reviews/${reviewId}/helpful`, { method: 'POST' })
    await fetchReviews()
  }

  const handleNotHelpful = async (reviewId: string) => {
    await fetch(`/api/reviews/${reviewId}/not-helpful`, { method: 'POST' })
    await fetchReviews()
  }

  const handleReport = async (reviewId: string) => {
    await fetch(`/api/reviews/${reviewId}/report`, { method: 'POST' })
    // Show confirmation toast
  }

  const stats = calculateReviewStats(reviews)
  const filteredReviews = filterReviews(reviews, filters)

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-48" />
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
              Customer Reviews
            </CardTitle>
            {showWriteReview && (
              <Button onClick={() => setWriteReviewOpen(true)}>
                Write a Review
              </Button>
            )}
          </div>
        </CardHeader>

        <CardContent>
          <Tabs defaultValue="all" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">
                All Reviews ({stats.totalReviews})
              </TabsTrigger>
              <TabsTrigger value="stats">
                Statistics
              </TabsTrigger>
              <TabsTrigger value="photos">
                With Photos ({reviews.filter(r => r.images && r.images.length > 0).length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6">
              {/* Filters */}
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Filter & Sort:</span>
                </div>

                <Select
                  value={filters.sortBy || 'recent'}
                  onValueChange={(value) => setFilters({ ...filters, sortBy: value as any })}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        Most Recent
                      </div>
                    </SelectItem>
                    <SelectItem value="helpful">Most Helpful</SelectItem>
                    <SelectItem value="rating-high">Highest Rating</SelectItem>
                    <SelectItem value="rating-low">Lowest Rating</SelectItem>
                  </SelectContent>
                </Select>

                <Button
                  variant={filters.verifiedOnly ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilters({ ...filters, verifiedOnly: !filters.verifiedOnly })}
                >
                  <ShieldCheck className="w-4 h-4 mr-2" />
                  Verified Only
                </Button>

                <Button
                  variant={filters.withImages ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilters({ ...filters, withImages: !filters.withImages })}
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  With Photos
                </Button>
              </div>

              {/* Reviews List */}
              <div className="space-y-4">
                {filteredReviews.length === 0 ? (
                  <div className="text-center py-12">
                    <Star className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No reviews yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Be the first to share your experience with this product
                    </p>
                    {showWriteReview && (
                      <Button onClick={() => setWriteReviewOpen(true)}>
                        Write First Review
                      </Button>
                    )}
                  </div>
                ) : (
                  filteredReviews.map((review) => (
                    <ReviewCard
                      key={review.id}
                      review={review}
                      onHelpful={handleHelpful}
                      onNotHelpful={handleNotHelpful}
                      onReport={handleReport}
                    />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="stats">
              <ReviewStatsDisplay
                stats={stats}
                onFilterByRating={(rating) => setFilters({ ...filters, rating: rating || undefined })}
                selectedRating={filters.rating || null}
              />
            </TabsContent>

            <TabsContent value="photos" className="space-y-4">
              {reviews
                .filter(r => r.images && r.images.length > 0 && r.status === 'approved')
                .map((review) => (
                  <ReviewCard
                    key={review.id}
                    review={review}
                    onHelpful={handleHelpful}
                    onNotHelpful={handleNotHelpful}
                    onReport={handleReport}
                  />
                ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Write Review Dialog */}
      <WriteReviewDialog
        open={writeReviewOpen}
        onClose={() => setWriteReviewOpen(false)}
        productId={productId}
        productName={productName}
        verifiedPurchase={userHasPurchased}
        onSubmit={handleSubmitReview}
      />
    </>
  )
}
