'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CouponValidation, calculateDiscountedPrice } from '@/lib/coupons';
import { Tag, CheckCircle, XCircle, AlertCircle, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

export function CouponApply({
  orderAmount,
  onCouponApplied,
}: {
  orderAmount: number;
  onCouponApplied?: (validation: CouponValidation) => void;
}) {
  const { toast } = useToast();
  const [couponCode, setCouponCode] = useState('');
  const [validating, setValidating] = useState(false);
  const [validation, setValidation] = useState<CouponValidation | null>(null);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  const handleApply = async () => {
    if (!couponCode.trim()) {
      toast({
        title: 'Enter Coupon Code',
        description: 'Please enter a valid coupon code',
        variant: 'destructive',
      });
      return;
    }

    setValidating(true);

    try {
      const response = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: couponCode.toUpperCase(),
          orderAmount,
        }),
      });

      const result: CouponValidation = await response.json();
      setValidation(result);

      if (result.valid) {
        setAppliedCoupon(couponCode.toUpperCase());
        toast({
          title: 'Coupon Applied!',
          description: `You saved ₹${result.discountAmount}`,
        });
        onCouponApplied?.(result);
      } else {
        toast({
          title: 'Invalid Coupon',
          description: result.error || 'This coupon cannot be applied',
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to validate coupon',
        variant: 'destructive',
      });
    } finally {
      setValidating(false);
    }
  };

  const handleRemove = () => {
    setAppliedCoupon(null);
    setValidation(null);
    setCouponCode('');
    onCouponApplied?.(null as any);
    toast({
      title: 'Coupon Removed',
      description: 'Coupon code has been removed',
    });
  };

  const pricing =
    validation?.valid && validation.discountAmount
      ? calculateDiscountedPrice(orderAmount, validation.discountAmount)
      : null;

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3">
        <Tag className="w-5 h-5 text-primary" />
        <h3 className="font-semibold">Apply Coupon Code</h3>
      </div>

      {!appliedCoupon ? (
        <div className="flex gap-2">
          <Input
            placeholder="Enter coupon code"
            value={couponCode}
            onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === 'Enter' && handleApply()}
            className="uppercase"
          />
          <Button onClick={handleApply} disabled={validating}>
            {validating ? 'Validating...' : 'Apply'}
          </Button>
        </div>
      ) : (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-3"
          >
            <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-semibold text-green-900 dark:text-green-100">
                    {appliedCoupon}
                  </p>
                  <p className="text-sm text-green-700 dark:text-green-300">
                    Coupon applied successfully
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={handleRemove}>
                Remove
              </Button>
            </div>

            {pricing && (
              <div className="space-y-2 p-3 bg-primary/5 rounded-lg">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Original Amount</span>
                  <span>₹{pricing.originalPrice.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-green-600 dark:text-green-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    Discount
                  </span>
                  <span className="text-green-600 dark:text-green-400 font-medium">
                    -₹{pricing.discountAmount.toLocaleString()}
                  </span>
                </div>
                <div className="pt-2 border-t flex items-center justify-between font-bold">
                  <span>Final Amount</span>
                  <span className="text-xl text-primary">
                    ₹{pricing.finalPrice.toLocaleString()}
                  </span>
                </div>
                <Badge className="w-full justify-center bg-green-600 text-white">
                  You Save ₹{pricing.savings.toLocaleString()} ({pricing.savingsPercentage}%)
                </Badge>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      )}

      {validation && !validation.valid && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-3 p-3 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-200 dark:border-red-800"
        >
          <div className="flex items-center gap-2">
            <XCircle className="w-5 h-5 text-red-600" />
            <p className="text-sm text-red-700 dark:text-red-300">{validation.error}</p>
          </div>
        </motion.div>
      )}
    </Card>
  );
}
