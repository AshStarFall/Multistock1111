'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Coupon, formatCouponValue, getDaysUntilExpiry, getCouponStatusColor } from '@/lib/coupons';
import { Copy, CheckCircle, Tag, Clock, Users, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

export function CouponCard({ coupon, onApply }: { coupon: Coupon; onApply?: (code: string) => void }) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(coupon.code);
    setCopied(true);
    toast({
      title: 'Code Copied!',
      description: `Coupon code "${coupon.code}" copied to clipboard`,
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const daysLeft = getDaysUntilExpiry(coupon.endDate);
  const usagePercentage = (coupon.usageCount / coupon.usageLimit) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="overflow-hidden border-2 border-dashed hover:border-primary transition-colors">
        <div className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Tag className="w-5 h-5 text-primary" />
                <h3 className="text-xl font-bold">{coupon.name}</h3>
              </div>
              <p className="text-sm text-muted-foreground">{coupon.description}</p>
            </div>
            <Badge className={getCouponStatusColor(coupon.status)}>
              {coupon.status}
            </Badge>
          </div>

          {/* Coupon Code Display */}
          <div className="bg-gradient-to-r from-primary/10 to-purple-500/10 rounded-lg p-4 mb-4 border-2 border-dashed border-primary/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Coupon Code</p>
                <p className="text-2xl font-bold font-mono tracking-wider">{coupon.code}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopy}
                className="gap-2"
              >
                {copied ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    Copy
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Discount Value */}
          <div className="flex items-center justify-center py-4 mb-4 bg-primary/5 rounded-lg">
            <div className="text-center">
              <p className="text-3xl font-bold text-primary">
                {formatCouponValue(coupon.type, coupon.value)}
              </p>
              {coupon.maxDiscountAmount && (
                <p className="text-xs text-muted-foreground mt-1">
                  Max discount: ₹{coupon.maxDiscountAmount}
                </p>
              )}
            </div>
          </div>

          {/* Details */}
          <div className="space-y-2 mb-4">
            {coupon.minPurchaseAmount && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Min. Purchase</span>
                <span className="font-medium">₹{coupon.minPurchaseAmount}</span>
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Expires in
              </span>
              <span className={`font-medium ${daysLeft <= 3 ? 'text-red-600' : ''}`}>
                {daysLeft > 0 ? `${daysLeft} days` : 'Expired'}
              </span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <Users className="w-3 h-3" />
                Usage
              </span>
              <span className="font-medium">
                {coupon.usageCount} / {coupon.usageLimit}
              </span>
            </div>
          </div>

          {/* Usage Progress Bar */}
          <div className="mb-4">
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <motion.div
                className={`h-full ${
                  usagePercentage >= 90
                    ? 'bg-red-600'
                    : usagePercentage >= 70
                    ? 'bg-yellow-600'
                    : 'bg-green-600'
                }`}
                initial={{ width: 0 }}
                animate={{ width: `${usagePercentage}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          {/* Action Buttons */}
          {onApply && (
            <Button
              className="w-full"
              onClick={() => onApply(coupon.code)}
              disabled={coupon.status !== 'active' || daysLeft <= 0}
            >
              Apply Coupon
            </Button>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
