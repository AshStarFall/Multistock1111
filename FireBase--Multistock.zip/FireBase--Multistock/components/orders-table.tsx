"use client"

import { useMemo, useState } from "react"
import type { Order, OrderStatus } from "@/lib/mock-orders"
import { orderTotal } from "@/lib/mock-orders"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download } from "lucide-react"

const PO_STATUSES: OrderStatus[] = ["Draft", "Open", "Partially Received", "Received", "Canceled"]
const SO_STATUSES: OrderStatus[] = ["Open", "Partially Fulfilled", "Fulfilled", "Canceled"]

function toCSV(rows: Order[]) {
  const header = ["number", "kind", "partyName", "status", "date", "dueDate", "currency", "itemsCount", "total"]
  const lines = rows.map((o) => {
    return [
      o.number,
      o.kind,
      o.partyName,
      o.status,
      o.date,
      o.dueDate ?? "",
      o.currency,
      o.items.length,
      orderTotal(o).toFixed(2),
    ].join(",")
  })
  return [header.join(","), ...lines].join("\n")
}

function download(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function StatusBadge({ status }: { status: OrderStatus }) {
  if (status === "Canceled") return <Badge variant="destructive">Canceled</Badge>
  if (status === "Draft") return <Badge variant="secondary">Draft</Badge>
  if (status === "Open") return <Badge className="bg-primary/15 text-primary">Open</Badge>
  if (status === "Partially Received" || status === "Partially Fulfilled")
    return <Badge className="bg-accent text-accent-foreground">{status}</Badge>
  // Received / Fulfilled
  return <Badge className="bg-secondary text-secondary-foreground">{status}</Badge>
}

export function OrdersTable({
  rows,
  kind,
}: {
  rows: Order[]
  kind: "purchase" | "sales"
}) {
  const [q, setQ] = useState("")
  const [status, setStatus] = useState<"all" | OrderStatus>("all")
  const [from, setFrom] = useState<string>("")
  const [to, setTo] = useState<string>("")
  const [coupon, setCoupon] = useState<string>("")
  const [referral, setReferral] = useState<string>("")

  const filtered = useMemo(() => {
    return rows.filter((o) => {
      const matchesQ = [o.number, o.partyName].some((v) => v.toLowerCase().includes(q.toLowerCase()))
      const statusOk = status === "all" ? true : o.status === status
      const d = new Date(o.date).getTime()
      const fromOk = from ? d >= new Date(from).getTime() : true
      const toOk = to ? d <= new Date(to).getTime() : true
      return matchesQ && statusOk && fromOk && toOk
    })
  }, [rows, q, status, from, to])

  return (
    <div className="space-y-3">
      <div
        role="region"
        aria-label="Orders toolbar"
        className="flex flex-col md:flex-row gap-2 items-stretch md:items-center justify-between"
      >
        <div className="flex flex-wrap gap-2 items-center">
          <Input
            placeholder={kind === "purchase" ? "Search PO number, supplier" : "Search SO number, customer"}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-64"
          />
          <select
            aria-label="Filter status"
            className="border rounded-md text-sm h-9 px-2 bg-background"
            value={status}
            onChange={(e) => setStatus(e.target.value as any)}
          >
            <option value="all">All Statuses</option>
            {(kind === "purchase" ? PO_STATUSES : SO_STATUSES).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <input
            type="date"
            aria-label="From date"
            className="border rounded-md text-sm h-9 px-2 bg-background"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
          <input
            type="date"
            aria-label="To date"
            className="border rounded-md text-sm h-9 px-2 bg-background"
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
          {kind === "sales" && (
            <>
              <input
                type="text"
                placeholder="Coupon code"
                className="border rounded-md text-sm h-9 px-2 bg-background w-40"
                value={coupon}
                onChange={(e) => setCoupon(e.target.value.toUpperCase())}
              />
              <Button
                type="button"
                variant="secondary"
                onClick={() => setCoupon(coupon.trim().toUpperCase())}
              >
                Apply
              </Button>
              <input
                type="text"
                placeholder="Referral code"
                className="border rounded-md text-sm h-9 px-2 bg-background w-40"
                value={referral}
                onChange={(e) => setReferral(e.target.value.toUpperCase())}
              />
              <Button
                type="button"
                variant="secondary"
                onClick={() => setReferral(referral.trim().toUpperCase())}
              >
                Add credit
              </Button>
            </>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => download(`${kind}-orders.csv`, toCSV(filtered))}>
            <Download className="h-4 w-4 mr-1" aria-hidden="true" /> Export CSV
          </Button>
        </div>
      </div>

      <div className="overflow-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left p-2">Order</th>
              <th className="text-left p-2">{kind === "purchase" ? "Supplier" : "Customer"}</th>
              <th className="text-left p-2">Date</th>
              <th className="text-left p-2">Status</th>
              <th className="text-right p-2">Items</th>
              <th className="text-right p-2">Total</th>
              {kind === "sales" && <th className="text-right p-2">Discounted</th>}
              <th className="text-left p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((o) => {
              const total = orderTotal(o)
              const discount = kind === "sales" ? computeDiscount(total, coupon) : 0
              const credit = kind === "sales" ? computeReferralCredit(total - discount, referral) : 0
              const discounted = Math.max(0, total - discount - credit)
              return (
              <tr key={o.id} className="border-t">
                <td className="p-2 font-medium">{o.number}</td>
                <td className="p-2">{o.partyName}</td>
                <td className="p-2">{new Date(o.date).toLocaleDateString()}</td>
                <td className="p-2">
                  <StatusBadge status={o.status} />
                </td>
                <td className="p-2 text-right">{o.items.length}</td>
                <td className="p-2 text-right">
                  {o.currency} {total.toFixed(2)}
                </td>
                {kind === "sales" && (
                  <td className="p-2 text-right">
                    {o.currency} {discounted.toFixed(2)}
                    {discount > 0 ? ` (−${discount.toFixed(2)} coupon)` : ""}
                    {credit > 0 ? ` (−${credit.toFixed(2)} referral)` : ""}
                  </td>
                )}
                <td className="p-2">
                  <Button variant="ghost" size="sm" className="text-primary">
                    View
                  </Button>
                </td>
              </tr>
            )})}
            {filtered.length === 0 && (
              <tr>
                <td className="p-3 text-muted-foreground" colSpan={7}>
                  No orders found for current filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-muted-foreground">
        Tip: Export to get a CSV template, then import via a future flow or manually add orders when integrations are
        enabled.
      </p>
    </div>
  )
}

// minimal in-memory coupons/discounts engine
const COUPONS: Record<string, { type: "percent" | "flat"; value: number; min?: number; maxOff?: number }> = {
  SAVE10: { type: "percent", value: 10 },
  SAVE20: { type: "percent", value: 20, min: 100 },
  FLAT50: { type: "flat", value: 50, min: 200 },
}

function computeDiscount(total: number, code: string): number {
  const c = COUPONS[code.trim().toUpperCase()]
  if (!c) return 0
  if (c.min && total < c.min) return 0
  const raw = c.type === "percent" ? (total * c.value) / 100 : c.value
  return c.maxOff ? Math.min(raw, c.maxOff) : raw
}

// simple referral credits registry (demo only)
const REFERRALS: Record<string, { credit: number; min?: number }> = {
  FRIEND20: { credit: 20, min: 50 },
  WELCOME10: { credit: 10 },
}

function computeReferralCredit(subtotalAfterDiscount: number, code: string): number {
  const r = REFERRALS[code.trim().toUpperCase()]
  if (!r) return 0
  if (r.min && subtotalAfterDiscount < r.min) return 0
  return Math.min(r.credit, subtotalAfterDiscount)
}
