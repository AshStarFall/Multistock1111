"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import Papa from "papaparse"
import { useRef } from "react"

export function UploadCsv() {
  const ref = useRef<HTMLInputElement>(null)
  const onPick = () => ref.current?.click()
  const onChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        console.log(" Parsed CSV rows:", results.data.length)
        await fetch("/api/products/import", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rows: results.data }),
        })
        alert("Import queued (mock).")
      },
    })
  }
  return (
    <>
      <input ref={ref} type="file" accept=".csv" className="sr-only" onChange={onChange} />
      <Button variant="outline" onClick={onPick}>
        Import CSV
      </Button>
    </>
  )
}
