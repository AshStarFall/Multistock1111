"use client"

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Send,
  Paperclip,
  Image as ImageIcon,
  Smile,
  MoreVertical,
  Phone,
  Video,
  Info
} from 'lucide-react'
import { 
  type Chat, 
  type ChatMessage,
  getChatDisplayName,
  getChatAvatar,
  formatMessageTime,
  groupMessagesByDate,
  isUserOnline
} from '@/lib/forum'

interface ChatWindowProps {
  chat: Chat
  messages: ChatMessage[]
  currentUserId: string
  onSendMessage?: (content: string) => void
  onSendFile?: (file: File) => void
}

export default function ChatWindow({
  chat,
  messages,
  currentUserId,
  onSendMessage,
  onSendFile
}: ChatWindowProps) {
  const [messageInput, setMessageInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const displayName = getChatDisplayName(chat, currentUserId)
  const avatar = getChatAvatar(chat, currentUserId)
  const otherParticipant = chat.participants.find(p => p.userId !== currentUserId)
  const isOnline = otherParticipant ? isUserOnline(otherParticipant.lastSeenAt) : false

  useEffect(() => {
    // Scroll to bottom on new messages
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = () => {
    if (!messageInput.trim()) return
    
    onSendMessage?.(messageInput)
    setMessageInput('')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      onSendFile?.(file)
    }
  }

  const groupedMessages = groupMessagesByDate(messages)

  return (
    <Card className="h-full flex flex-col">
      {/* Chat Header */}
      <div className="p-4 border-b flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="w-10 h-10">
              <AvatarImage src={avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`} />
              <AvatarFallback>{displayName[0]}</AvatarFallback>
            </Avatar>
            {chat.type === 'private' && isOnline && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-slate-900" />
            )}
          </div>
          <div>
            <h3 className="font-semibold">{displayName}</h3>
            <p className="text-xs text-muted-foreground">
              {chat.type === 'group' 
                ? `${chat.participants.length} members`
                : isOnline ? 'Online' : 'Offline'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon">
            <Phone className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Video className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Info className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {Array.from(groupedMessages.entries()).map(([date, dateMessages]) => (
            <div key={date} className="space-y-4">
              {/* Date Separator */}
              <div className="flex items-center justify-center">
                <Badge variant="outline" className="text-xs">
                  {date}
                </Badge>
              </div>

              {/* Messages */}
              {dateMessages.map((message, index) => {
                const isOwn = message.senderId === currentUserId
                const showAvatar = !isOwn && (
                  index === 0 || 
                  dateMessages[index - 1]?.senderId !== message.senderId
                )

                return (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    {/* Avatar */}
                    {showAvatar ? (
                      <Avatar className="w-8 h-8 flex-shrink-0">
                        <AvatarImage src={message.senderAvatar || `https://api.dicebear.com/7.x/initials/svg?seed=${message.senderName}`} />
                        <AvatarFallback>{message.senderName[0]}</AvatarFallback>
                      </Avatar>
                    ) : (
                      <div className="w-8 flex-shrink-0" />
                    )}

                    {/* Message Bubble */}
                    <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'} max-w-[70%]`}>
                      {showAvatar && !isOwn && (
                        <span className="text-xs text-muted-foreground mb-1">
                          {message.senderName}
                        </span>
                      )}
                      
                      <div className={`rounded-2xl px-4 py-2 ${
                        isOwn 
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800'
                      }`}>
                        {message.type === 'text' ? (
                          <p className="text-sm whitespace-pre-wrap break-words">
                            {message.content}
                          </p>
                        ) : message.type === 'image' ? (
                          <div className="space-y-2">
                            <img 
                              src={message.fileUrl} 
                              alt="Shared image" 
                              className="max-w-full rounded-lg"
                            />
                            {message.content && (
                              <p className="text-sm">{message.content}</p>
                            )}
                          </div>
                        ) : message.type === 'file' ? (
                          <div className="flex items-center gap-2">
                            <Paperclip className="w-4 h-4" />
                            <div>
                              <p className="text-sm font-medium">{message.fileName}</p>
                              <p className="text-xs opacity-70">{message.fileSize}</p>
                            </div>
                          </div>
                        ) : (
                          <p className="text-xs italic opacity-70">{message.content}</p>
                        )}
                      </div>

                      <span className="text-xs text-muted-foreground mt-1">
                        {formatMessageTime(message.createdAt)}
                        {isOwn && message.isRead && ' · Read'}
                      </span>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          ))}
        </div>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-2 text-sm text-muted-foreground mt-4"
            >
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span>typing...</span>
            </motion.div>
          )}
        </AnimatePresence>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 border-t">
        <div className="flex items-end gap-2">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileSelect}
          />
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
          >
            <Paperclip className="w-5 h-5" />
          </Button>

          <div className="flex-1 bg-slate-100 dark:bg-slate-900 rounded-full px-4 py-2">
            <Input
              placeholder="Type a message..."
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={handleKeyPress}
              className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 p-0"
            />
          </div>

          <Button
            variant="ghost"
            size="icon"
          >
            <Smile className="w-5 h-5" />
          </Button>

          <Button
            size="icon"
            onClick={handleSend}
            disabled={!messageInput.trim()}
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </Card>
  )
}
