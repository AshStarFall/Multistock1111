"use client"

import { motion } from 'framer-motion'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { MoreVertical, Pin, Archive, Trash } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { 
  type Chat, 
  getChatDisplayName,
  getChatAvatar,
  formatMessageTime,
  isUserOnline
} from '@/lib/forum'

interface ChatListItemProps {
  chat: Chat
  currentUserId: string
  isActive?: boolean
  onClick?: (chat: Chat) => void
  onPin?: (chatId: string) => void
  onArchive?: (chatId: string) => void
  onDelete?: (chatId: string) => void
}

export default function ChatListItem({
  chat,
  currentUserId,
  isActive,
  onClick,
  onPin,
  onArchive,
  onDelete
}: ChatListItemProps) {
  const displayName = getChatDisplayName(chat, currentUserId)
  const avatar = getChatAvatar(chat, currentUserId)
  const otherParticipant = chat.participants.find(p => p.userId !== currentUserId)
  const isOnline = otherParticipant ? isUserOnline(otherParticipant.lastSeenAt) : false

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      whileHover={{ backgroundColor: 'rgba(0,0,0,0.02)' }}
      className={`p-3 rounded-lg cursor-pointer ${
        isActive ? 'bg-slate-100 dark:bg-slate-800' : ''
      }`}
      onClick={() => onClick?.(chat)}
    >
      <div className="flex items-center gap-3">
        {/* Avatar with Online Indicator */}
        <div className="relative flex-shrink-0">
          <Avatar className="w-12 h-12">
            <AvatarImage src={avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${displayName}`} />
            <AvatarFallback>{displayName[0]}</AvatarFallback>
          </Avatar>
          {chat.type === 'private' && isOnline && (
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-slate-900" />
          )}
        </div>

        {/* Chat Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <h4 className="font-semibold truncate">{displayName}</h4>
            {chat.lastMessage && (
              <span className="text-xs text-muted-foreground flex-shrink-0 ml-2">
                {formatMessageTime(chat.lastMessage.createdAt)}
              </span>
            )}
          </div>
          
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground truncate">
              {chat.lastMessage?.type === 'text' 
                ? chat.lastMessage.content
                : chat.lastMessage?.type === 'image'
                ? '📷 Image'
                : chat.lastMessage?.type === 'file'
                ? '📎 File'
                : 'No messages yet'}
            </p>
            {chat.unreadCount > 0 && (
              <Badge className="ml-2 bg-blue-600 text-white h-5 min-w-[20px] rounded-full flex items-center justify-center">
                {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
              </Badge>
            )}
          </div>
        </div>

        {/* Actions Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="icon" className="flex-shrink-0 opacity-0 group-hover:opacity-100">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onPin?.(chat.id)}>
              <Pin className="w-4 h-4 mr-2" />
              Pin Chat
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onArchive?.(chat.id)}>
              <Archive className="w-4 h-4 mr-2" />
              Archive
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={() => onDelete?.(chat.id)}
              className="text-red-600"
            >
              <Trash className="w-4 h-4 mr-2" />
              Delete Chat
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </motion.div>
  )
}
