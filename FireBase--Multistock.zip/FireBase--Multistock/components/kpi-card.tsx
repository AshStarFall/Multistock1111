import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

type DeltaType = "up" | "down" | "neutral"

type BaseProps = {
  value: string | number
}

type VariantIcon = {
  title?: string
  icon?: LucideIcon
  intent?: "default" | "primary" | "warning" | "success"
}

type VariantLabel = {
  label?: string
  delta?: string
  deltaType?: DeltaType
}

export function KpiCard(props: BaseProps & VariantIcon & VariantLabel) {
  const { value, title, label, icon: Icon, intent = "default", delta, deltaType = "neutral" } = props

  const ring =
    intent === "primary"
      ? "ring-1 ring-[color:var(--color-primary)]/20"
      : intent === "warning"
        ? "ring-1 ring-[color:var(--color-accent)]/30"
        : intent === "success"
          ? "ring-1 ring-[color:var(--color-chart-2)]/30"
          : "ring-1 ring-border/60"

  const iconColor =
    intent === "primary"
      ? "text-[color:var(--color-primary)]"
      : intent === "warning"
        ? "text-[color:var(--color-accent)]"
        : intent === "success"
          ? "text-[color:var(--color-chart-2)]"
          : "text-foreground"

  const heading = title ?? label ?? "KPI"

  const deltaColor =
    deltaType === "up"
      ? "text-[color:var(--color-chart-2)]"
      : deltaType === "down"
        ? "text-[color:var(--color-destructive)]"
        : "text-muted-foreground"

  return (
    <Card className={cn(ring, "indian-card")}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium indian-text">{heading}</CardTitle>
        {Icon ? <Icon className={cn("h-5 w-5", iconColor)} aria-hidden="true" /> : null}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-semibold indian-accent">{value}</div>
        {delta ? <div className={cn("text-xs mt-1", deltaColor)}>{delta}</div> : null}
      </CardContent>
    </Card>
  )
}
