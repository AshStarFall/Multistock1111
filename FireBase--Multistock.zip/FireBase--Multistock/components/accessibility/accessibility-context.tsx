"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from "react"

interface AccessibilityContextType {
  highContrast: boolean
  toggleHighContrast: () => void
  reducedMotion: boolean
  toggleReducedMotion: () => void
  fontSize: 'small' | 'medium' | 'large'
  increaseFontSize: () => void
  decreaseFontSize: () => void
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined)

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const [highContrast, setHighContrast] = useState(false)
  const [reducedMotion, setReducedMotion] = useState(false)
  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>('medium')

  // Load preferences from localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedHighContrast = localStorage.getItem('highContrast') === 'true'
      const savedReducedMotion = localStorage.getItem('reducedMotion') === 'true'
      const savedFontSize = localStorage.getItem('fontSize') as 'small' | 'medium' | 'large' || 'medium'
      
      setHighContrast(savedHighContrast)
      setReducedMotion(savedReducedMotion)
      setFontSize(savedFontSize)
    }
  }, [])

  // Apply preferences to document
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // High contrast
      if (highContrast) {
        document.documentElement.classList.add('high-contrast')
      } else {
        document.documentElement.classList.remove('high-contrast')
      }
      
      // Reduced motion
      if (reducedMotion) {
        document.documentElement.classList.add('reduced-motion')
      } else {
        document.documentElement.classList.remove('reduced-motion')
      }
      
      // Font size
      document.documentElement.classList.remove('text-small', 'text-medium', 'text-large')
      document.documentElement.classList.add(`text-${fontSize}`)
      
      // Save to localStorage
      localStorage.setItem('highContrast', String(highContrast))
      localStorage.setItem('reducedMotion', String(reducedMotion))
      localStorage.setItem('fontSize', fontSize)
    }
  }, [highContrast, reducedMotion, fontSize])

  const toggleHighContrast = () => {
    setHighContrast(prev => !prev)
  }

  const toggleReducedMotion = () => {
    setReducedMotion(prev => !prev)
  }

  const increaseFontSize = () => {
    setFontSize(prev => {
      if (prev === 'small') return 'medium'
      if (prev === 'medium') return 'large'
      return 'large'
    })
  }

  const decreaseFontSize = () => {
    setFontSize(prev => {
      if (prev === 'large') return 'medium'
      if (prev === 'medium') return 'small'
      return 'small'
    })
  }

  return (
    <AccessibilityContext.Provider value={{
      highContrast,
      toggleHighContrast,
      reducedMotion,
      toggleReducedMotion,
      fontSize,
      increaseFontSize,
      decreaseFontSize
    }}>
      {children}
    </AccessibilityContext.Provider>
  )
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext)
  if (context === undefined) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider')
  }
  return context
}