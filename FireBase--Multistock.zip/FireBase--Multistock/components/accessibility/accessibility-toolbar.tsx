"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { 
  Contrast, 
  Move, 
  ZoomIn, 
  ZoomOut, 
  Settings,
  X
} from "lucide-react"
import { useAccessibility } from "@/components/accessibility/accessibility-context"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"

export function AccessibilityToolbar() {
  const { 
    highContrast, 
    toggleHighContrast, 
    reducedMotion, 
    toggleReducedMotion, 
    fontSize, 
    increaseFontSize, 
    decreaseFontSize 
  } = useAccessibility()
  
  const [isOpen, setIsOpen] = useState(false)
  
  // Close toolbar when ESC is pressed
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false)
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])
  
  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="fixed bottom-4 right-4 z-50 rounded-full shadow-lg bg-white dark:bg-slate-900 border-2 border-primary"
          aria-label="Accessibility settings"
        >
          <Settings className="w-5 h-5" />
        </Button>
      </SheetTrigger>
      <SheetContent 
        side="bottom" 
        className="rounded-t-xl h-auto max-h-[80vh] flex flex-col"
      >
        <SheetHeader className="flex flex-row items-center justify-between border-b pb-4">
          <div>
            <SheetTitle className="text-xl">Accessibility Settings</SheetTitle>
            <SheetDescription>
              Customize your experience to meet your needs
            </SheetDescription>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setIsOpen(false)}
            aria-label="Close accessibility settings"
          >
            <X className="w-5 h-5" />
          </Button>
        </SheetHeader>
        
        <div className="flex-1 overflow-y-auto py-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* High Contrast */}
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Contrast className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold">High Contrast</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Increase color contrast for better visibility
              </p>
              <Button 
                variant={highContrast ? "default" : "outline"} 
                className="w-full"
                onClick={toggleHighContrast}
                aria-pressed={highContrast}
              >
                {highContrast ? "Enabled" : "Enable"}
              </Button>
            </div>
            
            {/* Reduced Motion */}
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Move className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold">Reduced Motion</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Minimize animations and transitions
              </p>
              <Button 
                variant={reducedMotion ? "default" : "outline"} 
                className="w-full"
                onClick={toggleReducedMotion}
                aria-pressed={reducedMotion}
              >
                {reducedMotion ? "Enabled" : "Enable"}
              </Button>
            </div>
            
            {/* Text Size */}
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Settings className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold">Text Size</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Adjust text size for better readability
              </p>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={decreaseFontSize}
                  disabled={fontSize === 'small'}
                  aria-label="Decrease text size"
                >
                  <ZoomOut className="w-4 h-4" />
                </Button>
                <div className="flex-1 flex items-center justify-center">
                  <span className="font-medium capitalize">{fontSize}</span>
                </div>
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={increaseFontSize}
                  disabled={fontSize === 'large'}
                  aria-label="Increase text size"
                >
                  <ZoomIn className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Preview */}
          <div className="mt-8 bg-slate-50 dark:bg-slate-800 rounded-xl p-6">
            <h3 className="font-semibold mb-4">Preview</h3>
            <div className="space-y-4">
              <p className={highContrast ? "high-contrast-text" : ""}>
                This is a preview of how text will appear with your current settings.
              </p>
              <div className="flex gap-2">
                <Button variant="default">Sample Button</Button>
                <Button variant="outline">Outline Button</Button>
              </div>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}