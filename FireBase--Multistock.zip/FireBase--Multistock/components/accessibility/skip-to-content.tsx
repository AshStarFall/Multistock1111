"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"

export function SkipToContent() {
  useEffect(() => {
    // Focus the skip link on page load for keyboard users
    const skipLink = document.querySelector('[data-skip-to-content]')
    if (skipLink) {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault()
          const mainContent = document.querySelector('main')
          if (mainContent) {
            (mainContent as HTMLElement).focus()
            mainContent.scrollIntoView({ behavior: 'smooth' })
          }
        }
      }
      
      skipLink.addEventListener('keydown', handleKeyDown as EventListener)
      
      // Cleanup
      return () => {
        skipLink.removeEventListener('keydown', handleKeyDown as EventListener)
      }
    }
  }, [])

  return (
    <Button
      data-skip-to-content
      variant="outline"
      className="fixed top-4 left-4 z-50 bg-white dark:bg-slate-900 shadow-lg rounded-lg px-4 py-2 text-sm font-medium transform -translate-y-20 focus:translate-y-0 transition-transform duration-200 ease-in-out"
      onClick={(e) => {
        e.preventDefault()
        const mainContent = document.querySelector('main')
        if (mainContent) {
          (mainContent as HTMLElement).focus()
          mainContent.scrollIntoView({ behavior: 'smooth' })
        }
      }}
    >
      Skip to main content
    </Button>
  )
}