"use client"

import { Card } from "@/components/ui/card"
import { 
  Package, 
  Truck, 
  Warehouse, 
  ShoppingCart, 
  BarChart3, 
  Shield, 
  Clock, 
  Users,
  TrendingUp,
  Zap,
  Globe,
  Lock
} from "lucide-react"

const features = [
  {
    icon: Package,
    title: "Inventory Control",
    description: "Real-time tracking of stock levels across multiple warehouses with automated reorder alerts",
    color: "bg-indigo-500"
  },
  {
    icon: Truck,
    title: "Logistics Management",
    description: "End-to-end supply chain visibility with integrated shipping and delivery tracking",
    color: "bg-violet-500"
  },
  {
    icon: Warehouse,
    title: "Smart Storage",
    description: "Optimize warehouse space with intelligent slot allocation and locker management systems",
    color: "bg-cyan-500"
  },
  {
    icon: ShoppingCart,
    title: "Marketplace",
    description: "Buy and sell products in our secure marketplace with verified sellers and buyers",
    color: "bg-purple-500"
  },
  {
    icon: BarChart3,
    title: "Analytics & Reports",
    description: "Comprehensive business insights with customizable reports and data visualization",
    color: "bg-pink-500"
  },
  {
    icon: Shield,
    title: "Security First",
    description: "Enterprise-grade security with role-based access control and audit logging",
    color: "bg-emerald-500"
  },
  {
    icon: Clock,
    title: "24/7 Operations",
    description: "Round-the-clock system availability with real-time notifications and alerts",
    color: "bg-amber-500"
  },
  {
    icon: Users,
    title: "Multi-User Support",
    description: "Collaborate with your team using granular permissions and user management",
    color: "bg-rose-500"
  },
]

const stats = [
  { icon: TrendingUp, value: "99.9%", label: "Uptime" },
  { icon: Zap, value: "<100ms", label: "Response Time" },
  { icon: Globe, value: "50+", label: "Countries" },
  { icon: Lock, value: "SOC 2", label: "Compliant" },
]

export function PlatformFeatures() {
  return (
    <div className="space-y-8">
      {/* About Section */}
      <Card className="modern-card p-8 bg-gradient-to-br from-indigo-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-gradient-primary mb-4">
            Complete Logistics & Inventory Platform
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            MultiStock is your all-in-one solution for modern inventory management, warehouse operations, 
            and supply chain logistics. Built for businesses of all sizes, from startups to enterprises, 
            we provide the tools you need to streamline operations and scale efficiently.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <div 
                key={index}
                className="text-center p-4 rounded-xl bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm"
              >
                <Icon className="w-8 h-8 mx-auto mb-2 text-indigo-600 dark:text-indigo-400" />
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Features Grid */}
      <div>
        <h3 className="text-2xl font-bold mb-6 text-center">
          <span className="text-gradient-primary">Powerful Features</span> for Modern Businesses
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Card 
                key={index}
                className="modern-card p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold text-lg mb-2 text-foreground">
                  {feature.title}
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}
