"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  ThumbsUp,
  Reply,
  MoreVertical,
  Edit,
  Trash,
  Flag,
  CheckCircle
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { type ForumPost, getTimeAgo } from '@/lib/forum'

interface PostCardProps {
  post: ForumPost
  currentUserId?: string
  onLike?: (postId: string) => void
  onReply?: (postId: string) => void
  onEdit?: (postId: string) => void
  onDelete?: (postId: string) => void
  onMarkAnswer?: (postId: string) => void
}

export default function PostCard({
  post,
  currentUserId,
  onLike,
  onReply,
  onEdit,
  onDelete,
  onMarkAnswer
}: PostCardProps) {
  const { toast } = useToast()
  const [liked, setLiked] = useState(false)
  const isAuthor = currentUserId === post.authorId

  const handleLike = () => {
    setLiked(!liked)
    onLike?.(post.id)
  }

  const handleReport = () => {
    toast({
      title: "Post reported",
      description: "Thank you for helping keep our community safe"
    })
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className={post.isAnswer ? 'border-2 border-green-500' : ''}>
        <CardContent className="p-4">
          <div className="flex gap-4">
            {/* Author Avatar */}
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarImage src={post.authorAvatar || `https://api.dicebear.com/7.x/initials/svg?seed=${post.authorName}`} />
              <AvatarFallback>{post.authorName[0]}</AvatarFallback>
            </Avatar>

            {/* Post Content */}
            <div className="flex-1 min-w-0 space-y-3">
              {/* Author & Time */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{post.authorName}</span>
                  {post.isAnswer && (
                    <Badge className="bg-green-600">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Answer
                    </Badge>
                  )}
                  <span className="text-sm text-muted-foreground">
                    {getTimeAgo(post.createdAt)}
                    {post.isEdited && ' (edited)'}
                  </span>
                </div>

                {/* Actions Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {isAuthor && (
                      <>
                        <DropdownMenuItem onClick={() => onEdit?.(post.id)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => onDelete?.(post.id)}
                          className="text-red-600"
                        >
                          <Trash className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                      </>
                    )}
                    {!post.isAnswer && currentUserId && (
                      <>
                        <DropdownMenuItem onClick={() => onMarkAnswer?.(post.id)}>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Mark as Answer
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                      </>
                    )}
                    <DropdownMenuItem onClick={handleReport}>
                      <Flag className="w-4 h-4 mr-2" />
                      Report
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Content */}
              <div className="prose dark:prose-invert max-w-none">
                <p className="whitespace-pre-wrap">{post.content}</p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLike}
                  className={liked ? 'text-blue-600' : ''}
                >
                  <ThumbsUp className={`w-4 h-4 mr-1 ${liked ? 'fill-blue-600' : ''}`} />
                  {post.likes + (liked ? 1 : 0)}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onReply?.(post.id)}
                >
                  <Reply className="w-4 h-4 mr-1" />
                  Reply
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
