"use client"

import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MessageSquare, Eye, ThumbsUp, Pin, Lock, Archive } from 'lucide-react'
import { type ForumThread, getTimeAgo } from '@/lib/forum'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'

interface ThreadCardProps {
  thread: ForumThread
  onClick?: (thread: ForumThread) => void
}

export default function ThreadCard({ thread, onClick }: ThreadCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.2 }}
    >
      <Card 
        className="cursor-pointer hover:shadow-md transition-shadow"
        onClick={() => onClick?.(thread)}
      >
        <CardContent className="p-4">
          <div className="flex gap-4">
            {/* Author Avatar */}
            <Avatar className="w-12 h-12 flex-shrink-0">
              <AvatarImage src={thread.authorAvatar || `https://api.dicebear.com/7.x/initials/svg?seed=${thread.authorName}`} />
              <AvatarFallback>{thread.authorName[0]}</AvatarFallback>
            </Avatar>

            {/* Thread Content */}
            <div className="flex-1 min-w-0 space-y-2">
              {/* Title & Status */}
              <div className="flex items-start gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {thread.isPinned && (
                      <Pin className="w-4 h-4 text-blue-600 flex-shrink-0" />
                    )}
                    {thread.isLocked && (
                      <Lock className="w-4 h-4 text-red-600 flex-shrink-0" />
                    )}
                    <h3 className="font-semibold text-lg line-clamp-1">
                      {thread.title}
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {thread.content}
                  </p>
                </div>
              </div>

              {/* Tags */}
              {thread.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {thread.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Meta Info */}
              <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                <div className="flex items-center gap-4">
                  <span>by <span className="font-medium">{thread.authorName}</span></span>
                  <span>in <span className="font-medium">{thread.categoryName}</span></span>
                  <span>{getTimeAgo(thread.createdAt)}</span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    <span>{thread.replies}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    <span>{thread.views}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ThumbsUp className="w-4 h-4" />
                    <span>{thread.likes}</span>
                  </div>
                </div>
              </div>

              {/* Last Reply */}
              {thread.lastReplyBy && thread.lastReplyAt && (
                <div className="text-xs text-muted-foreground">
                  Last reply by <span className="font-medium">{thread.lastReplyBy}</span>{' '}
                  {getTimeAgo(thread.lastReplyAt)}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
