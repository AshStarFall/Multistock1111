"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { 
  Search, 
  Filter, 
  SlidersHorizontal, 
  X, 
  Package,
  TrendingUp,
  Calendar,
  Hash,
  Tag
} from "lucide-react"

interface AdvancedSearchFilterProps {
  onSearch: (filters: SearchFilters) => void
  categories: string[]
  className?: string
}

interface SearchFilters {
  query: string
  category: string
  status: string
  minPrice: number
  maxPrice: number
  minStock: number
  maxStock: number
  sortBy: string
  sortOrder: 'asc' | 'desc'
  dateFrom?: string
  dateTo?: string
}

const defaultFilters: SearchFilters = {
  query: "",
  category: "all",
  status: "all",
  minPrice: 0,
  maxPrice: 10000,
  minStock: 0,
  maxStock: 1000,
  sortBy: "name",
  sortOrder: "asc"
}

export function AdvancedSearchFilter({ onSearch, categories, className }: AdvancedSearchFilterProps) {
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters)
  const [open, setOpen] = useState(false)
  const [activeFilterCount, setActiveFilterCount] = useState(0)

  // Calculate active filter count
  useEffect(() => {
    const count = [
      filters.query,
      filters.category !== "all",
      filters.status !== "all",
      filters.minPrice > 0,
      filters.maxPrice < 10000,
      filters.minStock > 0,
      filters.maxStock < 1000,
      filters.dateFrom,
      filters.dateTo
    ].filter(Boolean).length
    
    setActiveFilterCount(count)
  }, [filters])

  const handleSearch = () => {
    onSearch(filters)
    setOpen(false)
  }

  const handleReset = () => {
    setFilters(defaultFilters)
    onSearch(defaultFilters)
    setOpen(false)
  }

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className={className}>
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Main Search */}
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            placeholder="Search by product name, SKU, description..."
            value={filters.query}
            onChange={(e) => updateFilter('query', e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            className="pl-12 h-12 text-base"
          />
        </div>

        {/* Category Filter */}
        <Select value={filters.category} onValueChange={(value) => updateFilter('category', value)}>
          <SelectTrigger className="w-full lg:w-48 h-12">
            <Tag className="w-4 h-4 mr-2" />
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Status Filter */}
        <Select value={filters.status} onValueChange={(value) => updateFilter('status', value)}>
          <SelectTrigger className="w-full lg:w-48 h-12">
            <Package className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Stock Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="in">✅ In Stock</SelectItem>
            <SelectItem value="low">⚠️ Low Stock</SelectItem>
            <SelectItem value="out">❌ Out of Stock</SelectItem>
          </SelectContent>
        </Select>

        {/* Advanced Filters Popover */}
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="h-12 px-6">
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Filters
              {activeFilterCount > 0 && (
                <Badge className="ml-2 bg-primary text-primary-foreground" variant="secondary">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-96 p-0">
            <div className="p-4 space-y-6">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Advanced Filters</h4>
                <Button variant="ghost" size="sm" onClick={handleReset}>
                  <X className="w-4 h-4 mr-2" />
                  Reset
                </Button>
              </div>
              
              <Separator />
              
              {/* Price Range */}
              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  Price Range
                </Label>
                <div className="px-2">
                  <Slider
                    value={[filters.minPrice, filters.maxPrice]}
                    onValueChange={([min, max]) => {
                      updateFilter('minPrice', min)
                      updateFilter('maxPrice', max)
                    }}
                    max={10000}
                    step={100}
                    className="w-full"
                  />
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">₹{filters.minPrice}</span>
                  <span className="text-muted-foreground">₹{filters.maxPrice}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Min Price</Label>
                    <Input
                      type="number"
                      value={filters.minPrice}
                      onChange={(e) => updateFilter('minPrice', Number(e.target.value))}
                      className="h-8"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Max Price</Label>
                    <Input
                      type="number"
                      value={filters.maxPrice}
                      onChange={(e) => updateFilter('maxPrice', Number(e.target.value))}
                      className="h-8"
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              {/* Stock Range */}
              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  <Hash className="w-4 h-4" />
                  Stock Range
                </Label>
                <div className="px-2">
                  <Slider
                    value={[filters.minStock, filters.maxStock]}
                    onValueChange={([min, max]) => {
                      updateFilter('minStock', min)
                      updateFilter('maxStock', max)
                    }}
                    max={1000}
                    step={10}
                    className="w-full"
                  />
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{filters.minStock}</span>
                  <span className="text-muted-foreground">{filters.maxStock}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Min Stock</Label>
                    <Input
                      type="number"
                      value={filters.minStock}
                      onChange={(e) => updateFilter('minStock', Number(e.target.value))}
                      className="h-8"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Max Stock</Label>
                    <Input
                      type="number"
                      value={filters.maxStock}
                      onChange={(e) => updateFilter('maxStock', Number(e.target.value))}
                      className="h-8"
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              {/* Date Range */}
              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Date Range
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">From</Label>
                    <Input
                      type="date"
                      value={filters.dateFrom || ""}
                      onChange={(e) => updateFilter('dateFrom', e.target.value || undefined)}
                      className="h-8"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">To</Label>
                    <Input
                      type="date"
                      value={filters.dateTo || ""}
                      onChange={(e) => updateFilter('dateTo', e.target.value || undefined)}
                      className="h-8"
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              {/* Sort Options */}
              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Sort By
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  <Select value={filters.sortBy} onValueChange={(value) => updateFilter('sortBy', value)}>
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="name">Name</SelectItem>
                      <SelectItem value="sku">SKU</SelectItem>
                      <SelectItem value="price">Price</SelectItem>
                      <SelectItem value="stock">Stock</SelectItem>
                      <SelectItem value="created_at">Date Added</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filters.sortOrder} onValueChange={(value) => updateFilter('sortOrder', value as 'asc' | 'desc')}>
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asc">Ascending</SelectItem>
                      <SelectItem value="desc">Descending</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Separator />
              
              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleReset} className="flex-1">
                  Reset
                </Button>
                <Button onClick={handleSearch} className="flex-1">
                  Apply Filters
                </Button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )
}