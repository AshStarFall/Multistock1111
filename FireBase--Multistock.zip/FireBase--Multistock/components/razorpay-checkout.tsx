'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { useToast } from '@/hooks/use-toast'
import Script from 'next/script'
import { CreditCard, Loader2 } from 'lucide-react'

interface RazorpayCheckoutProps {
  amount: number
  orderId?: string
  customerName?: string
  customerEmail?: string
  customerPhone?: string
  orderDetails?: any
  onSuccess?: (response: any) => void
  onFailure?: (error: any) => void
  buttonText?: string
  buttonClassName?: string
}

declare global {
  interface Window {
    Razorpay: any
  }
}

export function RazorpayCheckout({
  amount,
  orderId,
  customerName,
  customerEmail,
  customerPhone,
  orderDetails,
  onSuccess,
  onFailure,
  buttonText = 'Pay Now',
  buttonClassName,
}: RazorpayCheckoutProps) {
  const [loading, setLoading] = useState(false)
  const [scriptLoaded, setScriptLoaded] = useState(false)
  const { toast } = useToast()

  const createOrder = async () => {
    try {
      const response = await fetch('/api/payments/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          currency: 'INR',
          receipt: orderId || `order_${Date.now()}`,
          notes: orderDetails || {},
        }),
      })

      const data = await response.json()
      
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to create order')
      }

      return data.order
    } catch (error: any) {
      throw error
    }
  }

  const verifyPayment = async (response: any) => {
    try {
      const verifyResponse = await fetch('/api/payments/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          razorpay_order_id: response.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_signature: response.razorpay_signature,
          orderData: {
            amount,
            currency: 'INR',
            email: customerEmail,
            name: customerName,
            phone: customerPhone,
            ...orderDetails,
          },
        }),
      })

      const data = await verifyResponse.json()
      
      if (!data.success || !data.verified) {
        throw new Error('Payment verification failed')
      }

      return data
    } catch (error: any) {
      throw error
    }
  }

  const handlePayment = async () => {
    if (!scriptLoaded) {
      toast({
        title: 'Error',
        description: 'Payment gateway is loading. Please try again.',
        variant: 'destructive',
      })
      return
    }

    try {
      setLoading(true)

      // Create order
      const order = await createOrder()

      // Razorpay options
      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || 'rzp_test_key',
        amount: order.amount,
        currency: order.currency,
        name: 'MultiStock',
        description: 'Payment for order',
        order_id: order.id,
        prefill: {
          name: customerName || '',
          email: customerEmail || '',
          contact: customerPhone || '',
        },
        theme: {
          color: '#6366f1',
        },
        handler: async function (response: any) {
          try {
            // Verify payment
            const verificationResult = await verifyPayment(response)
            
            toast({
              title: 'Payment Successful!',
              description: 'Your payment has been processed successfully.',
            })

            // Redirect to success page
            window.location.href = `/payment/success?payment_id=${response.razorpay_payment_id}&order_id=${response.razorpay_order_id}`
            
            if (onSuccess) {
              onSuccess(verificationResult)
            }
          } catch (error: any) {
            toast({
              title: 'Verification Failed',
              description: error.message || 'Payment verification failed',
              variant: 'destructive',
            })
            
            if (onFailure) {
              onFailure(error)
            }
          }
        },
        modal: {
          ondismiss: function() {
            setLoading(false)
            toast({
              title: 'Payment Cancelled',
              description: 'You cancelled the payment.',
              variant: 'destructive',
            })
          }
        }
      }

      const razorpay = new window.Razorpay(options)
      razorpay.open()
      
    } catch (error: any) {
      console.error('Payment error:', error)
      toast({
        title: 'Payment Failed',
        description: error.message || 'Failed to initiate payment',
        variant: 'destructive',
      })
      
      if (onFailure) {
        onFailure(error)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        onLoad={() => setScriptLoaded(true)}
        onError={() => {
          toast({
            title: 'Error',
            description: 'Failed to load payment gateway',
            variant: 'destructive',
          })
        }}
      />
      
      <Button
        onClick={handlePayment}
        disabled={loading || !scriptLoaded}
        className={buttonClassName || 'bg-gradient-to-r from-indigo-600 to-violet-600'}
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <CreditCard className="w-4 h-4 mr-2" />
            {buttonText} ₹{amount.toLocaleString()}
          </>
        )}
      </Button>
    </>
  )
}
