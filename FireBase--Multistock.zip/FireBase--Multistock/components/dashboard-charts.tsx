"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart, BarChartIcon, LineChart, PieChart } from "lucide-react"
import dynamic from 'next/dynamic'

// Dynamic imports for chart components with proper typing
const WeeklyMovementsChart = dynamic(
  () => import('@/components/charts/weekly-movements-chart').then(mod => mod.WeeklyMovementsChart),
  { 
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-80">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }
)

const TopSKUsChart = dynamic(
  () => import('@/components/charts/top-skus-chart').then(mod => mod.TopSkusChart),
  { 
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-80">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }
)

const StockDistributionChart = dynamic(
  () => import('@/components/charts/stock-distribution-chart').then(mod => mod.StockDistributionChart),
  { 
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-80">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }
)

const OrderStatusChart = dynamic(
  () => import('@/components/charts/order-status-chart').then(mod => mod.OrderStatusChart),
  { 
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-80">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }
)

// Mock data for charts - matching the expected interfaces
const mockWeeklyData = [
  { week: 'Mon', inbound: 400, outbound: 200 },
  { week: 'Tue', inbound: 300, outbound: 150 },
  { week: 'Wed', inbound: 200, outbound: 100 },
  { week: 'Thu', inbound: 278, outbound: 180 },
  { week: 'Fri', inbound: 189, outbound: 90 },
  { week: 'Sat', inbound: 239, outbound: 120 },
  { week: 'Sun', inbound: 349, outbound: 210 },
]

const mockTopSKUs = [
  { sku: 'Product A', qty: 400 },
  { sku: 'Product B', qty: 300 },
  { sku: 'Product C', qty: 200 },
  { sku: 'Product D', qty: 278 },
  { sku: 'Product E', qty: 189 },
]

const mockStockDistribution = [
  { name: 'Warehouse 1', value: 400 },
  { name: 'Warehouse 2', value: 300 },
  { name: 'Warehouse 3', value: 200 },
  { name: 'Warehouse 4', value: 278 },
  { name: 'Warehouse 5', value: 189 },
]

const mockOrderStatus = [
  { status: 'Pending', count: 12 },
  { status: 'Processing', count: 8 },
  { status: 'Shipped', count: 15 },
  { status: 'Delivered', count: 22 },
  { status: 'Cancelled', count: 3 },
]

export function DashboardCharts() {
  const [activeChart, setActiveChart] = useState<'weekly' | 'top' | 'stock' | 'order'>('weekly')
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  if (!isClient) {
    return (
      <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center">
            <BarChartIcon className="w-5 h-5 mr-2 text-indigo-600" />
            Analytics Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2 mb-6">
            <Button 
              variant="default" 
              size="sm"
            >
              <BarChart className="w-4 h-4 mr-2" />
              Weekly
            </Button>
            <Button 
              variant="outline" 
              size="sm"
            >
              <LineChart className="w-4 h-4 mr-2" />
              Top SKUs
            </Button>
            <Button 
              variant="outline" 
              size="sm"
            >
              <PieChart className="w-4 h-4 mr-2" />
              Stock
            </Button>
            <Button 
              variant="outline" 
              size="sm"
            >
              <PieChart className="w-4 h-4 mr-2" />
              Orders
            </Button>
          </div>
          <div className="flex items-center justify-center h-80">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center">
          <BarChartIcon className="w-5 h-5 mr-2 text-indigo-600" />
          Analytics Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-6">
          <Button 
            variant={activeChart === 'weekly' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setActiveChart('weekly')}
          >
            <BarChart className="w-4 h-4 mr-2" />
            Weekly
          </Button>
          <Button 
            variant={activeChart === 'top' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setActiveChart('top')}
          >
            <LineChart className="w-4 h-4 mr-2" />
            Top SKUs
          </Button>
          <Button 
            variant={activeChart === 'stock' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setActiveChart('stock')}
          >
            <PieChart className="w-4 h-4 mr-2" />
            Stock
          </Button>
          <Button 
            variant={activeChart === 'order' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setActiveChart('order')}
          >
            <PieChart className="w-4 h-4 mr-2" />
            Orders
          </Button>
        </div>
        
        <div className="h-80">
          {activeChart === 'weekly' && <WeeklyMovementsChart data={mockWeeklyData} />}
          {activeChart === 'top' && <TopSKUsChart data={mockTopSKUs} />}
          {activeChart === 'stock' && <StockDistributionChart data={mockStockDistribution} />}
          {activeChart === 'order' && <OrderStatusChart data={mockOrderStatus} />}
        </div>
      </CardContent>
    </Card>
  )
}