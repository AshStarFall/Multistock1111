import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { StockStatusBadge } from "./stock-status-badge"

type Row = {
  id: string
  sku: string
  name: string
  category: string
  warehouse: string
  qty: number
  reorderPoint: number
  unitCost: number
}

export function ProductTable({ rows, loading }: { rows: Row[]; loading?: boolean }) {
  if (loading) {
    return <div className="text-sm text-muted-foreground">Loading products...</div>
  }
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>SKU</TableHead>
          <TableHead>Name</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Warehouse</TableHead>
          <TableHead className="text-right">Qty</TableHead>
          <TableHead className="text-right">Status</TableHead>
          <TableHead className="text-right">Unit Cost</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((r) => {
          const status = r.qty <= r.reorderPoint ? "low" : r.qty < r.reorderPoint * 1.5 ? "warning" : "ok"
          return (
            <TableRow key={r.id}>
              <TableCell className="font-mono text-sm">{r.sku}</TableCell>
              <TableCell className="text-pretty">{r.name}</TableCell>
              <TableCell>{r.category}</TableCell>
              <TableCell>{r.warehouse}</TableCell>
              <TableCell className="text-right">{r.qty}</TableCell>
              <TableCell className="text-right">
                <StockStatusBadge status={status as any} />
              </TableCell>
              <TableCell className="text-right indian-accent">₹{r.unitCost.toFixed(2)}</TableCell>
            </TableRow>
          )
        })}
      </TableBody>
    </Table>
  )
}
