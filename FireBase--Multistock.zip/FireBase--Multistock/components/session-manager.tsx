"use client"

import { useEffect, useRef } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useRouter } from 'next/navigation'

export function SessionManager() {
  const { logout, isAuthenticated } = useAuth()
  const router = useRouter()
  const heartbeatInterval = useRef<NodeJS.Timeout | null>(null)
  const checkInterval = useRef<NodeJS.Timeout | null>(null)
  const lastHeartbeat = useRef<number>(Date.now())
  const loginTimeRef = useRef<number>(Date.now())

  useEffect(() => {
    if (!isAuthenticated) return

    // Update login time when user authenticates
    loginTimeRef.current = Date.now()

    // Heartbeat to track server connectivity
    const sendHeartbeat = async () => {
      // Don't run heartbeat in the first 10 seconds after login
      const timeSinceLogin = Date.now() - loginTimeRef.current
      if (timeSinceLogin < 10000) return

      try {
        const response = await fetch('/api/heartbeat', {
          method: 'GET',
          signal: AbortSignal.timeout(15000), // 15 second timeout
        })
        
        if (response.ok) {
          lastHeartbeat.current = Date.now()
        }
      } catch (error) {
        // Silently ignore heartbeat failures - don't show errors
      }
    }

    // Check if server has been down for more than 5 minutes
    const checkServerConnection = () => {
      const timeSinceLastHeartbeat = Date.now() - lastHeartbeat.current
      const timeSinceLogin = Date.now() - loginTimeRef.current
      
      // Don't check in first 30 seconds after login
      if (timeSinceLogin < 30000) return
      
      if (timeSinceLastHeartbeat > 300000) { // 5 minutes
        console.log('Server connection lost, logging out...')
        logout()
        router.push('/auth/login?session=expired')
      }
    }

    // Send heartbeat every 60 seconds (very relaxed)
    heartbeatInterval.current = setInterval(sendHeartbeat, 60000)
    
    // Check connection every 30 seconds
    checkInterval.current = setInterval(checkServerConnection, 30000)

    // Send initial heartbeat after 15 seconds (plenty of time for page to load)
    const initialTimeout = setTimeout(sendHeartbeat, 15000)

    // Cleanup on unmount
    return () => {
      clearTimeout(initialTimeout)
      if (heartbeatInterval.current) clearInterval(heartbeatInterval.current)
      if (checkInterval.current) clearInterval(checkInterval.current)
    }
  }, [isAuthenticated, logout, router])

  // Listen for page visibility changes
  useEffect(() => {
    if (!isAuthenticated) return

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        // Check server connection when user returns to tab
        fetch('/api/heartbeat', { method: 'GET' })
          .then(response => {
            if (response.ok) {
              lastHeartbeat.current = Date.now()
            } else {
              throw new Error('Server unreachable')
            }
          })
          .catch(() => {
            logout()
            router.push('/auth/login?session=expired')
          })
      }
    }

    document.addEventListener('visibilitychange', handleVisibilityChange)

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
    }
  }, [isAuthenticated, logout, router])

  // Handle browser close/tab close - logout
  useEffect(() => {
    if (!isAuthenticated) return

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      // Clear auth data on browser close
      if (typeof window !== 'undefined') {
        localStorage.removeItem('isAuthenticated')
        localStorage.removeItem('user')
        // Set flag for logout on next visit
        sessionStorage.setItem('shouldLogout', 'true')
      }
    }

    const handleUnload = () => {
      // Attempt to logout when page is closed
      if (typeof window !== 'undefined') {
        logout()
      }
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    window.addEventListener('unload', handleUnload)

    // Check if we should logout on page load
    if (typeof window !== 'undefined' && sessionStorage.getItem('shouldLogout') === 'true') {
      sessionStorage.removeItem('shouldLogout')
      logout()
      router.push('/auth/login?session=closed')
    }

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload)
      window.removeEventListener('unload', handleUnload)
    }
  }, [isAuthenticated, logout, router])

  // Listen for online/offline events
  useEffect(() => {
    if (!isAuthenticated) return

    const handleOffline = () => {
      console.log('Network offline detected')
    }

    const handleOnline = () => {
      console.log('Network back online, checking server...')
      // Verify server is accessible
      fetch('/api/heartbeat', { method: 'GET' })
        .then(response => {
          if (response.ok) {
            lastHeartbeat.current = Date.now()
          } else {
            throw new Error('Server unreachable')
          }
        })
        .catch(() => {
          logout()
          router.push('/auth/login?session=expired')
        })
    }

    window.addEventListener('offline', handleOffline)
    window.addEventListener('online', handleOnline)

    return () => {
      window.removeEventListener('offline', handleOffline)
      window.removeEventListener('online', handleOnline)
    }
  }, [isAuthenticated, logout, router])

  return null // This is a utility component with no UI
}
