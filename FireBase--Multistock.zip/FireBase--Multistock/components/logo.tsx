"use client"

import Link from "next/link"
import { Package } from "lucide-react"
import { cn } from "@/lib/utils"

interface LogoProps {
  variant?: 'default' | 'minimal' | 'text-only'
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
  showTagline?: boolean
  href?: string
}

export function Logo({ 
  variant = 'default', 
  size = 'md', 
  className = '',
  showTagline = true,
  href = '/'
}: LogoProps) {
  
  const sizeClasses = {
    sm: {
      icon: 'w-6 h-6',
      iconWrapper: 'w-8 h-8',
      text: 'text-base',
      tagline: 'text-[10px]'
    },
    md: {
      icon: 'w-6 h-6',
      iconWrapper: 'w-10 h-10',
      text: 'text-xl',
      tagline: 'text-xs'
    },
    lg: {
      icon: 'w-8 h-8',
      iconWrapper: 'w-12 h-12',
      text: 'text-2xl',
      tagline: 'text-sm'
    },
    xl: {
      icon: 'w-10 h-10',
      iconWrapper: 'w-16 h-16',
      text: 'text-3xl',
      tagline: 'text-base'
    }
  }

  const sizes = sizeClasses[size]

  const LogoContent = () => (
    <div className={cn("flex items-center gap-3 group", className)}>
      {variant !== 'text-only' && (
        <div className={cn(
          "relative bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all",
          sizes.iconWrapper
        )}>
          <Package className={cn("text-white", sizes.icon)} />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-slate-900"></div>
        </div>
      )}
      
      {variant !== 'minimal' && (
        <div className="flex flex-col">
          <span className={cn(
            "font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent",
            sizes.text
          )}>
            MultiStock
          </span>
          {showTagline && (
            <span className={cn(
              "text-muted-foreground -mt-1",
              sizes.tagline
            )}>
              Logistics Platform
            </span>
          )}
        </div>
      )}
    </div>
  )

  if (href) {
    return (
      <Link href={href}>
        <LogoContent />
      </Link>
    )
  }

  return <LogoContent />
}
