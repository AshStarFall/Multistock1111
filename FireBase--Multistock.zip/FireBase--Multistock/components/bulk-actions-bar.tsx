'use client'

import { useState } from 'react'
import { Trash2, Edit, Download, CheckSquare, Square } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import { ConfirmDialog } from '@/components/confirm-dialog'

interface BulkActionsBarProps<T = any> {
  selectedItems: T[]
  onClearSelection: () => void
  onBulkDelete?: (items: T[]) => Promise<void>
  onBulkEdit?: (items: T[]) => void
  onBulkExport?: (items: T[]) => void
  customActions?: {
    label: string
    icon?: React.ReactNode
    onClick: (items: T[]) => void | Promise<void>
    variant?: 'default' | 'destructive'
  }[]
}

export function BulkActionsBar<T = any>({
  selectedItems,
  onClearSelection,
  onBulkDelete,
  onBulkEdit,
  onBulkExport,
  customActions = [],
}: BulkActionsBarProps<T>) {
  const [deleting, setDeleting] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  if (selectedItems.length === 0) return null

  const handleBulkDelete = async () => {
    if (!onBulkDelete) return

    setDeleting(true)
    try {
      await onBulkDelete(selectedItems)
      toast.success(`${selectedItems.length} items deleted successfully`)
      onClearSelection()
    } catch (error) {
      toast.error('Failed to delete items')
      console.error(error)
    } finally {
      setDeleting(false)
      setShowDeleteConfirm(false)
    }
  }

  const handleAction = async (action: () => void | Promise<void>) => {
    try {
      await action()
    } catch (error) {
      toast.error('Action failed')
      console.error(error)
    }
  }

  return (
    <>
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-bottom-5">
        <div className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-2xl rounded-2xl px-6 py-4 flex items-center gap-4">
          <div className="flex items-center gap-3">
            <CheckSquare className="w-5 h-5" />
            <div>
              <p className="font-semibold text-sm">
                {selectedItems.length} {selectedItems.length === 1 ? 'item' : 'items'} selected
              </p>
              <Button
                variant="link"
                size="sm"
                onClick={onClearSelection}
                className="h-auto p-0 text-xs text-white/80 hover:text-white"
              >
                Clear selection
              </Button>
            </div>
          </div>

          <div className="h-8 w-px bg-white/20" />

          <div className="flex items-center gap-2">
            {onBulkEdit && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleAction(() => onBulkEdit(selectedItems))}
                className="gap-2 bg-white/10 hover:bg-white/20 text-white border-0"
              >
                <Edit className="w-4 h-4" />
                Edit
              </Button>
            )}

            {onBulkExport && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleAction(() => onBulkExport(selectedItems))}
                className="gap-2 bg-white/10 hover:bg-white/20 text-white border-0"
              >
                <Download className="w-4 h-4" />
                Export
              </Button>
            )}

            {customActions.map((action, idx) => (
              <Button
                key={idx}
                variant="secondary"
                size="sm"
                onClick={() => handleAction(() => action.onClick(selectedItems))}
                className="gap-2 bg-white/10 hover:bg-white/20 text-white border-0"
              >
                {action.icon}
                {action.label}
              </Button>
            ))}

            {onBulkDelete && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowDeleteConfirm(true)}
                disabled={deleting}
                className="gap-2 bg-red-500/90 hover:bg-red-600 text-white border-0"
              >
                <Trash2 className="w-4 h-4" />
                {deleting ? 'Deleting...' : 'Delete'}
              </Button>
            )}
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={showDeleteConfirm}
        onOpenChange={setShowDeleteConfirm}
        title="Delete Selected Items"
        description={`Are you sure you want to delete ${selectedItems.length} ${selectedItems.length === 1 ? 'item' : 'items'}? This action cannot be undone.`}
        onConfirm={handleBulkDelete}
        variant="destructive"
      />
    </>
  )
}

// Hook for managing bulk selection
export function useBulkSelection<T extends { id: string | number }>(items: T[]) {
  const [selectedIds, setSelectedIds] = useState<Set<string | number>>(new Set())

  const toggleItem = (id: string | number) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev)
      if (newSet.has(id)) {
        newSet.delete(id)
      } else {
        newSet.add(id)
      }
      return newSet
    })
  }

  const toggleAll = () => {
    if (selectedIds.size === items.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(items.map(item => item.id)))
    }
  }

  const clearSelection = () => {
    setSelectedIds(new Set())
  }

  const isSelected = (id: string | number) => selectedIds.has(id)

  const selectedItems = items.filter(item => selectedIds.has(item.id))

  const allSelected = items.length > 0 && selectedIds.size === items.length
  const someSelected = selectedIds.size > 0 && selectedIds.size < items.length

  return {
    selectedIds,
    selectedItems,
    toggleItem,
    toggleAll,
    clearSelection,
    isSelected,
    allSelected,
    someSelected,
  }
}

// Checkbox component for bulk selection
interface BulkSelectCheckboxProps {
  checked: boolean
  onCheckedChange: (checked: boolean) => void
  className?: string
}

export function BulkSelectCheckbox({
  checked,
  onCheckedChange,
  className = '',
}: BulkSelectCheckboxProps) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      onClick={(e) => {
        e.stopPropagation()
        onCheckedChange(!checked)
      }}
      className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
        checked
          ? 'bg-indigo-600 border-indigo-600'
          : 'border-slate-300 dark:border-slate-600 hover:border-indigo-500'
      } ${className}`}
    >
      {checked && <CheckSquare className="w-4 h-4 text-white" />}
    </button>
  )
}
