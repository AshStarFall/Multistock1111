"use client"

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Gavel, TrendingUp, Crown, Clock } from 'lucide-react'
import { type Bid, formatCurrency } from '@/lib/auctions'

interface BidHistoryProps {
  auctionId: string
  bids: Bid[]
  currentUserId?: string
}

export default function BidHistory({ auctionId, bids, currentUserId }: BidHistoryProps) {
  const [sortedBids, setSortedBids] = useState<Bid[]>([])

  useEffect(() => {
    // Sort bids by amount (highest first)
    const sorted = [...bids].sort((a, b) => b.amount - a.amount)
    setSortedBids(sorted)
  }, [bids])

  const getTimeAgo = (timestamp: Date): string => {
    const seconds = Math.floor((new Date().getTime() - new Date(timestamp).getTime()) / 1000)
    
    if (seconds < 60) return 'Just now'
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
    return `${Math.floor(seconds / 86400)}d ago`
  }

  if (sortedBids.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gavel className="w-5 h-5" />
            Bid History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Gavel className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No bids yet</p>
            <p className="text-sm">Be the first to place a bid!</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const highestBid = sortedBids[0]
  const uniqueBidders = new Set(sortedBids.map(b => b.bidderId)).size

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Gavel className="w-5 h-5" />
            Bid History
          </div>
          <div className="flex items-center gap-4 text-sm font-normal text-muted-foreground">
            <div className="flex items-center gap-1">
              <Gavel className="w-4 h-4" />
              <span>{sortedBids.length} bids</span>
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span>{uniqueBidders} bidders</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            <AnimatePresence>
              {sortedBids.map((bid, index) => (
                <motion.div
                  key={bid.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <div className={`p-4 rounded-lg border ${
                    bid.bidderId === currentUserId 
                      ? 'bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800'
                      : 'bg-slate-50 dark:bg-slate-900'
                  }`}>
                    <div className="flex items-start justify-between gap-4">
                      {/* Bidder Info */}
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        {index === 0 && (
                          <Crown className="w-5 h-5 text-yellow-500 flex-shrink-0" />
                        )}
                        <Avatar className="w-8 h-8 flex-shrink-0">
                          <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${bid.bidderName}`} />
                          <AvatarFallback>{bid.bidderName[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium truncate">
                              {bid.bidderId === currentUserId ? 'You' : bid.bidderName}
                            </span>
                            {index === 0 && (
                              <Badge className="bg-green-600 text-white text-xs">
                                Highest Bid
                              </Badge>
                            )}
                            {bid.isAutoBid && (
                              <Badge variant="outline" className="text-xs">
                                Auto-bid
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            <span>{getTimeAgo(bid.timestamp)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Bid Amount */}
                      <div className="text-right flex-shrink-0">
                        <div className={`text-lg font-bold ${
                          index === 0 
                            ? 'text-green-600 dark:text-green-400' 
                            : ''
                        }`}>
                          {formatCurrency(bid.amount)}
                        </div>
                        {bid.status && (
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              bid.status === 'winning' 
                                ? 'border-green-600 text-green-600'
                                : bid.status === 'outbid'
                                ? 'border-red-600 text-red-600'
                                : ''
                            }`}
                          >
                            {bid.status}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  {index < sortedBids.length - 1 && (
                    <Separator className="my-2" />
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
