"use client"

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { Upload, X, Clock, DollarSign, Zap, Info } from 'lucide-react'
import { calculateBidIncrement } from '@/lib/auctions'

interface BidDialogContentProps {
  auctionId: string
  currentPrice: number
  bidIncrement: number
  buyNowPrice?: number
  userHighestBid?: number
  onSubmit?: (amount: number, isAutoBid: boolean, maxAutoBid?: number) => void
  onBuyNow?: () => void
  onClose?: () => void
}

export default function BidDialogContent({
  auctionId,
  currentPrice,
  bidIncrement,
  buyNowPrice,
  userHighestBid,
  onSubmit,
  onBuyNow,
  onClose
}: BidDialogContentProps) {
  const { toast } = useToast()
  const minimumBid = currentPrice + bidIncrement
  const [bidAmount, setBidAmount] = useState(minimumBid)
  const [isAutoBid, setIsAutoBid] = useState(false)
  const [maxAutoBid, setMaxAutoBid] = useState(minimumBid + bidIncrement * 3)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    if (bidAmount < minimumBid) {
      toast({
        title: "Invalid bid",
        description: `Minimum bid is ₹${minimumBid.toLocaleString()}`,
        variant: "destructive"
      })
      return
    }

    if (isAutoBid && maxAutoBid < bidAmount) {
      toast({
        title: "Invalid auto-bid",
        description: "Maximum auto-bid must be greater than or equal to your bid",
        variant: "destructive"
      })
      return
    }

    setLoading(true)
    try {
      await onSubmit?.(bidAmount, isAutoBid, isAutoBid ? maxAutoBid : undefined)
      toast({
        title: "Bid placed successfully!",
        description: isAutoBid 
          ? `Your auto-bid is active up to ₹${maxAutoBid.toLocaleString()}`
          : `You bid ₹${bidAmount.toLocaleString()}`
      })
      onClose?.()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to place bid. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleBuyNow = async () => {
    if (!buyNowPrice) return
    
    setLoading(true)
    try {
      await onBuyNow?.()
      toast({
        title: "Purchase confirmed!",
        description: `You bought this item for ₹${buyNowPrice.toLocaleString()}`
      })
      onClose?.()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete purchase. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const quickBidOptions = [
    minimumBid,
    minimumBid + bidIncrement,
    minimumBid + bidIncrement * 2,
    minimumBid + bidIncrement * 3
  ]

  return (
    <div className="space-y-6">
      {/* Current Status */}
      <div className="bg-slate-100 dark:bg-slate-900 rounded-lg p-4 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Current Bid:</span>
          <span className="text-xl font-bold">₹{currentPrice.toLocaleString()}</span>
        </div>
        {userHighestBid && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Your Highest Bid:</span>
            <Badge className="bg-blue-600">₹{userHighestBid.toLocaleString()}</Badge>
          </div>
        )}
        <div className="flex items-center justify-between pt-2 border-t">
          <span className="text-sm text-muted-foreground">Minimum Bid:</span>
          <span className="font-semibold text-green-600">₹{minimumBid.toLocaleString()}</span>
        </div>
      </div>

      {/* Bid Amount Input */}
      <div className="space-y-3">
        <Label htmlFor="bidAmount">Your Bid Amount (₹)</Label>
        <Input
          id="bidAmount"
          type="number"
          value={bidAmount}
          onChange={(e) => setBidAmount(Number(e.target.value))}
          min={minimumBid}
          step={bidIncrement}
          className="text-lg font-semibold"
        />
        
        {/* Quick Bid Buttons */}
        <div className="grid grid-cols-4 gap-2">
          {quickBidOptions.map((amount) => (
            <Button
              key={amount}
              variant="outline"
              size="sm"
              onClick={() => setBidAmount(amount)}
              className={bidAmount === amount ? 'border-blue-600 bg-blue-50' : ''}
            >
              ₹{(amount / 1000).toFixed(0)}K
            </Button>
          ))}
        </div>
      </div>

      {/* Auto-Bid Section */}
      <div className="space-y-3 p-4 border rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-orange-600" />
            <Label htmlFor="autoBid" className="cursor-pointer">Enable Auto-Bid</Label>
          </div>
          <Switch
            id="autoBid"
            checked={isAutoBid}
            onCheckedChange={setIsAutoBid}
          />
        </div>

        <AnimatePresence>
          {isAutoBid && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3"
            >
              <div className="flex items-start gap-2 text-xs text-muted-foreground bg-blue-50 dark:bg-blue-950 p-3 rounded">
                <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <p>
                  Auto-bid will automatically place bids on your behalf up to your maximum amount.
                  You'll only pay ₹{bidIncrement.toLocaleString()} more than the next highest bid.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxAutoBid">Maximum Auto-Bid (₹)</Label>
                <Input
                  id="maxAutoBid"
                  type="number"
                  value={maxAutoBid}
                  onChange={(e) => setMaxAutoBid(Number(e.target.value))}
                  min={bidAmount}
                  step={bidIncrement}
                  className="font-semibold"
                />
              </div>

              <div className="text-sm text-muted-foreground">
                Your maximum bid: <span className="font-semibold">₹{maxAutoBid.toLocaleString()}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          className="w-full" 
          onClick={handleSubmit}
          disabled={loading || bidAmount < minimumBid}
        >
          <DollarSign className="w-4 h-4 mr-2" />
          {loading ? 'Placing Bid...' : `Place Bid - ₹${bidAmount.toLocaleString()}`}
        </Button>

        {buyNowPrice && (
          <Button 
            className="w-full bg-green-600 hover:bg-green-700" 
            onClick={handleBuyNow}
            disabled={loading}
          >
            <Zap className="w-4 h-4 mr-2" />
            Buy Now - ₹{buyNowPrice.toLocaleString()}
          </Button>
        )}

        <Button 
          variant="outline" 
          className="w-full" 
          onClick={onClose}
          disabled={loading}
        >
          Cancel
        </Button>
      </div>

      {/* Bid Increment Info */}
      <div className="text-xs text-center text-muted-foreground">
        Bid increment: ₹{bidIncrement.toLocaleString()}
      </div>
    </div>
  )
}
