"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import {
  Clock,
  Gavel,
  Eye,
  MapPin,
  ShieldCheck,
  Star,
  TrendingUp,
  Zap
} from 'lucide-react'
import {
  type Auction,
  getAuctionStatus,
  getAuctionStatusColor,
  getAuctionStatusLabel,
  getTimeRemaining,
  formatCurrency,
  isEndingSoon
} from '@/lib/auctions'

interface AuctionCardProps {
  auction: Auction
  onView?: (auction: Auction) => void
  onQuickBid?: (auctionId: string) => void
}

export default function AuctionCard({ auction, onView, onQuickBid }: AuctionCardProps) {
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemaining(auction.endTime))
  const [imageError, setImageError] = useState(false)
  
  const status = getAuctionStatus(auction)
  const endingSoon = isEndingSoon(auction.endTime)

  useEffect(() => {
    if (status === 'active' || status === 'ending_soon') {
      const interval = setInterval(() => {
        setTimeRemaining(getTimeRemaining(auction.endTime))
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [auction.endTime, status])

  const handleClick = () => {
    onView?.(auction)
  }

  const handleQuickBid = (e: React.MouseEvent) => {
    e.stopPropagation()
    onQuickBid?.(auction.id)
  }

  // Calculate progress percentage (time elapsed)
  const totalDuration = new Date(auction.endTime).getTime() - new Date(auction.startTime).getTime()
  const elapsed = Date.now() - new Date(auction.startTime).getTime()
  const progressPercent = Math.min(100, (elapsed / totalDuration) * 100)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow" onClick={handleClick}>
        {/* Image */}
        <div className="relative aspect-[4/3] bg-slate-100 dark:bg-slate-800">
          {auction.images[0] && !imageError ? (
            <img
              src={auction.images[0]}
              alt={auction.title}
              className="w-full h-full object-cover"
              onError={() => setImageError(true)}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Gavel className="w-12 h-12 text-muted-foreground opacity-50" />
            </div>
          )}
          
          {/* Status Badge */}
          <Badge className={`absolute top-2 left-2 ${getAuctionStatusColor(status)}`}>
            {getAuctionStatusLabel(status)}
          </Badge>

          {/* Ending Soon Badge */}
          {endingSoon && status === 'ending_soon' && (
            <Badge className="absolute top-2 right-2 bg-orange-500 text-white animate-pulse">
              <Clock className="w-3 h-3 mr-1" />
              Ending Soon!
            </Badge>
          )}

          {/* Buy Now Badge */}
          {auction.buyNowPrice && status === 'active' && (
            <Badge className="absolute bottom-2 right-2 bg-green-500 text-white">
              <Zap className="w-3 h-3 mr-1" />
              Buy Now
            </Badge>
          )}
        </div>

        <CardContent className="p-4 space-y-3">
          {/* Title */}
          <h3 className="font-semibold text-lg line-clamp-2">{auction.title}</h3>

          {/* Current Price */}
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground">Current Bid</div>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {formatCurrency(auction.currentPrice)}
              </span>
              {auction.buyNowPrice && (
                <div className="text-right">
                  <div className="text-xs text-muted-foreground">Buy Now</div>
                  <div className="text-sm font-semibold text-green-600">
                    {formatCurrency(auction.buyNowPrice)}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Time Remaining */}
          {(status === 'active' || status === 'ending_soon') && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Time Remaining:</span>
                <span className={`font-semibold ${
                  timeRemaining.total <= 5 * 60 * 1000 ? 'text-orange-600' : ''
                }`}>
                  {timeRemaining.days > 0 && `${timeRemaining.days}d `}
                  {timeRemaining.hours > 0 && `${timeRemaining.hours}h `}
                  {timeRemaining.minutes > 0 && `${timeRemaining.minutes}m `}
                  {timeRemaining.days === 0 && `${timeRemaining.seconds}s`}
                </span>
              </div>
              <Progress value={progressPercent} className="h-1" />
            </div>
          )}

          {/* Bids Info */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2 border-t">
            <div className="flex items-center gap-1">
              <Gavel className="w-3 h-3" />
              <span>{auction.totalBids} bids</span>
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>{auction.uniqueBidders} bidders</span>
            </div>
            <div className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              <span>{auction.views}</span>
            </div>
          </div>

          {/* Seller Info */}
          <div className="flex items-center gap-2 pt-2 border-t">
            <Avatar className="w-8 h-8">
              <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${auction.sellerName}`} />
              <AvatarFallback>{auction.sellerName[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-sm font-medium truncate">{auction.sellerName}</span>
                {auction.sellerVerified && (
                  <ShieldCheck className="w-3 h-3 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span>{auction.sellerRating.toFixed(1)}</span>
                <span className="mx-1">•</span>
                <MapPin className="w-3 h-3" />
                <span className="truncate">{auction.location}</span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          {(status === 'active' || status === 'ending_soon') && (
            <Button 
              className="w-full" 
              onClick={handleQuickBid}
              variant={endingSoon ? 'default' : 'outline'}
            >
              <Gavel className="w-4 h-4 mr-2" />
              Place Bid
            </Button>
          )}

          {status === 'ended' && (
            <Button className="w-full" variant="outline" disabled>
              Auction Ended
            </Button>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}
