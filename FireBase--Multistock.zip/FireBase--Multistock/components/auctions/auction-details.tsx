"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import {
  Clock,
  Gavel,
  Eye,
  Heart,
  Share2,
  MapPin,
  Truck,
  ShieldCheck,
  Star,
  TrendingUp,
  Zap,
  AlertCircle,
  CheckCircle
} from 'lucide-react'
import {
  type Auction,
  type Bid,
  getAuctionStatus,
  getAuctionStatusColor,
  getAuctionStatusLabel,
  getTimeRemaining,
  formatCurrency,
  getMinimumBid,
  isUserWinning
} from '@/lib/auctions'
import BidDialogContent from './bid-dialog-content'
import BidHistory from './bid-history'

interface AuctionDetailsProps {
  auction: Auction
  bids: Bid[]
  userId?: string
  onBid?: (amount: number, isAutoBid: boolean, maxAutoBid?: number) => void
  onBuyNow?: () => void
  onWatch?: () => void
}

export default function AuctionDetails({
  auction,
  bids,
  userId = 'temp-user-id',
  onBid,
  onBuyNow,
  onWatch
}: AuctionDetailsProps) {
  const { toast } = useToast()
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemaining(auction.endTime))
  const [showBidDialog, setShowBidDialog] = useState(false)
  const [isWatching, setIsWatching] = useState(false)
  const [selectedImage, setSelectedImage] = useState(0)
  
  const status = getAuctionStatus(auction)
  const minimumBid = getMinimumBid(auction)
  const userIsWinning = userId ? isUserWinning(auction, userId, bids) : false
  const userHighestBid = bids.filter(b => b.bidderId === userId).sort((a, b) => b.amount - a.amount)[0]

  useEffect(() => {
    if (status === 'active' || status === 'ending_soon') {
      const interval = setInterval(() => {
        setTimeRemaining(getTimeRemaining(auction.endTime))
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [auction.endTime, status])

  const handleWatch = () => {
    setIsWatching(!isWatching)
    onWatch?.()
    toast({
      title: isWatching ? "Removed from watchlist" : "Added to watchlist",
      description: isWatching 
        ? "You won't receive notifications for this auction"
        : "You'll receive notifications about this auction"
    })
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href)
    toast({
      title: "Link copied!",
      description: "Auction link copied to clipboard"
    })
  }

  const totalDuration = new Date(auction.endTime).getTime() - new Date(auction.startTime).getTime()
  const elapsed = Date.now() - new Date(auction.startTime).getTime()
  const progressPercent = Math.min(100, (elapsed / totalDuration) * 100)

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Images & Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Images */}
          <Card>
            <CardContent className="p-6">
              {/* Main Image */}
              <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden mb-4">
                <img
                  src={auction.images[selectedImage] || '/placeholder.png'}
                  alt={auction.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Thumbnail Gallery */}
              {auction.images.length > 1 && (
                <div className="grid grid-cols-6 gap-2">
                  {auction.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`aspect-square rounded-lg overflow-hidden border-2 ${
                        selectedImage === index 
                          ? 'border-blue-600' 
                          : 'border-transparent hover:border-slate-300'
                      }`}
                    >
                      <img
                        src={image}
                        alt={`${auction.title} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground whitespace-pre-wrap">{auction.description}</p>
              
              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Condition</div>
                  <div className="font-medium">{auction.condition}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Category</div>
                  <div className="font-medium">{auction.category}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Location</div>
                  <div className="font-medium flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {auction.location}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Shipping</div>
                  <div className="font-medium flex items-center gap-1">
                    {auction.shippingAvailable ? (
                      <>
                        <Truck className="w-4 h-4 text-green-600" />
                        Available
                        {auction.shippingCost && ` - ${formatCurrency(auction.shippingCost)}`}
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4 text-orange-600" />
                        Pickup Only
                      </>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Seller Info */}
          <Card>
            <CardHeader>
              <CardTitle>Seller Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${auction.sellerName}`} />
                  <AvatarFallback>{auction.sellerName[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg">{auction.sellerName}</h3>
                    {auction.sellerVerified && (
                      <Badge className="bg-blue-600">
                        <ShieldCheck className="w-3 h-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{auction.sellerRating.toFixed(1)} rating</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{auction.location}</span>
                    </div>
                  </div>
                </div>
                <Button variant="outline">Contact Seller</Button>
              </div>
            </CardContent>
          </Card>

          {/* Bid History */}
          <BidHistory auctionId={auction.id} bids={bids} currentUserId={userId} />
        </div>

        {/* Right Column - Bidding Panel */}
        <div className="space-y-4">
          {/* Status Card */}
          <Card>
            <CardContent className="p-6 space-y-4">
              {/* Status Badge */}
              <div className="flex items-center justify-between">
                <Badge className={getAuctionStatusColor(status)}>
                  {getAuctionStatusLabel(status)}
                </Badge>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" onClick={handleWatch}>
                    <Heart className={`w-4 h-4 ${isWatching ? 'fill-red-500 text-red-500' : ''}`} />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={handleShare}>
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Title */}
              <h1 className="text-2xl font-bold">{auction.title}</h1>

              {/* Current Price */}
              <div className="space-y-2">
                <div className="text-sm text-muted-foreground">Current Bid</div>
                <div className="text-4xl font-bold text-blue-600 dark:text-blue-400">
                  {formatCurrency(auction.currentPrice)}
                </div>
                {auction.buyNowPrice && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Buy Now Price:</span>
                    <span className="font-semibold text-green-600">
                      {formatCurrency(auction.buyNowPrice)}
                    </span>
                  </div>
                )}
              </div>

              {/* User Status */}
              {userHighestBid && (
                <div className={`p-3 rounded-lg ${
                  userIsWinning 
                    ? 'bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800'
                    : 'bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-800'
                }`}>
                  <div className="flex items-center gap-2 mb-1">
                    {userIsWinning ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="font-semibold text-green-600">You're winning!</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4 text-orange-600" />
                        <span className="font-semibold text-orange-600">You've been outbid</span>
                      </>
                    )}
                  </div>
                  <div className="text-sm">
                    Your bid: {formatCurrency(userHighestBid.amount)}
                  </div>
                </div>
              )}

              {/* Time Remaining */}
              {(status === 'active' || status === 'ending_soon') && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Time Remaining:
                    </span>
                    <span className={`font-semibold ${
                      timeRemaining.total <= 5 * 60 * 1000 ? 'text-orange-600' : ''
                    }`}>
                      {timeRemaining.days > 0 && `${timeRemaining.days}d `}
                      {String(timeRemaining.hours).padStart(2, '0')}:
                      {String(timeRemaining.minutes).padStart(2, '0')}:
                      {String(timeRemaining.seconds).padStart(2, '0')}
                    </span>
                  </div>
                  <Progress value={progressPercent} className="h-2" />
                  <div className="text-xs text-muted-foreground text-center">
                    Ends on {new Date(auction.endTime).toLocaleString()}
                  </div>
                </div>
              )}

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                <div className="text-center">
                  <div className="text-xl font-bold">{auction.totalBids}</div>
                  <div className="text-xs text-muted-foreground">Bids</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold">{auction.uniqueBidders}</div>
                  <div className="text-xs text-muted-foreground">Bidders</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold">{auction.watchers}</div>
                  <div className="text-xs text-muted-foreground">Watchers</div>
                </div>
              </div>

              {/* Action Buttons */}
              {(status === 'active' || status === 'ending_soon') && (
                <div className="space-y-2 pt-4">
                  <Button 
                    className="w-full" 
                    size="lg"
                    onClick={() => setShowBidDialog(true)}
                  >
                    <Gavel className="w-5 h-5 mr-2" />
                    Place Bid (Min: {formatCurrency(minimumBid)})
                  </Button>

                  {auction.buyNowPrice && (
                    <Button 
                      className="w-full bg-green-600 hover:bg-green-700" 
                      size="lg"
                      onClick={onBuyNow}
                    >
                      <Zap className="w-5 h-5 mr-2" />
                      Buy Now - {formatCurrency(auction.buyNowPrice)}
                    </Button>
                  )}
                </div>
              )}

              {status === 'ended' && (
                <div className="p-4 bg-slate-100 dark:bg-slate-900 rounded-lg text-center">
                  <p className="font-semibold">Auction Ended</p>
                  <p className="text-sm text-muted-foreground">
                    Final bid: {formatCurrency(auction.currentPrice)}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bid Dialog */}
      <Dialog open={showBidDialog} onOpenChange={setShowBidDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Place Your Bid</DialogTitle>
            <DialogDescription>
              Enter your bid amount for {auction.title}
            </DialogDescription>
          </DialogHeader>
          <BidDialogContent
            auctionId={auction.id}
            currentPrice={auction.currentPrice}
            bidIncrement={auction.bidIncrement}
            buyNowPrice={auction.buyNowPrice}
            userHighestBid={userHighestBid?.amount}
            onSubmit={onBid}
            onBuyNow={onBuyNow}
            onClose={() => setShowBidDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}
