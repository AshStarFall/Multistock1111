"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Code2,
  Palette,
  Database,
  Laptop,
  Mail,
  Linkedin,
  Github,
  Globe,
  Users,
  Filter,
  Sparkles,
  Zap,
  Shield,
  Rocket,
} from "lucide-react"
import { motion } from "framer-motion"

interface TeamMember {
  id: string
  name: string
  role: string
  department: "Frontend" | "Backend" | "Design" | "Full Stack" | "DevOps"
  avatar?: string
  badge: string
  badgeIcon: any
  bio: string
  skills: string[]
  email?: string
  linkedin?: string
  github?: string
  portfolio?: string
  color: string
}

const teamMembers: TeamMember[] = [
  {
    id: "1",
    name: "Ashish",
    role: "Full Stack Architect",
    department: "Full Stack",
    badge: "Code Wizard",
    badgeIcon: Sparkles,
    bio: "Master of both frontend and backend, building scalable enterprise solutions",
    skills: ["React", "Next.js", "Node.js", "PostgreSQL", "System Design"],
    email: "ashish@multistock.dev",
    linkedin: "#",
    github: "#",
    portfolio: "#",
    color: "from-purple-500 to-pink-600",
  },
  {
    id: "2",
    name: "Priya Sharma",
    role: "Frontend Lead",
    department: "Frontend",
    badge: "UX Ninja",
    badgeIcon: Palette,
    bio: "Crafting beautiful, responsive interfaces with pixel-perfect precision",
    skills: ["React", "TypeScript", "Tailwind CSS", "Framer Motion", "Figma"],
    email: "priya@multistock.dev",
    linkedin: "#",
    github: "#",
    color: "from-pink-500 to-rose-600",
  },
  {
    id: "3",
    name: "Rahul Verma",
    role: "Backend Engineer",
    department: "Backend",
    badge: "API Guru",
    badgeIcon: Database,
    bio: "Building robust APIs and optimizing database performance at scale",
    skills: ["Node.js", "Express", "PostgreSQL", "Redis", "Docker"],
    email: "rahul@multistock.dev",
    linkedin: "#",
    github: "#",
    color: "from-blue-500 to-cyan-600",
  },
  {
    id: "4",
    name: "Sneha Patel",
    role: "UI/UX Designer",
    department: "Design",
    badge: "Design Maven",
    badgeIcon: Palette,
    bio: "Creating delightful user experiences through research-driven design",
    skills: ["Figma", "Adobe XD", "User Research", "Prototyping", "Design Systems"],
    email: "sneha@multistock.dev",
    linkedin: "#",
    portfolio: "#",
    color: "from-violet-500 to-purple-600",
  },
  {
    id: "5",
    name: "Arjun Singh",
    role: "DevOps Engineer",
    department: "DevOps",
    badge: "Cloud Champion",
    badgeIcon: Rocket,
    bio: "Automating deployments and ensuring 99.9% uptime across all services",
    skills: ["AWS", "Docker", "Kubernetes", "CI/CD", "Terraform"],
    email: "arjun@multistock.dev",
    linkedin: "#",
    github: "#",
    color: "from-emerald-500 to-teal-600",
  },
  {
    id: "6",
    name: "Kavya Reddy",
    role: "Frontend Developer",
    department: "Frontend",
    badge: "Component Queen",
    badgeIcon: Code2,
    bio: "Building reusable component libraries and maintaining design consistency",
    skills: ["React", "TypeScript", "Storybook", "Jest", "Accessibility"],
    email: "kavya@multistock.dev",
    linkedin: "#",
    github: "#",
    color: "from-orange-500 to-amber-600",
  },
]

const departments = ["All", "Frontend", "Backend", "Design", "Full Stack", "DevOps"] as const

export function DevTeam() {
  const [selectedDepartment, setSelectedDepartment] = useState<typeof departments[number]>("All")

  const filteredMembers =
    selectedDepartment === "All"
      ? teamMembers
      : teamMembers.filter((member) => member.department === selectedDepartment)

  const getDepartmentIcon = (dept: string) => {
    switch (dept) {
      case "Frontend":
        return <Laptop className="w-4 h-4" />
      case "Backend":
        return <Database className="w-4 h-4" />
      case "Design":
        return <Palette className="w-4 h-4" />
      case "Full Stack":
        return <Code2 className="w-4 h-4" />
      case "DevOps":
        return <Rocket className="w-4 h-4" />
      default:
        return <Users className="w-4 h-4" />
    }
  }

  const getDepartmentColor = (dept: string) => {
    switch (dept) {
      case "Frontend":
        return "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400"
      case "Backend":
        return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
      case "Design":
        return "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
      case "Full Stack":
        return "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400"
      case "DevOps":
        return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
      default:
        return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400"
    }
  }

  return (
    <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center">
          <Users className="w-6 h-6 mr-2 text-indigo-600" />
          Meet the Development Team
        </CardTitle>
        <p className="text-sm text-muted-foreground mt-2">
          Talented individuals building the future of inventory management
        </p>
      </CardHeader>
      <CardContent>
        {/* Filter Buttons */}
        <div className="flex flex-wrap gap-2 mb-6 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mr-2">
            <Filter className="w-4 h-4" />
            <span className="font-medium">Filter by role:</span>
          </div>
          {departments.map((dept) => (
            <Button
              key={dept}
              variant={selectedDepartment === dept ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedDepartment(dept)}
              className="gap-2"
            >
              {dept !== "All" && getDepartmentIcon(dept)}
              {dept}
            </Button>
          ))}
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMembers.map((member, index) => {
            const BadgeIcon = member.badgeIcon
            return (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="group relative overflow-hidden border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
                  {/* Gradient background effect */}
                  <div className={`absolute top-0 left-0 right-0 h-24 bg-gradient-to-r ${member.color} opacity-10 group-hover:opacity-20 transition-opacity`} />
                  
                  <CardContent className="p-6 relative">
                    {/* Avatar Section */}
                    <div className="flex flex-col items-center mb-4">
                      <div className="relative mb-3">
                        <Avatar className="w-24 h-24 border-4 border-white dark:border-slate-900 shadow-xl ring-4 ring-slate-100 dark:ring-slate-800 group-hover:ring-indigo-200 dark:group-hover:ring-indigo-900 transition-all">
                          <AvatarImage src={member.avatar} alt={member.name} />
                          <AvatarFallback className={`text-2xl font-bold bg-gradient-to-br ${member.color} text-white`}>
                            {member.name.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        {/* Badge sticker */}
                        <div className={`absolute -bottom-2 -right-2 px-3 py-1 rounded-full bg-gradient-to-r ${member.color} text-white shadow-lg flex items-center gap-1 text-xs font-semibold animate-bounce`}>
                          <BadgeIcon className="w-3 h-3" />
                          <span>{member.badge}</span>
                        </div>
                      </div>

                      {/* Name and Role */}
                      <h3 className="font-bold text-lg text-center mb-1 group-hover:text-indigo-600 transition-colors">
                        {member.name}
                      </h3>
                      <p className="text-sm text-muted-foreground text-center mb-2">
                        {member.role}
                      </p>
                      <Badge className={`gap-1.5 ${getDepartmentColor(member.department)}`}>
                        {getDepartmentIcon(member.department)}
                        {member.department}
                      </Badge>
                    </div>

                    {/* Bio */}
                    <p className="text-sm text-center text-muted-foreground mb-4 min-h-[40px]">
                      {member.bio}
                    </p>

                    {/* Skills */}
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-1.5 justify-center">
                        {member.skills.slice(0, 3).map((skill, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                          >
                            {skill}
                          </Badge>
                        ))}
                        {member.skills.length > 3 && (
                          <Badge
                            variant="secondary"
                            className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                          >
                            +{member.skills.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Contact Buttons */}
                    <div className="flex gap-2 justify-center pt-4 border-t border-slate-200 dark:border-slate-800">
                      {member.email && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 hover:text-indigo-600"
                          title={`Email ${member.name}`}
                        >
                          <Mail className="w-4 h-4" />
                        </Button>
                      )}
                      {member.linkedin && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9 hover:bg-blue-100 dark:hover:bg-blue-900/30 hover:text-blue-600"
                          title={`LinkedIn profile`}
                        >
                          <Linkedin className="w-4 h-4" />
                        </Button>
                      )}
                      {member.github && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100"
                          title={`GitHub profile`}
                        >
                          <Github className="w-4 h-4" />
                        </Button>
                      )}
                      {member.portfolio && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9 hover:bg-violet-100 dark:hover:bg-violet-900/30 hover:text-violet-600"
                          title={`Portfolio website`}
                        >
                          <Globe className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>

        {/* Empty State */}
        {filteredMembers.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-16 h-16 mx-auto text-slate-300 dark:text-slate-700 mb-4" />
            <p className="text-slate-500 dark:text-slate-400">
              No team members found in this department
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
