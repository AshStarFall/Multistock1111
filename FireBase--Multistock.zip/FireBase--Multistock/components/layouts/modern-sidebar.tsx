"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import {
  Home,
  Package,
  ShoppingCart,
  Users,
  BarChart3,
  Warehouse,
  Store,
  Boxes,
  MapPin,
  Lock,
  Settings,
  FileText,
  CreditCard,
  TrendingUp,
  MessageSquare,
  Calendar,
  HelpCircle,
  ChevronRight,
  Layers,
  Archive,
  Tag
} from "lucide-react"

interface ModernSidebarProps {
  isOpen: boolean
  onClose?: () => void
}

const navigationGroups = [
  {
    title: "Main",
    items: [
      { name: "Dashboard", href: "/dashboard", icon: Home, badge: null },
      { name: "Analytics", href: "/analytics", icon: BarChart3, badge: null },
      { name: "Reports", href: "/reports", icon: FileText, badge: null },
    ]
  },
  {
    title: "Inventory",
    items: [
      { name: "Products", href: "/inventory/products", icon: Package, badge: null },
      { name: "Stock Movements", href: "/movements", icon: TrendingUp, badge: null },
      { name: "Adjustments", href: "/adjustments", icon: Layers, badge: null },
      { name: "Categories", href: "/inventory/categories", icon: Tag, badge: null },
    ]
  },
  {
    title: "Orders",
    items: [
      { name: "Sales Orders", href: "/sales-orders", icon: ShoppingCart, badge: "New" },
      { name: "Purchase Orders", href: "/purchase-orders", icon: Archive, badge: null },
      { name: "Suppliers", href: "/suppliers", icon: Users, badge: null },
    ]
  },
  {
    title: "Storage & Rentals",
    items: [
      { name: "Warehouses", href: "/warehouses", icon: Warehouse, badge: null },
      { name: "Storage", href: "/storage", icon: MapPin, badge: null },
      { name: "Lockers", href: "/lockers", icon: Lock, badge: "Hot" },
      { name: "Rentals", href: "/rentals", icon: Boxes, badge: null },
      { name: "Bookings", href: "/bookings", icon: Calendar, badge: null },
    ]
  },
  {
    title: "Marketplace",
    items: [
      { name: "Marketplace", href: "/marketplace", icon: Store, badge: null },
      { name: "Auctions", href: "/auctions", icon: TrendingUp, badge: null },
    ]
  },
  {
    title: "Management",
    items: [
      { name: "Payments", href: "/payments", icon: CreditCard, badge: null },
      { name: "Users", href: "/admin/users", icon: Users, badge: null },
      { name: "Expenses", href: "/expenses", icon: FileText, badge: null },
      { name: "Forum", href: "/forum", icon: MessageSquare, badge: null },
    ]
  },
  {
    title: "System",
    items: [
      { name: "Settings", href: "/settings", icon: Settings, badge: null },
      { name: "Support", href: "/support", icon: HelpCircle, badge: null },
    ]
  }
]

export function ModernSidebar({ isOpen, onClose }: ModernSidebarProps) {
  const pathname = usePathname()

  return (
    <>
      {/* Backdrop for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-16 left-0 bottom-0 w-[280px] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-40 transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Scrollable Navigation */}
        <ScrollArea className="h-full py-4">
          <nav className="px-3 space-y-6">
            {navigationGroups.map((group) => (
              <div key={group.title}>
                {/* Group Title */}
                <h3 className="px-3 mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  {group.title}
                </h3>

                {/* Group Items */}
                <div className="space-y-1">
                  {group.items.map((item) => {
                    const Icon = item.icon
                    const isActive = pathname === item.href || pathname?.startsWith(item.href + '/')
                    
                    return (
                      <Link 
                        key={item.href} 
                        href={item.href}
                        onClick={() => {
                          // Close sidebar on mobile when clicking a link
                          if (window.innerWidth < 1024) {
                            onClose?.()
                          }
                        }}
                      >
                        <Button
                          variant="ghost"
                          className={cn(
                            "w-full justify-start gap-3 h-10 px-3 font-normal transition-all",
                            isActive 
                              ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 shadow-md" 
                              : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                          )}
                        >
                          <Icon className={cn(
                            "w-5 h-5 shrink-0",
                            isActive ? "text-white" : "text-slate-500 dark:text-slate-400"
                          )} />
                          <span className="flex-1 text-left text-sm truncate">
                            {item.name}
                          </span>
                          {item.badge && (
                            <Badge 
                              variant="secondary" 
                              className={cn(
                                "text-[10px] h-5 px-1.5",
                                isActive 
                                  ? "bg-white/20 text-white border-0" 
                                  : item.badge === "Hot" 
                                    ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                                    : "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                              )}
                            >
                              {item.badge}
                            </Badge>
                          )}
                        </Button>
                      </Link>
                    )
                  })}
                </div>
              </div>
            ))}
          </nav>

          {/* Bottom Branding */}
          <div className="px-6 py-4 mt-6 border-t border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-500 dark:text-slate-400 text-center">
              MultiStock Platform
            </p>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 text-center mt-1">
              Version 2.0.0
            </p>
          </div>
        </ScrollArea>
      </aside>
    </>
  )
}
