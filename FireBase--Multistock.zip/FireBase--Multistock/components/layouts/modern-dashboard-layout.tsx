"use client"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { ModernAppBar } from "./modern-app-bar"
import { ModernSidebar } from "./modern-sidebar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { useAuth } from "@/lib/auth-context"
import { cn } from "@/lib/utils"

interface ModernDashboardLayoutProps {
  children: React.ReactNode
}

export function ModernDashboardLayout({ children }: ModernDashboardLayoutProps) {
  const pathname = usePathname()
  const { isAuthenticated } = useAuth()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  // Auto-collapse sidebar on mobile, auto-open on desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setSidebarOpen(false)
      } else {
        setSidebarOpen(true)
      }
    }

    // Initial check
    handleResize()

    // Listen for resize events
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  // Don't show dashboard layout on auth pages
  const isAuthPage = pathname?.startsWith('/auth') || pathname?.startsWith('/register')
  const shouldShowDashboardLayout = isAuthenticated && !isAuthPage

  // If not authenticated or on auth page, show minimal layout
  if (!shouldShowDashboardLayout) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        {children}
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950">
      {/* Fixed AppBar */}
      <ModernAppBar 
        onMenuClick={() => setSidebarOpen(!sidebarOpen)} 
        sidebarOpen={sidebarOpen}
      />

      {/* Main Container */}
      <div className="flex flex-1 pt-16">
        {/* Sidebar */}
        <ModernSidebar 
          isOpen={sidebarOpen} 
          onClose={() => setSidebarOpen(false)} 
        />

        {/* Main Content Area */}
        <main 
          className={cn(
            "flex-1 flex flex-col transition-all duration-300 ease-in-out",
            // Add left margin when sidebar is open on desktop
            sidebarOpen && "lg:ml-[280px]"
          )}
        >
          {/* Content Container with proper spacing */}
          <div className="flex-1 p-4 sm:p-6 lg:p-8">
            {/* Content wrapper with max-width for better readability */}
            <div className="max-w-[1600px] mx-auto">
              {children}
            </div>
          </div>

          {/* Footer - stays at bottom, inside main content flow */}
          <Footer />
        </main>
      </div>

      {/* Chatbot - Fixed position */}
      <Chatbot />
    </div>
  )
}