"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { Menu, Bell, Search, Moon, Sun, User, Settings, LogOut, UserCog, Shield, Home, ArrowLeft } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { NotificationCenter } from "@/components/notification-center"
import { useAuth } from "@/lib/auth-context"
import { useRouter, usePathname } from "next/navigation"
import Link from "next/link"
import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"

export function Topbar({ onMenu }: { onMenu: () => void }) {
  const { user, logout, getRole } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [showUserSwitcher, setShowUserSwitcher] = useState(false)
  const [users, setUsers] = useState<any[]>([])
  const [loadingUsers, setLoadingUsers] = useState(false)

  // Check if we're on the dashboard page
  const isDashboardPage = pathname === '/dashboard'

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const handleLogout = () => {
    logout()
    window.location.href = '/'
  }

  // Only SuperAdmin can switch users
  const isSuperAdmin = getRole() === 'SuperAdmin'

  const loadUsers = async () => {
    if (!isSuperAdmin) return
    setLoadingUsers(true)
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('name')
      
      if (!error && data) {
        // Filter to show only Admin, SubAdmin, SeniorStaff, Staff (not Customer or guest)
        const switchableUsers = data.filter(u => 
          u.id !== user?.id && 
          ['Admin', 'SubAdmin', 'SeniorStaff', 'Staff'].includes(u.role)
        )
        setUsers(switchableUsers)
      }
    } catch (err) {
      console.error('Error loading users:', err)
    } finally {
      setLoadingUsers(false)
    }
  }

  const handleSwitchUser = async (targetUser: any) => {
    if (!isSuperAdmin) return
    
    // Store original admin session
    localStorage.setItem('original_admin', JSON.stringify(user))
    localStorage.setItem('impersonating', 'true')
    localStorage.setItem('impersonated_user', JSON.stringify(targetUser))
    
    // Force reload to apply new user context
    window.location.reload()
  }

  const handleStopImpersonation = () => {
    localStorage.removeItem('impersonating')
    localStorage.removeItem('impersonated_user')
    localStorage.removeItem('original_admin')
    window.location.reload()
  }

  const isImpersonating = localStorage.getItem('impersonating') === 'true'

  const getUserInitials = () => {
    if (!user) return 'U'
    if (user.name) {
      const names = user.name.split(' ')
      return names.map(n => n[0]).join('').toUpperCase().slice(0, 2)
    }
    return user.email?.[0].toUpperCase() || 'U'
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'Admin':
        return 'bg-gradient-to-r from-purple-500 to-pink-600'
      case 'Manager':
        return 'bg-gradient-to-r from-blue-500 to-cyan-600'
      case 'Team Leader':
        return 'bg-gradient-to-r from-green-500 to-emerald-600'
      default:
        return 'bg-gradient-to-r from-slate-500 to-slate-600'
    }
  }

  return (
    <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg border-b border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="h-16 px-6 flex items-center justify-between gap-4">
        {/* Left Section */}
        <div className="flex items-center gap-4">
          <Tooltip>
            <TooltipTrigger asChild>
          <button
            onClick={onMenu}
            className="lg:hidden flex items-center justify-center w-10 h-10 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5 text-slate-700 dark:text-slate-300" />
          </button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <p>Open navigation menu</p>
            </TooltipContent>
          </Tooltip>

          {/* Back Button */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => router.back()}
                className="flex items-center justify-center w-10 h-10 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="Go back"
              >
                <ArrowLeft className="w-5 h-5 text-slate-700 dark:text-slate-300" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <p>Go back</p>
            </TooltipContent>
          </Tooltip>

          {/* Home Button - Only show if not on dashboard */}
          {!isDashboardPage && (
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/dashboard">
                  <button
                    className="flex items-center justify-center w-10 h-10 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    aria-label="Go to dashboard"
                  >
                    <Home className="w-5 h-5 text-slate-700 dark:text-slate-300" />
                  </button>
                </Link>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                <p>Go to Dashboard</p>
              </TooltipContent>
            </Tooltip>
          )}

          {/* Page Title */}
          <div className="hidden md:block">
            <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">
              Dashboard
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Welcome back to MultiStock</p>
          </div>
        </div>

        {/* Center - Search */}
        <div className="flex-1 max-w-2xl hidden md:block">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search products, orders, or customers..."
              className="w-full pl-12 pr-4 py-2.5 bg-slate-100 dark:bg-slate-800 border-0 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-3">
          {/* Mobile Search Toggle */}
          <Tooltip>
            <TooltipTrigger asChild>
          <button
            className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            onClick={() => setShowSearch(!showSearch)}
          >
            <Search className="w-5 h-5 text-slate-700 dark:text-slate-300" />
          </button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <p>Search (Ctrl+K)</p>
            </TooltipContent>
          </Tooltip>

          {/* Theme Toggle */}
          <ThemeToggle />

          {/* Notifications */}
          <div data-notification-trigger>
            <NotificationCenter />
          </div>

          {/* User Menu */}
          <div className="flex items-center gap-3 pl-3 border-l border-slate-200 dark:border-slate-800">
            <div className="hidden lg:block text-right">
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {user?.name || user?.email?.split('@')[0] || 'User'}
              </p>
              <div className="flex items-center justify-end gap-2">
                <Badge className={`text-xs px-2 py-0 ${getRoleBadgeColor(getRole() || 'User')} text-white border-0`}>
                  {getRole() || 'User'}
                </Badge>
              </div>
            </div>

            <div className="relative group">
              <button className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Avatar className="w-10 h-10 border-2 border-indigo-200 dark:border-indigo-800">
                  <AvatarFallback className="bg-gradient-to-br from-indigo-600 to-violet-600 text-white font-semibold">
                    {getUserInitials()}
                  </AvatarFallback>
                </Avatar>
              </button>

              {/* Dropdown Menu */}
              <div className="absolute right-0 top-full mt-2 w-72 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                {/* Impersonation Alert */}
                {isImpersonating && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800">
                    <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 text-xs mb-2">
                      <Shield className="w-4 h-4" />
                      <span className="font-semibold">Impersonating User</span>
                    </div>
                    <button
                      onClick={handleStopImpersonation}
                      className="w-full px-2 py-1 text-xs bg-amber-600 hover:bg-amber-700 text-white rounded transition-colors"
                    >
                      Stop Impersonation
                    </button>
                  </div>
                )}

                <div className="p-4 border-b border-slate-200 dark:border-slate-800">
                  <p className="font-semibold text-slate-900 dark:text-slate-100">
                    {user?.name || 'User'}
                  </p>
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    {user?.email || 'user@example.com'}
                  </p>
                  <Badge className={`mt-2 text-xs ${getRoleBadgeColor(getRole() || 'User')} text-white border-0`}>
                    {getRole() || 'User'}
                  </Badge>
                </div>

                <div className="p-2">
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
                    <User className="w-4 h-4" />
                    <span>My Profile</span>
                  </button>
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
                    <Settings className="w-4 h-4" />
                    <span>Settings</span>
                  </button>
                  
                  {/* Switch User Feature (Superadmin Only) */}
                  {isSuperAdmin && !isImpersonating && (
                    <div className="relative">
                      <button 
                        onClick={() => {
                          setShowUserSwitcher(!showUserSwitcher)
                          if (!showUserSwitcher) loadUsers()
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 text-sm text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                      >
                        <UserCog className="w-4 h-4" />
                        <span>Switch User</span>
                      </button>
                      
                      {showUserSwitcher && (
                        <div className="absolute right-0 top-full mt-1 w-64 max-h-64 overflow-y-auto bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg">
                          <div className="p-2 border-b border-slate-200 dark:border-slate-700">
                            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                              Select user to impersonate
                            </p>
                          </div>
                          {loadingUsers ? (
                            <div className="p-4 text-center text-sm text-slate-500">
                              Loading users...
                            </div>
                          ) : users.length === 0 ? (
                            <div className="p-4 text-center text-sm text-slate-500">
                              No users available
                            </div>
                          ) : (
                            <div className="p-2 space-y-1">
                              {users.map((u) => (
                                <button
                                  key={u.id}
                                  onClick={() => handleSwitchUser(u)}
                                  className="w-full flex items-center gap-3 px-3 py-2 text-sm text-left hover:bg-slate-100 dark:hover:bg-slate-700 rounded transition-colors"
                                >
                                  <Avatar className="w-6 h-6">
                                    <AvatarFallback className="text-xs bg-gradient-to-br from-indigo-600 to-violet-600 text-white">
                                      {u.name?.substring(0, 2).toUpperCase() || u.email?.substring(0, 2).toUpperCase()}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1 min-w-0">
                                    <p className="font-medium text-slate-900 dark:text-slate-100 truncate">
                                      {u.name || u.email}
                                    </p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                                      {u.role || 'User'}
                                    </p>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="p-2 border-t border-slate-200 dark:border-slate-800">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Search Bar */}
      {showSearch && (
        <div className="md:hidden px-4 pb-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-12 pr-4 py-2.5 bg-slate-100 dark:bg-slate-800 border-0 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      )}
    </header>
  )
}
