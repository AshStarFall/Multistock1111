"use client"

import { useMemo } from "react"
import { products as seedProducts, lowStock } from "@/lib/mock-data"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function GlobalAlerts() {
  const low = useMemo(() => seedProducts.filter((p) => lowStock(p)), [])
  if (low.length === 0) return null
  return (
    <Alert className="border-amber-300 bg-amber-50/80 dark:bg-amber-500/10">
      <AlertTitle className="font-medium">Low-stock alert</AlertTitle>
      <AlertDescription>
        {low.length} SKU{low.length > 1 ? "s are" : " is"} at or below reorder point. Review in Products.
      </AlertDescription>
    </Alert>
  )
}
