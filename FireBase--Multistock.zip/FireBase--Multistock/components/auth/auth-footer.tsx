"use client"

import Link from 'next/link'

interface AuthFooterProps {
  mode: 'login' | 'register'
}

export function AuthFooter({ mode }: AuthFooterProps) {
  if (mode === 'login') {
    return (
      <p className="text-center text-sm text-muted-foreground">
        Don't have an account?{' '}
        <Link href="/register" className="font-medium text-primary hover:underline">
          Sign up
        </Link>
      </p>
    )
  }

  return (
    <p className="text-center text-sm text-muted-foreground">
      Already have an account?{' '}
      <Link href="/auth/login" className="font-medium text-primary hover:underline">
        Sign in
      </Link>
    </p>
  )
}
