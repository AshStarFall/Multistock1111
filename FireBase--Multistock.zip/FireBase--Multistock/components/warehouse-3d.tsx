"use client"

import { useEffect, useRef } from "react"

export function Warehouse3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrame: number
    let rotation = 0

    const draw = () => {
      const width = canvas.width
      const height = canvas.height
      const centerX = width / 2
      const centerY = height / 2

      // Clear canvas
      ctx.clearRect(0, 0, width, height)

      // Apply rotation
      rotation += 0.005

      // Draw warehouse structure with 3D effect
      ctx.save()
      ctx.translate(centerX, centerY)

      // Base platform
      ctx.fillStyle = "rgba(99, 102, 241, 0.1)"
      ctx.fillRect(-100, 50, 200, 10)

      // Main warehouse body (isometric view)
      const warehouseWidth = 120
      const warehouseHeight = 100
      const warehouseDepth = 80

      // Front face
      ctx.fillStyle = "rgba(99, 102, 241, 0.8)"
      ctx.beginPath()
      ctx.moveTo(-warehouseWidth / 2, 0)
      ctx.lineTo(warehouseWidth / 2, 0)
      ctx.lineTo(warehouseWidth / 2, warehouseHeight)
      ctx.lineTo(-warehouseWidth / 2, warehouseHeight)
      ctx.closePath()
      ctx.fill()

      // Top face
      ctx.fillStyle = "rgba(139, 92, 246, 0.9)"
      ctx.beginPath()
      ctx.moveTo(-warehouseWidth / 2, 0)
      ctx.lineTo(0, -warehouseDepth / 2)
      ctx.lineTo(warehouseWidth / 2 + warehouseDepth / 2, -warehouseDepth / 2)
      ctx.lineTo(warehouseWidth / 2, 0)
      ctx.closePath()
      ctx.fill()

      // Right face
      ctx.fillStyle = "rgba(99, 102, 241, 0.6)"
      ctx.beginPath()
      ctx.moveTo(warehouseWidth / 2, 0)
      ctx.lineTo(warehouseWidth / 2 + warehouseDepth / 2, -warehouseDepth / 2)
      ctx.lineTo(warehouseWidth / 2 + warehouseDepth / 2, warehouseHeight - warehouseDepth / 2)
      ctx.lineTo(warehouseWidth / 2, warehouseHeight)
      ctx.closePath()
      ctx.fill()

      // Add warehouse details (windows/doors)
      ctx.fillStyle = "rgba(255, 255, 255, 0.3)"
      for (let i = 0; i < 3; i++) {
        ctx.fillRect(-50 + i * 30, 20 + Math.sin(rotation + i) * 2, 20, 25)
      }

      // Draw animated boxes/packages
      const boxes = [
        { x: -40, y: 70, size: 15, color: "rgba(236, 72, 153, 0.8)" },
        { x: 0, y: 75, size: 18, color: "rgba(6, 182, 212, 0.8)" },
        { x: 35, y: 72, size: 16, color: "rgba(251, 146, 60, 0.8)" },
      ]

      boxes.forEach((box, index) => {
        const bounce = Math.sin(rotation * 2 + index) * 3
        ctx.fillStyle = box.color
        ctx.fillRect(box.x, box.y + bounce, box.size, box.size)
        
        // Box shadow
        ctx.fillStyle = "rgba(0, 0, 0, 0.2)"
        ctx.fillRect(box.x + 2, box.y + box.size + bounce, box.size, 2)
      })

      // Draw floating particles
      for (let i = 0; i < 20; i++) {
        const angle = (rotation + i * 0.3) % (Math.PI * 2)
        const radius = 150 + Math.sin(rotation + i) * 20
        const particleX = Math.cos(angle) * radius
        const particleY = Math.sin(angle) * radius - 50
        const opacity = 0.3 + Math.sin(rotation * 2 + i) * 0.2
        
        ctx.fillStyle = `rgba(139, 92, 246, ${opacity})`
        ctx.beginPath()
        ctx.arc(particleX, particleY, 2, 0, Math.PI * 2)
        ctx.fill()
      }

      ctx.restore()

      animationFrame = requestAnimationFrame(draw)
    }

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth
      canvas.height = canvas.offsetHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    draw()

    return () => {
      cancelAnimationFrame(animationFrame)
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return (
    <div className="relative w-full h-64 md:h-80 rounded-xl overflow-hidden bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-slate-900 dark:to-slate-800">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ display: "block" }}
      />
      <div className="absolute bottom-4 left-4 right-4 text-center">
        <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400">
          Smart Warehouse Management System
        </p>
      </div>
    </div>
  )
}
