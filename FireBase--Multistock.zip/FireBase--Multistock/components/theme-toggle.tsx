"use client"

import { Button } from "@/components/ui/button"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { useEffect, useState } from "react"

export function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  if (!mounted) {
    // Avoid SSR/CSR mismatch
    return (
      <Button variant="outline" size="icon" aria-label="Toggle theme" disabled>
        <Moon className="h-4 w-4 opacity-50" />
      </Button>
    )
  }

  const isDark = (theme ?? resolvedTheme) === "dark"
  function toggle() {
    setTheme(isDark ? "light" : "dark")
  }

  return (
    <Button variant="outline" size="icon" onClick={toggle} aria-label="Toggle theme" aria-pressed={isDark}>
      {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </Button>
  )
}
