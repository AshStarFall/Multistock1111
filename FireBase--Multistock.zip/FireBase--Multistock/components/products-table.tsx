"use client"

import type React from "react"

import { useMemo, useState } from "react"
import type { Product } from "@/lib/types"
import { warehouses, totalOnHand, lowStock } from "@/lib/mock-data"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Upload } from "lucide-react"

function toCSV(rows: Product[]) {
  const header = [
    "id",
    "sku",
    "name",
    "category",
    "unit",
    "cost",
    "price",
    "active",
    "reorderPoint",
    "updatedAt",
    ...warehouses.map((w) => `stock_${w.id}`),
  ]
  const lines = rows.map((p) => {
    const base = [
      p.id,
      p.sku,
      p.name,
      p.category ?? "",
      p.unit,
      p.cost,
      p.price,
      p.active,
      p.reorderPoint ?? "",
      p.updatedAt,
    ]
    const stocks = warehouses.map((w) => p.stockByWarehouse[w.id] ?? 0)
    return base.concat(stocks).join(",")
  })
  return [header.join(","), ...lines].join("\n")
}

function download(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function simpleParseCSV(text: string) {
  // minimal CSV parser for demo (no quotes/escapes)
  return text
    .trim()
    .split("\n")
    .map((row) => row.split(",").map((c) => c.trim()))
}

export function ProductsTable({
  rows,
  onImport,
}: {
  rows: Product[]
  onImport: (rows: Product[]) => void
}) {
  const [q, setQ] = useState("")
  const [selectedWh, setSelectedWh] = useState<string | "all">("all")
  const [transferOpen, setTransferOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [fromWh, setFromWh] = useState<string>(warehouses[0]?.id ?? "")
  const [toWh, setToWh] = useState<string>(warehouses[1]?.id ?? "")
  const [qty, setQty] = useState<number>(0)

  const filtered = useMemo(() => {
    return rows.filter((p) => {
      const matchesQ = [p.name, p.sku, p.category ?? ""].some((v) => v.toLowerCase().includes(q.toLowerCase()))
      const whOk = selectedWh === "all" ? true : (p.stockByWarehouse[selectedWh] ?? 0) > 0
      return matchesQ && whOk
    })
  }, [rows, q, selectedWh])

  function handleExport() {
    download("products.csv", toCSV(filtered))
  }

  async function handleImportFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    const text = await file.text()
    const [header, ...data] = simpleParseCSV(text)
    if (!header) return
    const whIds = warehouses.map((w) => w.id)

    const imported: Product[] = data.map((cols) => {
      const obj: Record<string, string> = {}
      header.forEach((h, i) => (obj[h] = cols[i]))
      const stockByWarehouse: Record<string, number> = {}
      whIds.forEach((wid) => {
        const key = `stock_${wid}`
        stockByWarehouse[wid] = Number(obj[key] ?? 0)
      })
      return {
        id: obj.id || crypto.randomUUID(),
        sku: obj.sku,
        name: obj.name,
        category: obj.category || undefined,
        unit: obj.unit || "ea",
        cost: Number(obj.cost ?? 0),
        price: Number(obj.price ?? 0),
        stockByWarehouse,
        reorderPoint: obj.reorderPoint ? Number(obj.reorderPoint) : undefined,
        supplierId: undefined,
        active: String(obj.active).toLowerCase() !== "false",
        updatedAt: new Date().toISOString(),
      }
    })
    onImport(imported)
    e.currentTarget.value = ""
  }

  const lowCount = filtered.filter((p) => lowStock(p)).length

  function applyTransfer() {
    if (!selectedProduct) return
    if (!fromWh || !toWh || fromWh === toWh || qty <= 0) return
    const available = selectedProduct.stockByWarehouse[fromWh] ?? 0
    if (qty > available) return
    const nextRows = rows.map((p) => {
      if (p.id !== selectedProduct.id) return p
      const nextStock = { ...p.stockByWarehouse }
      nextStock[fromWh] = (nextStock[fromWh] ?? 0) - qty
      nextStock[toWh] = (nextStock[toWh] ?? 0) + qty
      return { ...p, stockByWarehouse: nextStock, updatedAt: new Date().toISOString() }
    })
    onImport(nextRows)
    setTransferOpen(false)
  }

  return (
    <div className="space-y-3">
      <div
        role="region"
        aria-label="Product toolbar"
        className="flex flex-col md:flex-row gap-2 items-stretch md:items-center justify-between"
      >
        <div className="flex gap-2 items-center">
          <Input
            placeholder="Search by name, SKU, category"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-64"
          />
          <select
            aria-label="Filter by warehouse"
            className="border rounded-md text-sm h-9 px-2 bg-background"
            value={selectedWh}
            onChange={(e) => setSelectedWh(e.target.value as any)}
          >
            <option value="all">All Warehouses</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4 mr-1" aria-hidden="true" /> Export CSV
          </Button>
          <label className="inline-flex items-center">
            <input type="file" accept=".csv" onChange={handleImportFile} className="hidden" />
            <Button variant="secondary">
              <Upload className="h-4 w-4 mr-1" aria-hidden="true" /> Import CSV
            </Button>
          </label>
        </div>
      </div>

      {lowCount > 0 && (
        <div className="rounded-md border bg-amber-50 text-foreground p-3 text-sm">
          <span className="font-medium">Heads up:</span> {lowCount} product{lowCount > 1 ? "s" : ""} at or below reorder
          point.
        </div>
      )}

      <div className="overflow-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left p-2">SKU</th>
              <th className="text-left p-2">Name</th>
              <th className="text-left p-2">Unit</th>
              <th className="text-left p-2">On&nbsp;Hand</th>
              <th className="text-left p-2">Reorder</th>
              <th className="text-left p-2">Price</th>
              <th className="text-left p-2">Status</th>
              <th className="text-left p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => {
              const onHand = totalOnHand(p)
              const isLow = lowStock(p)
              return (
                <tr key={p.id} className="border-t">
                  <td className="p-2 font-medium">{p.sku}</td>
                  <td className="p-2">{p.name}</td>
                  <td className="p-2">{p.unit}</td>
                  <td className="p-2">{onHand}</td>
                  <td className="p-2">{p.reorderPoint ?? "-"}</td>
                  <td className="p-2">${p.price.toFixed(2)}</td>
                  <td className="p-2">
                    {isLow ? (
                      <Badge variant="destructive">Low</Badge>
                    ) : (
                      <Badge className="bg-primary text-primary-foreground">OK</Badge>
                    )}
                  </td>
                  <td className="p-2">
                    <button
                      className="underline"
                      onClick={() => {
                        setSelectedProduct(p)
                        setFromWh(warehouses[0]?.id ?? "")
                        setToWh(warehouses[1]?.id ?? "")
                        setQty(0)
                        setTransferOpen(true)
                      }}
                    >
                      Transfer
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <Dialog open={transferOpen} onOpenChange={setTransferOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transfer Stock</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <div className="space-y-3">
              <div className="text-sm">{selectedProduct.name}</div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 items-end">
                <div>
                  <label className="block text-xs mb-1">From</label>
                  <select
                    className="border rounded-md text-sm h-9 px-2 bg-background w-full"
                    value={fromWh}
                    onChange={(e) => setFromWh(e.target.value)}
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({selectedProduct.stockByWarehouse[w.id] ?? 0})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1">To</label>
                  <select
                    className="border rounded-md text-sm h-9 px-2 bg-background w-full"
                    value={toWh}
                    onChange={(e) => setToWh(e.target.value)}
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1">Quantity</label>
                  <input
                    type="number"
                    min={0}
                    className="border rounded-md text-sm h-9 px-2 bg-background w-full"
                    value={qty}
                    onChange={(e) => setQty(Number(e.target.value))}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="secondary" onClick={() => setTransferOpen(false)}>Cancel</Button>
                <Button onClick={applyTransfer} disabled={!fromWh || !toWh || fromWh === toWh || qty <= 0}>Transfer</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <p className="text-xs text-muted-foreground">
        Tip: Export to get a CSV template, edit in your spreadsheet, then import to bulk update rows.
      </p>
    </div>
  )
}
