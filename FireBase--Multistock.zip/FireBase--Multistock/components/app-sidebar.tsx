"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { Button } from "@/components/ui/button"
import {
  LayoutDashboard,
  Package,
  Warehouse,
  Users,
  Truck,
  ShoppingCart,
  Boxes,
  History,
  BarChart3,
  Settings,
  User,
  Shield,
  Mail,
  FolderOpen,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  LogOut,
  Bell,
  Search,
  Home,
  FileText,
  Plus,
  Store,
  MapPin,
  CreditCard,
  Ticket,
  MessageSquare,
  TrendingUp,
  Zap,
  Calendar,
  Tag,
  Gift,
  X,
  PanelLeft,
  PanelLeftClose,
} from "lucide-react"
import { LogoutButton } from "@/components/logout-button"

const mainNav = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, category: "main" },
  { href: "/inventory/products", label: "Inventory", icon: Package, category: "main" },
  { href: "/sales-orders", label: "Orders", icon: ShoppingCart, category: "main" },
  { href: "/warehouses", label: "Warehouses", icon: Warehouse, category: "main" },
  { href: "/suppliers", label: "Suppliers", icon: Users, category: "main" },
]

const operationsNav = [
  { href: "/rentals", label: "Rentals", icon: Truck, category: "operations" },
  { href: "/storage", label: "Storage", icon: Warehouse, category: "operations" },
  { href: "/lockers", label: "Lockers", icon: Boxes, category: "operations" },
  { href: "/marketplace", label: "Marketplace", icon: Store, category: "operations" },
  { href: "/bookings", label: "Bookings", icon: Calendar, category: "operations" },
]

const analyticsNav = [
  { href: "/reports", label: "Reports", icon: FileText, category: "analytics" },
  { href: "/analytics", label: "Analytics", icon: BarChart3, category: "analytics" },
  { href: "/movements", label: "Movements", icon: History, category: "analytics" },
  { href: "/trending", label: "Trending", icon: TrendingUp, category: "analytics" },
]

const adminNav = [
  { href: "/admin/products", label: "Products", icon: Package, category: "admin" },
  { href: "/admin/categories", label: "Categories", icon: FolderOpen, category: "admin" },
  { href: "/admin/role-access", label: "Users & Roles", icon: Shield, category: "admin" }, 
  { 
    title: "Web Pages",
    href: "/web-pages",
    icon: FileText,
    items: [
      {
        href: "/web-pages",
        label: "All Pages",
        icon: FileText,
      },
      {
        href: "/web-pages/create",
        label: "Create New",
        icon: Plus,
      },
    ],
  },
  { href: "/admin/email", label: "Email Templates", icon: Mail, category: "admin" },
  { href: "/admin/import", label: "Import Data", icon: Zap, category: "admin" },
]

const customerNav = [
  { href: "/marketplace", label: "Marketplace", icon: Store, category: "customer" },
  { href: "/rentals", label: "Rentals", icon: Truck, category: "customer" },
  { href: "/bookings", label: "My Bookings", icon: Calendar, category: "customer" },
  { href: "/payments", label: "Payments", icon: CreditCard, category: "customer" },
  { href: "/coupons", label: "Coupons", icon: Tag, category: "customer" },
  { href: "/referrals", label: "Referrals", icon: Gift, category: "customer" },
]

const supportNav = [
  { href: "/support", label: "Support", icon: MessageSquare, category: "support" },
  { href: "/forum", label: "Community Forum", icon: Users, category: "support" },
  { href: "/tickets", label: "My Tickets", icon: Ticket, category: "support" },
]

const settingsNav = [
  { href: "/profile", label: "Profile", icon: User, category: "settings" },
  { href: "/settings", label: "Settings", icon: Settings, category: "settings" },
  { href: "/settings/notifications", label: "Notifications", icon: Bell, category: "settings" },
  { href: "/settings/coupons", label: "Coupon Settings", icon: Tag, category: "settings" },
]

export function AppSidebar({
  open,
  onClose,
  collapsed: externalCollapsed = false,
  onToggleOpen,
  onToggleCollapse,
  userRole = "Staff",
}: {
  open: boolean
  onClose: () => void
  collapsed?: boolean
  onToggleOpen?: () => void
  onToggleCollapse?: () => void
  userRole?: string
}) {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = React.useState(externalCollapsed)
  const [searchQuery, setSearchQuery] = React.useState("")
  
  React.useEffect(() => {
    setCollapsed(externalCollapsed)
  }, [externalCollapsed])
  
  const [expandedSections, setExpandedSections] = React.useState<Record<string, boolean>>({
    main: true,
    admin: true,
    operations: false,
    analytics: false,
    customer: false,
    support: false,
    settings: false,
  })

  const toggleSection = React.useCallback((section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }, [])

  // Filter navigation items based on user role
  const getFilteredNavItems = React.useCallback(() => {
    switch (userRole) {
      case 'SuperAdmin':
      case 'Admin':
        return { mainNav, operationsNav, analyticsNav, adminNav, customerNav, supportNav, settingsNav }
      case 'Customer':
        return { mainNav: customerNav, operationsNav: [], analyticsNav: [], adminNav: [], customerNav: [], supportNav, settingsNav }
      case 'SubAdmin':
      case 'SeniorStaff':
      case 'Staff':
      default:
        return { mainNav, operationsNav, analyticsNav, adminNav: [], customerNav: [], supportNav, settingsNav }
    }
  }, [userRole])

  const { mainNav: filteredMainNav, operationsNav: filteredOperationsNav, analyticsNav: filteredAnalyticsNav, adminNav: filteredAdminNav, customerNav: filteredCustomerNav, supportNav: filteredSupportNav, settingsNav: filteredSettingsNav } = React.useMemo(() => getFilteredNavItems(), [getFilteredNavItems])

  const NavItem = React.memo(({ item, collapsed }: { item: any; collapsed: boolean }) => {
    const Icon = item.icon
    const active = pathname === item.href || pathname?.startsWith(item.href + "/")

    const navItemContent = (
      <Link
        href={item.href}
        onClick={onClose}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 border-l-4",
          "hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-700 dark:hover:text-indigo-300",
          active ? "border-indigo-600 bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-200 dark:shadow-indigo-900/50" : "border-transparent text-slate-700 dark:text-slate-300",
          collapsed && "justify-center px-2"
        )}
      >
        <Icon className={cn("w-5 h-5 shrink-0", active ? "text-white" : "")}/>
        {!collapsed && (
          <span className={cn("font-medium text-sm", active ? "text-white" : "")}> 
            {item.label}
          </span>
        )}
        {!collapsed && active && (
          <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />
        )}
      </Link>
    )

    if (collapsed) {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              {navItemContent}
            </TooltipTrigger>
            <TooltipContent side="right" className="ml-2">
              <p>{item.label}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )
    }

    return navItemContent
  })

  const NavSection = React.memo(({ title, items, collapsed, sectionKey }: { title: string; items: any[]; collapsed: boolean; sectionKey: string }) => {
    // Filter items based on search query
    const filteredItems = React.useMemo(() => 
      searchQuery 
        ? items.filter(item => 
            item.label?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.title?.toLowerCase().includes(searchQuery.toLowerCase())
          )
        : items
    , [items, searchQuery])

    // Don't render section if no items match search query
    if (searchQuery && filteredItems.length === 0) return null

    const isExpanded = expandedSections[sectionKey]
  
    return (
      <div className="mb-4">
        {!collapsed && (
          <button
            onClick={() => toggleSection(sectionKey)}
            className="w-full px-3 mb-2 flex items-center justify-between group hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg py-1.5 transition-colors"
          >
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {title}
            </p>
            {isExpanded ? (
              <ChevronUp className="w-3 h-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300" />
            ) : (
              <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300" />
            )}
          </button>
        )}
        {(collapsed || isExpanded) && (
          <ul className="space-y-1">
            {filteredItems.map((item) => (
              <li key={item.href || item.title}>
                {item.items ? (
                  // Handle nested items - only show parent in collapsed mode
                  <>
                    <NavItem item={{...item, label: item.title}} collapsed={collapsed} />
                    {!collapsed && isExpanded && (
                      <ul className="ml-6 mt-1 space-y-1">
                        {item.items.map((subItem: any) => (
                          <li key={subItem.href}>
                            <NavItem item={subItem} collapsed={collapsed} />
                          </li>
                        ))}
                      </ul>
                    )}
                  </>
                ) : (
                  // Regular item
                  <NavItem item={item} collapsed={collapsed} />
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    )
  })

  return (
    <TooltipProvider>
      <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-r-xl border-r border-slate-200 dark:border-slate-800">
        {/* Toggle Buttons */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-800 flex-shrink-0">
          <div className={cn("flex gap-2", collapsed && "justify-center")}>
            {/* Open/Close Toggle */}
            {onToggleOpen && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 hover:bg-slate-100 dark:hover:bg-slate-800"
                      onClick={onToggleOpen}
                    >
                      {open ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="ml-2">
                    <p>{open ? 'Close sidebar' : 'Open sidebar'}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {/* Expand/Collapse Toggle - Only show when sidebar is open */}
            {onToggleCollapse && open && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 hover:bg-slate-100 dark:hover:bg-slate-800"
                      onClick={onToggleCollapse}
                    >
                      {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="ml-2">
                    <p>{collapsed ? 'Expand sidebar' : 'Collapse sidebar'}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>

        {/* Search Section */}
        {!collapsed && (
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex-shrink-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search menu..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800 border-0 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Scrollable Navigation - Takes remaining space */}
  <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 space-y-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-transparent" style={{maxHeight: 'calc(100vh - 120px)'}}>
          {filteredMainNav.length > 0 && (
            <NavSection title="Overview" items={filteredMainNav} collapsed={collapsed} sectionKey="main" />
          )}
          {filteredAdminNav.length > 0 && (
            <NavSection title="Management" items={filteredAdminNav} collapsed={collapsed} sectionKey="admin" />
          )}
          {filteredOperationsNav.length > 0 && (
            <NavSection title="Operations" items={filteredOperationsNav} collapsed={collapsed} sectionKey="operations" />
          )}
          {filteredAnalyticsNav.length > 0 && (
            <NavSection title="Analytics" items={filteredAnalyticsNav} collapsed={collapsed} sectionKey="analytics" />
          )}
          {filteredCustomerNav.length > 0 && (
            <NavSection title="Customers" items={filteredCustomerNav} collapsed={collapsed} sectionKey="customer" />
          )}
          {filteredSupportNav.length > 0 && (
            <NavSection title="Support" items={filteredSupportNav} collapsed={collapsed} sectionKey="support" />
          )}
          {filteredSettingsNav.length > 0 && (
            <NavSection title="Settings" items={filteredSettingsNav} collapsed={collapsed} sectionKey="settings" />
          )}
        </div>

        {/* Footer - Logout Button */}
        <div className={cn(
          "p-4 border-t border-slate-200 dark:border-slate-800 flex-shrink-0",
          collapsed && "px-2"
        )}>
          <LogoutButton collapsed={collapsed} />
        </div>
      </div>
    </TooltipProvider>
  )
}