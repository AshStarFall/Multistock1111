"use client"

import type React from "react"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { warehouses as seedWarehouses } from "@/lib/mock-data"

type ProductMinimal = {
  id: string
  sku: string
  name: string
  unit: string
  cost: number
  price: number
  category?: string
  reorderPoint?: number
  active: boolean
  supplierId?: string
  imageUrl?: string
  stockByWarehouse: Record<string, number>
  updatedAt: string
}

export function AddProductDialog({
  trigger,
  onAdded,
}: {
  trigger?: React.ReactNode
  onAdded: (row: ProductMinimal) => void
}) {
  const [open, setOpen] = useState(false)
  const [sku, setSku] = useState("")
  const [name, setName] = useState("")
  const [price, setPrice] = useState<number>(0)
  const [reorderPoint, setReorderPoint] = useState<number>(0)
  const [imageUrl, setImageUrl] = useState<string>("")
  const [warehouseId, setWarehouseId] = useState<string>(seedWarehouses[0]?.id ?? "")
  const [stock, setStock] = useState<number>(0)

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!sku || !name) return
    const id = crypto.randomUUID()
    const stockByWarehouse: Record<string, number> = warehouseId ? { [warehouseId]: stock } : {}
    const row: ProductMinimal = {
      id,
      sku,
      name,
      unit: "ea",
      cost: 0,
      price,
      imageUrl: imageUrl || undefined,
      active: true,
      reorderPoint: reorderPoint || undefined,
      stockByWarehouse,
      updatedAt: new Date().toISOString(),
    }
    onAdded(row)
    setOpen(false)
    setSku("")
    setName("")
    setPrice(0)
    setReorderPoint(0)
    setWarehouseId(seedWarehouses[0]?.id ?? "")
    setStock(0)
    setImageUrl("")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger ?? <Button>Add product</Button>}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add product</DialogTitle>
          <DialogDescription>Create a new product in your catalog.</DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="sku">SKU</Label>
            <Input id="sku" value={sku} onChange={(e) => setSku(e.target.value)} required />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="price">Price</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="rop">Reorder point</Label>
              <Input
                id="rop"
                type="number"
                value={reorderPoint}
                onChange={(e) => setReorderPoint(Number(e.target.value))}
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="img">Image URL</Label>
            <Input id="img" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="/path or https://..." />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="imgfile">Or upload image</Label>
            <Input
              id="imgfile"
              type="file"
              accept="image/*"
              onChange={async (e) => {
                const file = e.target.files?.[0]
                if (!file) return
                const reader = new FileReader()
                reader.onload = () => setImageUrl(String(reader.result))
                reader.readAsDataURL(file)
              }}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="wh">Initial warehouse</Label>
              <select
                id="wh"
                value={warehouseId}
                onChange={(e) => setWarehouseId(e.target.value)}
                className="border rounded-md text-sm h-9 px-2 bg-background"
              >
                {seedWarehouses.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="qty">Initial stock</Label>
              <Input id="qty" type="number" value={stock} onChange={(e) => setStock(Number(e.target.value))} />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit">Save</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
