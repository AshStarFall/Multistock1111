'use client'

import { useState } from 'react'
import { Download, FileText, FileSpreadsheet, Table } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'

interface ExportDialogProps {
  data: any[]
  exportFunction: (format: 'pdf' | 'excel' | 'csv', onProgress?: (progress: number) => void) => Promise<void>
  title?: string
  description?: string
}

export function ExportDialog({
  data,
  exportFunction,
  title = 'Export Data',
  description = 'Choose a format to export your data',
}: ExportDialogProps) {
  const [open, setOpen] = useState(false)
  const [format, setFormat] = useState<'pdf' | 'excel' | 'csv'>('pdf')
  const [exporting, setExporting] = useState(false)
  const [progress, setProgress] = useState(0)

  const handleExport = async () => {
    if (data.length === 0) {
      toast.error('No data to export')
      return
    }

    setExporting(true)
    setProgress(0)

    try {
      await exportFunction(format, (p) => setProgress(p))
      
      toast.success('Export completed!', {
        description: `Your data has been exported as ${format.toUpperCase()}`,
      })
      
      setTimeout(() => {
        setOpen(false)
        setProgress(0)
      }, 1000)
    } catch (error) {
      console.error('Export failed:', error)
      toast.error('Export failed', {
        description: 'An error occurred while exporting your data',
      })
    } finally {
      setExporting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-2 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <Download className="w-4 h-4" />
          Export
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-3">
            <Label>Export Format</Label>
            <RadioGroup
              value={format}
              onValueChange={(v) => setFormat(v as any)}
              disabled={exporting}
            >
              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer">
                <RadioGroupItem value="pdf" id="pdf" />
                <Label
                  htmlFor="pdf"
                  className="flex items-center gap-3 cursor-pointer flex-1"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-md bg-red-100 dark:bg-red-900/30">
                    <FileText className="w-5 h-5 text-red-600 dark:text-red-400" />
                  </div>
                  <div>
                    <p className="font-medium">PDF Document</p>
                    <p className="text-xs text-muted-foreground">
                      Best for printing and sharing
                    </p>
                  </div>
                </Label>
              </div>

              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer">
                <RadioGroupItem value="excel" id="excel" />
                <Label
                  htmlFor="excel"
                  className="flex items-center gap-3 cursor-pointer flex-1"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-md bg-green-100 dark:bg-green-900/30">
                    <FileSpreadsheet className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="font-medium">Excel Spreadsheet</p>
                    <p className="text-xs text-muted-foreground">
                      Best for data analysis
                    </p>
                  </div>
                </Label>
              </div>

              <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer">
                <RadioGroupItem value="csv" id="csv" />
                <Label
                  htmlFor="csv"
                  className="flex items-center gap-3 cursor-pointer flex-1"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-md bg-blue-100 dark:bg-blue-900/30">
                    <Table className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="font-medium">CSV File</p>
                    <p className="text-xs text-muted-foreground">
                      Best for importing to other systems
                    </p>
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {exporting && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Exporting...</span>
                <span className="font-medium">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          <div className="bg-slate-50 dark:bg-slate-900 p-3 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>{data.length}</strong> {data.length === 1 ? 'record' : 'records'} will be exported
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            disabled={exporting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleExport}
            disabled={exporting || data.length === 0}
            className="gap-2"
          >
            {exporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Exporting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Export {format.toUpperCase()}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
