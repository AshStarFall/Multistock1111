'use client';

import { Card } from '@/components/ui/card';
import { ExpenseSummary } from '@/lib/expenses';
import { TrendingUp, TrendingDown, DollarSign, PieChart } from 'lucide-react';
import { motion } from 'framer-motion';

export function ExpenseOverview({ summary }: { summary: ExpenseSummary }) {
  const lastMonthAmount = summary.monthlyTrend[summary.monthlyTrend.length - 2]?.amount || 0;
  const thisMonthAmount = summary.monthlyTrend[summary.monthlyTrend.length - 1]?.amount || 0;
  const monthlyChange = lastMonthAmount > 0 
    ? ((thisMonthAmount - lastMonthAmount) / lastMonthAmount) * 100 
    : 0;

  const stats = [
    {
      label: 'Total Expenses',
      value: `₹${summary.totalExpenses.toLocaleString()}`,
      icon: DollarSign,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50 dark:bg-blue-950/20',
    },
    {
      label: 'This Month',
      value: `₹${thisMonthAmount.toLocaleString()}`,
      icon: monthlyChange >= 0 ? TrendingUp : TrendingDown,
      color: monthlyChange >= 0 ? 'text-red-600' : 'text-green-600',
      bgColor: monthlyChange >= 0 
        ? 'bg-red-50 dark:bg-red-950/20' 
        : 'bg-green-50 dark:bg-green-950/20',
      change: `${monthlyChange >= 0 ? '+' : ''}${monthlyChange.toFixed(1)}%`,
    },
    {
      label: 'Categories',
      value: summary.categoryBreakdown.length.toString(),
      icon: PieChart,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50 dark:bg-purple-950/20',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  {stat.change && (
                    <p className={`text-sm mt-1 ${stat.color}`}>{stat.change} from last month</p>
                  )}
                </div>
                <div className={`p-3 rounded-full ${stat.bgColor}`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}
