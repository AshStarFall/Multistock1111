'use client';

import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Budget, calculateBudgetUtilization, getBudgetStatus, getCategoryInfo } from '@/lib/expenses';
import { AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

export function BudgetTracker({ budgets }: { budgets: Budget[] }) {
  if (budgets.length === 0) {
    return (
      <Card className="p-12 text-center">
        <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-xl font-semibold mb-2">No Budgets Set</h3>
        <p className="text-muted-foreground">
          Create budgets to track your spending limits
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {budgets.map((budget, index) => {
        const utilization = calculateBudgetUtilization(budget);
        const status = getBudgetStatus(utilization);
        const categoryInfo = getCategoryInfo(budget.category);

        const StatusIcon = 
          status.status === 'safe' ? CheckCircle :
          status.status === 'exceeded' ? AlertCircle :
          AlertTriangle;

        return (
          <motion.div
            key={budget.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${categoryInfo.color} bg-opacity-10`}>
                    <span className="text-2xl">{categoryInfo.icon}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">{categoryInfo.label} Budget</h3>
                    <p className="text-sm text-muted-foreground capitalize">
                      {budget.period}
                    </p>
                  </div>
                </div>
                <Badge className={status.color}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {status.message}
                </Badge>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Spent</span>
                  <span className="font-medium">₹{budget.spent.toLocaleString()}</span>
                </div>
                <Progress 
                  value={Math.min(utilization, 100)} 
                  className={`h-3 ${
                    status.status === 'safe' ? '[&>div]:bg-green-600' :
                    status.status === 'warning' ? '[&>div]:bg-yellow-600' :
                    status.status === 'danger' ? '[&>div]:bg-orange-600' :
                    '[&>div]:bg-red-600'
                  }`}
                />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Remaining</span>
                  <span className={`font-medium ${budget.remaining < 0 ? 'text-red-600' : ''}`}>
                    ₹{budget.remaining.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t">
                <span className="text-sm text-muted-foreground">Budget Limit</span>
                <span className="font-bold">₹{budget.limit.toLocaleString()}</span>
              </div>

              <div className="mt-2 text-center">
                <span className={`text-2xl font-bold ${
                  status.status === 'exceeded' ? 'text-red-600' : 'text-primary'
                }`}>
                  {utilization.toFixed(1)}%
                </span>
                <span className="text-sm text-muted-foreground ml-1">utilized</span>
              </div>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}
