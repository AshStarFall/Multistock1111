'use client';

import { Card } from '@/components/ui/card';
import { ExpenseSummary, getCategoryInfo } from '@/lib/expenses';
import { motion } from 'framer-motion';

export function ExpenseCharts({ summary }: { summary: ExpenseSummary }) {
  const maxMonthlyAmount = Math.max(...summary.monthlyTrend.map((m) => m.amount));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Monthly Trend Chart */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Monthly Expenses</h3>
        <div className="space-y-3">
          {summary.monthlyTrend.map((month, index) => (
            <div key={month.month}>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-muted-foreground">{month.month}</span>
                <span className="font-medium">₹{month.amount.toLocaleString()}</span>
              </div>
              <div className="h-8 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-blue-600 to-purple-600"
                  initial={{ width: 0 }}
                  animate={{ width: `${(month.amount / maxMonthlyAmount) * 100}%` }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Category Breakdown Chart */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Category Breakdown</h3>
        <div className="space-y-3">
          {summary.topCategories.map((cat, index) => {
            const categoryInfo = getCategoryInfo(cat.category);
            return (
              <div key={cat.category}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="flex items-center gap-2">
                    <span>{categoryInfo.icon}</span>
                    <span className="text-muted-foreground">{categoryInfo.label}</span>
                  </span>
                  <span className="font-medium">
                    ₹{cat.amount.toLocaleString()} ({cat.percentage.toFixed(1)}%)
                  </span>
                </div>
                <div className="h-8 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full ${categoryInfo.color}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${cat.percentage}%` }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Pie Chart Visualization */}
        <div className="mt-6">
          <div className="flex flex-wrap gap-2">
            {summary.categoryBreakdown.map((cat) => {
              const categoryInfo = getCategoryInfo(cat.category);
              return (
                <div
                  key={cat.category}
                  className="flex items-center gap-2 text-xs"
                >
                  <div className={`w-3 h-3 rounded-full ${categoryInfo.color}`} />
                  <span>{categoryInfo.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </Card>
    </div>
  );
}
