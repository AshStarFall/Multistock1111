"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { RatingStars } from '@/components/rating-stars'
import {
  ThumbsUp,
  ThumbsDown,
  ShieldCheck,
  ImageIcon,
  Flag,
  MoreVertical,
  Trash2,
  CheckCircle,
  XCircle
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { type Review } from '@/lib/reviews'
import { getTimeAgo } from '@/lib/reviews'
import { cn } from '@/lib/utils'

interface ReviewCardProps {
  review: Review
  showModeration?: boolean
  onHelpful?: (reviewId: string) => void
  onNotHelpful?: (reviewId: string) => void
  onReport?: (reviewId: string) => void
  onApprove?: (reviewId: string) => void
  onReject?: (reviewId: string) => void
  onDelete?: (reviewId: string) => void
}

export function ReviewCard({
  review,
  showModeration = false,
  onHelpful,
  onNotHelpful,
  onReport,
  onApprove,
  onReject,
  onDelete
}: ReviewCardProps) {
  const [showFullComment, setShowFullComment] = useState(false)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [userVote, setUserVote] = useState<'helpful' | 'not-helpful' | null>(null)

  const isLongComment = review.comment.length > 300
  const displayComment = showFullComment || !isLongComment
    ? review.comment
    : review.comment.substring(0, 300) + '...'

  const handleHelpful = () => {
    if (userVote === 'helpful') {
      setUserVote(null)
    } else {
      setUserVote('helpful')
      onHelpful?.(review.id)
    }
  }

  const handleNotHelpful = () => {
    if (userVote === 'not-helpful') {
      setUserVote(null)
    } else {
      setUserVote('not-helpful')
      onNotHelpful?.(review.id)
    }
  }

  return (
    <>
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-start gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={review.userAvatar} alt={review.userName} />
                <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white">
                  {review.userName.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-semibold text-slate-900 dark:text-slate-100">
                    {review.userName}
                  </h4>
                  {review.verifiedPurchase && (
                    <Badge variant="outline" className="text-xs">
                      <ShieldCheck className="w-3 h-3 mr-1 text-green-600" />
                      Verified Purchase
                    </Badge>
                  )}
                  {showModeration && (
                    <Badge
                      variant="outline"
                      className={cn(
                        review.status === 'approved' && 'border-green-600 text-green-600',
                        review.status === 'rejected' && 'border-red-600 text-red-600',
                        review.status === 'pending' && 'border-yellow-600 text-yellow-600'
                      )}
                    >
                      {review.status}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <RatingStars rating={review.rating} size="sm" />
                  <span className="text-xs text-muted-foreground">
                    {getTimeAgo(review.createdAt)}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {!showModeration && (
                  <DropdownMenuItem onClick={() => onReport?.(review.id)}>
                    <Flag className="w-4 h-4 mr-2" />
                    Report Review
                  </DropdownMenuItem>
                )}
                {showModeration && (
                  <>
                    {review.status !== 'approved' && (
                      <DropdownMenuItem onClick={() => onApprove?.(review.id)}>
                        <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                        Approve
                      </DropdownMenuItem>
                    )}
                    {review.status !== 'rejected' && (
                      <DropdownMenuItem onClick={() => onReject?.(review.id)}>
                        <XCircle className="w-4 h-4 mr-2 text-red-600" />
                        Reject
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => onDelete?.(review.id)} className="text-red-600">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Review Title */}
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">
            {review.title}
          </h3>

          {/* Review Comment */}
          <p className="text-slate-700 dark:text-slate-300 mb-4 whitespace-pre-line">
            {displayComment}
          </p>
          {isLongComment && (
            <Button
              variant="link"
              size="sm"
              onClick={() => setShowFullComment(!showFullComment)}
              className="p-0 h-auto"
            >
              {showFullComment ? 'Show less' : 'Read more'}
            </Button>
          )}

          {/* Review Images */}
          {review.images && review.images.length > 0 && (
            <div className="flex gap-2 mb-4">
              {review.images.map((image, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedImage(image)}
                  className="relative w-20 h-20 rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-700 hover:border-blue-500 transition-colors"
                >
                  <img
                    src={image}
                    alt={`Review ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </motion.button>
              ))}
            </div>
          )}

          {/* Helpful Actions */}
          <div className="flex items-center gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <span className="text-sm text-muted-foreground">Was this helpful?</span>
            <div className="flex items-center gap-2">
              <Button
                variant={userVote === 'helpful' ? 'default' : 'outline'}
                size="sm"
                onClick={handleHelpful}
                className="gap-1"
              >
                <ThumbsUp className="w-4 h-4" />
                <span>{review.helpful}</span>
              </Button>
              <Button
                variant={userVote === 'not-helpful' ? 'default' : 'outline'}
                size="sm"
                onClick={handleNotHelpful}
                className="gap-1"
              >
                <ThumbsDown className="w-4 h-4" />
                <span>{review.notHelpful}</span>
              </Button>
            </div>
          </div>

          {/* Moderation Note */}
          {showModeration && review.moderationNote && (
            <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                <span className="font-semibold">Moderation Note:</span> {review.moderationNote}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Image Modal */}
      {selectedImage && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSelectedImage(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
        >
          <motion.img
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            src={selectedImage}
            alt="Review"
            className="max-w-full max-h-full rounded-lg"
          />
        </motion.div>
      )}
    </>
  )
}
