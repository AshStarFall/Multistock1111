'use client'

import { Suspense, lazy, ComponentType } from 'react'
import { Skeleton } from '@/components/ui/skeleton'

interface LazyLoadProps {
  children: React.ReactNode
  fallback?: React.ReactNode
  height?: string
}

/**
 * Wrapper component for lazy loading with suspense
 */
export function LazyLoad({ children, fallback, height = '200px' }: LazyLoadProps) {
  const defaultFallback = (
    <div className="w-full animate-pulse" style={{ height }}>
      <Skeleton className="w-full h-full" />
    </div>
  )

  return (
    <Suspense fallback={fallback || defaultFallback}>
      {children}
    </Suspense>
  )
}

/**
 * Dynamic import wrapper with loading state
 */
export function createLazyComponent<P extends object>(
  importFunc: () => Promise<{ default: ComponentType<P> }>,
  fallback?: React.ReactNode
) {
  const LazyComponent = lazy(importFunc)

  return function LazyWrapper(props: P) {
    return (
      <Suspense fallback={fallback || <Skeleton className="w-full h-32" />}>
        <LazyComponent {...props} />
      </Suspense>
    )
  }
}
