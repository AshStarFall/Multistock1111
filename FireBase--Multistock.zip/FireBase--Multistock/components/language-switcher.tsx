"use client"

import { useState } from "react"
import { getLang, setLang, type Lang } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Globe, Check } from "lucide-react"

const languages = [
  { code: "en" as Lang, name: "English", flag: "🇺🇸" },
  { code: "hi" as Lang, name: "हिंदी", flag: "🇮🇳" },
  { code: "kn" as Lang, name: "ಕನ್ನಡ", flag: "🇮🇳" },
]

export function LanguageSwitcher() {
  const [currentLang, setCurrentLang] = useState<Lang>(getLang())

  const handleLanguageChange = (lang: Lang) => {
    setLang(lang)
    setCurrentLang(lang)
    // Reload the page to apply language changes
    window.location.reload()
  }

  const currentLanguage = languages.find(lang => lang.code === currentLang)

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Globe className="h-4 w-4" />
          <span className="hidden sm:inline">{currentLanguage?.flag}</span>
          <span className="hidden sm:inline">{currentLanguage?.name}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {languages.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => handleLanguageChange(lang.code)}
            className="flex items-center gap-2"
          >
            <span>{lang.flag}</span>
            <span>{lang.name}</span>
            {currentLang === lang.code && (
              <Check className="h-4 w-4 ml-auto" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
