"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { 
  MapPin, Phone, Mail, Facebook, Twitter, Linkedin, Instagram,
  Truck, Shield, Award, Users, Github, Package
} from "lucide-react"

const projectGuide = {
  name: "Ms. Nishmitha",
  role: "Project Guide",
  department: "Computer Science & Engineering",
  bio: "Department guide and mentor for the MultiStock project.",
  image: "/profile-photos/NishmithaMam.jpeg",
  fallback: "MN",
  skills: ["Project Management", "System Design", "Mentorship", "Research"]
}

const developers = [
  {
    name: "Ashish",
    role: "Lead Developer",
    bio: "Full-stack developer with expertise in React and Node.js.",
    image: "/profile-photos/Ashish.jpeg",
    fallback: "AS",
    skills: ["React", "Next.js", "TypeScript", "Node.js"]
  },
  {
    name: "Harshitha",
    role: "UI/UX Designer",
    bio: "Creative designer focused on user experience.",
    image: "/profile-photos/Harshitha.jpeg",
    fallback: "HA",
    skills: ["Figma", "UI/UX", "Prototyping"]
  },
  {
    name: "Avinash",
    role: "Backend Developer",
    bio: "Backend specialist with database expertise.",
    image: "/profile-photos/Avinash.jpg",
    fallback: "AV",
    skills: ["Python", "PostgreSQL", "APIs"]
  },
  {
    name: "Ashray",
    role: "DevOps Engineer",
    bio: "DevOps expert managing infrastructure.",
    image: "/profile-photos/Ashray.jpeg",
    fallback: "AR",
    skills: ["Docker", "CI/CD", "Cloud"]
  }
]

export function Footer() {
  const [selectedMember, setSelectedMember] = useState<typeof projectGuide | typeof developers[0] | null>(null)

  return (
    <>
      <footer className="bg-gradient-to-b from-background to-muted/30 border-t">
        <div className="container mx-auto px-4 py-12">
          {/* Project Guide Section - Moved to TOP for visibility */}
          <div className="mb-12 pb-12 border-b">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 px-6 py-3 rounded-full mb-6 shadow-lg">
                <Award className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
                <h3 className="font-bold text-xl text-indigo-600 dark:text-indigo-400">
                  Project Guide
                </h3>
              </div>
              
              <div className="inline-block cursor-pointer group" onClick={() => setSelectedMember(projectGuide)}>
                <div className="relative mb-6">
                  <div className="w-48 h-48 mx-auto rounded-full overflow-hidden border-4 border-white dark:border-slate-800 shadow-2xl ring-8 ring-indigo-500/30 transition-all group-hover:ring-indigo-500/60 group-hover:scale-105">
                    <Avatar className="w-full h-full">
                      <AvatarImage src={projectGuide.image} alt={projectGuide.name} className="object-cover" />
                      <AvatarFallback className="bg-gradient-to-br from-indigo-600 to-purple-600 text-white text-4xl font-bold">
                        {projectGuide.fallback}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-14 h-14 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full border-4 border-white dark:border-slate-800 shadow-lg flex items-center justify-center">
                    <Award className="w-7 h-7 text-white" />
                  </div>
                </div>
                
                <div>
                  <h4 className="text-3xl font-bold mb-2 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{projectGuide.name}</h4>
                  <p className="text-xl text-indigo-600 dark:text-indigo-400 font-semibold mb-3">{projectGuide.role}</p>
                  <Badge className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white mb-3 px-4 py-1 text-sm shadow-lg">Department Guide</Badge>
                  <p className="text-base text-muted-foreground font-medium">{projectGuide.department}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Footer Links */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Package className="w-7 h-7 text-white" />
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  MultiStock
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                Comprehensive inventory management platform
              </p>
              <div className="flex gap-3">
                <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Facebook className="h-4 w-4" />
                </a>
                <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Twitter className="h-4 w-4" />
                </a>
                <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Linkedin className="h-4 w-4" />
                </a>
                <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Instagram className="h-4 w-4" />
                </a>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">Dashboard</a></li>
                <li><a href="/inventory/products" className="text-muted-foreground hover:text-primary transition-colors">Inventory</a></li>
                <li><a href="/warehouses" className="text-muted-foreground hover:text-primary transition-colors">Warehouses</a></li>
                <li><a href="/marketplace" className="text-muted-foreground hover:text-primary transition-colors">Marketplace</a></li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Services</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Truck className="h-4 w-4" />
                  <span>Logistics</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Shield className="h-4 w-4" />
                  <span>Secure Storage</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Award className="h-4 w-4" />
                  <span>Quality Service</span>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Contact</h3>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4 mt-0.5" />
                  <span>Main Office</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span>Phone</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span>Email</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t pt-12">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-blue-50 dark:bg-blue-950 px-4 py-2 rounded-full mb-6">
                <Users className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-lg text-blue-600 dark:text-blue-400">Development Team</h3>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 max-w-6xl mx-auto px-4">
              {developers.map((dev) => (
                <div key={dev.name} className="text-center cursor-pointer group" onClick={() => setSelectedMember(dev)}>
                  <div className="relative mb-6 inline-block">
                    <div className="w-36 h-36 rounded-full overflow-hidden border-4 border-background shadow-xl ring-4 ring-primary/20 transition-all group-hover:ring-primary/50 group-hover:scale-105">
                      <Avatar className="w-full h-full">
                        <AvatarImage src={dev.image} alt={dev.name} className="object-cover" />
                        <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white text-2xl font-bold">
                          {dev.fallback}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-10 h-10 bg-green-500 rounded-full border-4 border-background shadow-lg"></div>
                  </div>
                  
                  <div>
                    <h4 className="font-bold text-lg mb-1">{dev.name}</h4>
                    <p className="text-sm text-primary font-medium">{dev.role}</p>
                  </div>
                </div>
              ))}
            </div>

            <p className="text-center text-sm text-muted-foreground mt-12">Built with ❤️ by our team • August 2025</p>
          </div>
        </div>

        <div className="border-t bg-muted/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
              <span>© 2025 MultiStock • Student Project</span>
              <div className="flex gap-4">
                <a href="/privacy" className="hover:text-primary transition-colors">Privacy</a>
                <a href="/terms" className="hover:text-primary transition-colors">Terms</a>
                <a href="/support" className="hover:text-primary transition-colors">Support</a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <Dialog open={!!selectedMember} onOpenChange={() => setSelectedMember(null)}>
        <DialogContent className="sm:max-w-[500px]">
          {selectedMember && (
            <>
              <DialogHeader>
                <div className="flex flex-col items-center text-center space-y-4">
                  <Avatar className="h-32 w-32 border-4 border-primary shadow-2xl">
                    <AvatarImage src={selectedMember.image} alt={selectedMember.name} />
                    <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white text-3xl font-bold">
                      {selectedMember.fallback}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <DialogTitle className="text-2xl font-bold">{selectedMember.name}</DialogTitle>
                    <DialogDescription className="text-lg font-medium text-primary mt-1">{selectedMember.role}</DialogDescription>
                    {'department' in selectedMember && (
                      <p className="text-sm text-muted-foreground mt-1">{selectedMember.department}</p>
                    )}
                  </div>
                </div>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <h4 className="font-semibold mb-2">About</h4>
                  <p className="text-sm text-muted-foreground">{selectedMember.bio}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedMember.skills.map((skill) => (
                      <Badge key={skill} variant="secondary">{skill}</Badge>
                    ))}
                  </div>
                </div>
                <div className="pt-4 border-t flex justify-center gap-3">
                  <button className="p-2 rounded-full hover:bg-muted transition-colors">
                    <Github className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-muted transition-colors">
                    <Linkedin className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-muted transition-colors">
                    <Twitter className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
