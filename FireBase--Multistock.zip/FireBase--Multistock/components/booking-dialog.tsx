"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { addBooking } from "@/lib/bookings"

export function BookingDialog({ resourceId, title, type }: { resourceId: string; title: string; type: "rental" | "storage" }) {
  const [open, setOpen] = useState(false)
  const [start, setStart] = useState("")
  const [end, setEnd] = useState("")
  const [pricePerDay, setPricePerDay] = useState(100)
  const [coupon, setCoupon] = useState("")

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!start || !end) return
    addBooking({ resourceId, title, type, startDate: start, endDate: end, pricePerDay, couponCode: coupon || undefined })
    setOpen(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary">Book</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Book {title}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-3">
          <div>
            <label className="block text-xs mb-1">Start date</label>
            <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} required />
          </div>
          <div>
            <label className="block text-xs mb-1">End date</label>
            <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} required />
          </div>
          <div>
            <label className="block text-xs mb-1">Price / day</label>
            <Input type="number" min={0} value={pricePerDay} onChange={(e) => setPricePerDay(Number(e.target.value))} />
          </div>
          <div>
            <label className="block text-xs mb-1">Coupon</label>
            <Input placeholder="CODE (optional)" value={coupon} onChange={(e) => setCoupon(e.target.value.toUpperCase())} />
          </div>
          <div className="flex justify-end"><Button type="submit">Confirm</Button></div>
        </form>
      </DialogContent>
    </Dialog>
  )
}


