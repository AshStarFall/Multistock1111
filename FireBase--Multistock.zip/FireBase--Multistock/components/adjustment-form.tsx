"use client"

import { useState } from "react"
import { warehouses } from "@/lib/mock-data"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { addAuditEvent } from "@/lib/audit-log"

export type Adjustment = {
  id: string
  date: string
  sku: string
  warehouseId: string
  qty: number // +/- for add/remove
  reason: string
}

import { load, save } from "@/lib/storage"
const KEY = "adjustments"

function listAdjustments(): Adjustment[] {
  return load<Adjustment[]>(KEY, [])
}
function addAdjustment(a: Omit<Adjustment, "id" | "date">) {
  const rows = listAdjustments()
  const row: Adjustment = { id: crypto.randomUUID(), date: new Date().toISOString(), ...a }
  rows.unshift(row)
  save(KEY, rows.slice(0, 500))
  return row
}

export function useAdjustments() {
  const rows = listAdjustments()
  return rows
}

export function AdjustmentForm({ onCreated }: { onCreated: () => void }) {
  const [sku, setSku] = useState("")
  const [warehouseId, setWarehouseId] = useState(warehouses[0]?.id ?? "")
  const [qty, setQty] = useState<number>(0)
  const [reason, setReason] = useState("")

  function submit() {
    if (!sku || !warehouseId || !qty) return
    const row = addAdjustment({ sku, warehouseId, qty, reason })
    addAuditEvent({
      action: qty >= 0 ? "inventory.adjustment.add" : "inventory.adjustment.remove",
      meta: { sku, warehouseId, qty, reason, id: row.id },
    })
    setSku("")
    setQty(0)
    setReason("")
    onCreated()
  }

  return (
    <div className="flex flex-col gap-2 md:flex-row md:items-end">
      <div className="grid gap-1">
        <label className="text-xs text-muted-foreground" htmlFor="sku">
          SKU
        </label>
        <Input id="sku" value={sku} onChange={(e) => setSku(e.target.value)} placeholder="SKU-12345" className="w-44" />
      </div>
      <div className="grid gap-1">
        <label className="text-xs text-muted-foreground" htmlFor="wh">
          Warehouse
        </label>
        <select
          id="wh"
          value={warehouseId}
          onChange={(e) => setWarehouseId(e.target.value)}
          className="border rounded-md text-sm h-9 px-2 bg-background w-48"
        >
          {warehouses.map((w) => (
            <option key={w.id} value={w.id}>
              {w.name}
            </option>
          ))}
        </select>
      </div>
      <div className="grid gap-1">
        <label className="text-xs text-muted-foreground" htmlFor="qty">
          Quantity (+/-)
        </label>
        <Input
          id="qty"
          type="number"
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          className="w-32"
          placeholder="e.g. -2"
        />
      </div>
      <div className="grid gap-1 flex-1">
        <label className="text-xs text-muted-foreground" htmlFor="reason">
          Reason
        </label>
        <Input id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Cycle count" />
      </div>
      <Button onClick={submit} className="bg-primary text-primary-foreground hover:opacity-90">
        Save
      </Button>
    </div>
  )
}
