"use client"

import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { RatingStars } from '@/components/rating-stars'
import { Star, ShieldCheck } from 'lucide-react'
import { type ReviewStats } from '@/lib/reviews'
import { getRatingBadgeColor } from '@/lib/reviews'

interface ReviewStatsDisplayProps {
  stats: ReviewStats
  onFilterByRating?: (rating: number | null) => void
  selectedRating?: number | null
}

export function ReviewStatsDisplay({
  stats,
  onFilterByRating,
  selectedRating
}: ReviewStatsDisplayProps) {
  const { averageRating, totalReviews, distribution, verifiedPurchaseCount } = stats

  const getRatingPercentage = (count: number): number => {
    return totalReviews > 0 ? (count / totalReviews) * 100 : 0
  }

  return (
    <div className="space-y-6">
      {/* Overall Rating */}
      <div className="flex items-start gap-6">
        <div className="text-center">
          <div className="text-5xl font-bold text-slate-900 dark:text-slate-100 mb-2">
            {averageRating.toFixed(1)}
          </div>
          <RatingStars rating={averageRating} size="lg" className="mb-2" />
          <p className="text-sm text-muted-foreground">
            Based on {totalReviews} {totalReviews === 1 ? 'review' : 'reviews'}
          </p>
        </div>

        {/* Rating Distribution */}
        <div className="flex-1 space-y-2">
          {[5, 4, 3, 2, 1].map((rating) => {
            const count = distribution[rating as keyof typeof distribution]
            const percentage = getRatingPercentage(count)
            const isSelected = selectedRating === rating

            return (
              <button
                key={rating}
                onClick={() => onFilterByRating?.(isSelected ? null : rating)}
                className={`w-full flex items-center gap-3 group hover:bg-slate-50 dark:hover:bg-slate-800 p-2 rounded-lg transition-colors ${
                  isSelected ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                }`}
              >
                <div className="flex items-center gap-1 w-12">
                  <span className="text-sm font-medium">{rating}</span>
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                </div>
                <div className="flex-1">
                  <Progress value={percentage} className="h-2" />
                </div>
                <div className="w-12 text-right">
                  <span className="text-sm text-muted-foreground">{count}</span>
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Additional Stats */}
      <div className="flex items-center gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Badge variant="outline" className={getRatingBadgeColor(averageRating)}>
          {averageRating >= 4.5 ? 'Excellent' : averageRating >= 3.5 ? 'Good' : averageRating >= 2.5 ? 'Average' : 'Poor'}
        </Badge>
        {verifiedPurchaseCount > 0 && (
          <Badge variant="outline" className="text-green-600 border-green-600">
            <ShieldCheck className="w-3 h-3 mr-1" />
            {verifiedPurchaseCount} Verified {verifiedPurchaseCount === 1 ? 'Purchase' : 'Purchases'}
          </Badge>
        )}
      </div>
    </div>
  )
}
