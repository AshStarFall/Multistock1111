"use client"

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useAuth } from '@/lib/auth-context'
import {
  MessageCircle,
  X,
  Send,
  User,
  Bot,
  ChevronRight,
  Search,
  ArrowLeft,
  Minimize2,
  Maximize2
} from 'lucide-react'
import {
  FAQ_DATA,
  FAQ_CATEGORIES,
  QUICK_REPLIES,
  getGreeting,
  searchFAQs,
  getFAQsByCategory,
  getRelatedFAQs,
  type FAQItem,
  type FAQCategory
} from '@/lib/faq-data'

interface Message {
  id: string
  type: 'user' | 'bot'
  content: string
  timestamp: Date
  options?: { text: string; action: string }[]
}

export function Chatbot() {
  const { user } = useAuth() // Get user from auth context
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<FAQCategory | null>(null)
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  // Initialize chat with greeting
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      addBotMessage(
        `${getGreeting()} Welcome to MultiStock Support! 👋\n\nI'm here to help you with any questions. You can:\n\n• Browse categories below\n• Search for answers\n• Type your question\n\nHow can I assist you today?`,
        []
      )
    }
  }, [isOpen])

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, isTyping])

  const addBotMessage = (content: string, options?: { text: string; action: string }[]) => {
    const message: Message = {
      id: Date.now().toString(),
      type: 'bot',
      content,
      timestamp: new Date(),
      options
    }
    setMessages(prev => [...prev, message])
  }

  const addUserMessage = (content: string) => {
    const message: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, message])
  }

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    addUserMessage(inputValue)
    handleUserQuery(inputValue)
    setInputValue('')
  }

  const handleUserQuery = (query: string) => {
    setIsTyping(true)

    // Simulate typing delay
    setTimeout(() => {
      const results = searchFAQs(query)

      if (results.length === 0) {
        addBotMessage(
          "I couldn't find an exact answer to your question. 😕\n\nWould you like to:\n\n1. Browse FAQ categories\n2. Contact live support\n3. Try rephrasing your question",
          [
            { text: 'Browse Categories', action: 'categories' },
            { text: 'Contact Support', action: 'contact' }
          ]
        )
      } else if (results.length === 1) {
        const faq = results[0]
        addBotMessage(`${faq.answer}\n\n📚 Category: ${FAQ_CATEGORIES[faq.category].label}`)
        
        // Show related questions
        const related = getRelatedFAQs(faq.id)
        if (related.length > 0) {
          addBotMessage(
            "Related questions you might find helpful:",
            related.slice(0, 3).map(r => ({ text: r.question, action: `faq-${r.id}` }))
          )
        }
      } else {
        // Multiple results
        addBotMessage(
          `I found ${results.length} answers that might help you:`,
          results.slice(0, 5).map(r => ({ text: r.question, action: `faq-${r.id}` }))
        )
      }

      setIsTyping(false)
    }, 800)
  }

  const handleOptionClick = (action: string) => {
    if (action === 'categories') {
      setSelectedCategory(null)
      showCategories()
    } else if (action === 'contact') {
      addBotMessage(
        "📞 Contact our support team:\n\n• Email: support@multistock.com\n• Phone: 1800-XXX-XXXX (9 AM - 9 PM)\n• Live Chat: Available 24/7\n\nOr raise a ticket in Help Center for faster resolution."
      )
    } else if (action === 'track') {
      addBotMessage(
        "To track your order:\n\n1. Go to Dashboard > My Orders\n2. Click on the order\n3. View real-time tracking\n\nNeed help with a specific order? Please share your Order ID."
      )
    } else if (action === 'return') {
      addBotMessage(
        "To return a product:\n\n1. Go to My Orders\n2. Select the order\n3. Click 'Return Item'\n4. Choose reason\n5. Schedule free pickup\n\n✅ 7-day return policy for most items!"
      )
    } else if (action === 'payment') {
      addBotMessage(
        "Common payment issues:\n\n💳 Payment failed but money deducted?\n→ Auto-refund in 5-7 days\n\n💰 Want to change payment method?\n→ Go to Settings > Payments\n\n🔒 Is payment secure?\n→ Yes! 256-bit SSL encryption\n\nNeed specific help? Describe your issue."
      )
    } else if (action === 'sell') {
      addBotMessage(
        "🛍️ Start selling on MultiStock:\n\n1. Click 'Sell on MultiStock'\n2. Register as seller\n3. Choose subscription plan\n4. List your products\n\n💼 Plans start from FREE!\n\nWant to know more about seller benefits?"
      )
    } else if (action === 'rental') {
      addBotMessage(
        "🔑 Rental Service:\n\n• Choose item & duration\n• Get it delivered\n• Use during rental period\n• Return via free pickup\n\n✅ Insurance included!\n\nBrowse rental items or ask specific questions."
      )
    } else if (action.startsWith('cat-')) {
      const category = action.replace('cat-', '') as FAQCategory
      showCategoryFAQs(category)
    } else if (action.startsWith('faq-')) {
      const faqId = action.replace('faq-', '')
      const faq = FAQ_DATA.find(f => f.id === faqId)
      if (faq) {
        addBotMessage(`${faq.answer}\n\n📚 Category: ${FAQ_CATEGORIES[faq.category].label}`)
        
        // Show related
        const related = getRelatedFAQs(faq.id)
        if (related.length > 0) {
          addBotMessage(
            "You might also want to know:",
            related.slice(0, 3).map(r => ({ text: r.question, action: `faq-${r.id}` }))
          )
        }
      }
    }
  }

  const showCategories = () => {
    addBotMessage(
      "📋 Choose a category to explore:",
      Object.entries(FAQ_CATEGORIES).map(([key, value]) => ({
        text: `${value.icon} ${value.label}`,
        action: `cat-${key}`
      }))
    )
  }

  const showCategoryFAQs = (category: FAQCategory) => {
    setSelectedCategory(category)
    const faqs = getFAQsByCategory(category)
    addBotMessage(
      `${FAQ_CATEGORIES[category].icon} ${FAQ_CATEGORIES[category].label}\n\nSelect a question:`,
      faqs.map(faq => ({ text: faq.question, action: `faq-${faq.id}` }))
    )
  }

  // Don't render chatbot if user is not logged in
  if (!user) {
    return null
  }

  return (
    <>
      {/* Floating Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              size="lg"
              onClick={() => setIsOpen(true)}
              className="h-14 w-14 rounded-full shadow-2xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <MessageCircle className="w-6 h-6" />
            </Button>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? 'auto' : '600px'
            }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-6 right-6 z-50 w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                    <Bot className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">MultiStock Support</h3>
                  <p className="text-xs text-blue-100">Online • Instant replies</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="text-white hover:bg-white/20"
                >
                  {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/20"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Messages */}
                <ScrollArea className="flex-1 p-4 space-y-4" ref={scrollRef}>
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-2 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {message.type === 'bot' && (
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                          <Bot className="w-5 h-5 text-white" />
                        </div>
                      )}
                      <div className={`flex flex-col gap-2 max-w-[75%]`}>
                        <div
                          className={`rounded-2xl px-4 py-2 ${
                            message.type === 'user'
                              ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          <p className="text-sm whitespace-pre-line">{message.content}</p>
                        </div>
                        {message.options && (
                          <div className="flex flex-col gap-2">
                            {message.options.map((option, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                onClick={() => handleOptionClick(option.action)}
                                className="justify-start text-left h-auto py-2 px-3"
                              >
                                <ChevronRight className="w-4 h-4 mr-2 flex-shrink-0" />
                                <span className="text-xs">{option.text}</span>
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>
                      {message.type === 'user' && (
                        <div className="w-8 h-8 bg-slate-200 dark:bg-slate-700 rounded-full flex items-center justify-center flex-shrink-0">
                          <User className="w-5 h-5" />
                        </div>
                      )}
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                        <Bot className="w-5 h-5 text-white" />
                      </div>
                      <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-2">
                        <div className="flex gap-1">
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    </div>
                  )}
                </ScrollArea>

                {/* Quick Replies */}
                {messages.length === 1 && (
                  <div className="px-4 pb-2">
                    <p className="text-xs text-muted-foreground mb-2">Quick actions:</p>
                    <div className="flex flex-wrap gap-2">
                      {QUICK_REPLIES.map((reply, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          onClick={() => handleOptionClick(reply.action)}
                          className="text-xs"
                        >
                          {reply.text}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Input */}
                <div className="p-4 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your question..."
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault()
                          handleSendMessage()
                        }
                      }}
                      className="flex-1"
                    />
                    <Button
                      onClick={handleSendMessage}
                      size="icon"
                      disabled={!inputValue.trim()}
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    Powered by MultiStock AI
                  </p>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
