"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Bell, Mail, Smartphone, Clock, Save, Check } from 'lucide-react'
import { type NotificationPreferences } from '@/lib/notifications'
import { useToast } from '@/hooks/use-toast'

interface NotificationPreferencesPageProps {
  userId: string
  initialPreferences?: NotificationPreferences
}

export function NotificationPreferencesPage({
  userId,
  initialPreferences
}: NotificationPreferencesPageProps) {
  const [preferences, setPreferences] = useState<NotificationPreferences>(
    initialPreferences || {
      userId,
      emailNotifications: true,
      pushNotifications: true,
      smsNotifications: false,
      categories: {
        orders: true,
        payments: true,
        shipping: true,
        marketing: false,
        auctions: true,
        messages: true,
        system: true
      },
      quietHours: {
        enabled: false,
        start: '22:00',
        end: '08:00'
      }
    }
  )
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const { toast } = useToast()

  const handleSave = async () => {
    setSaving(true)
    try {
      const response = await fetch('/api/notifications/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(preferences)
      })

      if (!response.ok) throw new Error('Failed to save preferences')

      setSaved(true)
      toast({
        title: 'Preferences saved',
        description: 'Your notification preferences have been updated.',
      })

      setTimeout(() => setSaved(false), 3000)
    } catch (error) {
      toast({
        title: 'Save failed',
        description: 'Failed to save preferences. Please try again.',
        variant: 'destructive'
      })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Notification Preferences</h1>
        <p className="text-muted-foreground">
          Manage how and when you receive notifications
        </p>
      </div>

      {/* Notification Channels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notification Channels
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Push Notifications
              </Label>
              <p className="text-sm text-muted-foreground">
                Receive notifications in your browser
              </p>
            </div>
            <Switch
              checked={preferences.pushNotifications}
              onCheckedChange={(checked) =>
                setPreferences({ ...preferences, pushNotifications: checked })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email Notifications
              </Label>
              <p className="text-sm text-muted-foreground">
                Receive notifications via email
              </p>
            </div>
            <Switch
              checked={preferences.emailNotifications}
              onCheckedChange={(checked) =>
                setPreferences({ ...preferences, emailNotifications: checked })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base flex items-center gap-2">
                <Smartphone className="w-4 h-4" />
                SMS Notifications
              </Label>
              <p className="text-sm text-muted-foreground">
                Receive important alerts via SMS
              </p>
            </div>
            <Switch
              checked={preferences.smsNotifications}
              onCheckedChange={(checked) =>
                setPreferences({ ...preferences, smsNotifications: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Notification Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Notification Categories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">📦 Orders</Label>
              <p className="text-sm text-muted-foreground">
                Order confirmations, updates, and delivery status
              </p>
            </div>
            <Switch
              checked={preferences.categories.orders}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, orders: checked }
                })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">💳 Payments</Label>
              <p className="text-sm text-muted-foreground">
                Payment confirmations, receipts, and billing alerts
              </p>
            </div>
            <Switch
              checked={preferences.categories.payments}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, payments: checked }
                })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">🚚 Shipping</Label>
              <p className="text-sm text-muted-foreground">
                Shipping updates and delivery notifications
              </p>
            </div>
            <Switch
              checked={preferences.categories.shipping}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, shipping: checked }
                })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">💬 Messages</Label>
              <p className="text-sm text-muted-foreground">
                Direct messages and chat notifications
              </p>
            </div>
            <Switch
              checked={preferences.categories.messages}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, messages: checked }
                })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">⚡ Auctions</Label>
              <p className="text-sm text-muted-foreground">
                Auction bids, wins, and reminders
              </p>
            </div>
            <Switch
              checked={preferences.categories.auctions}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, auctions: checked }
                })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">🎁 Marketing</Label>
              <p className="text-sm text-muted-foreground">
                Promotional offers, deals, and newsletters
              </p>
            </div>
            <Switch
              checked={preferences.categories.marketing}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, marketing: checked }
                })
              }
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">ℹ️ System</Label>
              <p className="text-sm text-muted-foreground">
                System updates, maintenance, and important alerts
              </p>
            </div>
            <Switch
              checked={preferences.categories.system}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  categories: { ...preferences.categories, system: checked }
                })
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Quiet Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Quiet Hours
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Quiet Hours</Label>
              <p className="text-sm text-muted-foreground">
                Pause non-urgent notifications during specified hours
              </p>
            </div>
            <Switch
              checked={preferences.quietHours.enabled}
              onCheckedChange={(checked) =>
                setPreferences({
                  ...preferences,
                  quietHours: { ...preferences.quietHours, enabled: checked }
                })
              }
            />
          </div>

          {preferences.quietHours.enabled && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="grid grid-cols-2 gap-4 pt-2"
            >
              <div className="space-y-2">
                <Label htmlFor="start-time">Start Time</Label>
                <Select
                  value={preferences.quietHours.start}
                  onValueChange={(value) =>
                    setPreferences({
                      ...preferences,
                      quietHours: { ...preferences.quietHours, start: value }
                    })
                  }
                >
                  <SelectTrigger id="start-time">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 24 }, (_, i) => {
                      const hour = i.toString().padStart(2, '0')
                      return (
                        <SelectItem key={`${hour}:00`} value={`${hour}:00`}>
                          {hour}:00
                        </SelectItem>
                      )
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="end-time">End Time</Label>
                <Select
                  value={preferences.quietHours.end}
                  onValueChange={(value) =>
                    setPreferences({
                      ...preferences,
                      quietHours: { ...preferences.quietHours, end: value }
                    })
                  }
                >
                  <SelectTrigger id="end-time">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 24 }, (_, i) => {
                      const hour = i.toString().padStart(2, '0')
                      return (
                        <SelectItem key={`${hour}:00`} value={`${hour}:00`}>
                          {hour}:00
                        </SelectItem>
                      )
                    })}
                  </SelectContent>
                </Select>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end gap-4">
        <Button
          onClick={handleSave}
          disabled={saving || saved}
          className="min-w-[120px]"
        >
          {saved ? (
            <>
              <Check className="w-4 h-4 mr-2" />
              Saved
            </>
          ) : saving ? (
            'Saving...'
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
