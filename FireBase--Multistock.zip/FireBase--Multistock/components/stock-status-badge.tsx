import { Badge } from "@/components/ui/badge"
export function StockStatusBadge({ status }: { status: "ok" | "warning" | "low" }) {
  if (status === "ok") return <Badge className="bg-green-600 hover:bg-green-600/90">OK</Badge>
  if (status === "warning") return <Badge className="bg-amber-500 hover:bg-amber-500/90">Warning</Badge>
  return <Badge className="bg-blue-600 hover:bg-blue-600/90">Reorder</Badge>
}
