"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Package, Truck, Warehouse, ShoppingCart } from "lucide-react"
import { Card } from "@/components/ui/card"

const features = [
  {
    icon: Package,
    title: "Inventory Management",
    description: "Track and manage your products across multiple warehouses with real-time stock updates",
    color: "from-indigo-500 to-purple-600"
  },
  {
    icon: Truck,
    title: "Logistics Solutions",
    description: "Streamline your supply chain with integrated shipping and delivery management",
    color: "from-violet-500 to-pink-600"
  },
  {
    icon: Warehouse,
    title: "Storage & Lockers",
    description: "Efficient warehouse management with smart locker systems and slot tracking",
    color: "from-cyan-500 to-blue-600"
  },
  {
    icon: ShoppingCart,
    title: "Marketplace Platform",
    description: "Buy and sell products in our integrated marketplace with verified sellers",
    color: "from-emerald-500 to-teal-600"
  }
]

export function FeaturedCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlay, setIsAutoPlay] = useState(true)

  useEffect(() => {
    if (!isAutoPlay) return
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % features.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlay])

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + features.length) % features.length)
    setIsAutoPlay(false)
  }

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % features.length)
    setIsAutoPlay(false)
  }

  const feature = features[currentIndex]
  const Icon = feature.icon

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-950 dark:to-slate-900 border-slate-700">
      <div className="p-8 md:p-12">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide">Featured Services</h3>
          <div className="flex gap-2">
            {features.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setCurrentIndex(index)
                  setIsAutoPlay(false)
                }}
                className={`h-1.5 rounded-full transition-all ${
                  index === currentIndex 
                    ? 'w-8 bg-indigo-500' 
                    : 'w-1.5 bg-slate-600 hover:bg-slate-500'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-8">
          {/* Icon */}
          <div className={`hidden md:flex items-center justify-center w-24 h-24 rounded-2xl bg-gradient-to-br ${feature.color} shadow-2xl`}>
            <Icon className="w-12 h-12 text-white" />
          </div>

          {/* Content */}
          <div className="flex-1">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              {feature.title}
            </h2>
            <p className="text-slate-300 text-lg leading-relaxed">
              {feature.description}
            </p>
          </div>

          {/* Navigation Buttons */}
          <div className="flex flex-col gap-2">
            <button
              onClick={goToPrevious}
              className="p-2 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-white transition-colors"
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={goToNext}
              className="p-2 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-white transition-colors"
              aria-label="Next slide"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </Card>
  )
}
