"use client"

import { Star, StarHalf } from 'lucide-react'
import { cn } from '@/lib/utils'

interface RatingStarsProps {
  rating: number
  maxRating?: number
  size?: 'sm' | 'md' | 'lg' | 'xl'
  showNumber?: boolean
  interactive?: boolean
  onChange?: (rating: number) => void
  className?: string
}

export function RatingStars({
  rating,
  maxRating = 5,
  size = 'md',
  showNumber = false,
  interactive = false,
  onChange,
  className
}: RatingStarsProps) {
  const sizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
    xl: 'w-6 h-6'
  }

  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
    xl: 'text-lg'
  }

  const renderStar = (index: number) => {
    const starValue = index + 1
    const filled = rating >= starValue
    const halfFilled = rating >= starValue - 0.5 && rating < starValue

    if (interactive) {
      return (
        <button
          key={index}
          type="button"
          onClick={() => onChange?.(starValue)}
          onMouseEnter={(e) => {
            if (onChange) {
              const target = e.currentTarget
              target.style.transform = 'scale(1.2)'
            }
          }}
          onMouseLeave={(e) => {
            if (onChange) {
              const target = e.currentTarget
              target.style.transform = 'scale(1)'
            }
          }}
          className="transition-transform duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded"
        >
          <Star
            className={cn(
              sizeClasses[size],
              filled ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300 dark:text-slate-600',
              'transition-colors duration-150'
            )}
          />
        </button>
      )
    }

    return (
      <div key={index}>
        {halfFilled ? (
          <div className="relative">
            <Star className={cn(sizeClasses[size], 'text-slate-300 dark:text-slate-600')} />
            <StarHalf
              className={cn(
                sizeClasses[size],
                'fill-yellow-400 text-yellow-400 absolute top-0 left-0'
              )}
            />
          </div>
        ) : (
          <Star
            className={cn(
              sizeClasses[size],
              filled ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300 dark:text-slate-600'
            )}
          />
        )}
      </div>
    )
  }

  return (
    <div className={cn('flex items-center gap-1', className)}>
      <div className="flex items-center gap-0.5">
        {Array.from({ length: maxRating }, (_, i) => renderStar(i))}
      </div>
      {showNumber && (
        <span className={cn('font-medium text-slate-700 dark:text-slate-300', textSizeClasses[size])}>
          {rating.toFixed(1)}
        </span>
      )}
    </div>
  )
}
