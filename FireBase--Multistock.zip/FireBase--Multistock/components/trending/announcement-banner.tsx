'use client';

import { useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Announcement, getAnnouncementColor } from '@/lib/trending';
import { X, AlertCircle, CheckCircle, AlertTriangle, Info, Megaphone } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const iconMap = {
  info: Info,
  success: CheckCircle,
  warning: AlertTriangle,
  error: AlertCircle,
  promotion: Megaphone,
};

export function AnnouncementBanner({ announcements }: { announcements: Announcement[] }) {
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const visibleAnnouncements = announcements.filter(
    (announcement) => !dismissed.has(announcement.id)
  );

  if (visibleAnnouncements.length === 0) return null;

  const handleDismiss = (id: string) => {
    setDismissed(new Set([...dismissed, id]));
  };

  return (
    <div className="space-y-2">
      <AnimatePresence>
        {visibleAnnouncements.map((announcement) => {
          const colors = getAnnouncementColor(announcement.type);
          const Icon = iconMap[announcement.type];

          return (
            <motion.div
              key={announcement.id}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
            >
              <Alert
                className={`${colors.bg} ${colors.text} ${colors.border} border`}
              >
                <Icon className="h-4 w-4" />
                <AlertTitle className="flex items-center justify-between">
                  <span className="font-semibold">{announcement.title}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 -mt-1 -mr-2"
                    onClick={() => handleDismiss(announcement.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </AlertTitle>
                <AlertDescription className="mt-2">
                  <p>{announcement.message}</p>
                  {announcement.link && (
                    <Button
                      variant="link"
                      className="p-0 h-auto mt-2 text-current underline"
                      asChild
                    >
                      <a href={announcement.link} target="_blank" rel="noopener noreferrer">
                        {announcement.linkText || 'Learn more'}
                      </a>
                    </Button>
                  )}
                </AlertDescription>
              </Alert>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
