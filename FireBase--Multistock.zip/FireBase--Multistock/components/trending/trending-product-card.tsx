'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingProduct, formatDealCountdown, isDealExpiringSoon } from '@/lib/trending';
import { TrendingUp, Clock, Star, ShoppingCart, Flame } from 'lucide-react';
import { motion } from 'framer-motion';

export function TrendingProductCard({ product }: { product: TrendingProduct }) {
  const [timeLeft, setTimeLeft] = useState(formatDealCountdown(product.dealEndsAt));

  useEffect(() => {
    if (!product.dealEndsAt) return;

    const interval = setInterval(() => {
      setTimeLeft(formatDealCountdown(product.dealEndsAt));
    }, 1000);

    return () => clearInterval(interval);
  }, [product.dealEndsAt]);

  const isExpiringSoon = isDealExpiringSoon(product.dealEndsAt);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="overflow-hidden hover:shadow-lg transition-shadow">
        <div className="relative">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover"
          />
          
          {product.discount && product.discount > 0 && (
            <Badge className="absolute top-2 left-2 bg-red-600 text-white">
              {product.discount}% OFF
            </Badge>
          )}

          {product.isHotDeal && (
            <Badge className="absolute top-2 right-2 bg-orange-600 text-white flex items-center gap-1">
              <Flame className="w-3 h-3" />
              Hot Deal
            </Badge>
          )}

          {product.trendingScore > 70 && (
            <Badge className="absolute bottom-2 left-2 bg-purple-600 text-white flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Trending
            </Badge>
          )}

          {product.stock < 10 && product.stock > 0 && (
            <Badge className="absolute bottom-2 right-2 bg-yellow-600 text-white">
              Only {product.stock} left!
            </Badge>
          )}

          {product.stock === 0 && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <Badge className="bg-gray-800 text-white text-lg">Out of Stock</Badge>
            </div>
          )}
        </div>

        <div className="p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-lg line-clamp-2">{product.name}</h3>
            <div className="flex items-center gap-1 shrink-0">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-medium">{product.rating.toFixed(1)}</span>
              <span className="text-xs text-muted-foreground">({product.reviews})</span>
            </div>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {product.description}
          </p>

          <div className="flex items-center gap-2 mb-3">
            <Badge variant="outline">{product.category}</Badge>
            {product.tags.slice(0, 2).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-primary">₹{product.price.toLocaleString()}</span>
                {product.originalPrice && (
                  <span className="text-sm text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground">by {product.seller}</p>
            </div>
          </div>

          {product.dealEndsAt && (
            <div
              className={`flex items-center gap-2 mb-3 p-2 rounded-md ${
                isExpiringSoon
                  ? 'bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-300'
                  : 'bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-300'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">
                {timeLeft === 'Expired' ? 'Deal Expired' : `Ends in ${timeLeft}`}
              </span>
            </div>
          )}

          <div className="flex gap-2">
            <Button className="flex-1" size="sm" disabled={product.stock === 0}>
              <ShoppingCart className="w-4 h-4 mr-2" />
              Add to Cart
            </Button>
            <Button variant="outline" size="sm">
              View
            </Button>
          </div>

          <div className="mt-3 pt-3 border-t flex items-center justify-between text-xs text-muted-foreground">
            <span>{product.salesCount} sold</span>
            <span>{product.viewsCount} views</span>
            <span className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {product.trendingScore}
            </span>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
