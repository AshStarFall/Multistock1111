'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingProduct } from '@/lib/trending';
import { ChevronLeft, ChevronRight, Star, TrendingUp, Flame } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function TrendingCarousel({ products }: { products: TrendingProduct[] }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  // Auto-advance carousel every 5 seconds
  useEffect(() => {
    if (!autoPlay || products.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % products.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [autoPlay, products.length]);

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + products.length) % products.length);
    setAutoPlay(false);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % products.length);
    setAutoPlay(false);
  };

  if (products.length === 0) return null;

  const currentProduct = products[currentIndex];

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="overflow-hidden">
            <div className="grid md:grid-cols-2 gap-6 p-6">
              <div className="relative">
                <img
                  src={currentProduct.image}
                  alt={currentProduct.name}
                  className="w-full h-80 object-cover rounded-lg"
                />
                
                <div className="absolute top-2 left-2 flex gap-2">
                  {currentProduct.discount && currentProduct.discount > 0 && (
                    <Badge className="bg-red-600 text-white text-lg">
                      {currentProduct.discount}% OFF
                    </Badge>
                  )}
                  {currentProduct.isHotDeal && (
                    <Badge className="bg-orange-600 text-white flex items-center gap-1">
                      <Flame className="w-4 h-4" />
                      Hot Deal
                    </Badge>
                  )}
                </div>

                {currentProduct.trendingScore > 80 && (
                  <Badge className="absolute top-2 right-2 bg-purple-600 text-white flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    #1 Trending
                  </Badge>
                )}
              </div>

              <div className="flex flex-col justify-center">
                <Badge className="w-fit mb-2" variant="secondary">
                  {currentProduct.category}
                </Badge>

                <h2 className="text-3xl font-bold mb-3">{currentProduct.name}</h2>

                <p className="text-muted-foreground mb-4">
                  {currentProduct.description}
                </p>

                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{currentProduct.rating.toFixed(1)}</span>
                  </div>
                  <span className="text-muted-foreground">
                    ({currentProduct.reviews} reviews)
                  </span>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-muted-foreground">
                    {currentProduct.salesCount} sold
                  </span>
                </div>

                <div className="flex items-baseline gap-3 mb-6">
                  <span className="text-4xl font-bold text-primary">
                    ₹{currentProduct.price.toLocaleString()}
                  </span>
                  {currentProduct.originalPrice && (
                    <span className="text-xl text-muted-foreground line-through">
                      ₹{currentProduct.originalPrice.toLocaleString()}
                    </span>
                  )}
                  {currentProduct.discount && (
                    <Badge className="bg-green-600 text-white">
                      Save ₹{(currentProduct.originalPrice! - currentProduct.price).toLocaleString()}
                    </Badge>
                  )}
                </div>

                <div className="flex gap-3 mb-4">
                  <Button size="lg" className="flex-1">
                    Buy Now
                  </Button>
                  <Button size="lg" variant="outline">
                    Add to Cart
                  </Button>
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>Seller: {currentProduct.seller}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    Trending Score: {currentProduct.trendingScore}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Controls */}
      {products.length > 1 && (
        <>
          <Button
            variant="outline"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur"
            onClick={handlePrevious}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <Button
            variant="outline"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur"
            onClick={handleNext}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>

          {/* Dots indicator */}
          <div className="flex justify-center gap-2 mt-4">
            {products.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentIndex
                    ? 'bg-primary w-8'
                    : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
                }`}
                onClick={() => {
                  setCurrentIndex(index);
                  setAutoPlay(false);
                }}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
