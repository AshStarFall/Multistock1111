"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  Upload,
  X,
  Image as ImageIcon,
  Plus
} from 'lucide-react'
import {
  type ListingType,
  type ListingCondition,
  type RentalPeriod,
  getListingTypeLabel,
  getConditionLabel,
  getRentalPeriodLabel
} from '@/lib/marketplace'

interface ListingFormProps {
  sellerId: string
  initialData?: any
  onSubmit?: (data: any) => void
  onCancel?: () => void
}

export default function ListingForm({ sellerId, initialData, onSubmit, onCancel }: ListingFormProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  const [formData, setFormData] = useState({
    title: initialData?.title || '',
    description: initialData?.description || '',
    category: initialData?.category || '',
    type: initialData?.type as ListingType || 'sell',
    condition: initialData?.condition as ListingCondition || 'good',
    price: initialData?.price || '',
    rentalPeriod: initialData?.rentalPeriod as RentalPeriod || 'daily',
    rentalDeposit: initialData?.rentalDeposit || '',
    quantity: initialData?.quantity || '1',
    location: initialData?.location || '',
    tags: initialData?.tags?.join(', ') || ''
  })

  const [images, setImages] = useState<File[]>([])
  const [imagePreviews, setImagePreviews] = useState<string[]>(initialData?.images || [])

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    
    // Validate file size (5MB max)
    const validFiles = files.filter(file => {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds 5MB limit`,
          variant: "destructive"
        })
        return false
      }
      return true
    })

    // Create previews
    validFiles.forEach(file => {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreviews(prev => [...prev, reader.result as string])
      }
      reader.readAsDataURL(file)
    })

    setImages(prev => [...prev, ...validFiles])
  }

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index))
    setImagePreviews(prev => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validation
    if (!formData.title.trim()) {
      toast({ title: "Title is required", variant: "destructive" })
      return
    }
    
    if (!formData.description.trim()) {
      toast({ title: "Description is required", variant: "destructive" })
      return
    }
    
    if (!formData.price || Number(formData.price) <= 0) {
      toast({ title: "Valid price is required", variant: "destructive" })
      return
    }

    if (imagePreviews.length === 0) {
      toast({ title: "At least one image is required", variant: "destructive" })
      return
    }

    setLoading(true)

    try {
      const listingData = {
        ...formData,
        sellerId,
        price: Number(formData.price),
        rentalDeposit: formData.rentalDeposit ? Number(formData.rentalDeposit) : undefined,
        quantity: Number(formData.quantity),
        tags: formData.tags.split(',').map((t: string) => t.trim()).filter(Boolean),
        images: imagePreviews
      }

      // Call API
      const response = await fetch('/api/marketplace/listings', {
        method: initialData?.id ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(listingData)
      })

      if (!response.ok) throw new Error('Failed to save listing')

      const result = await response.json()

      toast({
        title: initialData?.id ? "Listing updated!" : "Listing created!",
        description: "Your listing has been saved successfully."
      })

      onSubmit?.(result.listing)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save listing. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Images Upload */}
      <div className="space-y-2">
        <Label>Product Images *</Label>
        <div className="grid grid-cols-4 gap-4">
          {imagePreviews.map((preview, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative aspect-square"
            >
              <img
                src={preview}
                alt={`Preview ${index + 1}`}
                className="w-full h-full object-cover rounded-lg"
              />
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute -top-2 -right-2 h-6 w-6"
                onClick={() => removeImage(index)}
              >
                <X className="w-4 h-4" />
              </Button>
            </motion.div>
          ))}
          
          {imagePreviews.length < 10 && (
            <label className="aspect-square border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950 transition-colors">
              <Upload className="w-8 h-8 text-muted-foreground mb-2" />
              <span className="text-xs text-muted-foreground text-center px-2">
                Upload Image
              </span>
              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleImageUpload}
              />
            </label>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          Upload up to 10 images. Max 5MB each. First image will be the main image.
        </p>
      </div>

      {/* Title */}
      <div className="space-y-2">
        <Label htmlFor="title">Title *</Label>
        <Input
          id="title"
          placeholder="e.g., Brand New iPhone 15 Pro Max"
          value={formData.title}
          onChange={(e) => handleChange('title', e.target.value)}
          maxLength={100}
        />
        <p className="text-xs text-muted-foreground text-right">
          {formData.title.length}/100
        </p>
      </div>

      {/* Description */}
      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          placeholder="Describe your item in detail..."
          value={formData.description}
          onChange={(e) => handleChange('description', e.target.value)}
          rows={5}
          maxLength={2000}
        />
        <p className="text-xs text-muted-foreground text-right">
          {formData.description.length}/2000
        </p>
      </div>

      {/* Category & Type */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="category">Category *</Label>
          <Select value={formData.category} onValueChange={(value) => handleChange('category', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="electronics">Electronics</SelectItem>
              <SelectItem value="furniture">Furniture</SelectItem>
              <SelectItem value="vehicles">Vehicles</SelectItem>
              <SelectItem value="real_estate">Real Estate</SelectItem>
              <SelectItem value="clothing">Clothing</SelectItem>
              <SelectItem value="books">Books</SelectItem>
              <SelectItem value="sports">Sports & Outdoors</SelectItem>
              <SelectItem value="tools">Tools & Equipment</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">Listing Type *</Label>
          <Select value={formData.type} onValueChange={(value: ListingType) => handleChange('type', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sell">For Sale</SelectItem>
              <SelectItem value="rent">For Rent</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Condition */}
      <div className="space-y-2">
        <Label htmlFor="condition">Condition *</Label>
        <Select value={formData.condition} onValueChange={(value: ListingCondition) => handleChange('condition', value)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="new">Brand New</SelectItem>
            <SelectItem value="like_new">Like New</SelectItem>
            <SelectItem value="excellent">Excellent</SelectItem>
            <SelectItem value="good">Good</SelectItem>
            <SelectItem value="fair">Fair</SelectItem>
            <SelectItem value="poor">Poor</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Price */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="price">
            Price (₹) * {formData.type === 'rent' && '(Per Period)'}
          </Label>
          <Input
            id="price"
            type="number"
            placeholder="0"
            value={formData.price}
            onChange={(e) => handleChange('price', e.target.value)}
            min="0"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity Available *</Label>
          <Input
            id="quantity"
            type="number"
            value={formData.quantity}
            onChange={(e) => handleChange('quantity', e.target.value)}
            min="1"
          />
        </div>
      </div>

      {/* Rental-specific fields */}
      <AnimatePresence>
        {formData.type === 'rent' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="space-y-2">
              <Label htmlFor="rentalPeriod">Rental Period *</Label>
              <Select value={formData.rentalPeriod} onValueChange={(value: RentalPeriod) => handleChange('rentalPeriod', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Per Hour</SelectItem>
                  <SelectItem value="daily">Per Day</SelectItem>
                  <SelectItem value="weekly">Per Week</SelectItem>
                  <SelectItem value="monthly">Per Month</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="rentalDeposit">Security Deposit (₹)</Label>
              <Input
                id="rentalDeposit"
                type="number"
                placeholder="Optional"
                value={formData.rentalDeposit}
                onChange={(e) => handleChange('rentalDeposit', e.target.value)}
                min="0"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Location */}
      <div className="space-y-2">
        <Label htmlFor="location">Location *</Label>
        <Input
          id="location"
          placeholder="e.g., Mumbai, Maharashtra"
          value={formData.location}
          onChange={(e) => handleChange('location', e.target.value)}
        />
      </div>

      {/* Tags */}
      <div className="space-y-2">
        <Label htmlFor="tags">Tags (comma-separated)</Label>
        <Input
          id="tags"
          placeholder="e.g., smartphone, apple, latest, warranty"
          value={formData.tags}
          onChange={(e) => handleChange('tags', e.target.value)}
        />
        <p className="text-xs text-muted-foreground">
          Add keywords to help buyers find your listing
        </p>
      </div>

      {/* Actions */}
      <div className="flex gap-4 pt-4">
        <Button type="submit" disabled={loading} className="flex-1">
          {loading ? 'Saving...' : initialData?.id ? 'Update Listing' : 'Create Listing'}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
      </div>
    </form>
  )
}
