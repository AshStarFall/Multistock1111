"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Heart,
  MapPin,
  Eye,
  ShieldCheck,
  Star,
  Clock
} from 'lucide-react'
import {
  type MarketplaceListing,
  getListingTypeLabel,
  getConditionLabel,
  getRentalPeriodLabel,
  formatCurrency,
  getTimeAgo,
  getSellerTierColor
} from '@/lib/marketplace'

interface ListingCardProps {
  listing: MarketplaceListing
  onView?: (listing: MarketplaceListing) => void
  onFavorite?: (listingId: string) => void
}

export default function ListingCard({ listing, onView, onFavorite }: ListingCardProps) {
  const [isFavorited, setIsFavorited] = useState(false)
  const [imageError, setImageError] = useState(false)

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsFavorited(!isFavorited)
    onFavorite?.(listing.id)
  }

  const handleClick = () => {
    onView?.(listing)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow" onClick={handleClick}>
        {/* Image */}
        <div className="relative aspect-[4/3] bg-slate-100 dark:bg-slate-800">
          {listing.images[0] && !imageError ? (
            <img
              src={listing.images[0]}
              alt={listing.title}
              className="w-full h-full object-cover"
              onError={() => setImageError(true)}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-4xl">📦</span>
            </div>
          )}
          
          {/* Featured Badge */}
          {listing.featuredUntil && new Date(listing.featuredUntil) > new Date() && (
            <Badge className="absolute top-2 left-2 bg-amber-500 text-white">
              ⭐ Featured
            </Badge>
          )}

          {/* Type Badge */}
          <Badge className="absolute top-2 right-2 bg-white/90 dark:bg-slate-900/90">
            {getListingTypeLabel(listing.type)}
          </Badge>

          {/* Favorite Button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute bottom-2 right-2 bg-white/90 dark:bg-slate-900/90 hover:bg-white"
            onClick={handleFavorite}
          >
            <Heart
              className={`w-4 h-4 ${
                isFavorited ? 'fill-red-500 text-red-500' : 'text-slate-600'
              }`}
            />
          </Button>
        </div>

        <CardContent className="p-4 space-y-3">
          {/* Title & Price */}
          <div>
            <h3 className="font-semibold text-lg line-clamp-1">{listing.title}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {formatCurrency(listing.price, listing.currency)}
              </span>
              {listing.type === 'rent' && listing.rentalPeriod && (
                <span className="text-sm text-muted-foreground">
                  {getRentalPeriodLabel(listing.rentalPeriod)}
                </span>
              )}
            </div>
          </div>

          {/* Condition */}
          <Badge variant="outline" className="w-fit">
            {getConditionLabel(listing.condition)}
          </Badge>

          {/* Seller Info */}
          <div className="flex items-center gap-2 pt-2 border-t">
            <Avatar className="w-8 h-8">
              <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${listing.sellerName}`} />
              <AvatarFallback>{listing.sellerName[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-sm font-medium truncate">{listing.sellerName}</span>
                {listing.sellerVerified && (
                  <ShieldCheck className="w-3 h-3 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span>{listing.sellerRating.toFixed(1)}</span>
                <Badge className={`ml-1 text-xs ${getSellerTierColor(listing.sellerTier)}`}>
                  {listing.sellerTier}
                </Badge>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2">
            <div className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              <span>{listing.views}</span>
            </div>
            <div className="flex items-center gap-1">
              <Heart className="w-3 h-3" />
              <span>{listing.favorites}</span>
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span className="truncate">{listing.location}</span>
            </div>
          </div>

          {/* Time */}
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{getTimeAgo(listing.createdAt)}</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
