"use client"

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Package,
  Star,
  TrendingUp,
  Eye,
  Heart,
  DollarSign,
  Calendar,
  Crown,
  Plus
} from 'lucide-react'
import { type SellerSubscription, formatCurrency, getSellerTierColor } from '@/lib/marketplace'

interface SellerDashboardProps {
  subscription: SellerSubscription
  stats: {
    activeListings: number
    totalViews: number
    totalFavorites: number
    totalSales: number
    revenue: number
    averageRating: number
  }
  onCreateListing?: () => void
  onUpgrade?: () => void
}

export default function SellerDashboard({ 
  subscription, 
  stats, 
  onCreateListing, 
  onUpgrade 
}: SellerDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview')

  const listingsPercentage = subscription.listingsLimit === -1 
    ? 0 
    : (subscription.listingsUsed / subscription.listingsLimit) * 100

  const featuredPercentage = subscription.featuredListingsLimit === -1 
    ? 0 
    : (subscription.featuredListingsUsed / subscription.featuredListingsLimit) * 100

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Seller Dashboard</h1>
          <p className="text-muted-foreground">Manage your marketplace listings</p>
        </div>
        <Button onClick={onCreateListing}>
          <Plus className="w-4 h-4 mr-2" />
          Create Listing
        </Button>
      </div>

      {/* Subscription Card */}
      <Card className="border-2 border-purple-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Crown className="w-6 h-6 text-purple-600" />
              <div>
                <CardTitle>
                  {subscription.tier.charAt(0).toUpperCase() + subscription.tier.slice(1)} Plan
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Active until {new Date(subscription.endDate).toLocaleDateString()}
                </p>
              </div>
            </div>
            {subscription.tier !== 'enterprise' && (
              <Button onClick={onUpgrade} variant="outline">
                Upgrade Plan
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Listings Usage */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Active Listings</span>
              <span className="font-medium">
                {subscription.listingsUsed} / {subscription.listingsLimit === -1 ? '∞' : subscription.listingsLimit}
              </span>
            </div>
            {subscription.listingsLimit !== -1 && (
              <Progress value={listingsPercentage} className="h-2" />
            )}
          </div>

          {/* Featured Listings Usage */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Featured Listings</span>
              <span className="font-medium">
                {subscription.featuredListingsUsed} / {subscription.featuredListingsLimit === -1 ? '∞' : subscription.featuredListingsLimit}
              </span>
            </div>
            {subscription.featuredListingsLimit !== -1 && (
              <Progress value={featuredPercentage} className="h-2" />
            )}
          </div>

          {/* Commission Rate */}
          <div className="flex items-center justify-between text-sm pt-2 border-t">
            <span className="text-muted-foreground">Commission Rate</span>
            <Badge className="bg-green-100 text-green-700">
              {subscription.commissionRate}%
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalViews.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Across all listings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Favorites</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalFavorites.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Items favorited</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</div>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-3 h-3 ${
                    star <= Math.round(stats.averageRating)
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-slate-300'
                  }`}
                />
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeListings}</div>
            <p className="text-xs text-muted-foreground">Currently published</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalSales}</div>
            <p className="text-xs text-muted-foreground">Items sold</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.revenue)}</div>
            <p className="text-xs text-muted-foreground">Before commissions</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity / Listings Tabs */}
      <Card>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <CardHeader>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="listings">My Listings</TabsTrigger>
              <TabsTrigger value="sales">Sales History</TabsTrigger>
            </TabsList>
          </CardHeader>
          <CardContent>
            <TabsContent value="overview" className="space-y-4">
              <div className="text-center py-8 text-muted-foreground">
                <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Your recent activity will appear here</p>
              </div>
            </TabsContent>
            
            <TabsContent value="listings" className="space-y-4">
              <div className="text-center py-8 text-muted-foreground">
                <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No listings yet</p>
                <Button onClick={onCreateListing} className="mt-4" variant="outline">
                  Create Your First Listing
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="sales" className="space-y-4">
              <div className="text-center py-8 text-muted-foreground">
                <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No sales yet</p>
              </div>
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
    </div>
  )
}
