"use client"

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Check } from 'lucide-react'
import { SUBSCRIPTION_PLANS, formatCurrency, type SellerTier } from '@/lib/marketplace'

interface SubscriptionPlansProps {
  currentTier?: SellerTier
  onSelectPlan?: (tier: SellerTier) => void
}

export default function SubscriptionPlans({ currentTier, onSelectPlan }: SubscriptionPlansProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {SUBSCRIPTION_PLANS.map((plan, index) => (
        <motion.div
          key={plan.tier}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className={`relative ${
            plan.popular 
              ? 'border-2 border-purple-500 shadow-lg' 
              : currentTier === plan.tier
              ? 'border-2 border-blue-500'
              : ''
          }`}>
            {plan.popular && (
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-500">
                Most Popular
              </Badge>
            )}
            
            {currentTier === plan.tier && (
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-500">
                Current Plan
              </Badge>
            )}

            <CardHeader className="text-center">
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <CardDescription className="text-sm">
                {plan.tier.charAt(0).toUpperCase() + plan.tier.slice(1)} seller tier
              </CardDescription>
              <div className="pt-4">
                <div className="text-4xl font-bold">
                  {plan.price === 0 ? 'Free' : formatCurrency(plan.price)}
                </div>
                <div className="text-sm text-muted-foreground">
                  per {plan.billingPeriod === 'monthly' ? 'month' : 'year'}
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Key Stats */}
              <div className="space-y-2 pb-4 border-b">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Active Listings:</span>
                  <span className="font-semibold">
                    {plan.listingsLimit === -1 ? 'Unlimited' : plan.listingsLimit}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Featured:</span>
                  <span className="font-semibold">
                    {plan.featuredListingsLimit === -1 ? 'Unlimited' : plan.featuredListingsLimit}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Commission:</span>
                  <span className="font-semibold text-green-600">
                    {plan.commissionRate}%
                  </span>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-2">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              {/* CTA Button */}
              <Button
                className="w-full mt-4"
                variant={plan.popular ? 'default' : currentTier === plan.tier ? 'outline' : 'outline'}
                disabled={currentTier === plan.tier}
                onClick={() => onSelectPlan?.(plan.tier)}
              >
                {currentTier === plan.tier 
                  ? 'Current Plan' 
                  : currentTier && SUBSCRIPTION_PLANS.findIndex(p => p.tier === currentTier) < SUBSCRIPTION_PLANS.findIndex(p => p.tier === plan.tier)
                  ? 'Upgrade'
                  : plan.tier === 'free'
                  ? 'Start Free'
                  : 'Select Plan'}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
