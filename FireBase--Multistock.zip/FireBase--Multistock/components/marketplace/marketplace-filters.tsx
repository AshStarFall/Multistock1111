"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Slider } from '@/components/ui/slider'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger
} from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import { Filter, X } from 'lucide-react'
import { type MarketplaceFilters, type ListingType, type ListingCondition } from '@/lib/marketplace'

interface MarketplaceFiltersProps {
  filters: MarketplaceFilters
  onFiltersChange: (filters: MarketplaceFilters) => void
}

export default function MarketplaceFiltersComponent({ filters, onFiltersChange }: MarketplaceFiltersProps) {
  const [localFilters, setLocalFilters] = useState<MarketplaceFilters>(filters)
  const [priceRange, setPriceRange] = useState<[number, number]>([
    filters.minPrice || 0,
    filters.maxPrice || 100000
  ])

  const handleApply = () => {
    onFiltersChange({
      ...localFilters,
      minPrice: priceRange[0],
      maxPrice: priceRange[1]
    })
  }

  const handleReset = () => {
    const resetFilters: MarketplaceFilters = {}
    setLocalFilters(resetFilters)
    setPriceRange([0, 100000])
    onFiltersChange(resetFilters)
  }

  const activeFilterCount = Object.keys(filters).length

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" className="relative">
          <Filter className="w-4 h-4 mr-2" />
          Filters
          {activeFilterCount > 0 && (
            <Badge className="ml-2 bg-blue-600">{activeFilterCount}</Badge>
          )}
        </Button>
      </SheetTrigger>
      
      <SheetContent className="w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Filter Listings</SheetTitle>
          <SheetDescription>
            Refine your search to find exactly what you need
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 py-6">
          {/* Listing Type */}
          <div className="space-y-2">
            <Label>Listing Type</Label>
            <Select 
              value={localFilters.type || 'all'} 
              onValueChange={(value) => setLocalFilters(prev => ({ 
                ...prev, 
                type: value === 'all' ? undefined : value as ListingType 
              }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="All types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="sell">For Sale</SelectItem>
                <SelectItem value="rent">For Rent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label>Category</Label>
            <Select 
              value={localFilters.category || 'all'} 
              onValueChange={(value) => setLocalFilters(prev => ({ 
                ...prev, 
                category: value === 'all' ? undefined : value 
              }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                <SelectItem value="electronics">Electronics</SelectItem>
                <SelectItem value="furniture">Furniture</SelectItem>
                <SelectItem value="vehicles">Vehicles</SelectItem>
                <SelectItem value="real_estate">Real Estate</SelectItem>
                <SelectItem value="clothing">Clothing</SelectItem>
                <SelectItem value="books">Books</SelectItem>
                <SelectItem value="sports">Sports & Outdoors</SelectItem>
                <SelectItem value="tools">Tools & Equipment</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Price Range */}
          <div className="space-y-4">
            <Label>Price Range (₹)</Label>
            <div className="px-2">
              <Slider
                min={0}
                max={100000}
                step={1000}
                value={priceRange}
                onValueChange={(value) => setPriceRange(value as [number, number])}
                className="w-full"
              />
            </div>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <Label className="text-xs text-muted-foreground">Min</Label>
                <Input
                  type="number"
                  value={priceRange[0]}
                  onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                  className="mt-1"
                />
              </div>
              <div className="pt-6">-</div>
              <div className="flex-1">
                <Label className="text-xs text-muted-foreground">Max</Label>
                <Input
                  type="number"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                  className="mt-1"
                />
              </div>
            </div>
          </div>

          {/* Condition */}
          <div className="space-y-2">
            <Label>Condition</Label>
            <Select 
              value={localFilters.condition || 'all'} 
              onValueChange={(value) => setLocalFilters(prev => ({ 
                ...prev, 
                condition: value === 'all' ? undefined : value as ListingCondition 
              }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Any condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any condition</SelectItem>
                <SelectItem value="new">Brand New</SelectItem>
                <SelectItem value="like_new">Like New</SelectItem>
                <SelectItem value="excellent">Excellent</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label>Location</Label>
            <Input
              placeholder="e.g., Mumbai"
              value={localFilters.location || ''}
              onChange={(e) => setLocalFilters(prev => ({ 
                ...prev, 
                location: e.target.value || undefined 
              }))}
            />
          </div>

          {/* Verified Only */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="verified"
              checked={localFilters.verifiedOnly || false}
              onCheckedChange={(checked) => setLocalFilters(prev => ({ 
                ...prev, 
                verifiedOnly: checked ? true : undefined 
              }))}
            />
            <Label htmlFor="verified" className="cursor-pointer">
              Show only verified sellers
            </Label>
          </div>

          {/* Sort By */}
          <div className="space-y-2">
            <Label>Sort By</Label>
            <Select 
              value={localFilters.sortBy || 'newest'} 
              onValueChange={(value: any) => setLocalFilters(prev => ({ 
                ...prev, 
                sortBy: value 
              }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="price_low">Price: Low to High</SelectItem>
                <SelectItem value="price_high">Price: High to Low</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-4 pt-4 border-t">
          <Button onClick={handleReset} variant="outline" className="flex-1">
            Reset
          </Button>
          <Button onClick={handleApply} className="flex-1">
            Apply Filters
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
