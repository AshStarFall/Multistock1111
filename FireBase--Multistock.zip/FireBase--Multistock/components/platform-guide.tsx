"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import {
  Package,
  ShoppingCart,
  FileText,
  BarChart3,
  Warehouse,
  Users,
  Truck,
  Settings,
  ChevronDown,
  ChevronRight,
  BookOpen,
  Video,
  ExternalLink,
  Calendar,
  Lightbulb,
  Rocket,
  CheckCircle2,
  Clock,
} from "lucide-react"
import Link from "next/link"

interface Module {
  name: string
  icon: any
  description: string
  features: string[]
  docLink: string
  tutorialLink?: string
}

interface RoadmapItem {
  title: string
  description: string
  status: "completed" | "in-progress" | "planned"
  quarter: string
  icon: any
}

const modules: Module[] = [
  {
    name: "Inventory Management",
    icon: Package,
    description: "Track stock levels, manage products, and monitor inventory across multiple warehouses",
    features: [
      "Real-time stock tracking",
      "Low stock alerts",
      "Multi-warehouse support",
      "Batch & serial number tracking",
      "Product categorization",
    ],
    docLink: "/inventory",
    tutorialLink: "#",
  },
  {
    name: "Sales & Purchase Orders",
    icon: ShoppingCart,
    description: "Create, manage, and track orders with automated workflows",
    features: [
      "Order creation & processing",
      "Invoice generation",
      "Payment tracking",
      "Order history & analytics",
      "Customer & supplier management",
    ],
    docLink: "/sales-orders",
    tutorialLink: "#",
  },
  {
    name: "Reports & Analytics",
    icon: BarChart3,
    description: "Comprehensive insights and data visualization for informed decision-making",
    features: [
      "Sales performance metrics",
      "Inventory turnover analysis",
      "Custom report builder",
      "Export to Excel/PDF",
      "Real-time dashboards",
    ],
    docLink: "/reports",
    tutorialLink: "#",
  },
  {
    name: "Warehouse Management",
    icon: Warehouse,
    description: "Organize and optimize warehouse operations with 3D visualization",
    features: [
      "Multiple warehouse support",
      "Location tracking",
      "3D warehouse visualization",
      "Stock movements",
      "Transfer management",
    ],
    docLink: "/warehouses",
    tutorialLink: "#",
  },
  {
    name: "User & Role Management",
    icon: Users,
    description: "Control access, permissions, and user workflows",
    features: [
      "Role-based access control",
      "User activity tracking",
      "Custom permissions",
      "Team collaboration tools",
      "Audit logs",
    ],
    docLink: "/admin/role-access",
    tutorialLink: "#",
  },
  {
    name: "Rentals & Storage",
    icon: Truck,
    description: "Manage rental agreements, bookings, and storage lockers",
    features: [
      "Rental agreements",
      "Booking calendar",
      "Locker management",
      "Payment scheduling",
      "Contract templates",
    ],
    docLink: "/rentals",
    tutorialLink: "#",
  },
]

const roadmap: RoadmapItem[] = [
  {
    title: "AI-Powered Demand Forecasting",
    description: "Predict stock requirements using machine learning algorithms",
    status: "completed",
    quarter: "Q4 2024",
    icon: Lightbulb,
  },
  {
    title: "Mobile App Launch",
    description: "iOS & Android apps for on-the-go inventory management",
    status: "in-progress",
    quarter: "Q1 2025",
    icon: Rocket,
  },
  {
    title: "Multi-Currency Support",
    description: "Handle international transactions with automatic conversion",
    status: "in-progress",
    quarter: "Q1 2025",
    icon: Clock,
  },
  {
    title: "Barcode Scanning Integration",
    description: "Quick product lookup and stock updates via barcode/QR codes",
    status: "planned",
    quarter: "Q2 2025",
    icon: Package,
  },
  {
    title: "Advanced Analytics Dashboard",
    description: "Predictive analytics, trend forecasting, and custom KPIs",
    status: "planned",
    quarter: "Q2 2025",
    icon: BarChart3,
  },
  {
    title: "Supplier Portal",
    description: "Self-service portal for suppliers to manage orders and invoices",
    status: "planned",
    quarter: "Q3 2025",
    icon: Users,
  },
]

export function PlatformGuide() {
  const [openModules, setOpenModules] = useState<Set<string>>(new Set())

  const toggleModule = (moduleName: string) => {
    const newSet = new Set(openModules)
    if (newSet.has(moduleName)) {
      newSet.delete(moduleName)
    } else {
      newSet.add(moduleName)
    }
    setOpenModules(newSet)
  }

  const getStatusColor = (status: RoadmapItem["status"]) => {
    switch (status) {
      case "completed":
        return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
      case "in-progress":
        return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
      case "planned":
        return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400"
    }
  }

  const getStatusIcon = (status: RoadmapItem["status"]) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="w-4 h-4" />
      case "in-progress":
        return <Clock className="w-4 h-4 animate-pulse" />
      case "planned":
        return <Calendar className="w-4 h-4" />
    }
  }

  return (
    <Card className="border-0 shadow-lg bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center">
          <BookOpen className="w-6 h-6 mr-2 text-indigo-600" />
          Platform Project Guide
        </CardTitle>
        <p className="text-sm text-muted-foreground mt-2">
          Comprehensive overview of MultiStock's architecture, features, and development roadmap
        </p>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="modules" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="modules" className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              Modules
            </TabsTrigger>
            <TabsTrigger value="roadmap" className="flex items-center gap-2">
              <Rocket className="w-4 h-4" />
              Roadmap
            </TabsTrigger>
            <TabsTrigger value="resources" className="flex items-center gap-2">
              <Video className="w-4 h-4" />
              Resources
            </TabsTrigger>
          </TabsList>

          <TabsContent value="modules" className="mt-6 space-y-4">
            {modules.map((module) => {
              const Icon = module.icon
              const isOpen = openModules.has(module.name)

              return (
                <Collapsible
                  key={module.name}
                  open={isOpen}
                  onOpenChange={() => toggleModule(module.name)}
                >
                  <CollapsibleTrigger asChild>
                    <div className="group cursor-pointer p-4 rounded-xl border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg group-hover:scale-110 transition-transform duration-300">
                            <Icon className="w-6 h-6" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg mb-1 group-hover:text-indigo-600 transition-colors">
                              {module.name}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {module.description}
                            </p>
                          </div>
                        </div>
                        {isOpen ? (
                          <ChevronDown className="w-5 h-5 text-slate-400 transition-transform" />
                        ) : (
                          <ChevronRight className="w-5 h-5 text-slate-400 transition-transform" />
                        )}
                      </div>
                    </div>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="mt-2 pl-4">
                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                      <h4 className="font-semibold text-sm mb-3 flex items-center">
                        <Lightbulb className="w-4 h-4 mr-2 text-amber-500" />
                        Key Features
                      </h4>
                      <ul className="space-y-2 mb-4">
                        {module.features.map((feature, idx) => (
                          <li
                            key={idx}
                            className="flex items-center text-sm text-slate-700 dark:text-slate-300"
                          >
                            <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-500 shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <div className="flex gap-2">
                        <Link href={module.docLink}>
                          <Button variant="outline" size="sm" className="gap-2">
                            <ExternalLink className="w-4 h-4" />
                            Open Module
                          </Button>
                        </Link>
                        {module.tutorialLink && (
                          <Button variant="ghost" size="sm" className="gap-2">
                            <Video className="w-4 h-4" />
                            Watch Tutorial
                          </Button>
                        )}
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              )
            })}
          </TabsContent>

          <TabsContent value="roadmap" className="mt-6 space-y-4">
            <div className="space-y-3">
              {roadmap.map((item, idx) => {
                const Icon = item.icon
                return (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border-2 border-border bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start space-x-3">
                        <div className="p-2 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 text-white">
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-base mb-1">{item.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {item.description}
                          </p>
                        </div>
                      </div>
                      <Badge className={`gap-1.5 ${getStatusColor(item.status)}`}>
                        {getStatusIcon(item.status)}
                        {item.status.replace("-", " ")}
                      </Badge>
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3 mr-1" />
                      {item.quarter}
                    </div>
                  </div>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="resources" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link href="/docs/getting-started">
                <div className="p-6 rounded-xl border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 cursor-pointer bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-lg group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <h3 className="font-semibold text-base group-hover:text-indigo-600 transition-colors">
                      Getting Started Guide
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Complete onboarding tutorial for new users
                  </p>
                </div>
              </Link>

              <Link href="/docs/video-tutorials">
                <div className="p-6 rounded-xl border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 cursor-pointer bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-lg group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 text-white">
                      <Video className="w-5 h-5" />
                    </div>
                    <h3 className="font-semibold text-base group-hover:text-indigo-600 transition-colors">
                      Video Tutorials
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Step-by-step video walkthroughs for each module
                  </p>
                </div>
              </Link>

              <Link href="/docs/api">
                <div className="p-6 rounded-xl border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 cursor-pointer bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-lg group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 text-white">
                      <Settings className="w-5 h-5" />
                    </div>
                    <h3 className="font-semibold text-base group-hover:text-indigo-600 transition-colors">
                      API Documentation
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Developer reference for integration and automation
                  </p>
                </div>
              </Link>

              <Link href="/support">
                <div className="p-6 rounded-xl border-2 border-border hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-300 cursor-pointer bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-lg group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-orange-500 to-red-600 text-white">
                      <Users className="w-5 h-5" />
                    </div>
                    <h3 className="font-semibold text-base group-hover:text-indigo-600 transition-colors">
                      Community & Support
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Get help from our community and support team
                  </p>
                </div>
              </Link>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
