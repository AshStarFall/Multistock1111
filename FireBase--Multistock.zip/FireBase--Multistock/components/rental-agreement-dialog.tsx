"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { createAgreement, listAgreementsByItem, type PricingModel } from "@/lib/agreements"
import { calculatePrice } from "@/lib/pricing"

export function RentalAgreementDialog({ itemId }: { itemId: string }) {
  const [open, setOpen] = useState(false)
  const [customer, setCustomer] = useState("")
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [pricingModel, setPricingModel] = useState<PricingModel>("fixed")
  const [notes, setNotes] = useState("")
  const [quote, setQuote] = useState<number>(0)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!customer || !startDate) return
    createAgreement({ itemId, customer, startDate, endDate: endDate || undefined, pricingModel, notes: notes || undefined })
    setOpen(false)
  }

  const history = listAgreementsByItem(itemId)

  function recomputeQuote(s: string, e: string, model: PricingModel) {
    if (!s) {
      setQuote(0)
      return
    }
    const sDate = new Date(s)
    const eDate = e ? new Date(e) : new Date(sDate.getTime() + 24 * 60 * 60 * 1000)
    const days = Math.max(1, Math.ceil((eDate.getTime() - sDate.getTime()) / (24 * 60 * 60 * 1000)))
    const price = calculatePrice(model, days, {
      fixed: { ratePerDay: 100 },
      tiered: { tiers: [{ uptoDays: 3, ratePerDay: 90 }, { uptoDays: 7, ratePerDay: 80 }], overflowRatePerDay: 70 },
      subscription: { monthly: 300, includedDaysPerMonth: 10, overageRatePerDay: 20 },
      rent_to_own: { daily: 15, maxCap: 600 },
    })
    setQuote(price)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary">Agreement</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Rental Agreement</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4">
          <form onSubmit={submit} className="grid gap-3">
            <div>
              <label className="block text-xs mb-1">Customer</label>
              <Input value={customer} onChange={(e) => setCustomer(e.target.value)} required />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs mb-1">Start date</label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => {
                    const v = e.target.value
                    setStartDate(v)
                    recomputeQuote(v, endDate, pricingModel)
                  }}
                  required
                />
              </div>
              <div>
                <label className="block text-xs mb-1">End date</label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => {
                    const v = e.target.value
                    setEndDate(v)
                    recomputeQuote(startDate, v, pricingModel)
                  }}
                />
              </div>
            </div>
            <div>
              <label className="block text-xs mb-1">Pricing model</label>
              <select
                className="border rounded-md text-sm h-9 px-2 bg-background w-full"
                value={pricingModel}
                onChange={(e) => {
                  const pm = e.target.value as PricingModel
                  setPricingModel(pm)
                  recomputeQuote(startDate, endDate, pm)
                }}
              >
                <option value="fixed">Fixed</option>
                <option value="tiered">Tiered</option>
                <option value="subscription">Subscription</option>
                <option value="rent_to_own">Rent to own</option>
              </select>
            </div>
            <div>
              <label className="block text-xs mb-1">Notes</label>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">Estimated total:</span> ${quote.toFixed(2)}
            </div>
            <div className="flex justify-end gap-2">
              <Button type="submit">Save</Button>
            </div>
          </form>

          <div>
            <div className="text-sm font-medium mb-1">History</div>
            {history.length === 0 ? (
              <div className="text-xs text-muted-foreground">No agreements yet.</div>
            ) : (
              <ul className="space-y-1 text-xs">
                {history.map((h) => (
                  <li key={h.id} className="border rounded p-2">
                    <div>{h.customer}</div>
                    <div className="text-muted-foreground">{h.startDate} → {h.endDate ?? "open"} • {h.pricingModel}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}


