"use client"

import React from "react"
import { cn } from "@/lib/utils"

type IconType = React.ComponentType<{ className?: string }>

interface PageHeaderProps {
  title: string
  description?: string
  icon?: IconType
  actions?: React.ReactNode
  className?: string
  titleClassName?: string
}

export function PageHeader({
  title,
  description,
  icon: Icon,
  actions,
  className,
  titleClassName,
}: PageHeaderProps) {
  return (
    <div className={cn("flex items-start md:items-center justify-between gap-4", className)}>
      <div className="flex items-start gap-3">
        {Icon && (
          <div className="mt-1 hidden sm:block">
            <Icon className="w-8 h-8 text-primary" />
          </div>
        )}
        <div>
          <h1 className={cn("text-3xl font-bold", titleClassName)}>{title}</h1>
          {description && (
            <p className="text-muted-foreground mt-1">{description}</p>
          )}
        </div>
      </div>
      {actions && (
        <div className="flex items-center gap-2 flex-wrap justify-end">{actions}</div>
      )}
    </div>
  )
}

export default PageHeader
