'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { Command } from 'cmdk'
import {
  Search,
  Package,
  ShoppingCart,
  Users,
  Warehouse,
  TrendingUp,
  FileText,
  Settings,
  Bell,
  CreditCard,
  BarChart3,
  Calendar,
  DollarSign,
  Truck,
  Box,
  AlertCircle,
} from 'lucide-react'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { useEffect, useState, useCallback } from 'react'
import { cn } from '@/lib/utils'

interface CommandItem {
  id: string
  label: string
  description?: string
  icon: React.ReactNode
  action: () => void
  group: string
  keywords?: string[]
}

export function CommandPalette() {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const router = useRouter()

  // Command+K or Ctrl+K to open
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setOpen((open) => !open)
      }
    }

    document.addEventListener('keydown', down)
    return () => document.removeEventListener('keydown', down)
  }, [])

  const navigate = useCallback((path: string) => {
    setOpen(false)
    router.push(path)
  }, [router])

  const commands: CommandItem[] = [
    // Navigation
    {
      id: 'nav-dashboard',
      label: 'Dashboard',
      description: 'Go to dashboard',
      icon: <BarChart3 className="w-4 h-4" />,
      action: () => navigate('/dashboard'),
      group: 'Navigation',
      keywords: ['home', 'overview', 'main'],
    },
    {
      id: 'nav-products',
      label: 'Products',
      description: 'Manage products',
      icon: <Package className="w-4 h-4" />,
      action: () => navigate('/admin/products'),
      group: 'Navigation',
      keywords: ['items', 'inventory', 'stock'],
    },
    {
      id: 'nav-orders',
      label: 'Sales Orders',
      description: 'View sales orders',
      icon: <ShoppingCart className="w-4 h-4" />,
      action: () => navigate('/sales-orders'),
      group: 'Navigation',
      keywords: ['sales', 'purchases', 'transactions'],
    },
    {
      id: 'nav-purchase-orders',
      label: 'Purchase Orders',
      description: 'View purchase orders',
      icon: <FileText className="w-4 h-4" />,
      action: () => navigate('/purchase-orders'),
      group: 'Navigation',
      keywords: ['buying', 'procurement', 'suppliers'],
    },
    {
      id: 'nav-inventory',
      label: 'Inventory',
      description: 'Check inventory',
      icon: <Box className="w-4 h-4" />,
      action: () => navigate('/inventory'),
      group: 'Navigation',
      keywords: ['stock', 'items', 'warehouse'],
    },
    {
      id: 'nav-warehouses',
      label: 'Warehouses',
      description: 'Manage warehouses',
      icon: <Warehouse className="w-4 h-4" />,
      action: () => navigate('/warehouses'),
      group: 'Navigation',
      keywords: ['locations', 'storage', 'facilities'],
    },
    {
      id: 'nav-suppliers',
      label: 'Suppliers',
      description: 'Manage suppliers',
      icon: <Truck className="w-4 h-4" />,
      action: () => navigate('/suppliers'),
      group: 'Navigation',
      keywords: ['vendors', 'contacts', 'providers'],
    },
    {
      id: 'nav-analytics',
      label: 'Analytics',
      description: 'View analytics',
      icon: <TrendingUp className="w-4 h-4" />,
      action: () => navigate('/analytics'),
      group: 'Navigation',
      keywords: ['reports', 'insights', 'metrics', 'statistics'],
    },
    {
      id: 'nav-reports',
      label: 'Reports',
      description: 'Generate reports',
      icon: <FileText className="w-4 h-4" />,
      action: () => navigate('/reports'),
      group: 'Navigation',
      keywords: ['export', 'pdf', 'excel', 'documents'],
    },
    {
      id: 'nav-payments',
      label: 'Payments',
      description: 'View payments',
      icon: <CreditCard className="w-4 h-4" />,
      action: () => navigate('/payments'),
      group: 'Navigation',
      keywords: ['transactions', 'billing', 'invoices'],
    },
    {
      id: 'nav-alerts',
      label: 'Alerts',
      description: 'View alerts',
      icon: <AlertCircle className="w-4 h-4" />,
      action: () => navigate('/alerts'),
      group: 'Navigation',
      keywords: ['notifications', 'warnings', 'low stock'],
    },
    {
      id: 'nav-bookings',
      label: 'Bookings',
      description: 'Manage bookings',
      icon: <Calendar className="w-4 h-4" />,
      action: () => navigate('/bookings'),
      group: 'Navigation',
      keywords: ['reservations', 'appointments', 'schedule'],
    },
    {
      id: 'nav-rentals',
      label: 'Rentals',
      description: 'Manage rentals',
      icon: <DollarSign className="w-4 h-4" />,
      action: () => navigate('/rentals'),
      group: 'Navigation',
      keywords: ['leases', 'renting', 'agreements'],
    },
    {
      id: 'nav-settings',
      label: 'Settings',
      description: 'Open settings',
      icon: <Settings className="w-4 h-4" />,
      action: () => navigate('/settings'),
      group: 'Navigation',
      keywords: ['preferences', 'configuration', 'options'],
    },
    {
      id: 'nav-profile',
      label: 'Profile',
      description: 'View profile',
      icon: <Users className="w-4 h-4" />,
      action: () => navigate('/profile'),
      group: 'Navigation',
      keywords: ['account', 'user', 'personal'],
    },

    // Actions
    {
      id: 'action-new-product',
      label: 'Add New Product',
      description: 'Create a new product',
      icon: <Package className="w-4 h-4" />,
      action: () => {
        navigate('/admin/products')
        setTimeout(() => {
          document.getElementById('add-product-btn')?.click()
        }, 500)
      },
      group: 'Actions',
      keywords: ['create', 'new', 'item'],
    },
    {
      id: 'action-new-order',
      label: 'Create Sales Order',
      description: 'Create a new sales order',
      icon: <ShoppingCart className="w-4 h-4" />,
      action: () => {
        navigate('/sales-orders')
        setTimeout(() => {
          document.querySelector<HTMLElement>('[data-action="new-order"]')?.click()
        }, 500)
      },
      group: 'Actions',
      keywords: ['create', 'new', 'sale'],
    },
    {
      id: 'action-new-purchase',
      label: 'Create Purchase Order',
      description: 'Create a new purchase order',
      icon: <FileText className="w-4 h-4" />,
      action: () => {
        navigate('/purchase-orders')
        setTimeout(() => {
          document.querySelector<HTMLElement>('[data-action="new-purchase"]')?.click()
        }, 500)
      },
      group: 'Actions',
      keywords: ['create', 'new', 'buy'],
    },

    // Quick access
    {
      id: 'quick-notifications',
      label: 'Notifications',
      description: 'View all notifications',
      icon: <Bell className="w-4 h-4" />,
      action: () => {
        setOpen(false)
        document.querySelector<HTMLElement>('[data-notification-trigger]')?.click()
      },
      group: 'Quick Access',
      keywords: ['alerts', 'messages'],
    },
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="p-0 gap-0 max-w-2xl">
        <Command className="rounded-lg border-none shadow-2xl">
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <Command.Input
              placeholder="Type a command or search..."
              className="flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
              value={search}
              onValueChange={setSearch}
            />
            <kbd className="pointer-events-none ml-auto hidden h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100 sm:flex">
              <span className="text-xs">ESC</span>
            </kbd>
          </div>
          <Command.List className="max-h-[400px] overflow-y-auto p-2">
            <Command.Empty className="py-6 text-center text-sm text-muted-foreground">
              No results found.
            </Command.Empty>

            {['Navigation', 'Actions', 'Quick Access'].map((group) => {
              const groupCommands = commands.filter((c) => c.group === group)
              if (groupCommands.length === 0) return null

              return (
                <Command.Group key={group} heading={group} className="mb-2">
                  {groupCommands.map((command) => (
                    <Command.Item
                      key={command.id}
                      value={`${command.label} ${command.description} ${command.keywords?.join(' ')}`}
                      onSelect={() => command.action()}
                      className={cn(
                        'flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer',
                        'hover:bg-slate-100 dark:hover:bg-slate-800',
                        'data-[selected=true]:bg-slate-100 dark:data-[selected=true]:bg-slate-800',
                        'transition-colors'
                      )}
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-md bg-gradient-to-br from-indigo-500 to-violet-600 text-white">
                        {command.icon}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{command.label}</p>
                        {command.description && (
                          <p className="text-xs text-muted-foreground">
                            {command.description}
                          </p>
                        )}
                      </div>
                    </Command.Item>
                  ))}
                </Command.Group>
              )
            })}
          </Command.List>

          <div className="border-t px-3 py-2 text-xs text-muted-foreground">
            <div className="flex items-center justify-between">
              <span>Press</span>
              <div className="flex gap-2">
                <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium">
                  ↑↓
                </kbd>
                <span>to navigate</span>
                <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium">
                  ↵
                </kbd>
                <span>to select</span>
              </div>
            </div>
          </div>
        </Command>
      </DialogContent>
    </Dialog>
  )
}
