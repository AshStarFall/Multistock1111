"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { 
  Bell, 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  Truck, 
  Package,
  Clock,
  X
} from "lucide-react"
import { t } from "@/lib/i18n"
import Link from "next/link"

const mockNotifications = [
  {
    id: 1,
    type: "success",
    title: "New Order Received",
    message: "Order #12345 has been placed successfully",
    time: "2 minutes ago",
    icon: CheckCircle,
    unread: true
  },
  {
    id: 2,
    type: "info",
    title: "Delivery Completed",
    message: "Package delivered to customer in Mumbai",
    time: "15 minutes ago",
    icon: Truck,
    unread: true
  },
  {
    id: 3,
    type: "warning",
    title: "Low Stock Alert",
    message: "Product 'Thermal Labels' is running low",
    time: "1 hour ago",
    icon: AlertTriangle,
    unread: false
  },
  {
    id: 4,
    type: "info",
    title: "New Product Added",
    message: "5 new products added to inventory",
    time: "2 hours ago",
    icon: Package,
    unread: false
  },
  {
    id: 5,
    type: "info",
    title: "System Update",
    message: "Scheduled maintenance completed",
    time: "3 hours ago",
    icon: Info,
    unread: false
  }
]

export function NotificationsPopup() {
  const [isOpen, setIsOpen] = useState(false)
  const [notifications, setNotifications] = useState(mockNotifications)
  
  const unreadCount = notifications.filter(n => n.unread).length

  const markAsRead = (id: number) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, unread: false } : n)
    )
  }

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, unread: false }))
    )
  }

  const getIconColor = (type: string) => {
    switch (type) {
      case "success": return "text-green-600"
      case "warning": return "text-amber-600"
      case "info": return "text-blue-600"
      default: return "text-gray-600"
    }
  }

  const getBgColor = (type: string) => {
    switch (type) {
      case "success": return "bg-green-50 border-green-200"
      case "warning": return "bg-amber-50 border-amber-200"
      case "info": return "bg-blue-50 border-blue-200"
      default: return "bg-gray-50 border-gray-200"
    }
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold">
                {t("alerts")}
              </CardTitle>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={markAllAsRead}
                    className="text-xs h-6 px-2"
                  >
                    Mark all read
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="h-6 w-6 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-80 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  No notifications
                </div>
              ) : (
                <div className="space-y-1">
                  {notifications.slice(0, 5).map((notification) => {
                    const Icon = notification.icon
                    return (
                      <div
                        key={notification.id}
                        className={`p-3 border-l-4 cursor-pointer hover:bg-muted/50 transition-colors ${
                          notification.unread ? 'bg-muted/30' : ''
                        } ${getBgColor(notification.type)}`}
                        onClick={() => markAsRead(notification.id)}
                      >
                        <div className="flex items-start gap-3">
                          <Icon className={`h-4 w-4 mt-0.5 ${getIconColor(notification.type)}`} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-medium truncate">
                                {notification.title}
                              </p>
                              {notification.unread && (
                                <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0" />
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {notification.message}
                            </p>
                            <div className="flex items-center gap-1 mt-1">
                              <Clock className="h-3 w-3 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">
                                {notification.time}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
            
            {notifications.length > 0 && (
              <div className="border-t p-3">
                <Link href="/alerts">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setIsOpen(false)}
                  >
                    View All Notifications
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  )
}
