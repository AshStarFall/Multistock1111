-- Feature 14: Trending Sales
ALTER TABLE products ADD COLUMN IF NOT EXISTS sales_count INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS views_count INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS is_hot_deal BOOLEAN DEFAULT false;
ALTER TABLE products ADD COLUMN IF NOT EXISTS deal_ends_at TIMESTAMPTZ;
ALTER TABLE products ADD COLUMN IF NOT EXISTS original_price NUMERIC;
ALTER TABLE products ADD COLUMN IF NOT EXISTS discount_percentage INTEGER;

CREATE TABLE IF NOT EXISTS announcements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('info', 'success', 'warning', 'error', 'promotion')),
  priority TEXT NOT NULL CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ,
  link TEXT,
  link_text TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Feature 12: Verification System
CREATE TABLE IF NOT EXISTS verification_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  request_type TEXT NOT NULL CHECK (request_type IN ('individual', 'business')),
  status TEXT NOT NULL CHECK (status IN ('pending', 'under_review', 'approved', 'rejected', 'expired')),
  documents JSONB,
  business_name TEXT,
  business_type TEXT,
  tax_id TEXT,
  website TEXT,
  notes TEXT,
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID,
  reviewer_comments TEXT,
  trust_score INTEGER DEFAULT 0,
  verified_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ
);

-- Feature 13: Coupons & Discounts
CREATE TABLE IF NOT EXISTS coupons (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  type TEXT NOT NULL CHECK (type IN ('percentage', 'fixed_amount', 'free_shipping', 'bogo')),
  value NUMERIC NOT NULL,
  min_purchase_amount NUMERIC,
  max_discount_amount NUMERIC,
  usage_limit INTEGER NOT NULL,
  usage_count INTEGER DEFAULT 0,
  per_user_limit INTEGER,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('active', 'inactive', 'expired', 'depleted')),
  applicable_products TEXT[],
  applicable_categories TEXT[],
  excluded_products TEXT[],
  is_public BOOLEAN DEFAULT true,
  created_by UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coupon_usages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  coupon_id UUID NOT NULL REFERENCES coupons(id),
  coupon_code TEXT NOT NULL,
  user_id UUID NOT NULL,
  order_id UUID,
  discount_amount NUMERIC NOT NULL,
  used_at TIMESTAMPTZ DEFAULT NOW()
);

-- Feature 15: Expense Tracker
CREATE TABLE IF NOT EXISTS expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  category TEXT NOT NULL CHECK (category IN ('inventory', 'shipping', 'marketing', 'utilities', 'salaries', 'rent', 'equipment', 'taxes', 'maintenance', 'other')),
  amount NUMERIC NOT NULL,
  description TEXT NOT NULL,
  date DATE NOT NULL,
  payment_method TEXT,
  receipt_url TEXT,
  tags TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS budgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  category TEXT NOT NULL,
  budget_limit NUMERIC NOT NULL,
  period TEXT NOT NULL CHECK (period IN ('monthly', 'quarterly', 'yearly')),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  spent NUMERIC DEFAULT 0,
  remaining NUMERIC,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Performance Indexes (Create after tables are created)
-- For announcements
CREATE INDEX IF NOT EXISTS idx_announcements_active 
ON announcements(is_active, start_date, end_date) 
WHERE is_active = true;

-- For verification requests
CREATE INDEX IF NOT EXISTS idx_verification_user 
ON verification_requests(user_id, status);

-- For coupons
CREATE INDEX IF NOT EXISTS idx_coupons_code 
ON coupons(code);

CREATE INDEX IF NOT EXISTS idx_coupons_active 
ON coupons(status, start_date, end_date) 
WHERE status = 'active';

-- For coupon usages
CREATE INDEX IF NOT EXISTS idx_coupon_usages_user 
ON coupon_usages(user_id, coupon_id);

-- For expenses
CREATE INDEX IF NOT EXISTS idx_expenses_user_date 
ON expenses(user_id, date DESC);

CREATE INDEX IF NOT EXISTS idx_expenses_category 
ON expenses(category, date DESC);

-- For budgets
CREATE INDEX IF NOT EXISTS idx_budgets_user 
ON budgets(user_id, is_active) 
WHERE is_active = true;

CREATE INDEX IF NOT EXISTS idx_budgets_period 
ON budgets(category, start_date, end_date);
