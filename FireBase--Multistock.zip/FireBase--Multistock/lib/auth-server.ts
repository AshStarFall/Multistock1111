import { NextRequest } from 'next/server'
import { createJWT, verifyJWT, getTokenFromRequest, type JWTPayload } from './jwt'
import { hasPermission, type Permission, type Role } from './rbac'

export interface AuthUser {
  id: string
  email: string
  role: Role
  permissions: Permission[]
}

export async function getServerSession(request: NextRequest): Promise<AuthUser | null> {
  try {
    const token = getTokenFromRequest(request)
    if (!token) return null

    const payload = await verifyJWT(token)
    if (!payload) return null

    return {
      id: payload.userId,
      email: payload.email,
      role: payload.role as Role,
      permissions: payload.permissions
    }
  } catch {
    return null
  }
}

export async function createServerSession(user: AuthUser): Promise<string> {
  return await createJWT({
    userId: user.id,
    email: user.email,
    role: user.role,
    permissions: user.permissions
  })
}

export function requireAuth(request: NextRequest): AuthUser {
  const session = getServerSession(request)
  if (!session) {
    throw new Error('Authentication required')
  }
  return session as AuthUser
}

export function requirePermission(request: NextRequest, permission: Permission): AuthUser {
  const user = requireAuth(request)
  if (!hasPermission(user.role, permission)) {
    throw new Error(`Insufficient permissions. Required: ${permission}`)
  }
  return user
}

export function requireRole(request: NextRequest, allowedRoles: Role[]): AuthUser {
  const user = requireAuth(request)
  if (!allowedRoles.includes(user.role)) {
    throw new Error(`Insufficient role. Required: ${allowedRoles.join(' or ')}`)
  }
  return user
}
