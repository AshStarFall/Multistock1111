export type Warehouse = {
  id: string
  name: string
  code: string
  address?: string
}

export type Supplier = {
  id: string
  name: string
  email?: string
  phone?: string
}

export type Product = {
  id: string
  sku: string
  name: string
  category?: string
  unit: string
  cost: number
  price: number
  imageUrl?: string
  stockByWarehouse: Record<string, number> // warehouseId -> qty
  reorderPoint?: number
  supplierId?: string
  active: boolean
  updatedAt: string
}

// Rentals
export type RentalItem = {
  id: string
  equipmentId: string
  name: string
  imageUrl?: string
  category?: string
  rentedTo?: string
  returnDate?: string
  status: "available" | "in_use" | "overdue"
  pricePerDay?: number
  serialNumber?: string
}

export type RentalAgreement = {
  id: string
  itemId: string
  customerId: string
  startDate: string
  endDate?: string
  pricingModel: "fixed" | "tiered" | "subscription" | "rent_to_own"
  deposit?: number
  damaged?: boolean
  notes?: string
}

// Storage
export type StorageType = "shelf" | "pallet" | "locker" | "cold" | "bin" | "custom"

export type StorageSlot = {
  id: string
  type: StorageType
  size: string
  customer?: string
  status: "available" | "occupied" | "reserved"
  endDate?: string
}

// Lockers
export type Locker = {
  id: string
  status: "available" | "in_use" | "maintenance"
  lastUpdate: string
  passwordHint?: string
  customerId?: string
}

// Marketplace
export type MarketplaceAd = {
  id: string
  title: string
  description: string
  imageUrl?: string
  sellerId: string
  verified: boolean
}

export type Bid = {
  id: string
  resourceType: "rental" | "stock" | "storage" | "locker"
  resourceId: string
  bidderId: string
  pricePerHour: number
  placedAt: string
}

export type Subscription = {
  id: string
  customerId: string
  plan: "basic" | "pro" | "enterprise"
  status: "active" | "paused" | "cancelled"
  startedAt: string
  renewsAt?: string
}
