// Notification System Types and Utilities

export type NotificationType = 
  | 'order'
  | 'payment'
  | 'shipping'
  | 'return'
  | 'review'
  | 'message'
  | 'auction'
  | 'marketplace'
  | 'system'
  | 'alert'
  | 'promotion'
  | 'reminder'

export type NotificationPriority = 'low' | 'medium' | 'high' | 'urgent'

export interface Notification {
  id: string
  userId: string
  type: NotificationType
  priority: NotificationPriority
  title: string
  message: string
  icon?: string
  imageUrl?: string
  link?: string
  actionLabel?: string
  actionUrl?: string
  read: boolean
  archived: boolean
  createdAt: Date
  readAt?: Date
  expiresAt?: Date
  metadata?: Record<string, any>
}

export interface NotificationPreferences {
  userId: string
  emailNotifications: boolean
  pushNotifications: boolean
  smsNotifications: boolean
  categories: {
    orders: boolean
    payments: boolean
    shipping: boolean
    marketing: boolean
    auctions: boolean
    messages: boolean
    system: boolean
  }
  quietHours: {
    enabled: boolean
    start: string // "22:00"
    end: string // "08:00"
  }
}

// Get notification icon by type
export function getNotificationIcon(type: NotificationType): string {
  const icons: Record<NotificationType, string> = {
    order: '📦',
    payment: '💳',
    shipping: '🚚',
    return: '↩️',
    review: '⭐',
    message: '💬',
    auction: '⚡',
    marketplace: '🛒',
    system: 'ℹ️',
    alert: '⚠️',
    promotion: '🎁',
    reminder: '🔔'
  }
  return icons[type]
}

// Get notification color by priority
export function getNotificationColor(priority: NotificationPriority): string {
  const colors = {
    low: 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700',
    medium: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800',
    high: 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800',
    urgent: 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
  }
  return colors[priority]
}

// Get notification badge color
export function getNotificationBadgeColor(priority: NotificationPriority): string {
  const colors = {
    low: 'bg-slate-500',
    medium: 'bg-blue-500',
    high: 'bg-orange-500',
    urgent: 'bg-red-500'
  }
  return colors[priority]
}

// Format time ago
export function getNotificationTimeAgo(date: Date): string {
  const now = new Date()
  const diffInMs = now.getTime() - new Date(date).getTime()
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60))
  const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60))
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24))

  if (diffInMinutes < 1) return 'Just now'
  if (diffInMinutes < 60) return `${diffInMinutes}m ago`
  if (diffInHours < 24) return `${diffInHours}h ago`
  if (diffInDays < 7) return `${diffInDays}d ago`
  if (diffInDays < 30) return `${Math.floor(diffInDays / 7)}w ago`
  return new Date(date).toLocaleDateString()
}

// Group notifications by date
export function groupNotificationsByDate(notifications: Notification[]): Record<string, Notification[]> {
  const groups: Record<string, Notification[]> = {
    'Today': [],
    'Yesterday': [],
    'This Week': [],
    'Earlier': []
  }

  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000)
  const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)

  notifications.forEach(notification => {
    const notifDate = new Date(notification.createdAt)
    const notifDay = new Date(notifDate.getFullYear(), notifDate.getMonth(), notifDate.getDate())

    if (notifDay.getTime() === today.getTime()) {
      groups['Today'].push(notification)
    } else if (notifDay.getTime() === yesterday.getTime()) {
      groups['Yesterday'].push(notification)
    } else if (notifDay.getTime() >= weekAgo.getTime()) {
      groups['This Week'].push(notification)
    } else {
      groups['Earlier'].push(notification)
    }
  })

  // Remove empty groups
  Object.keys(groups).forEach(key => {
    if (groups[key].length === 0) {
      delete groups[key]
    }
  })

  return groups
}

// Filter notifications
export function filterNotifications(
  notifications: Notification[],
  filters: {
    unreadOnly?: boolean
    type?: NotificationType
    priority?: NotificationPriority
  }
): Notification[] {
  let filtered = [...notifications]

  if (filters.unreadOnly) {
    filtered = filtered.filter(n => !n.read)
  }

  if (filters.type) {
    filtered = filtered.filter(n => n.type === filters.type)
  }

  if (filters.priority) {
    filtered = filtered.filter(n => n.priority === filters.priority)
  }

  return filtered
}

// Check if in quiet hours
export function isInQuietHours(preferences: NotificationPreferences): boolean {
  if (!preferences.quietHours.enabled) return false

  const now = new Date()
  const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
  
  const start = preferences.quietHours.start
  const end = preferences.quietHours.end

  if (start < end) {
    return currentTime >= start && currentTime < end
  } else {
    // Handles overnight quiet hours (e.g., 22:00 to 08:00)
    return currentTime >= start || currentTime < end
  }
}
