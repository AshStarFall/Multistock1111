// Community Marketplace Types and Utilities

export type ListingType = 'sell' | 'rent'

export type ListingStatus = 
  | 'draft'
  | 'pending_review'
  | 'active'
  | 'sold'
  | 'rented'
  | 'expired'
  | 'rejected'
  | 'removed'

export type ListingCondition = 
  | 'new'
  | 'like_new'
  | 'excellent'
  | 'good'
  | 'fair'
  | 'poor'

export type RentalPeriod = 'hourly' | 'daily' | 'weekly' | 'monthly'

export type SellerTier = 'free' | 'basic' | 'premium' | 'enterprise'

export interface MarketplaceListing {
  id: string
  sellerId: string
  sellerName: string
  sellerTier: SellerTier
  sellerRating: number
  sellerVerified: boolean
  title: string
  description: string
  category: string
  type: ListingType
  status: ListingStatus
  condition: ListingCondition
  price: number
  currency: string
  images: string[]
  rentalPeriod?: RentalPeriod
  rentalDeposit?: number
  quantity: number
  location: string
  tags: string[]
  views: number
  favorites: number
  createdAt: Date
  updatedAt: Date
  expiresAt?: Date
  featuredUntil?: Date
}

export interface SellerSubscription {
  id: string
  userId: string
  tier: SellerTier
  listingsLimit: number
  listingsUsed: number
  featuredListingsLimit: number
  featuredListingsUsed: number
  commissionRate: number
  features: string[]
  startDate: Date
  endDate: Date
  autoRenew: boolean
  status: 'active' | 'expired' | 'cancelled'
}

export interface MarketplaceFilters {
  type?: ListingType
  category?: string
  minPrice?: number
  maxPrice?: number
  condition?: ListingCondition
  location?: string
  verifiedOnly?: boolean
  search?: string
  sortBy?: 'newest' | 'price_low' | 'price_high' | 'popular' | 'rating'
}

export interface SubscriptionPlan {
  tier: SellerTier
  name: string
  price: number
  billingPeriod: 'monthly' | 'yearly'
  listingsLimit: number
  featuredListingsLimit: number
  commissionRate: number
  features: string[]
  popular?: boolean
}

// Subscription Plans
export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    tier: 'free',
    name: 'Free',
    price: 0,
    billingPeriod: 'monthly',
    listingsLimit: 3,
    featuredListingsLimit: 0,
    commissionRate: 15,
    features: [
      'Up to 3 active listings',
      '15% commission on sales',
      'Basic support',
      'Standard listing visibility'
    ]
  },
  {
    tier: 'basic',
    name: 'Basic',
    price: 499,
    billingPeriod: 'monthly',
    listingsLimit: 15,
    featuredListingsLimit: 2,
    commissionRate: 10,
    features: [
      'Up to 15 active listings',
      '10% commission on sales',
      '2 featured listings per month',
      'Priority support',
      'Enhanced visibility',
      'Analytics dashboard'
    ]
  },
  {
    tier: 'premium',
    name: 'Premium',
    price: 999,
    billingPeriod: 'monthly',
    listingsLimit: 50,
    featuredListingsLimit: 10,
    commissionRate: 5,
    features: [
      'Up to 50 active listings',
      '5% commission on sales',
      '10 featured listings per month',
      'Priority support',
      'Top search placement',
      'Advanced analytics',
      'Verified seller badge',
      'Custom store page'
    ],
    popular: true
  },
  {
    tier: 'enterprise',
    name: 'Enterprise',
    price: 2499,
    billingPeriod: 'monthly',
    listingsLimit: -1, // Unlimited
    featuredListingsLimit: -1,
    commissionRate: 3,
    features: [
      'Unlimited listings',
      '3% commission on sales',
      'Unlimited featured listings',
      'Dedicated account manager',
      'Premium placement',
      'White-label options',
      'API access',
      'Custom integrations',
      'Bulk upload tools'
    ]
  }
]

// Get listing type label
export function getListingTypeLabel(type: ListingType): string {
  return type === 'sell' ? 'For Sale' : 'For Rent'
}

// Get listing status label
export function getListingStatusLabel(status: ListingStatus): string {
  const labels: Record<ListingStatus, string> = {
    draft: 'Draft',
    pending_review: 'Pending Review',
    active: 'Active',
    sold: 'Sold',
    rented: 'Rented',
    expired: 'Expired',
    rejected: 'Rejected',
    removed: 'Removed'
  }
  return labels[status]
}

// Get listing status color
export function getListingStatusColor(status: ListingStatus): string {
  const colors: Record<ListingStatus, string> = {
    draft: 'bg-slate-100 text-slate-700 dark:bg-slate-900/20 dark:text-slate-400',
    pending_review: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400',
    active: 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400',
    sold: 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
    rented: 'bg-purple-100 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400',
    expired: 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400',
    rejected: 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400',
    removed: 'bg-slate-100 text-slate-700 dark:bg-slate-900/20 dark:text-slate-400'
  }
  return colors[status]
}

// Get condition label
export function getConditionLabel(condition: ListingCondition): string {
  const labels: Record<ListingCondition, string> = {
    new: 'Brand New',
    like_new: 'Like New',
    excellent: 'Excellent',
    good: 'Good',
    fair: 'Fair',
    poor: 'Poor'
  }
  return labels[condition]
}

// Get rental period label
export function getRentalPeriodLabel(period: RentalPeriod): string {
  const labels: Record<RentalPeriod, string> = {
    hourly: 'Per Hour',
    daily: 'Per Day',
    weekly: 'Per Week',
    monthly: 'Per Month'
  }
  return labels[period]
}

// Get seller tier badge color
export function getSellerTierColor(tier: SellerTier): string {
  const colors: Record<SellerTier, string> = {
    free: 'bg-slate-100 text-slate-700',
    basic: 'bg-blue-100 text-blue-700',
    premium: 'bg-purple-100 text-purple-700',
    enterprise: 'bg-amber-100 text-amber-700'
  }
  return colors[tier]
}

// Format currency
export function formatCurrency(amount: number, currency: string = 'INR'): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(amount)
}

// Filter marketplace listings
export function filterListings(
  listings: MarketplaceListing[],
  filters: MarketplaceFilters
): MarketplaceListing[] {
  let filtered = [...listings]

  if (filters.type) {
    filtered = filtered.filter(l => l.type === filters.type)
  }

  if (filters.category) {
    filtered = filtered.filter(l => l.category === filters.category)
  }

  if (filters.minPrice !== undefined) {
    filtered = filtered.filter(l => l.price >= filters.minPrice!)
  }

  if (filters.maxPrice !== undefined) {
    filtered = filtered.filter(l => l.price <= filters.maxPrice!)
  }

  if (filters.condition) {
    filtered = filtered.filter(l => l.condition === filters.condition)
  }

  if (filters.location) {
    filtered = filtered.filter(l => 
      l.location.toLowerCase().includes(filters.location!.toLowerCase())
    )
  }

  if (filters.verifiedOnly) {
    filtered = filtered.filter(l => l.sellerVerified)
  }

  if (filters.search) {
    const query = filters.search.toLowerCase()
    filtered = filtered.filter(l =>
      l.title.toLowerCase().includes(query) ||
      l.description.toLowerCase().includes(query) ||
      l.tags.some(tag => tag.toLowerCase().includes(query))
    )
  }

  // Sort
  if (filters.sortBy) {
    switch (filters.sortBy) {
      case 'newest':
        filtered.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        )
        break
      case 'price_low':
        filtered.sort((a, b) => a.price - b.price)
        break
      case 'price_high':
        filtered.sort((a, b) => b.price - a.price)
        break
      case 'popular':
        filtered.sort((a, b) => b.views - a.views)
        break
      case 'rating':
        filtered.sort((a, b) => b.sellerRating - a.sellerRating)
        break
    }
  }

  return filtered
}

// Calculate commission
export function calculateCommission(amount: number, tier: SellerTier): number {
  const plan = SUBSCRIPTION_PLANS.find(p => p.tier === tier)
  if (!plan) return 0
  return (amount * plan.commissionRate) / 100
}

// Check if can create listing
export function canCreateListing(subscription: SellerSubscription): {
  allowed: boolean
  reason?: string
} {
  if (subscription.status !== 'active') {
    return { allowed: false, reason: 'Subscription is not active' }
  }

  if (subscription.listingsLimit === -1) {
    return { allowed: true }
  }

  if (subscription.listingsUsed >= subscription.listingsLimit) {
    return { 
      allowed: false, 
      reason: `You've reached your limit of ${subscription.listingsLimit} listings. Upgrade to create more.` 
    }
  }

  return { allowed: true }
}

// Get time ago
export function getTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000)
  
  if (seconds < 60) return 'Just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`
  if (seconds < 2592000) return `${Math.floor(seconds / 604800)}w ago`
  return new Date(date).toLocaleDateString()
}
