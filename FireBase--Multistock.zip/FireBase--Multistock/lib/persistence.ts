"use client"

import { useEffect, useState } from "react"
import { load, save } from "./storage"

export function usePersistentState<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => load<T>(key, initial))
  useEffect(() => {
    save<T>(key, state)
  }, [key, state])
  return [state, setState] as const
}
