// Email service using Resend API
let resend: any = null
try {
  // Lazy import to avoid build errors when package/env is missing
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { Resend } = require('resend')
  if (process.env.RESEND_API_KEY) {
    resend = new Resend(process.env.RESEND_API_KEY)
  }
} catch (e) {
  console.warn('Resend package not available. Email sending disabled in this environment.')
}

export interface EmailTemplate {
  id: string
  name: string
  subject: string
  body_html: string
  body_text: string
  variables: string[]
}

export interface EmailData {
  template_id?: string
  recipient_email: string
  recipient_name?: string
  subject: string
  body_html?: string
  body_text?: string
  variables?: Record<string, string>
}

export class EmailService {
  private supabase: any

  constructor(supabase: any) {
    this.supabase = supabase
  }

  async sendEmail(emailData: EmailData): Promise<boolean> {
    try {
      // Log email attempt
      const { data: logData, error: logError } = await this.supabase
        .from('email_logs')
        .insert({
          template_id: emailData.template_id,
          recipient_email: emailData.recipient_email,
          recipient_name: emailData.recipient_name,
          subject: emailData.subject,
          body_html: emailData.body_html,
          body_text: emailData.body_text,
          status: 'pending'
        })
        .select()
        .single()

      if (logError) {
        console.error('Error logging email:', logError)
      }

      // Send email using Resend (if available). Otherwise, mark as sent in dev.
      if (resend) {
        const { error } = await resend.emails.send({
          from: 'MultiStock Logistics <noreply@multistock.com>',
          to: [emailData.recipient_email],
          subject: emailData.subject,
          html: emailData.body_html,
          text: emailData.body_text,
        })
        if (error) {
          throw error
        }
      } else {
        console.log('Email sending skipped (Resend unavailable). Would send to:', emailData.recipient_email)
      }

      if (error) {
        console.error('Error sending email:', error)
        
        // Update log with error
        if (logData) {
          await this.supabase
            .from('email_logs')
            .update({
              status: 'failed',
              error_message: error.message
            })
            .eq('id', logData.id)
        }
        
        return false
      }

      // Update log with success
      if (logData) {
        await this.supabase
          .from('email_logs')
          .update({
            status: 'sent',
            sent_at: new Date().toISOString()
          })
          .eq('id', logData.id)
      }

      return true
    } catch (error) {
      console.error('Error in email service:', error)
      return false
    }
  }

  async sendTemplateEmail(templateName: string, recipientEmail: string, variables: Record<string, string> = {}): Promise<boolean> {
    try {
      // Get template from database
      const { data: template, error: templateError } = await this.supabase
        .from('email_templates')
        .select('*')
        .eq('name', templateName)
        .eq('is_active', true)
        .single()

      if (templateError || !template) {
        console.error('Template not found:', templateName)
        return false
      }

      // Replace variables in template
      let subject = template.subject
      let bodyHtml = template.body_html
      let bodyText = template.body_text

      Object.entries(variables).forEach(([key, value]) => {
        const placeholder = `{{${key}}}`
        subject = subject.replace(new RegExp(placeholder, 'g'), value)
        bodyHtml = bodyHtml.replace(new RegExp(placeholder, 'g'), value)
        bodyText = bodyText.replace(new RegExp(placeholder, 'g'), value)
      })

      return await this.sendEmail({
        template_id: template.id,
        recipient_email: recipientEmail,
        recipient_name: variables.user_name || '',
        subject,
        body_html: bodyHtml,
        body_text: bodyText,
        variables
      })
    } catch (error) {
      console.error('Error sending template email:', error)
      return false
    }
  }

  async sendRoleChangeNotification(userEmail: string, userName: string, oldRole: string, newRole: string, isPromotion: boolean): Promise<boolean> {
    return await this.sendTemplateEmail('role_change_notification', userEmail, {
      user_name: userName,
      change_type: isPromotion ? 'promoted' : 'demoted',
      old_role: oldRole,
      new_role: newRole,
      announcement_text: `Your role has been ${isPromotion ? 'promoted' : 'demoted'} from ${oldRole} to ${newRole}. Please log in to see your updated permissions.`
    })
  }

  async sendWelcomeEmail(userEmail: string, userName: string, role: string): Promise<boolean> {
    return await this.sendTemplateEmail('welcome_email', userEmail, {
      user_name: userName,
      role: role
    })
  }

  async getEmailLogs(limit = 50): Promise<any[]> {
    try {
      const { data, error } = await this.supabase
        .from('email_logs')
        .select(`
          *,
          template:email_templates(*)
        `)
        .order('created_at', { ascending: false })
        .limit(limit)

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error fetching email logs:', error)
      return []
    }
  }

  async getEmailTemplates(): Promise<EmailTemplate[]> {
    try {
      const { data, error } = await this.supabase
        .from('email_templates')
        .select('*')
        .order('name')

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error fetching email templates:', error)
      return []
    }
  }
}

// Utility function to create email service instance
export function createEmailService(supabase: any): EmailService {
  return new EmailService(supabase)
}
