// Usage & Expense Tracker System
export type ExpenseCategory = 
  | 'inventory'
  | 'shipping'
  | 'marketing'
  | 'utilities'
  | 'salaries'
  | 'rent'
  | 'equipment'
  | 'taxes'
  | 'maintenance'
  | 'other';

export type ExpenseRecord = {
  id: string;
  userId: string;
  category: ExpenseCategory;
  amount: number;
  description: string;
  date: string;
  paymentMethod?: string;
  receiptUrl?: string;
  tags?: string[];
  createdAt: string;
};

export type Budget = {
  id: string;
  userId: string;
  category: ExpenseCategory;
  limit: number;
  period: 'monthly' | 'quarterly' | 'yearly';
  startDate: string;
  endDate: string;
  spent: number;
  remaining: number;
  isActive: boolean;
};

export type ExpenseSummary = {
  totalExpenses: number;
  categoryBreakdown: { category: ExpenseCategory; amount: number; percentage: number }[];
  monthlyTrend: { month: string; amount: number }[];
  topCategories: { category: ExpenseCategory; amount: number }[];
  budgetUtilization: number;
};

export const EXPENSE_CATEGORIES: { value: ExpenseCategory; label: string; icon: string; color: string }[] = [
  { value: 'inventory', label: 'Inventory', icon: '📦', color: 'bg-blue-600' },
  { value: 'shipping', label: 'Shipping', icon: '🚚', color: 'bg-green-600' },
  { value: 'marketing', label: 'Marketing', icon: '📢', color: 'bg-purple-600' },
  { value: 'utilities', label: 'Utilities', icon: '⚡', color: 'bg-yellow-600' },
  { value: 'salaries', label: 'Salaries', icon: '👥', color: 'bg-indigo-600' },
  { value: 'rent', label: 'Rent', icon: '🏢', color: 'bg-orange-600' },
  { value: 'equipment', label: 'Equipment', icon: '🔧', color: 'bg-gray-600' },
  { value: 'taxes', label: 'Taxes', icon: '💰', color: 'bg-red-600' },
  { value: 'maintenance', label: 'Maintenance', icon: '🛠️', color: 'bg-teal-600' },
  { value: 'other', label: 'Other', icon: '📝', color: 'bg-pink-600' },
];

// Calculate expense summary
export function calculateExpenseSummary(expenses: ExpenseRecord[]): ExpenseSummary {
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);

  // Category breakdown
  const categoryMap = new Map<ExpenseCategory, number>();
  expenses.forEach((exp) => {
    const current = categoryMap.get(exp.category) || 0;
    categoryMap.set(exp.category, current + exp.amount);
  });

  const categoryBreakdown = Array.from(categoryMap.entries())
    .map(([category, amount]) => ({
      category,
      amount,
      percentage: (amount / totalExpenses) * 100,
    }))
    .sort((a, b) => b.amount - a.amount);

  // Monthly trend (last 6 months)
  const now = new Date();
  const monthlyMap = new Map<string, number>();

  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    monthlyMap.set(key, 0);
  }

  expenses.forEach((exp) => {
    const date = new Date(exp.date);
    const key = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    if (monthlyMap.has(key)) {
      monthlyMap.set(key, (monthlyMap.get(key) || 0) + exp.amount);
    }
  });

  const monthlyTrend = Array.from(monthlyMap.entries()).map(([month, amount]) => ({
    month,
    amount,
  }));

  // Top categories (top 5)
  const topCategories = categoryBreakdown.slice(0, 5);

  return {
    totalExpenses,
    categoryBreakdown,
    monthlyTrend,
    topCategories,
    budgetUtilization: 0, // Will be calculated with budget data
  };
}

// Calculate budget utilization
export function calculateBudgetUtilization(budget: Budget): number {
  if (budget.limit === 0) return 0;
  return (budget.spent / budget.limit) * 100;
}

// Check if budget is exceeded
export function isBudgetExceeded(budget: Budget): boolean {
  return budget.spent > budget.limit;
}

// Get budget status
export function getBudgetStatus(utilization: number): {
  status: 'safe' | 'warning' | 'danger' | 'exceeded';
  color: string;
  message: string;
} {
  if (utilization <= 50) {
    return {
      status: 'safe',
      color: 'text-green-600 bg-green-50 dark:bg-green-950/20',
      message: 'Within budget',
    };
  } else if (utilization <= 80) {
    return {
      status: 'warning',
      color: 'text-yellow-600 bg-yellow-50 dark:bg-yellow-950/20',
      message: 'Approaching limit',
    };
  } else if (utilization < 100) {
    return {
      status: 'danger',
      color: 'text-orange-600 bg-orange-50 dark:bg-orange-950/20',
      message: 'Near budget limit',
    };
  } else {
    return {
      status: 'exceeded',
      color: 'text-red-600 bg-red-50 dark:bg-red-950/20',
      message: 'Budget exceeded',
    };
  }
}

// Get category info
export function getCategoryInfo(category: ExpenseCategory) {
  return EXPENSE_CATEGORIES.find((c) => c.value === category) || EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
}

// Filter expenses by date range
export function filterExpensesByDateRange(
  expenses: ExpenseRecord[],
  startDate: Date,
  endDate: Date
): ExpenseRecord[] {
  return expenses.filter((exp) => {
    const expDate = new Date(exp.date);
    return expDate >= startDate && expDate <= endDate;
  });
}

// Export expenses to CSV
export function exportToCSV(expenses: ExpenseRecord[]): string {
  const headers = ['Date', 'Category', 'Amount', 'Description', 'Payment Method', 'Tags'];
  const rows = expenses.map((exp) => [
    new Date(exp.date).toLocaleDateString(),
    exp.category,
    exp.amount.toString(),
    exp.description,
    exp.paymentMethod || '',
    (exp.tags || []).join('; '),
  ]);

  const csvContent = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n');

  return csvContent;
}

// Download CSV file
export function downloadCSV(csvContent: string, filename: string = 'expenses.csv') {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Get date range presets
export function getDateRangePreset(preset: 'today' | 'week' | 'month' | 'quarter' | 'year'): {
  startDate: Date;
  endDate: Date;
} {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  switch (preset) {
    case 'today':
      return { startDate: today, endDate: new Date() };
    
    case 'week':
      const weekStart = new Date(today);
      weekStart.setDate(today.getDate() - 7);
      return { startDate: weekStart, endDate: new Date() };
    
    case 'month':
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      return { startDate: monthStart, endDate: new Date() };
    
    case 'quarter':
      const quarterMonth = Math.floor(now.getMonth() / 3) * 3;
      const quarterStart = new Date(now.getFullYear(), quarterMonth, 1);
      return { startDate: quarterStart, endDate: new Date() };
    
    case 'year':
      const yearStart = new Date(now.getFullYear(), 0, 1);
      return { startDate: yearStart, endDate: new Date() };
    
    default:
      return { startDate: today, endDate: new Date() };
  }
}
