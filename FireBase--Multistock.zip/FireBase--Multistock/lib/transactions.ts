// Transaction System Types and Utilities

export type TransactionType = 
  | 'purchase'
  | 'refund'
  | 'payment'
  | 'rental'
  | 'deposit'
  | 'withdrawal'
  | 'subscription'
  | 'commission'
  | 'auction'
  | 'marketplace'

export type TransactionStatus = 
  | 'pending'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'refunded'

export type PaymentMethod = 
  | 'credit_card'
  | 'debit_card'
  | 'upi'
  | 'net_banking'
  | 'wallet'
  | 'cod'
  | 'bank_transfer'

export interface Transaction {
  id: string
  userId: string
  type: TransactionType
  status: TransactionStatus
  amount: number
  currency: string
  paymentMethod: PaymentMethod
  orderId?: string
  description: string
  referenceNumber: string
  receiptUrl?: string
  metadata?: Record<string, any>
  createdAt: Date
  updatedAt: Date
  completedAt?: Date
}

export interface TransactionFilters {
  type?: TransactionType
  status?: TransactionStatus
  paymentMethod?: PaymentMethod
  startDate?: Date
  endDate?: Date
  minAmount?: number
  maxAmount?: number
  search?: string
}

export interface TransactionStats {
  totalTransactions: number
  totalAmount: number
  successfulTransactions: number
  failedTransactions: number
  pendingTransactions: number
  averageAmount: number
}

// Get transaction type label
export function getTransactionTypeLabel(type: TransactionType): string {
  const labels: Record<TransactionType, string> = {
    purchase: 'Purchase',
    refund: 'Refund',
    payment: 'Payment',
    rental: 'Rental',
    deposit: 'Deposit',
    withdrawal: 'Withdrawal',
    subscription: 'Subscription',
    commission: 'Commission',
    auction: 'Auction',
    marketplace: 'Marketplace'
  }
  return labels[type]
}

// Get transaction type icon
export function getTransactionTypeIcon(type: TransactionType): string {
  const icons: Record<TransactionType, string> = {
    purchase: '🛒',
    refund: '↩️',
    payment: '💳',
    rental: '🔑',
    deposit: '💰',
    withdrawal: '🏦',
    subscription: '📅',
    commission: '💼',
    auction: '⚡',
    marketplace: '🛍️'
  }
  return icons[type]
}

// Get transaction status label
export function getTransactionStatusLabel(status: TransactionStatus): string {
  const labels: Record<TransactionStatus, string> = {
    pending: 'Pending',
    processing: 'Processing',
    completed: 'Completed',
    failed: 'Failed',
    cancelled: 'Cancelled',
    refunded: 'Refunded'
  }
  return labels[status]
}

// Get transaction status color
export function getTransactionStatusColor(status: TransactionStatus): string {
  const colors: Record<TransactionStatus, string> = {
    pending: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400',
    processing: 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
    completed: 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400',
    failed: 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400',
    cancelled: 'bg-slate-100 text-slate-700 dark:bg-slate-900/20 dark:text-slate-400',
    refunded: 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400'
  }
  return colors[status]
}

// Get payment method label
export function getPaymentMethodLabel(method: PaymentMethod): string {
  const labels: Record<PaymentMethod, string> = {
    credit_card: 'Credit Card',
    debit_card: 'Debit Card',
    upi: 'UPI',
    net_banking: 'Net Banking',
    wallet: 'Wallet',
    cod: 'Cash on Delivery',
    bank_transfer: 'Bank Transfer'
  }
  return labels[method]
}

// Get payment method icon
export function getPaymentMethodIcon(method: PaymentMethod): string {
  const icons: Record<PaymentMethod, string> = {
    credit_card: '💳',
    debit_card: '💳',
    upi: '📱',
    net_banking: '🏦',
    wallet: '👛',
    cod: '💵',
    bank_transfer: '🏦'
  }
  return icons[method]
}

// Format currency
export function formatCurrency(amount: number, currency: string = 'INR'): string {
  const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })
  return formatter.format(amount)
}

// Filter transactions
export function filterTransactions(
  transactions: Transaction[],
  filters: TransactionFilters
): Transaction[] {
  let filtered = [...transactions]

  if (filters.type) {
    filtered = filtered.filter(t => t.type === filters.type)
  }

  if (filters.status) {
    filtered = filtered.filter(t => t.status === filters.status)
  }

  if (filters.paymentMethod) {
    filtered = filtered.filter(t => t.paymentMethod === filters.paymentMethod)
  }

  if (filters.startDate) {
    filtered = filtered.filter(t => new Date(t.createdAt) >= filters.startDate!)
  }

  if (filters.endDate) {
    filtered = filtered.filter(t => new Date(t.createdAt) <= filters.endDate!)
  }

  if (filters.minAmount !== undefined) {
    filtered = filtered.filter(t => t.amount >= filters.minAmount!)
  }

  if (filters.maxAmount !== undefined) {
    filtered = filtered.filter(t => t.amount <= filters.maxAmount!)
  }

  if (filters.search) {
    const query = filters.search.toLowerCase()
    filtered = filtered.filter(t =>
      t.description.toLowerCase().includes(query) ||
      t.referenceNumber.toLowerCase().includes(query) ||
      t.id.toLowerCase().includes(query)
    )
  }

  return filtered
}

// Calculate transaction statistics
export function calculateTransactionStats(transactions: Transaction[]): TransactionStats {
  const totalTransactions = transactions.length
  const totalAmount = transactions
    .filter(t => t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0)
  
  const successfulTransactions = transactions.filter(
    t => t.status === 'completed'
  ).length
  
  const failedTransactions = transactions.filter(
    t => t.status === 'failed'
  ).length
  
  const pendingTransactions = transactions.filter(
    t => t.status === 'pending' || t.status === 'processing'
  ).length
  
  const averageAmount = successfulTransactions > 0 
    ? totalAmount / successfulTransactions 
    : 0

  return {
    totalTransactions,
    totalAmount,
    successfulTransactions,
    failedTransactions,
    pendingTransactions,
    averageAmount
  }
}

// Export transactions to CSV
export function exportToCSV(transactions: Transaction[]): string {
  const headers = [
    'Transaction ID',
    'Date',
    'Type',
    'Status',
    'Amount',
    'Payment Method',
    'Description',
    'Reference Number'
  ]

  const rows = transactions.map(t => [
    t.id,
    new Date(t.createdAt).toLocaleString(),
    getTransactionTypeLabel(t.type),
    getTransactionStatusLabel(t.status),
    formatCurrency(t.amount, t.currency),
    getPaymentMethodLabel(t.paymentMethod),
    t.description,
    t.referenceNumber
  ])

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n')

  return csvContent
}

// Download file helper
export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
