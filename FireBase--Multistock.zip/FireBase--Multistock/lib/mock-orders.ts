export type OrderStatus =
  | "Draft"
  | "Open"
  | "Partially Received"
  | "Received"
  | "Partially Fulfilled"
  | "Fulfilled"
  | "Canceled"

export type OrderKind = "purchase" | "sales"

export type OrderItem = {
  sku: string
  name: string
  qty: number
  unitPrice: number
}

export type Order = {
  id: string
  number: string
  kind: OrderKind
  partyName: string // supplier for PO, customer for SO
  status: OrderStatus
  date: string // ISO
  dueDate?: string // optional
  items: OrderItem[]
  currency: string
}

export type MovementType = "inbound" | "outbound" | "transfer" | "adjustment"

export type Movement = {
  id: string
  date: string // ISO
  type: MovementType
  sku: string
  qty: number
  from?: string
  to?: string
  reference?: string // order number or note
}

function rand(n: number, m: number) {
  return Math.floor(Math.random() * (m - n + 1)) + n
}

function toIso(daysAgo = 0) {
  const d = new Date()
  d.setDate(d.getDate() - daysAgo)
  return d.toISOString()
}

export const purchaseOrders: Order[] = Array.from({ length: 16 }).map((_, i) => {
  const statuses: OrderStatus[] = ["Draft", "Open", "Partially Received", "Received", "Canceled"]
  const status = statuses[i % statuses.length]
  const items: OrderItem[] = [
    { sku: `SKU-${1000 + i}`, name: `Item ${i + 1}`, qty: rand(1, 40), unitPrice: rand(5, 30) },
    { sku: `SKU-${2000 + i}`, name: `Item B${i + 1}`, qty: rand(1, 20), unitPrice: rand(10, 60) },
  ]
  return {
    id: crypto.randomUUID(),
    number: `PO-${202500 + i}`,
    kind: "purchase",
    partyName: ["Reliance Industries", "Tata Group", "Adani Enterprises", "Mahindra & Mahindra"][i % 4],
    status,
    date: toIso(i * 2),
    dueDate: toIso(i * 2 - rand(0, 4)),
    items,
    currency: "INR",
  }
})

export const salesOrders: Order[] = Array.from({ length: 18 }).map((_, i) => {
  const statuses: OrderStatus[] = ["Open", "Partially Fulfilled", "Fulfilled", "Canceled"]
  const status = statuses[i % statuses.length]
  const items: OrderItem[] = [
    { sku: `SKU-${3000 + i}`, name: `Product ${i + 1}`, qty: rand(1, 10), unitPrice: rand(20, 90) },
  ]
  return {
    id: crypto.randomUUID(),
    number: `SO-${202500 + i}`,
    kind: "sales",
    partyName: ["Rajesh Kumar", "Priya Sharma", "Indian Retail Co.", "Bharat Mart"][i % 4],
    status,
    date: toIso(i),
    dueDate: toIso(i - rand(0, 3)),
    items,
    currency: "INR",
  }
})

export const movements: Movement[] = [
  // derive a few from orders
  ...purchaseOrders.slice(0, 6).map((o, i) => ({
    id: crypto.randomUUID(),
    date: o.date,
    type: i % 2 ? ("inbound" as const) : ("transfer" as const),
    sku: o.items[0].sku,
    qty: rand(5, 30),
    from: i % 2 ? undefined : "WH-North",
    to: i % 2 ? "WH-Central" : "WH-East",
    reference: o.number,
  })),
  ...salesOrders.slice(0, 6).map((o) => ({
    id: crypto.randomUUID(),
    date: o.date,
    type: "outbound" as const,
    sku: o.items[0].sku,
    qty: rand(1, 8),
    from: "WH-Central",
    to: undefined,
    reference: o.number,
  })),
  // adjustments
  {
    id: crypto.randomUUID(),
    date: toIso(1),
    type: "adjustment",
    sku: "SKU-ADJ-1",
    qty: -3,
    from: "WH-North",
    to: undefined,
    reference: "Cycle Count",
  },
]

export function orderTotal(o: Order) {
  return o.items.reduce((sum, it) => sum + it.qty * it.unitPrice, 0)
}
