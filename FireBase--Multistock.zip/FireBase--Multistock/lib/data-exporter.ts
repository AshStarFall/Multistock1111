import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'

interface ExportColumn {
  header: string
  key: string
  width?: number
}

interface ExportOptions {
  filename: string
  title?: string
  subtitle?: string
  columns: ExportColumn[]
  data: any[]
  includeTimestamp?: boolean
}

export class DataExporter {
  /**
   * Export data to PDF
   */
  static async exportToPDF(options: ExportOptions): Promise<void> {
    const {
      filename,
      title = 'Report',
      subtitle,
      columns,
      data,
      includeTimestamp = true,
    } = options

    const doc = new jsPDF()
    
    // Add header
    doc.setFontSize(20)
    doc.setTextColor(79, 70, 229) // Indigo-600
    doc.text(title, 14, 22)
    
    if (subtitle) {
      doc.setFontSize(12)
      doc.setTextColor(100, 100, 100)
      doc.text(subtitle, 14, 30)
    }
    
    if (includeTimestamp) {
      doc.setFontSize(9)
      doc.setTextColor(150, 150, 150)
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, subtitle ? 36 : 30)
    }

    // Add table
    const tableData = data.map(row =>
      columns.map(col => row[col.key] ?? '-')
    )

    autoTable(doc, {
      head: [columns.map(col => col.header)],
      body: tableData,
      startY: subtitle ? 42 : 36,
      theme: 'grid',
      styles: {
        fontSize: 9,
        cellPadding: 3,
      },
      headStyles: {
        fillColor: [79, 70, 229], // Indigo-600
        textColor: 255,
        fontStyle: 'bold',
      },
      alternateRowStyles: {
        fillColor: [245, 247, 250],
      },
      margin: { top: 40 },
    })

    // Add footer with page numbers
    const pageCount = (doc as any).internal.getNumberOfPages()
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)
      doc.setFontSize(9)
      doc.setTextColor(150, 150, 150)
      doc.text(
        `Page ${i} of ${pageCount}`,
        doc.internal.pageSize.width / 2,
        doc.internal.pageSize.height - 10,
        { align: 'center' }
      )
    }

    // Save the PDF
    doc.save(`${filename}.pdf`)
  }

  /**
   * Export data to Excel
   */
  static async exportToExcel(options: ExportOptions): Promise<void> {
    const {
      filename,
      title = 'Report',
      columns,
      data,
      includeTimestamp = true,
    } = options

    // Create workbook
    const wb = XLSX.utils.book_new()
    
    // Prepare data with headers
    const wsData = [
      [title],
      includeTimestamp ? [`Generated on: ${new Date().toLocaleString()}`] : [],
      [], // Empty row
      columns.map(col => col.header),
      ...data.map(row => columns.map(col => row[col.key] ?? '-'))
    ]

    // Create worksheet
    const ws = XLSX.utils.aoa_to_sheet(wsData)

    // Set column widths
    ws['!cols'] = columns.map(col => ({ wch: col.width || 15 }))

    // Style the header row (title)
    if (ws['A1']) {
      ws['A1'].s = {
        font: { bold: true, sz: 16, color: { rgb: '4F46E5' } },
        alignment: { horizontal: 'left' }
      }
    }

    // Style the column headers
    const headerRow = includeTimestamp ? 4 : 3
    columns.forEach((_, idx) => {
      const cell = XLSX.utils.encode_cell({ r: headerRow, c: idx })
      if (ws[cell]) {
        ws[cell].s = {
          font: { bold: true, color: { rgb: 'FFFFFF' } },
          fill: { fgColor: { rgb: '4F46E5' } },
          alignment: { horizontal: 'center' }
        }
      }
    })

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Data')

    // Save the file
    XLSX.writeFile(wb, `${filename}.xlsx`)
  }

  /**
   * Export data to CSV
   */
  static async exportToCSV(options: ExportOptions): Promise<void> {
    const { filename, columns, data } = options

    // Create CSV content
    const headers = columns.map(col => col.header).join(',')
    const rows = data.map(row =>
      columns.map(col => {
        const value = row[col.key] ?? ''
        // Escape quotes and wrap in quotes if contains comma
        const escaped = String(value).replace(/"/g, '""')
        return escaped.includes(',') ? `"${escaped}"` : escaped
      }).join(',')
    )

    const csv = [headers, ...rows].join('\n')

    // Create blob and download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `${filename}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  /**
   * Export with progress tracking
   */
  static async exportWithProgress(
    options: ExportOptions,
    format: 'pdf' | 'excel' | 'csv',
    onProgress?: (progress: number) => void
  ): Promise<void> {
    const totalSteps = 100
    const updateProgress = (step: number) => {
      onProgress?.(Math.min((step / totalSteps) * 100, 100))
    }

    try {
      updateProgress(10)
      
      // Simulate preparation
      await new Promise(resolve => setTimeout(resolve, 200))
      updateProgress(30)

      // Export based on format
      switch (format) {
        case 'pdf':
          await this.exportToPDF(options)
          break
        case 'excel':
          await this.exportToExcel(options)
          break
        case 'csv':
          await this.exportToCSV(options)
          break
      }

      updateProgress(80)
      
      // Simulate finalization
      await new Promise(resolve => setTimeout(resolve, 200))
      updateProgress(100)
    } catch (error) {
      console.error('Export failed:', error)
      throw error
    }
  }
}

// Example usage functions
export const exportProducts = async (
  products: any[],
  format: 'pdf' | 'excel' | 'csv' = 'pdf',
  onProgress?: (progress: number) => void
) => {
  await DataExporter.exportWithProgress(
    {
      filename: `products-${Date.now()}`,
      title: 'Products Report',
      subtitle: `Total Products: ${products.length}`,
      columns: [
        { header: 'Product ID', key: 'id', width: 12 },
        { header: 'Name', key: 'name', width: 25 },
        { header: 'Category', key: 'category', width: 15 },
        { header: 'SKU', key: 'sku', width: 15 },
        { header: 'Price', key: 'price', width: 12 },
        { header: 'Stock', key: 'stock_quantity', width: 10 },
        { header: 'Status', key: 'status', width: 12 },
      ],
      data: products,
      includeTimestamp: true,
    },
    format,
    onProgress
  )
}

export const exportOrders = async (
  orders: any[],
  format: 'pdf' | 'excel' | 'csv' = 'pdf',
  onProgress?: (progress: number) => void
) => {
  await DataExporter.exportWithProgress(
    {
      filename: `orders-${Date.now()}`,
      title: 'Sales Orders Report',
      subtitle: `Total Orders: ${orders.length}`,
      columns: [
        { header: 'Order ID', key: 'id', width: 12 },
        { header: 'Customer', key: 'customer_name', width: 20 },
        { header: 'Date', key: 'order_date', width: 15 },
        { header: 'Total Amount', key: 'total_amount', width: 15 },
        { header: 'Status', key: 'status', width: 12 },
        { header: 'Payment', key: 'payment_status', width: 12 },
      ],
      data: orders,
      includeTimestamp: true,
    },
    format,
    onProgress
  )
}

export const exportInventory = async (
  inventory: any[],
  format: 'pdf' | 'excel' | 'csv' = 'pdf',
  onProgress?: (progress: number) => void
) => {
  await DataExporter.exportWithProgress(
    {
      filename: `inventory-${Date.now()}`,
      title: 'Inventory Report',
      subtitle: `Total Items: ${inventory.length}`,
      columns: [
        { header: 'Product', key: 'product_name', width: 25 },
        { header: 'Warehouse', key: 'warehouse_name', width: 20 },
        { header: 'Quantity', key: 'quantity', width: 12 },
        { header: 'Reorder Level', key: 'reorder_level', width: 15 },
        { header: 'Last Updated', key: 'last_updated', width: 18 },
      ],
      data: inventory,
      includeTimestamp: true,
    },
    format,
    onProgress
  )
}
