// Auction System Types and Utilities

export type AuctionStatus = 
  | 'draft'
  | 'scheduled'
  | 'active'
  | 'ending_soon' // Last 5 minutes
  | 'ended'
  | 'cancelled'
  | 'completed' // Winner confirmed

export type BidStatus = 'active' | 'outbid' | 'winning' | 'won' | 'lost'

export interface Auction {
  id: string
  sellerId: string
  sellerName: string
  sellerRating: number
  sellerVerified: boolean
  title: string
  description: string
  category: string
  images: string[]
  condition: string
  startingPrice: number
  currentPrice: number
  reservePrice?: number // Minimum price to sell
  buyNowPrice?: number // Optional instant buy
  bidIncrement: number // Minimum bid increase
  status: AuctionStatus
  startTime: Date
  endTime: Date
  duration: number // in hours
  totalBids: number
  uniqueBidders: number
  views: number
  watchers: number
  location: string
  shippingAvailable: boolean
  shippingCost?: number
  createdAt: Date
  updatedAt: Date
}

export interface Bid {
  id: string
  auctionId: string
  bidderId: string
  bidderName: string
  amount: number
  timestamp: Date
  status: BidStatus
  isAutoBid: boolean
  maxAutoBid?: number
}

export interface AuctionWinner {
  auctionId: string
  auction: Auction
  winnerId: string
  winnerName: string
  winningBid: number
  totalBids: number
  wonAt: Date
  paymentStatus: 'pending' | 'paid' | 'failed'
  paymentDueDate: Date
  notified: boolean
}

export interface AuctionFilters {
  category?: string
  status?: AuctionStatus
  minPrice?: number
  maxPrice?: number
  endingSoon?: boolean // Next 24 hours
  hasReserve?: boolean
  hasBuyNow?: boolean
  shippingAvailable?: boolean
  search?: string
  sortBy?: 'ending_soon' | 'newly_listed' | 'price_low' | 'price_high' | 'most_bids'
}

// Calculate time remaining
export function getTimeRemaining(endTime: Date): {
  total: number
  days: number
  hours: number
  minutes: number
  seconds: number
} {
  const total = new Date(endTime).getTime() - new Date().getTime()
  
  if (total <= 0) {
    return { total: 0, days: 0, hours: 0, minutes: 0, seconds: 0 }
  }

  const seconds = Math.floor((total / 1000) % 60)
  const minutes = Math.floor((total / 1000 / 60) % 60)
  const hours = Math.floor((total / (1000 * 60 * 60)) % 24)
  const days = Math.floor(total / (1000 * 60 * 60 * 24))

  return { total, days, hours, minutes, seconds }
}

// Format time remaining as string
export function formatTimeRemaining(endTime: Date): string {
  const { total, days, hours, minutes, seconds } = getTimeRemaining(endTime)
  
  if (total <= 0) return 'Ended'
  
  if (days > 0) {
    return `${days}d ${hours}h`
  } else if (hours > 0) {
    return `${hours}h ${minutes}m`
  } else if (minutes > 0) {
    return `${minutes}m ${seconds}s`
  } else {
    return `${seconds}s`
  }
}

// Get auction status based on time
export function getAuctionStatus(auction: Auction): AuctionStatus {
  const now = new Date()
  const startTime = new Date(auction.startTime)
  const endTime = new Date(auction.endTime)
  const { total } = getTimeRemaining(endTime)

  if (auction.status === 'cancelled' || auction.status === 'completed') {
    return auction.status
  }

  if (now < startTime) {
    return 'scheduled'
  }

  if (now > endTime) {
    return 'ended'
  }

  // Last 5 minutes
  if (total <= 5 * 60 * 1000) {
    return 'ending_soon'
  }

  return 'active'
}

// Get status color
export function getAuctionStatusColor(status: AuctionStatus): string {
  const colors: Record<AuctionStatus, string> = {
    draft: 'bg-slate-100 text-slate-700 dark:bg-slate-900/20 dark:text-slate-400',
    scheduled: 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
    active: 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400',
    ending_soon: 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400',
    ended: 'bg-slate-100 text-slate-700 dark:bg-slate-900/20 dark:text-slate-400',
    cancelled: 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400',
    completed: 'bg-purple-100 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400'
  }
  return colors[status]
}

// Get status label
export function getAuctionStatusLabel(status: AuctionStatus): string {
  const labels: Record<AuctionStatus, string> = {
    draft: 'Draft',
    scheduled: 'Scheduled',
    active: 'Active',
    ending_soon: 'Ending Soon',
    ended: 'Ended',
    cancelled: 'Cancelled',
    completed: 'Completed'
  }
  return labels[status]
}

// Validate bid amount
export function validateBid(
  amount: number,
  auction: Auction,
  userHighestBid?: number
): { valid: boolean; error?: string } {
  // Check if auction is active
  const status = getAuctionStatus(auction)
  if (status !== 'active' && status !== 'ending_soon') {
    return { valid: false, error: 'Auction is not active' }
  }

  // Check minimum bid
  const minimumBid = auction.currentPrice + auction.bidIncrement
  if (amount < minimumBid) {
    return {
      valid: false,
      error: `Minimum bid is ₹${minimumBid.toLocaleString()}`
    }
  }

  // Check if user is trying to bid against themselves
  if (userHighestBid && amount <= userHighestBid) {
    return {
      valid: false,
      error: 'You already have a higher bid'
    }
  }

  // Check reserve price (if public)
  if (auction.reservePrice && amount < auction.reservePrice) {
    return {
      valid: false,
      error: `Bid must meet reserve price of ₹${auction.reservePrice.toLocaleString()}`
    }
  }

  return { valid: true }
}

// Calculate next minimum bid
export function getMinimumBid(auction: Auction): number {
  return auction.currentPrice + auction.bidIncrement
}

// Format currency
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(amount)
}

// Check if auction is ending soon (next 24 hours)
export function isEndingSoon(endTime: Date): boolean {
  const { total } = getTimeRemaining(endTime)
  return total > 0 && total <= 24 * 60 * 60 * 1000
}

// Check if user is winning
export function isUserWinning(auction: Auction, userId: string, bids: Bid[]): boolean {
  if (bids.length === 0) return false
  
  const highestBid = bids.reduce((prev, current) => 
    current.amount > prev.amount ? current : prev
  )
  
  return highestBid.bidderId === userId
}

// Get user's highest bid
export function getUserHighestBid(userId: string, bids: Bid[]): Bid | undefined {
  const userBids = bids.filter(b => b.bidderId === userId)
  if (userBids.length === 0) return undefined
  
  return userBids.reduce((prev, current) => 
    current.amount > prev.amount ? current : prev
  )
}

// Filter auctions
export function filterAuctions(
  auctions: Auction[],
  filters: AuctionFilters
): Auction[] {
  let filtered = [...auctions]

  if (filters.category) {
    filtered = filtered.filter(a => a.category === filters.category)
  }

  if (filters.status) {
    filtered = filtered.filter(a => getAuctionStatus(a) === filters.status)
  }

  if (filters.minPrice !== undefined) {
    filtered = filtered.filter(a => a.currentPrice >= filters.minPrice!)
  }

  if (filters.maxPrice !== undefined) {
    filtered = filtered.filter(a => a.currentPrice <= filters.maxPrice!)
  }

  if (filters.endingSoon) {
    filtered = filtered.filter(a => isEndingSoon(a.endTime))
  }

  if (filters.hasReserve !== undefined) {
    filtered = filtered.filter(a => 
      filters.hasReserve ? a.reservePrice !== undefined : a.reservePrice === undefined
    )
  }

  if (filters.hasBuyNow !== undefined) {
    filtered = filtered.filter(a => 
      filters.hasBuyNow ? a.buyNowPrice !== undefined : a.buyNowPrice === undefined
    )
  }

  if (filters.shippingAvailable !== undefined) {
    filtered = filtered.filter(a => a.shippingAvailable === filters.shippingAvailable)
  }

  if (filters.search) {
    const query = filters.search.toLowerCase()
    filtered = filtered.filter(a =>
      a.title.toLowerCase().includes(query) ||
      a.description.toLowerCase().includes(query)
    )
  }

  // Sort
  if (filters.sortBy) {
    switch (filters.sortBy) {
      case 'ending_soon':
        filtered.sort((a, b) => 
          new Date(a.endTime).getTime() - new Date(b.endTime).getTime()
        )
        break
      case 'newly_listed':
        filtered.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        )
        break
      case 'price_low':
        filtered.sort((a, b) => a.currentPrice - b.currentPrice)
        break
      case 'price_high':
        filtered.sort((a, b) => b.currentPrice - a.currentPrice)
        break
      case 'most_bids':
        filtered.sort((a, b) => b.totalBids - a.totalBids)
        break
    }
  }

  return filtered
}

// Calculate bid increment based on current price
export function calculateBidIncrement(currentPrice: number): number {
  if (currentPrice < 1000) return 50
  if (currentPrice < 5000) return 100
  if (currentPrice < 10000) return 250
  if (currentPrice < 50000) return 500
  if (currentPrice < 100000) return 1000
  return 2500
}

// Anti-sniping: Extend auction if bid in last 2 minutes
export function shouldExtendAuction(endTime: Date, bidTime: Date): boolean {
  const timeRemaining = new Date(endTime).getTime() - new Date(bidTime).getTime()
  return timeRemaining <= 2 * 60 * 1000 // 2 minutes
}

// Calculate new end time (add 2 minutes)
export function extendAuctionTime(endTime: Date): Date {
  const newEndTime = new Date(endTime)
  newEndTime.setMinutes(newEndTime.getMinutes() + 2)
  return newEndTime
}
