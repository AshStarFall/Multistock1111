"use client"

export type PricingModel = "fixed" | "tiered" | "subscription" | "rent_to_own"

export type Tier = { uptoDays: number; ratePerDay: number }

export type PricingConfig = {
  fixed?: { ratePerDay: number }
  tiered?: { tiers: Tier[]; overflowRatePerDay: number }
  subscription?: { monthly: number; includedDaysPerMonth: number; overageRatePerDay: number }
  rent_to_own?: { daily: number; maxCap: number }
}

export function calculatePrice(model: PricingModel, days: number, config: PricingConfig): number {
  const d = Math.max(0, Math.floor(days))
  if (d === 0) return 0
  switch (model) {
    case "fixed": {
      const rate = config.fixed?.ratePerDay ?? 100
      return d * rate
    }
    case "tiered": {
      const tiers = (config.tiered?.tiers ?? []).slice().sort((a, b) => a.uptoDays - b.uptoDays)
      let remaining = d
      let total = 0
      for (const t of tiers) {
        if (remaining <= 0) break
        const take = Math.min(remaining, t.uptoDays)
        total += take * t.ratePerDay
        remaining -= take
      }
      if (remaining > 0) total += remaining * (config.tiered?.overflowRatePerDay ?? tiers.at(-1)?.ratePerDay ?? 100)
      return total
    }
    case "subscription": {
      const monthly = config.subscription?.monthly ?? 300
      const included = config.subscription?.includedDaysPerMonth ?? 10
      const overRate = config.subscription?.overageRatePerDay ?? 20
      const months = Math.ceil(d / 30)
      const includedTotal = months * included
      const overage = Math.max(0, d - includedTotal)
      return months * monthly + overage * overRate
    }
    case "rent_to_own": {
      const daily = config.rent_to_own?.daily ?? 10
      const cap = config.rent_to_own?.maxCap ?? 1000
      return Math.min(cap, d * daily)
    }
  }
}


