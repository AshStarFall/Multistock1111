const NS = "invms"
function k(key: string) {
  return `${NS}:${key}`
}

export function load<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback
  try {
    const raw = localStorage.getItem(k(key))
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

export function save<T>(key: string, value: T) {
  if (typeof window === "undefined") return
  try {
    localStorage.setItem(k(key), JSON.stringify(value))
  } catch {}
}

export function safeGet<T>(key: string, fallback: T): T {
  return load<T>(key, fallback)
}

export function safeSet<T>(key: string, value: T) {
  return save<T>(key, value)
}
