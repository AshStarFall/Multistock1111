import { authenticator } from 'otplib'

export interface MFASecret {
  secret: string
  qrCodeUrl: string
}

export function generateMFASecret(userEmail: string): MFASecret {
  const secret = authenticator.generateSecret()
  const qrCodeUrl = authenticator.keyuri(userEmail, 'MultiStock Logistics', secret)
  
  return {
    secret,
    qrCodeUrl
  }
}

export function verifyMFAToken(secret: string, token: string): boolean {
  try {
    return authenticator.verify({ token, secret })
  } catch {
    return false
  }
}

export function generateBackupCodes(): string[] {
  return Array.from({ length: 10 }, () => 
    Math.random().toString(36).substring(2, 8).toUpperCase()
  )
}
