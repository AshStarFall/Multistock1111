export async function authenticateUser(identifier: string, password: string) {
  try {
    console.log('🔍 Looking for user:', identifier)
    
    // Check if identifier is email or username
    const isEmail = identifier.includes('@')
    
    let query = supabase
      .from('users')
      .select('*')
      .eq('is_active', true)
    
    // Search by email OR username
    if (isEmail) {
      query = query.eq('email', identifier)
    } else {
      query = query.eq('username', identifier)
    }
    
    const { data: user, error } = await query.single()

    if (error || !user) {
      console.log('❌ User not found:', identifier)
      return null
    }

    console.log('✅ User found:', user.email)
    
    // Verify password
    console.log('🔐 Verifying password...')
    const isValid = await bcrypt.compare(password, user.password_hash)
    
    if (!isValid) {
      console.log('❌ Invalid password')
      return null
    }

    console.log('✅ Login successful!')
    
    return {
      id: user.id,
      email: user.email,
      username: user.username,
      name: user.name,
      role: user.role,
      department: user.department
    }
  } catch (error) {
    console.error('❌ Authentication error:', error)
    return null
  }
}