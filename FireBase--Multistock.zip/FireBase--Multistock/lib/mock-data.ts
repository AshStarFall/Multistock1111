import type { Product, Warehouse, Supplier } from "./types"

export const warehouses: Warehouse[] = [
  { id: "wh-mum", name: "Mumbai Distribution Center", code: "MUM-01", address: "Bandra Kurla Complex, Mumbai, Maharashtra 400051" },
  { id: "wh-del", name: "Delhi Distribution Center", code: "DEL-01", address: "Connaught Place, New Delhi, Delhi 110001" },
  { id: "wh-bang", name: "Bangalore Distribution Center", code: "BANG-01", address: "Electronic City, Bangalore, Karnataka 560100" },
  { id: "wh-chen", name: "Chennai Distribution Center", code: "CHEN-01", address: "Tidel Park, Chennai, Tamil Nadu 600113" },
]

export const suppliers: Supplier[] = [
  { id: "sup-1", name: "Reliance Industries Ltd", email: "procurement@ril.com", phone: "+91-22-3555-5555" },
  { id: "sup-2", name: "Tata Steel Limited", email: "orders@tatasteel.com", phone: "+91-33-6666-7777" },
  { id: "sup-3", name: "Adani Logistics", email: "supply@adani.com", phone: "+91-79-8888-9999" },
]

export const products: Product[] = [
  {
    id: "p-1",
    sku: "SKU-0001",
    name: "Thermal Label Roll - Made in India",
    imageUrl: "/placeholder.jpg",
    category: "Packaging",
    unit: "roll",
    cost: 150.0,
    price: 300.0,
    stockByWarehouse: { "wh-mum": 120, "wh-del": 60, "wh-bang": 45, "wh-chen": 30 },
    reorderPoint: 50,
    supplierId: "sup-1",
    active: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "p-2",
    sku: "SKU-0002",
    name: "Corrugated Box - Small (Indian Standard)",
    imageUrl: "/placeholder.jpg",
    category: "Packaging",
    unit: "box",
    cost: 45.0,
    price: 110.0,
    stockByWarehouse: { "wh-mum": 45, "wh-del": 20, "wh-bang": 35, "wh-chen": 25 },
    reorderPoint: 40,
    supplierId: "sup-2",
    active: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "p-3",
    sku: "SKU-0003",
    name: "Bubble Wrap - Eco-Friendly",
    imageUrl: "/placeholder.jpg",
    category: "Packaging",
    unit: "roll",
    cost: 180.0,
    price: 360.0,
    stockByWarehouse: { "wh-mum": 25, "wh-del": 12, "wh-bang": 18, "wh-chen": 15 },
    reorderPoint: 30,
    supplierId: "sup-1",
    active: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "p-4",
    sku: "SKU-0004",
    name: "Steel Storage Rack - Heavy Duty",
    imageUrl: "/placeholder.jpg",
    category: "Storage Equipment",
    unit: "piece",
    cost: 2500.0,
    price: 4500.0,
    stockByWarehouse: { "wh-mum": 8, "wh-del": 5, "wh-bang": 6, "wh-chen": 4 },
    reorderPoint: 10,
    supplierId: "sup-2",
    active: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "p-5",
    sku: "SKU-0005",
    name: "Industrial Forklift - Electric",
    imageUrl: "/placeholder.jpg",
    category: "Heavy Machinery",
    unit: "piece",
    cost: 450000.0,
    price: 650000.0,
    stockByWarehouse: { "wh-mum": 2, "wh-del": 1, "wh-bang": 1, "wh-chen": 1 },
    reorderPoint: 2,
    supplierId: "sup-3",
    active: true,
    updatedAt: new Date().toISOString(),
  },
]

// helpers
export function totalOnHand(product: Product) {
  return Object.values(product.stockByWarehouse).reduce((a, b) => a + b, 0)
}

export function lowStock(product: Product) {
  if (product.reorderPoint == null) return false
  return totalOnHand(product) <= product.reorderPoint
}
