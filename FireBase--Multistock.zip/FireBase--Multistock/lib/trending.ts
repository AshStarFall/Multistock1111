// Trending Sales & Hot Deals System
export type TrendingProduct = {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  image: string;
  category: string;
  seller: string;
  sellerId: string;
  rating: number;
  reviews: number;
  salesCount: number;
  viewsCount: number;
  trendingScore: number;
  isHotDeal: boolean;
  dealEndsAt?: string;
  stock: number;
  tags: string[];
};

export type Announcement = {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'promotion';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  startDate: string;
  endDate?: string;
  link?: string;
  linkText?: string;
  isActive: boolean;
  createdAt: string;
};

export type DemandMetrics = {
  productId: string;
  productName: string;
  category: string;
  dailyViews: number;
  dailySales: number;
  weeklyViews: number;
  weeklySales: number;
  monthlyViews: number;
  monthlySales: number;
  conversionRate: number;
  growthRate: number;
  trendingRank: number;
};

export type FilterOptions = {
  category?: string;
  priceRange?: { min: number; max: number };
  minDiscount?: number;
  minRating?: number;
  sortBy?: 'trending' | 'sales' | 'discount' | 'price-low' | 'price-high' | 'newest';
  onlyHotDeals?: boolean;
};

// Calculate trending score based on multiple factors
export function calculateTrendingScore(product: {
  salesCount: number;
  viewsCount: number;
  rating: number;
  reviews: number;
  createdAt: string;
}): number {
  const daysSinceCreated = Math.max(
    1,
    (Date.now() - new Date(product.createdAt).getTime()) / (1000 * 60 * 60 * 24)
  );

  // Weighted scoring algorithm
  const salesWeight = 0.4;
  const viewsWeight = 0.2;
  const ratingWeight = 0.2;
  const reviewsWeight = 0.1;
  const recencyWeight = 0.1;

  // Normalize values
  const salesScore = Math.min(product.salesCount / 100, 1) * 100;
  const viewsScore = Math.min(product.viewsCount / 1000, 1) * 100;
  const ratingScore = (product.rating / 5) * 100;
  const reviewsScore = Math.min(product.reviews / 50, 1) * 100;
  const recencyScore = Math.max(0, 100 - daysSinceCreated * 2); // Newer = higher score

  const totalScore =
    salesScore * salesWeight +
    viewsScore * viewsWeight +
    ratingScore * ratingWeight +
    reviewsScore * reviewsWeight +
    recencyScore * recencyWeight;

  return Math.round(totalScore);
}

// Filter and sort trending products
export function filterTrendingProducts(
  products: TrendingProduct[],
  filters: FilterOptions
): TrendingProduct[] {
  let filtered = [...products];

  // Apply filters
  if (filters.category) {
    filtered = filtered.filter((p) => p.category === filters.category);
  }

  if (filters.priceRange) {
    filtered = filtered.filter(
      (p) =>
        p.price >= filters.priceRange!.min && p.price <= filters.priceRange!.max
    );
  }

  if (filters.minDiscount) {
    filtered = filtered.filter((p) => (p.discount || 0) >= filters.minDiscount!);
  }

  if (filters.minRating) {
    filtered = filtered.filter((p) => p.rating >= filters.minRating!);
  }

  if (filters.onlyHotDeals) {
    filtered = filtered.filter((p) => p.isHotDeal);
  }

  // Apply sorting
  switch (filters.sortBy) {
    case 'trending':
      filtered.sort((a, b) => b.trendingScore - a.trendingScore);
      break;
    case 'sales':
      filtered.sort((a, b) => b.salesCount - a.salesCount);
      break;
    case 'discount':
      filtered.sort((a, b) => (b.discount || 0) - (a.discount || 0));
      break;
    case 'price-low':
      filtered.sort((a, b) => a.price - b.price);
      break;
    case 'price-high':
      filtered.sort((a, b) => b.price - a.price);
      break;
    case 'newest':
      filtered.sort((a, b) => b.salesCount - a.salesCount); // Use as proxy for newest
      break;
    default:
      filtered.sort((a, b) => b.trendingScore - a.trendingScore);
  }

  return filtered;
}

// Check if a deal is expiring soon (within 24 hours)
export function isDealExpiringSoon(dealEndsAt?: string): boolean {
  if (!dealEndsAt) return false;
  const timeLeft = new Date(dealEndsAt).getTime() - Date.now();
  return timeLeft > 0 && timeLeft < 24 * 60 * 60 * 1000;
}

// Get time remaining for a deal
export function getDealTimeRemaining(dealEndsAt?: string): {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  expired: boolean;
} {
  if (!dealEndsAt) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
  }

  const timeLeft = new Date(dealEndsAt).getTime() - Date.now();

  if (timeLeft <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
  }

  const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
  const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

  return { days, hours, minutes, seconds, expired: false };
}

// Format deal countdown text
export function formatDealCountdown(dealEndsAt?: string): string {
  const time = getDealTimeRemaining(dealEndsAt);

  if (time.expired) return 'Expired';

  if (time.days > 0) {
    return `${time.days}d ${time.hours}h left`;
  } else if (time.hours > 0) {
    return `${time.hours}h ${time.minutes}m left`;
  } else if (time.minutes > 0) {
    return `${time.minutes}m ${time.seconds}s left`;
  } else {
    return `${time.seconds}s left`;
  }
}

// Get categories with trending product counts
export function getTrendingCategories(products: TrendingProduct[]): {
  category: string;
  count: number;
  avgDiscount: number;
}[] {
  const categoryMap = new Map<string, { count: number; totalDiscount: number }>();

  products.forEach((product) => {
    const existing = categoryMap.get(product.category) || {
      count: 0,
      totalDiscount: 0,
    };
    categoryMap.set(product.category, {
      count: existing.count + 1,
      totalDiscount: existing.totalDiscount + (product.discount || 0),
    });
  });

  return Array.from(categoryMap.entries())
    .map(([category, data]) => ({
      category,
      count: data.count,
      avgDiscount: Math.round(data.totalDiscount / data.count),
    }))
    .sort((a, b) => b.count - a.count);
}

// Filter active announcements
export function getActiveAnnouncements(announcements: Announcement[]): Announcement[] {
  const now = Date.now();

  return announcements
    .filter((announcement) => {
      if (!announcement.isActive) return false;

      const startTime = new Date(announcement.startDate).getTime();
      const endTime = announcement.endDate
        ? new Date(announcement.endDate).getTime()
        : Infinity;

      return now >= startTime && now <= endTime;
    })
    .sort((a, b) => {
      // Sort by priority first
      const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
      const priorityDiff =
        priorityOrder[b.priority] - priorityOrder[a.priority];
      if (priorityDiff !== 0) return priorityDiff;

      // Then by start date (newest first)
      return (
        new Date(b.startDate).getTime() - new Date(a.startDate).getTime()
      );
    });
}

// Get announcement color based on type
export function getAnnouncementColor(type: Announcement['type']): {
  bg: string;
  text: string;
  border: string;
} {
  switch (type) {
    case 'info':
      return {
        bg: 'bg-blue-50 dark:bg-blue-950/20',
        text: 'text-blue-900 dark:text-blue-100',
        border: 'border-blue-200 dark:border-blue-800',
      };
    case 'success':
      return {
        bg: 'bg-green-50 dark:bg-green-950/20',
        text: 'text-green-900 dark:text-green-100',
        border: 'border-green-200 dark:border-green-800',
      };
    case 'warning':
      return {
        bg: 'bg-yellow-50 dark:bg-yellow-950/20',
        text: 'text-yellow-900 dark:text-yellow-100',
        border: 'border-yellow-200 dark:border-yellow-800',
      };
    case 'error':
      return {
        bg: 'bg-red-50 dark:bg-red-950/20',
        text: 'text-red-900 dark:text-red-100',
        border: 'border-red-200 dark:border-red-800',
      };
    case 'promotion':
      return {
        bg: 'bg-purple-50 dark:bg-purple-950/20',
        text: 'text-purple-900 dark:text-purple-100',
        border: 'border-purple-200 dark:border-purple-800',
      };
    default:
      return {
        bg: 'bg-gray-50 dark:bg-gray-950/20',
        text: 'text-gray-900 dark:text-gray-100',
        border: 'border-gray-200 dark:border-gray-800',
      };
  }
}
