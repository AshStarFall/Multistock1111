// Discount & Coupons System
export type CouponType = 'percentage' | 'fixed_amount' | 'free_shipping' | 'bogo';

export type CouponStatus = 'active' | 'inactive' | 'expired' | 'depleted';

export type Coupon = {
  id: string;
  code: string;
  name: string;
  description: string;
  type: CouponType;
  value: number; // percentage or fixed amount
  minPurchaseAmount?: number;
  maxDiscountAmount?: number;
  usageLimit: number;
  usageCount: number;
  perUserLimit?: number;
  startDate: string;
  endDate: string;
  status: CouponStatus;
  applicableProducts?: string[];
  applicableCategories?: string[];
  excludedProducts?: string[];
  isPublic: boolean;
  createdBy: string;
  createdAt: string;
};

export type CouponUsage = {
  id: string;
  couponId: string;
  couponCode: string;
  userId: string;
  orderId: string;
  discountAmount: number;
  usedAt: string;
};

export type CouponValidation = {
  valid: boolean;
  coupon?: Coupon;
  discountAmount?: number;
  error?: string;
};

// Generate random coupon code
export function generateCouponCode(length: number = 8): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Generate task-based coupon codes
export function generateTaskCoupon(taskName: string): string {
  const prefix = taskName.substring(0, 3).toUpperCase();
  const random = generateCouponCode(5);
  return `${prefix}${random}`;
}

// Validate coupon
export function validateCoupon(
  coupon: Coupon,
  orderAmount: number,
  userId: string,
  userUsageCount: number = 0
): CouponValidation {
  // Check if coupon is active
  if (coupon.status !== 'active') {
    return { valid: false, error: 'This coupon is not active' };
  }

  // Check date validity
  const now = new Date();
  const startDate = new Date(coupon.startDate);
  const endDate = new Date(coupon.endDate);

  if (now < startDate) {
    return { valid: false, error: 'This coupon is not yet valid' };
  }

  if (now > endDate) {
    return { valid: false, error: 'This coupon has expired' };
  }

  // Check usage limit
  if (coupon.usageCount >= coupon.usageLimit) {
    return { valid: false, error: 'This coupon has reached its usage limit' };
  }

  // Check per-user limit
  if (coupon.perUserLimit && userUsageCount >= coupon.perUserLimit) {
    return {
      valid: false,
      error: `You have already used this coupon ${coupon.perUserLimit} time(s)`,
    };
  }

  // Check minimum purchase amount
  if (coupon.minPurchaseAmount && orderAmount < coupon.minPurchaseAmount) {
    return {
      valid: false,
      error: `Minimum purchase amount of ₹${coupon.minPurchaseAmount} required`,
    };
  }

  // Calculate discount amount
  let discountAmount = 0;

  switch (coupon.type) {
    case 'percentage':
      discountAmount = (orderAmount * coupon.value) / 100;
      if (coupon.maxDiscountAmount) {
        discountAmount = Math.min(discountAmount, coupon.maxDiscountAmount);
      }
      break;

    case 'fixed_amount':
      discountAmount = Math.min(coupon.value, orderAmount);
      break;

    case 'free_shipping':
      // Placeholder - would calculate shipping cost
      discountAmount = 100; // Example shipping cost
      break;

    case 'bogo':
      // Buy One Get One - 50% off on the order
      discountAmount = orderAmount * 0.5;
      break;

    default:
      discountAmount = 0;
  }

  return {
    valid: true,
    coupon,
    discountAmount: Math.round(discountAmount),
  };
}

// Calculate final price after coupon
export function calculateDiscountedPrice(
  originalPrice: number,
  discountAmount: number
): {
  originalPrice: number;
  discountAmount: number;
  finalPrice: number;
  savings: number;
  savingsPercentage: number;
} {
  const finalPrice = Math.max(0, originalPrice - discountAmount);
  const savings = originalPrice - finalPrice;
  const savingsPercentage = (savings / originalPrice) * 100;

  return {
    originalPrice,
    discountAmount,
    finalPrice: Math.round(finalPrice),
    savings: Math.round(savings),
    savingsPercentage: Math.round(savingsPercentage * 10) / 10,
  };
}

// Get coupon status color
export function getCouponStatusColor(status: CouponStatus): string {
  switch (status) {
    case 'active':
      return 'text-green-600 bg-green-50 dark:bg-green-950/20';
    case 'inactive':
      return 'text-gray-600 bg-gray-50 dark:bg-gray-950/20';
    case 'expired':
      return 'text-red-600 bg-red-50 dark:bg-red-950/20';
    case 'depleted':
      return 'text-orange-600 bg-orange-50 dark:bg-orange-950/20';
    default:
      return 'text-blue-600 bg-blue-50 dark:bg-blue-950/20';
  }
}

// Get coupon type label
export function getCouponTypeLabel(type: CouponType): string {
  switch (type) {
    case 'percentage':
      return 'Percentage Discount';
    case 'fixed_amount':
      return 'Fixed Amount';
    case 'free_shipping':
      return 'Free Shipping';
    case 'bogo':
      return 'Buy One Get One';
    default:
      return type;
  }
}

// Get coupon type icon
export function getCouponTypeIcon(type: CouponType): string {
  switch (type) {
    case 'percentage':
      return '%';
    case 'fixed_amount':
      return '₹';
    case 'free_shipping':
      return '🚚';
    case 'bogo':
      return '2x';
    default:
      return '🎁';
  }
}

// Format coupon value
export function formatCouponValue(type: CouponType, value: number): string {
  switch (type) {
    case 'percentage':
      return `${value}% OFF`;
    case 'fixed_amount':
      return `₹${value} OFF`;
    case 'free_shipping':
      return 'FREE SHIPPING';
    case 'bogo':
      return 'BUY 1 GET 1';
    default:
      return `${value}`;
  }
}

// Check if coupon is expiring soon (within 3 days)
export function isCouponExpiringSoon(endDate: string): boolean {
  const now = Date.now();
  const end = new Date(endDate).getTime();
  const daysLeft = (end - now) / (1000 * 60 * 60 * 24);
  return daysLeft > 0 && daysLeft <= 3;
}

// Get days until expiry
export function getDaysUntilExpiry(endDate: string): number {
  const now = Date.now();
  const end = new Date(endDate).getTime();
  return Math.ceil((end - now) / (1000 * 60 * 60 * 24));
}

// Filter available coupons
export function getAvailableCoupons(
  coupons: Coupon[],
  orderAmount?: number
): Coupon[] {
  const now = new Date();

  return coupons.filter((coupon) => {
    if (coupon.status !== 'active') return false;
    if (new Date(coupon.endDate) < now) return false;
    if (coupon.usageCount >= coupon.usageLimit) return false;
    if (orderAmount && coupon.minPurchaseAmount) {
      return orderAmount >= coupon.minPurchaseAmount;
    }
    return true;
  });
}
