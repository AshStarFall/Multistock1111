"use client"

import { safeGet, safeSet } from "./storage"

export type Role =
  | "admin"
  | "subadmin"
  | "manager"
  | "team_leader"
  | "employee"
  | "customer"
  | "guest"

export type Permission =
  | "view"
  | "edit"
  | "add"
  | "transfer"
  | "remove"
  | "admin_view"

export type SessionUser = {
  id: string
  name: string
  email?: string
  role: Role
  username?: string
}

const SESSION_KEY = "msl-session"
const USERS_KEY = "msl-users"

const roleHierarchy: Role[] = [
  "guest",
  "customer",
  "employee",
  "team_leader",
  "manager",
  "subadmin",
  "admin",
]

const rolePermissions: Record<Role, Permission[]> = {
  guest: ["view"],
  customer: ["view"],
  employee: ["view", "edit", "add", "transfer", "remove"],
  team_leader: ["view", "edit", "add", "transfer", "remove"],
  manager: ["view", "edit", "add", "transfer", "remove"],
  subadmin: ["view", "edit", "add", "transfer", "remove", "admin_view"],
  admin: ["view", "edit", "add", "transfer", "remove", "admin_view"],
}

export function getSession(): SessionUser | null {
  return safeGet<SessionUser | null>(SESSION_KEY, null)
}

export function setSession(user: SessionUser | null) {
  safeSet(SESSION_KEY, user)
}

export function hasPermission(role: Role, permission: Permission): boolean {
  return rolePermissions[role]?.includes(permission) ?? false
}

export function roleAtLeast(role: Role, minimum: Role): boolean {
  return roleHierarchy.indexOf(role) >= roleHierarchy.indexOf(minimum)
}

export function isAdmin(role: Role) {
  return role === "admin" || role === "subadmin"
}

export function requireRoles(allowed: Role[], role: Role): boolean {
  return allowed.includes(role)
}

export function signInAs(role: Role) {
  const user: SessionUser = {
    id: `user_${Math.random().toString(36).slice(2, 8)}`,
    name: role.toUpperCase(),
    role,
  }
  setSession(user)
  return user
}

export function signOut() {
  setSession(null)
}

export type RegisteredUser = {
  id: string
  name: string
  email: string
  passwordHash: string
  role: Role
  username: string
}

export function getUsers(): RegisteredUser[] {
  const users = safeGet<RegisteredUser[]>(USERS_KEY, [])
  if (users.length === 0) {
    const seed: RegisteredUser[] = [
      { id: "user_admin", name: "Administrator", email: "admin@gmail.com", username: "admin", passwordHash: hashPassword("123"), role: "admin" },
      { id: "user_subadmin", name: "Sub Admin", email: "subadmin@msl.local", username: "subadmin", passwordHash: hashPassword("1234"), role: "subadmin" },
      { id: "user_manager", name: "Manager", email: "manager@msl.local", username: "manager", passwordHash: hashPassword("1234"), role: "manager" },
      { id: "user_lead", name: "Team Lead", email: "lead@msl.local", username: "lead", passwordHash: hashPassword("1234"), role: "team_leader" },
      { id: "user_employee", name: "Employee", email: "employee@msl.local", username: "employee", passwordHash: hashPassword("1234"), role: "employee" },
      { id: "user_customer", name: "Customer", email: "customer@msl.local", username: "customer", passwordHash: hashPassword("1234"), role: "customer" },
    ]
    saveUsers(seed)
    return seed
  }
  return users
}

export function saveUsers(users: RegisteredUser[]) {
  safeSet(USERS_KEY, users)
}

export function hashPassword(pw: string) {
  // demo hash only (DO NOT use in production)
  return btoa(pw)
}

export function signup(name: string, email: string, username: string, password: string, role: Role): SessionUser {
  const users = getUsers()
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("Email already registered")
  }
  if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
    throw new Error("Username already taken")
  }
  const u: RegisteredUser = {
    id: `user_${Math.random().toString(36).slice(2, 8)}`,
    name,
    email,
    username,
    passwordHash: hashPassword(password),
    role,
  }
  const next = [u, ...users]
  saveUsers(next)
  const session: SessionUser = { id: u.id, name: u.name, email: u.email, role: u.role, username: u.username }
  setSession(session)
  return session
}

export function login(emailOrUsername: string, password: string): SessionUser {
  const users = getUsers()
  const key = emailOrUsername.toLowerCase()
  const u = users.find((x) => x.email.toLowerCase() === key || x.username.toLowerCase() === key)
  if (!u) throw new Error("User not found")
  if (u.passwordHash !== hashPassword(password)) throw new Error("Invalid password")
  // Defer session until MFA verified
  const pending: SessionUser = { id: u.id, name: u.name, email: u.email, role: u.role, username: u.username }
  safeSet("msl-mfa-pending", pending)
  return pending
}


