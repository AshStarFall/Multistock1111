"use client"

import { safeGet, safeSet } from "./storage"

export type Booking = {
  id: string
  type: "rental" | "storage"
  resourceId: string
  title: string
  startDate: string
  endDate: string
  createdAt: string
  pricePerDay?: number
  couponCode?: string
  subtotal?: number
  discount?: number
  total?: number
}

const KEY = "msl-bookings"

function nowISO() {
  return new Date().toISOString()
}

export function listBookings(): Booking[] {
  return safeGet<Booking[]>(KEY, [])
}

export function addBooking(input: Omit<Booking, "id" | "createdAt" | "subtotal" | "discount" | "total">) {
  const msPerDay = 24 * 60 * 60 * 1000
  const days = Math.max(1, Math.ceil((new Date(input.endDate).getTime() - new Date(input.startDate).getTime()) / msPerDay))
  const pricePerDay = input.pricePerDay ?? 100
  const subtotal = days * pricePerDay
  const allCoupons = safeGet<{ id: string; code: string; percentOff: number; active: boolean }[]>("msl-coupons", [])
  const applied = input.couponCode ? allCoupons.find((c) => c.code === input.couponCode && c.active) : undefined
  const discount = applied ? Math.round((subtotal * applied.percentOff) / 100) : 0
  const total = subtotal - discount
  const b: Booking = {
    id: `bk_${Math.random().toString(36).slice(2, 8)}`,
    createdAt: nowISO(),
    ...input,
    pricePerDay,
    subtotal,
    discount,
    total,
  }
  const next = [b, ...listBookings()]
  safeSet(KEY, next)
  return b
}


