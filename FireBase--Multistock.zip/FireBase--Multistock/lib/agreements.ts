"use client"

import { safeGet, safeSet } from "./storage"

export type PricingModel = "fixed" | "tiered" | "subscription" | "rent_to_own"

export type RentalAgreement = {
  id: string
  itemId: string
  customer: string
  startDate: string
  endDate?: string
  pricingModel: PricingModel
  notes?: string
  createdAt: string
}

const KEY = "msl-agreements"

function nowISO() {
  return new Date().toISOString()
}

export function listAgreements(): RentalAgreement[] {
  return safeGet<RentalAgreement[]>(KEY, [])
}

export function createAgreement(input: Omit<RentalAgreement, "id" | "createdAt">) {
  const a: RentalAgreement = { id: `agr_${Math.random().toString(36).slice(2, 8)}`, createdAt: nowISO(), ...input }
  const next = [a, ...listAgreements()]
  safeSet(KEY, next)
  return a
}

export function listAgreementsByItem(itemId: string) {
  return listAgreements().filter((a) => a.itemId === itemId)
}


