"use client"

import { safeGet, safeSet } from "./storage"

export type Listing = {
  id: string
  title: string
  description?: string
  imageUrl?: string
  owner: string
  bids: { id: string; bidder: string; amount: number; placedAt: string }[]
  acceptedBidId?: string
  createdAt: string
}

const KEY = "msl-listings"

function nowISO() {
  return new Date().toISOString()
}

export function listListings(): Listing[] {
  return safeGet<Listing[]>(KEY, [])
}

export function addListing(input: Omit<Listing, "id" | "createdAt" | "bids">) {
  const l: Listing = { id: `ls_${Math.random().toString(36).slice(2, 8)}`, createdAt: nowISO(), bids: [], ...input }
  const next = [l, ...listListings()]
  safeSet(KEY, next)
  return l
}

export function placeBid(listingId: string, bidder: string, amount: number) {
  const all = listListings()
  const next = all.map((l) =>
    l.id === listingId ? { ...l, bids: [{ id: `bd_${Math.random().toString(36).slice(2, 8)}`, bidder, amount, placedAt: nowISO() }, ...l.bids] } : l,
  )
  safeSet(KEY, next)
}

export function acceptBid(listingId: string, bidId: string) {
  const all = listListings()
  const next = all.map((l) => (l.id === listingId ? { ...l, acceptedBidId: bidId } : l))
  safeSet(KEY, next)
}


