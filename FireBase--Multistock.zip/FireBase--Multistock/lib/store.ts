"use client"

import useSWR, { mutate } from "swr"
import { safeGet, safeSet } from "./storage"

export type ID = string

export type Product = {
  id: ID
  name: string
  sku: string
  warehouseId: ID
  stock: number
  price: number
  createdAt: string
  updatedAt: string
}

export type Warehouse = {
  id: ID
  name: string
  code: string
  location?: string
  createdAt: string
  updatedAt: string
}

export type Supplier = {
  id: ID
  name: string
  email?: string
  phone?: string
  createdAt: string
  updatedAt: string
}

export type Adjustment = {
  id: ID
  productId: ID
  delta: number
  reason?: string
  createdAt: string
}

type StoreShape = {
  products: Product[]
  warehouses: Warehouse[]
  suppliers: Supplier[]
  adjustments: Adjustment[]
}

const KEY = "inv-store"

function nowISO() {
  return new Date().toISOString()
}

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`
}

function load(): StoreShape {
  return safeGet<StoreShape>(KEY, {
    products: [],
    warehouses: [],
    suppliers: [],
    adjustments: [],
  })
}

function save(next: StoreShape) {
  safeSet(KEY, next)
}

export function useStore() {
  const { data } = useSWR<StoreShape>(KEY, {
    fetcher: () => load(),
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  })
  const state = data ?? load()

  function set(partial: Partial<StoreShape>) {
    const next = { ...state, ...partial }
    save(next)
    mutate(KEY, next, { revalidate: false })
  }

  // Products
  function addProduct(input: Omit<Product, "id" | "createdAt" | "updatedAt">) {
    const p: Product = { id: uid("prd"), createdAt: nowISO(), updatedAt: nowISO(), ...input }
    set({ products: [p, ...state.products] })
    return p
  }
  function updateProduct(id: ID, patch: Partial<Product>) {
    set({
      products: state.products.map((p) => (p.id === id ? { ...p, ...patch, updatedAt: nowISO() } : p)),
    })
  }
  function deleteProduct(id: ID) {
    set({ products: state.products.filter((p) => p.id !== id) })
  }

  // Warehouses
  function addWarehouse(input: Omit<Warehouse, "id" | "createdAt" | "updatedAt">) {
    const w: Warehouse = { id: uid("wh"), createdAt: nowISO(), updatedAt: nowISO(), ...input }
    set({ warehouses: [w, ...state.warehouses] })
    return w
  }
  function updateWarehouse(id: ID, patch: Partial<Warehouse>) {
    set({
      warehouses: state.warehouses.map((w) => (w.id === id ? { ...w, ...patch, updatedAt: nowISO() } : w)),
    })
  }
  function deleteWarehouse(id: ID) {
    // Also optionally move products out or prevent delete; for demo, allow delete
    set({ warehouses: state.warehouses.filter((w) => w.id !== id) })
  }

  // Suppliers
  function addSupplier(input: Omit<Supplier, "id" | "createdAt" | "updatedAt">) {
    const s: Supplier = { id: uid("sup"), createdAt: nowISO(), updatedAt: nowISO(), ...input }
    set({ suppliers: [s, ...state.suppliers] })
    return s
  }
  function updateSupplier(id: ID, patch: Partial<Supplier>) {
    set({
      suppliers: state.suppliers.map((s) => (s.id === id ? { ...s, ...patch, updatedAt: nowISO() } : s)),
    })
  }
  function deleteSupplier(id: ID) {
    set({ suppliers: state.suppliers.filter((s) => s.id !== id) })
  }

  // Adjustments (also adjusts product stock)
  function addAdjustment(input: Omit<Adjustment, "id" | "createdAt">) {
    const a: Adjustment = { id: uid("adj"), createdAt: nowISO(), ...input }
    const products = state.products.map((p) =>
      p.id === a.productId ? { ...p, stock: p.stock + a.delta, updatedAt: nowISO() } : p,
    )
    set({ adjustments: [a, ...state.adjustments], products })
    return a
  }

  return {
    state,
    // actions
    addProduct,
    updateProduct,
    deleteProduct,
    addWarehouse,
    updateWarehouse,
    deleteWarehouse,
    addSupplier,
    updateSupplier,
    deleteSupplier,
    addAdjustment,
  }
}
