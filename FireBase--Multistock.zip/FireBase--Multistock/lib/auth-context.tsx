'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useRouter } from 'next/navigation'

interface User {
  id: string
  email: string
  name: string
  role: string
  department?: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  isAuthenticated: boolean
  isGuest: boolean
  login: (identifier: string, password: string) => Promise<void>
  signUp: (email: string, password: string, name: string, phone?: string) => Promise<void>
  logout: () => void
  getRole: () => string | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setMounted(true)
    
    // Check localStorage only on client side
    if (typeof window !== 'undefined') {
      const storedUser = localStorage.getItem('user')
      const token = localStorage.getItem('token')
      
      if (storedUser && token) {
        try {
          setUser(JSON.parse(storedUser))
        } catch (error) {
          console.error('Failed to parse stored user:', error)
          localStorage.removeItem('user')
          localStorage.removeItem('token')
        }
      }
    }
    setLoading(false)
  }, [])

  const login = async (identifier: string, password: string) => {
    console.log(`🔐 Auth context login called`)
    
    try {
      console.log('🌐 Sending login request to /api/auth/login')
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ identifier, password }),
      })

      console.log('📡 Response received:', response.status)

      let data
      try {
        data = await response.json()
      } catch (jsonError) {
        console.error('❌ Failed to parse response as JSON:', jsonError)
        throw new Error('Server returned invalid response. Please try refreshing the page.')
      }

      if (response.ok && data.success) {
        console.log('✅ Login successful')
        
        // Set user state immediately for faster UI update
        setUser(data.user)
        
        if (typeof window !== 'undefined') {
          localStorage.setItem('token', data.token)
          localStorage.setItem('user', JSON.stringify(data.user))
          
          // Use direct navigation for immediate redirect
          window.location.href = '/dashboard'
        }
      } else {
        throw new Error(data.error || 'Invalid credentials')
      }
    } catch (error: any) {
      console.error('❌ Login error:', error)
      
      // Don't retry - just show the error
      if (error.message === 'Failed to fetch') {
        throw new Error('Cannot connect to server. Please check if the server is running.')
      }
      throw error
    }
  }

  const signUp = async (email: string, password: string, name: string, phone?: string) => {
    console.log('📝 Auth context signUp called')
    
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name, phone })
      })

      let data
      try {
        data = await response.json()
      } catch (jsonError) {
        console.error('❌ Failed to parse response as JSON:', jsonError)
        throw new Error('Server returned invalid response. Please check server logs.')
      }

      if (response.ok && data.success) {
        console.log('✅ Registration successful')
        
        setUser(data.user)
        
        if (typeof window !== 'undefined') {
          localStorage.setItem('token', data.token)
          localStorage.setItem('user', JSON.stringify(data.user))
          
          // Force immediate redirect
          setTimeout(() => {
            window.location.replace('/dashboard')
          }, 100)
        }
      } else {
        throw new Error(data.error || 'Registration failed')
      }
    } catch (error: any) {
      console.error('❌ Registration error:', error)
      throw error
    }
  }

  const logout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
    }
    setUser(null)
    // Small delay before redirect
    setTimeout(() => {
      router.push('/')
    }, 100)
  }

  const getRole = () => {
    return user?.role || null
  }

  const isAuthenticated = !!user
  const isGuest = !user

  return (
    <AuthContext.Provider value={{ user, loading, isAuthenticated, isGuest, login, signUp, logout, getRole }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}