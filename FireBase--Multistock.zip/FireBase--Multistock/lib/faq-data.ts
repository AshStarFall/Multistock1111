// FAQ Data for Chatbot - Organized by Category
// Similar to Airtel Thanks app Q&A system

export interface FAQItem {
  id: string
  question: string
  answer: string
  category: FAQCategory
  keywords: string[]
  relatedQuestions?: string[]
}

export type FAQCategory = 
  | 'orders'
  | 'shipping'
  | 'payments'
  | 'returns'
  | 'account'
  | 'marketplace'
  | 'rentals'
  | 'auctions'
  | 'general'

export const FAQ_CATEGORIES = {
  orders: { label: 'Orders', icon: '📦', color: 'blue' },
  shipping: { label: 'Shipping & Delivery', icon: '🚚', color: 'green' },
  payments: { label: 'Payments & Billing', icon: '💳', color: 'purple' },
  returns: { label: 'Returns & Refunds', icon: '↩️', color: 'orange' },
  account: { label: 'Account & Profile', icon: '👤', color: 'indigo' },
  marketplace: { label: 'Marketplace', icon: '🛒', color: 'pink' },
  rentals: { label: 'Rentals', icon: '🔑', color: 'cyan' },
  auctions: { label: 'Auctions & Bidding', icon: '⚡', color: 'amber' },
  general: { label: 'General', icon: 'ℹ️', color: 'slate' },
}

export const FAQ_DATA: FAQItem[] = [
  // ORDERS
  {
    id: 'order-1',
    question: 'How do I track my order?',
    answer: 'You can track your order by going to "My Orders" in your dashboard. Click on the order and you\'ll see real-time tracking information including current location and estimated delivery time.',
    category: 'orders',
    keywords: ['track', 'order', 'status', 'where is my order', 'delivery'],
    relatedQuestions: ['order-2', 'order-3']
  },
  {
    id: 'order-2',
    question: 'Can I cancel my order?',
    answer: 'Yes, you can cancel your order within 1 hour of placing it. Go to "My Orders", select the order, and click "Cancel Order". If the order has already been shipped, you\'ll need to initiate a return instead.',
    category: 'orders',
    keywords: ['cancel', 'order', 'stop', 'abort'],
    relatedQuestions: ['order-1', 'return-1']
  },
  {
    id: 'order-3',
    question: 'How long does order processing take?',
    answer: 'Orders are typically processed within 24 hours. During peak seasons or sales, it may take up to 48 hours. You\'ll receive a confirmation email once your order is shipped.',
    category: 'orders',
    keywords: ['processing', 'time', 'how long', 'when will ship'],
  },
  {
    id: 'order-4',
    question: 'Can I modify my order after placing it?',
    answer: 'You can modify your order (change address, add items, etc.) within 30 minutes of placing it. Go to "My Orders" and click "Modify Order". After 30 minutes, the order enters processing and cannot be changed.',
    category: 'orders',
    keywords: ['modify', 'change', 'edit', 'update', 'order'],
  },

  // SHIPPING
  {
    id: 'ship-1',
    question: 'What are the shipping charges?',
    answer: 'Shipping is FREE for orders above ₹499. For orders below ₹499, standard shipping costs ₹49. Express shipping (1-2 days) costs ₹99 regardless of order value.',
    category: 'shipping',
    keywords: ['shipping', 'delivery', 'charges', 'cost', 'fee', 'free'],
  },
  {
    id: 'ship-2',
    question: 'What is the delivery time?',
    answer: 'Standard delivery takes 3-7 business days depending on your location. Express delivery takes 1-2 business days. Metro cities usually receive orders faster. You can see estimated delivery date at checkout.',
    category: 'shipping',
    keywords: ['delivery', 'time', 'how long', 'when', 'arrive'],
  },
  {
    id: 'ship-3',
    question: 'Do you deliver to my pin code?',
    answer: 'We deliver to 20,000+ pin codes across India. Enter your pin code at checkout to check serviceability. If we don\'t currently deliver to your area, you can request coverage expansion.',
    category: 'shipping',
    keywords: ['pin code', 'location', 'deliver', 'area', 'available'],
  },
  {
    id: 'ship-4',
    question: 'Can I change my delivery address?',
    answer: 'Yes, you can change the delivery address before the order is shipped. Go to "My Orders", select the order, and click "Change Address". Once shipped, address cannot be changed.',
    category: 'shipping',
    keywords: ['address', 'change', 'delivery', 'location', 'wrong address'],
  },

  // PAYMENTS
  {
    id: 'pay-1',
    question: 'What payment methods do you accept?',
    answer: 'We accept Credit Cards, Debit Cards, Net Banking, UPI (Google Pay, PhonePe, Paytm), Wallets (Paytm, Mobikwik), and Cash on Delivery (COD) for eligible orders.',
    category: 'payments',
    keywords: ['payment', 'method', 'options', 'how to pay', 'upi', 'cod'],
  },
  {
    id: 'pay-2',
    question: 'Is Cash on Delivery (COD) available?',
    answer: 'Yes, COD is available for orders up to ₹10,000. A COD fee of ₹50 applies. COD may not be available in all areas - you\'ll see the option at checkout if available for your location.',
    category: 'payments',
    keywords: ['cod', 'cash on delivery', 'pay on delivery'],
  },
  {
    id: 'pay-3',
    question: 'My payment failed but money was deducted. What should I do?',
    answer: 'If payment fails but money is deducted, it will be automatically refunded within 5-7 business days. You can also contact our support team with your transaction ID for faster resolution.',
    category: 'payments',
    keywords: ['payment failed', 'money deducted', 'refund', 'transaction'],
  },
  {
    id: 'pay-4',
    question: 'Are my payment details secure?',
    answer: 'Yes, absolutely! We use 256-bit SSL encryption and comply with PCI DSS standards. We never store your complete card details. All payments are processed through secure payment gateways.',
    category: 'payments',
    keywords: ['secure', 'safe', 'security', 'card details', 'payment'],
  },

  // RETURNS & REFUNDS
  {
    id: 'return-1',
    question: 'What is your return policy?',
    answer: '7-day return policy for most products. Items must be unused, in original packaging with tags. Some products like food items, personal care are non-returnable. Return shipping is free if product is damaged/defective.',
    category: 'returns',
    keywords: ['return', 'policy', 'exchange', 'send back'],
  },
  {
    id: 'return-2',
    question: 'How do I return a product?',
    answer: 'Go to "My Orders", select the order, and click "Return Item". Choose reason for return, schedule free pickup, and pack the item securely. Our courier will pick it up from your address.',
    category: 'returns',
    keywords: ['return', 'how to', 'process', 'steps'],
  },
  {
    id: 'return-3',
    question: 'When will I get my refund?',
    answer: 'Refunds are processed within 2-3 business days after we receive the returned item. The amount will be credited to your original payment method. Bank transfers may take additional 5-7 days.',
    category: 'returns',
    keywords: ['refund', 'money back', 'when', 'how long'],
  },
  {
    id: 'return-4',
    question: 'Can I exchange a product instead of returning?',
    answer: 'Yes! During the return process, select "Exchange" instead of "Return". You can exchange for different size, color, or even a different product of same/higher value.',
    category: 'returns',
    keywords: ['exchange', 'swap', 'different size', 'color'],
  },

  // ACCOUNT
  {
    id: 'acc-1',
    question: 'How do I create an account?',
    answer: 'Click "Sign Up" at the top right, enter your email/phone and create a password. Verify your email/phone with the OTP sent. That\'s it! You can also sign up using Google or Facebook.',
    category: 'account',
    keywords: ['create account', 'sign up', 'register', 'new account'],
  },
  {
    id: 'acc-2',
    question: 'I forgot my password. What should I do?',
    answer: 'Click "Forgot Password" on the login page. Enter your registered email/phone. You\'ll receive a password reset link. Click the link and create a new password.',
    category: 'account',
    keywords: ['forgot password', 'reset password', 'password recovery'],
  },
  {
    id: 'acc-3',
    question: 'How do I change my email/phone number?',
    answer: 'Go to Settings > Account Settings. Click "Edit" next to email/phone. Enter new details and verify with OTP. Your account will be updated immediately.',
    category: 'account',
    keywords: ['change email', 'change phone', 'update', 'modify'],
  },
  {
    id: 'acc-4',
    question: 'How do I delete my account?',
    answer: 'Go to Settings > Account Settings > Delete Account. You\'ll need to verify your identity. Note: This action is irreversible. All your data, orders, and wallet balance will be permanently deleted.',
    category: 'account',
    keywords: ['delete account', 'close account', 'remove account'],
  },

  // MARKETPLACE
  {
    id: 'market-1',
    question: 'How can I sell on MultiStock Marketplace?',
    answer: 'Click "Sell on MultiStock" in the menu. Fill the seller registration form with business details. Choose a subscription plan (Free, Basic, Pro, or Business). Once approved, you can start listing products!',
    category: 'marketplace',
    keywords: ['sell', 'become seller', 'list products', 'marketplace'],
  },
  {
    id: 'market-2',
    question: 'What are the seller subscription plans?',
    answer: 'Free: 3 listings, 5% commission. Basic (₹499/mo): 20 listings, 3% commission. Pro (₹999/mo): Unlimited listings, 1% commission, verified badge. Business (₹2999/mo): All features, 0.5% commission, priority listing.',
    category: 'marketplace',
    keywords: ['subscription', 'plans', 'pricing', 'seller fees'],
  },
  {
    id: 'market-3',
    question: 'How do I get verified seller badge?',
    answer: 'Subscribe to Pro or Business plan. Submit verification documents (Business registration, GST, ID proof). Our team reviews in 2-3 business days. Once approved, you\'ll get the verified badge (✓).',
    category: 'marketplace',
    keywords: ['verified', 'badge', 'tick', 'verification'],
  },

  // RENTALS
  {
    id: 'rent-1',
    question: 'How does the rental service work?',
    answer: 'Browse rental items, select rental duration (daily/weekly/monthly), add to cart, and checkout. Item will be delivered to you. Use it for the rental period. Return it via free pickup before due date.',
    category: 'rentals',
    keywords: ['rental', 'how it works', 'rent', 'process'],
  },
  {
    id: 'rent-2',
    question: 'What if I damage a rented item?',
    answer: 'All rentals include insurance. Minor wear is acceptable. For significant damage, you\'ll be charged repair cost (max 30% of item value). Intentional damage may result in full item cost + penalty.',
    category: 'rentals',
    keywords: ['damage', 'rental', 'broken', 'insurance'],
  },
  {
    id: 'rent-3',
    question: 'Can I extend my rental period?',
    answer: 'Yes! Before the due date, go to "My Rentals" and click "Extend Rental". Choose additional days/weeks. Pay the extension fee. Your rental will be automatically extended.',
    category: 'rentals',
    keywords: ['extend', 'rental', 'more time', 'longer'],
  },

  // AUCTIONS
  {
    id: 'auction-1',
    question: 'How do auctions work?',
    answer: 'Sellers list items for 24-hour auctions with reserve price. Buyers place bids. Highest bid at end time wins. Winner pays within 24 hours. If auction gets bid in last 2 minutes, it auto-extends by 5 minutes.',
    category: 'auctions',
    keywords: ['auction', 'how it works', 'bidding', 'process'],
  },
  {
    id: 'auction-2',
    question: 'What if I win an auction but don\'t pay?',
    answer: 'You must pay within 24 hours of winning. First offense: Warning. Second offense: ₹1000 penalty. Third offense: Account suspended + ₹5000 reactivation fee + negative rating from admin.',
    category: 'auctions',
    keywords: ['auction', 'not paying', 'penalty', 'suspended'],
  },

  // GENERAL
  {
    id: 'gen-1',
    question: 'How do I contact customer support?',
    answer: 'You can reach us via: Email: support@multistock.com, Phone: 1800-XXX-XXXX (9 AM - 9 PM), Live Chat (click chat icon bottom-right), or raise a ticket in Help Center.',
    category: 'general',
    keywords: ['contact', 'support', 'help', 'customer service'],
  },
  {
    id: 'gen-2',
    question: 'Is MultiStock available in my city?',
    answer: 'MultiStock delivers to 20,000+ pin codes across India covering all major cities and towns. Enter your pin code at checkout to check availability in your area.',
    category: 'general',
    keywords: ['available', 'city', 'location', 'area', 'coverage'],
  },
  {
    id: 'gen-3',
    question: 'Do you have a mobile app?',
    answer: 'Yes! Download MultiStock app from Google Play Store or Apple App Store. Get exclusive app-only deals, faster checkout, push notifications for orders, and offline browsing.',
    category: 'general',
    keywords: ['app', 'mobile', 'android', 'ios', 'download'],
  },
]

// Quick replies for common scenarios
export const QUICK_REPLIES = [
  { text: 'Track Order', category: 'orders', action: 'track' },
  { text: 'Return Product', category: 'returns', action: 'return' },
  { text: 'Payment Issues', category: 'payments', action: 'payment' },
  { text: 'Contact Support', category: 'general', action: 'contact' },
  { text: 'Become Seller', category: 'marketplace', action: 'sell' },
  { text: 'Rental Help', category: 'rentals', action: 'rental' },
]

// Greeting messages based on time
export function getGreeting(): string {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good morning! ☀️'
  if (hour < 17) return 'Good afternoon! 👋'
  if (hour < 22) return 'Good evening! 🌆'
  return 'Hello! 🌙'
}

// Search FAQs by keywords
export function searchFAQs(query: string): FAQItem[] {
  const lowerQuery = query.toLowerCase()
  return FAQ_DATA.filter(faq => 
    faq.question.toLowerCase().includes(lowerQuery) ||
    faq.answer.toLowerCase().includes(lowerQuery) ||
    faq.keywords.some(keyword => keyword.includes(lowerQuery))
  )
}

// Get FAQs by category
export function getFAQsByCategory(category: FAQCategory): FAQItem[] {
  return FAQ_DATA.filter(faq => faq.category === category)
}

// Get related FAQs
export function getRelatedFAQs(faqId: string): FAQItem[] {
  const faq = FAQ_DATA.find(f => f.id === faqId)
  if (!faq?.relatedQuestions) return []
  return FAQ_DATA.filter(f => faq.relatedQuestions?.includes(f.id))
}
