// Verification & Trust Score System
export type VerificationStatus = 'pending' | 'under_review' | 'approved' | 'rejected' | 'expired';

export type DocumentType = 
  | 'government_id'
  | 'business_license'
  | 'tax_certificate'
  | 'address_proof'
  | 'bank_statement'
  | 'other';

export type VerificationDocument = {
  id: string;
  type: DocumentType;
  fileName: string;
  fileUrl: string;
  uploadedAt: string;
  status: 'pending' | 'verified' | 'rejected';
  rejectionReason?: string;
};

export type VerificationRequest = {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  requestType: 'individual' | 'business';
  status: VerificationStatus;
  documents: VerificationDocument[];
  businessName?: string;
  businessType?: string;
  taxId?: string;
  website?: string;
  notes?: string;
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  reviewerComments?: string;
  trustScore: number;
  verifiedAt?: string;
  expiresAt?: string;
};

export type TrustScore = {
  userId: string;
  totalScore: number;
  verificationScore: number;
  activityScore: number;
  reputationScore: number;
  consistencyScore: number;
  lastCalculated: string;
  badges: VerificationBadge[];
};

export type VerificationBadge = {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  earnedAt: string;
};

export const DOCUMENT_TYPES: { value: DocumentType; label: string; required: boolean }[] = [
  { value: 'government_id', label: 'Government ID (Aadhaar/PAN/Passport)', required: true },
  { value: 'business_license', label: 'Business License', required: false },
  { value: 'tax_certificate', label: 'GST/Tax Certificate', required: false },
  { value: 'address_proof', label: 'Address Proof', required: true },
  { value: 'bank_statement', label: 'Bank Statement', required: false },
  { value: 'other', label: 'Other Document', required: false },
];

export const TRUST_SCORE_BADGES: {
  minScore: number;
  name: string;
  description: string;
  icon: string;
  color: string;
}[] = [
  {
    minScore: 90,
    name: 'Platinum Verified',
    description: 'Highest trust level with complete verification',
    icon: '💎',
    color: 'bg-purple-600',
  },
  {
    minScore: 75,
    name: 'Gold Verified',
    description: 'Highly trusted verified member',
    icon: '🥇',
    color: 'bg-yellow-600',
  },
  {
    minScore: 60,
    name: 'Silver Verified',
    description: 'Trusted verified member',
    icon: '🥈',
    color: 'bg-gray-400',
  },
  {
    minScore: 40,
    name: 'Bronze Verified',
    description: 'Basic verification completed',
    icon: '🥉',
    color: 'bg-orange-600',
  },
  {
    minScore: 0,
    name: 'Unverified',
    description: 'Not yet verified',
    icon: '❓',
    color: 'bg-gray-500',
  },
];

// Calculate comprehensive trust score
export function calculateTrustScore(metrics: {
  isVerified: boolean;
  accountAge: number; // days
  totalTransactions: number;
  successfulTransactions: number;
  averageRating: number;
  totalReviews: number;
  responseRate: number;
  disputesCount: number;
}): number {
  let score = 0;

  // Verification (40 points)
  if (metrics.isVerified) {
    score += 40;
  }

  // Activity Score (20 points)
  const activityScore = Math.min(
    20,
    (metrics.totalTransactions / 50) * 10 + (metrics.accountAge / 365) * 10
  );
  score += activityScore;

  // Reputation Score (25 points)
  if (metrics.totalReviews > 0) {
    const ratingScore = (metrics.averageRating / 5) * 15;
    const reviewScore = Math.min(10, (metrics.totalReviews / 20) * 10);
    score += ratingScore + reviewScore;
  }

  // Consistency Score (15 points)
  if (metrics.totalTransactions > 0) {
    const successRate = metrics.successfulTransactions / metrics.totalTransactions;
    const consistencyScore = successRate * 10;
    const responseScore = metrics.responseRate * 5;
    score += consistencyScore + responseScore;
  }

  // Deductions
  const disputePenalty = metrics.disputesCount * 5;
  score = Math.max(0, score - disputePenalty);

  return Math.round(Math.min(100, score));
}

// Get badge based on trust score
export function getTrustBadge(score: number): typeof TRUST_SCORE_BADGES[0] {
  for (const badge of TRUST_SCORE_BADGES) {
    if (score >= badge.minScore) {
      return badge;
    }
  }
  return TRUST_SCORE_BADGES[TRUST_SCORE_BADGES.length - 1];
}

// Validate document file
export function validateDocument(file: File): { valid: boolean; error?: string } {
  const maxSize = 5 * 1024 * 1024; // 5MB
  const allowedTypes = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp',
    'application/pdf',
  ];

  if (!allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: 'Only JPG, PNG, WebP, and PDF files are allowed',
    };
  }

  if (file.size > maxSize) {
    return {
      valid: false,
      error: 'File size must be less than 5MB',
    };
  }

  return { valid: true };
}

// Get verification status color
export function getStatusColor(status: VerificationStatus): string {
  switch (status) {
    case 'approved':
      return 'text-green-600 bg-green-50 dark:bg-green-950/20';
    case 'pending':
    case 'under_review':
      return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-950/20';
    case 'rejected':
      return 'text-red-600 bg-red-50 dark:bg-red-950/20';
    case 'expired':
      return 'text-gray-600 bg-gray-50 dark:bg-gray-950/20';
    default:
      return 'text-blue-600 bg-blue-50 dark:bg-blue-950/20';
  }
}

// Get verification status label
export function getStatusLabel(status: VerificationStatus): string {
  switch (status) {
    case 'pending':
      return 'Pending Submission';
    case 'under_review':
      return 'Under Review';
    case 'approved':
      return 'Verified';
    case 'rejected':
      return 'Rejected';
    case 'expired':
      return 'Expired';
    default:
      return status;
  }
}

// Check if verification is expired
export function isVerificationExpired(expiresAt?: string): boolean {
  if (!expiresAt) return false;
  return new Date(expiresAt) < new Date();
}

// Get required documents for verification type
export function getRequiredDocuments(type: 'individual' | 'business'): DocumentType[] {
  if (type === 'business') {
    return ['government_id', 'business_license', 'tax_certificate', 'address_proof'];
  }
  return ['government_id', 'address_proof'];
}

// Format file size
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
}
