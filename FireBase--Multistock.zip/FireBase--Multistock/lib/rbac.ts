// Role-Based Access Control System - 6-Tier Hierarchy
// SuperAdmin > Admin > SubAdmin > SeniorStaff > Staff > Customer

export type Permission = 
  | 'products:read' | 'products:write' | 'products:delete'
  | 'rentals:read' | 'rentals:write' | 'rentals:delete'
  | 'lockers:read' | 'lockers:write' | 'lockers:delete'
  | 'marketplace:read' | 'marketplace:write' | 'marketplace:delete'
  | 'auctions:read' | 'auctions:write' | 'auctions:delete' | 'auctions:approve'
  | 'billing:read' | 'billing:write' | 'billing:manage'
  | 'analytics:read' | 'analytics:advanced'
  | 'users:read' | 'users:write' | 'users:delete' | 'users:suspend'
  | 'settings:read' | 'settings:write' | 'settings:admin'
  | 'coupons:read' | 'coupons:write' | 'coupons:delete'
  | 'forum:read' | 'forum:write' | 'forum:moderate' | 'forum:admin'
  | 'verification:read' | 'verification:approve'
  | 'transactions:read' | 'transactions:manage'
  | 'warehouses:read' | 'warehouses:write' | 'warehouses:delete'

export type Role = 'SuperAdmin' | 'Admin' | 'SubAdmin' | 'SeniorStaff' | 'Staff' | 'Customer' | 'guest'

export const ROLE_HIERARCHY: Record<Role, number> = {
  SuperAdmin: 6,
  Admin: 5,
  SubAdmin: 4,
  SeniorStaff: 3,
  Staff: 2,
  Customer: 1,
  guest: 0,
}

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  SuperAdmin: [
    // Full system access - all permissions
    'products:read', 'products:write', 'products:delete',
    'rentals:read', 'rentals:write', 'rentals:delete',
    'lockers:read', 'lockers:write', 'lockers:delete',
    'marketplace:read', 'marketplace:write', 'marketplace:delete',
    'auctions:read', 'auctions:write', 'auctions:delete', 'auctions:approve',
    'billing:read', 'billing:write', 'billing:manage',
    'analytics:read', 'analytics:advanced',
    'users:read', 'users:write', 'users:delete', 'users:suspend',
    'settings:read', 'settings:write', 'settings:admin',
    'coupons:read', 'coupons:write', 'coupons:delete',
    'forum:read', 'forum:write', 'forum:moderate', 'forum:admin',
    'verification:read', 'verification:approve',
    'transactions:read', 'transactions:manage',
    'warehouses:read', 'warehouses:write', 'warehouses:delete',
  ],
  Admin: [
    // High-level management - most permissions
    'products:read', 'products:write', 'products:delete',
    'rentals:read', 'rentals:write', 'rentals:delete',
    'lockers:read', 'lockers:write', 'lockers:delete',
    'marketplace:read', 'marketplace:write', 'marketplace:delete',
    'auctions:read', 'auctions:write', 'auctions:approve',
    'billing:read', 'billing:write', 'billing:manage',
    'analytics:read', 'analytics:advanced',
    'users:read', 'users:write', 'users:suspend',
    'settings:read', 'settings:write',
    'coupons:read', 'coupons:write', 'coupons:delete',
    'forum:read', 'forum:write', 'forum:moderate',
    'verification:read', 'verification:approve',
    'transactions:read', 'transactions:manage',
    'warehouses:read', 'warehouses:write', 'warehouses:delete',
  ],
  SubAdmin: [
    // Departmental management
    'products:read', 'products:write', 'products:delete',
    'rentals:read', 'rentals:write',
    'lockers:read', 'lockers:write',
    'marketplace:read', 'marketplace:write',
    'auctions:read', 'auctions:write',
    'billing:read', 'billing:write',
    'analytics:read',
    'users:read', 'users:write',
    'settings:read', 'settings:write',
    'coupons:read', 'coupons:write',
    'forum:read', 'forum:write', 'forum:moderate',
    'verification:read',
    'transactions:read',
    'warehouses:read', 'warehouses:write',
  ],
  SeniorStaff: [
    // Senior operational staff
    'products:read', 'products:write',
    'rentals:read', 'rentals:write',
    'lockers:read', 'lockers:write',
    'marketplace:read', 'marketplace:write',
    'auctions:read',
    'billing:read', 'billing:write',
    'analytics:read',
    'users:read',
    'settings:read',
    'coupons:read',
    'forum:read', 'forum:write',
    'transactions:read',
    'warehouses:read',
  ],
  Staff: [
    // Basic operational staff
    'products:read', 'products:write',
    'rentals:read', 'rentals:write',
    'lockers:read',
    'marketplace:read',
    'billing:read',
    'users:read',
    'forum:read', 'forum:write',
    'warehouses:read',
  ],
  Customer: [
    // End users/customers
    'products:read',
    'rentals:read', 'rentals:write', // Can rent items
    'marketplace:read', 'marketplace:write', // Can list items for sale
    'auctions:read', 'auctions:write', // Can bid
    'billing:read',
    'coupons:read',
    'forum:read', 'forum:write',
  ],
  guest: [
    // Public access only
    'products:read',
    'marketplace:read',
    'auctions:read',
  ]
}

export function hasPermission(userRole: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[userRole]?.includes(permission) ?? false
}

export function hasAnyPermission(userRole: Role, permissions: Permission[]): boolean {
  return permissions.some(permission => hasPermission(userRole, permission))
}

export function requirePermission(userRole: Role, permission: Permission): void {
  if (!hasPermission(userRole, permission)) {
    throw new Error(`Insufficient permissions. Required: ${permission}`)
  }
}

export function getRoleHierarchy(role: Role): number {
  return ROLE_HIERARCHY[role] ?? 0
}

export function canAccessResource(userRole: Role, resourceRole: Role): boolean {
  return getRoleHierarchy(userRole) >= getRoleHierarchy(resourceRole)
}

export function getRoleBadgeColor(role: Role): string {
  switch (role) {
    case 'SuperAdmin':
      return 'bg-gradient-to-r from-red-500 to-pink-500'
    case 'Admin':
      return 'bg-gradient-to-r from-purple-500 to-indigo-500'
    case 'SubAdmin':
      return 'bg-gradient-to-r from-blue-500 to-cyan-500'
    case 'SeniorStaff':
      return 'bg-gradient-to-r from-green-500 to-emerald-500'
    case 'Staff':
      return 'bg-gradient-to-r from-amber-500 to-orange-500'
    case 'Customer':
      return 'bg-gradient-to-r from-slate-500 to-gray-500'
    default:
      return 'bg-slate-500'
  }
}

export function getRoleIcon(role: Role): string {
  switch (role) {
    case 'SuperAdmin':
      return '👑'
    case 'Admin':
      return '🛡️'
    case 'SubAdmin':
      return '⭐'
    case 'SeniorStaff':
      return '💼'
    case 'Staff':
      return '👤'
    case 'Customer':
      return '🛒'
    default:
      return '👤'
  }
}

export function getRoleDisplayName(role: Role): string {
  switch (role) {
    case 'SuperAdmin':
      return 'Super Administrator'
    case 'Admin':
      return 'Administrator'
    case 'SubAdmin':
      return 'Sub Administrator'
    case 'SeniorStaff':
      return 'Senior Staff'
    case 'Staff':
      return 'Staff Member'
    case 'Customer':
      return 'Customer'
    default:
      return 'Guest'
  }
}
