// Forum and Chat Types and Utilities

export type ThreadStatus = 'active' | 'locked' | 'pinned' | 'archived'

export type MessageType = 'text' | 'image' | 'file' | 'system'

export type ChatType = 'private' | 'group'

export interface ForumCategory {
  id: string
  name: string
  description: string
  icon: string
  color: string
  threadCount: number
  postCount: number
  order: number
  moderators: string[]
  createdAt: Date
}

export interface ForumThread {
  id: string
  categoryId: string
  categoryName: string
  authorId: string
  authorName: string
  authorAvatar?: string
  title: string
  content: string
  status: ThreadStatus
  isPinned: boolean
  isLocked: boolean
  views: number
  replies: number
  likes: number
  tags: string[]
  lastReplyAt?: Date
  lastReplyBy?: string
  createdAt: Date
  updatedAt: Date
}

export interface ForumPost {
  id: string
  threadId: string
  authorId: string
  authorName: string
  authorAvatar?: string
  content: string
  isEdited: boolean
  editedAt?: Date
  likes: number
  isAnswer: boolean // For question threads
  createdAt: Date
  updatedAt: Date
}

export interface Chat {
  id: string
  type: ChatType
  name?: string // For group chats
  avatar?: string
  participants: ChatParticipant[]
  lastMessage?: ChatMessage
  unreadCount: number
  createdAt: Date
  updatedAt: Date
}

export interface ChatParticipant {
  userId: string
  userName: string
  userAvatar?: string
  role: 'admin' | 'member'
  joinedAt: Date
  lastSeenAt?: Date
}

export interface ChatMessage {
  id: string
  chatId: string
  senderId: string
  senderName: string
  senderAvatar?: string
  type: MessageType
  content: string
  fileUrl?: string
  fileName?: string
  fileSize?: number
  replyTo?: string // Message ID being replied to
  isRead: boolean
  readBy: string[]
  createdAt: Date
  updatedAt: Date
}

// Forum categories data
export const FORUM_CATEGORIES: Omit<ForumCategory, 'id' | 'threadCount' | 'postCount' | 'createdAt'>[] = [
  {
    name: 'General Discussion',
    description: 'Talk about anything related to the platform',
    icon: '💬',
    color: 'blue',
    order: 1,
    moderators: []
  },
  {
    name: 'Help & Support',
    description: 'Get help from the community and experts',
    icon: '🆘',
    color: 'red',
    order: 2,
    moderators: []
  },
  {
    name: 'Marketplace',
    description: 'Discuss buying, selling, and trading',
    icon: '🛒',
    color: 'green',
    order: 3,
    moderators: []
  },
  {
    name: 'Auctions',
    description: 'Share auction tips and experiences',
    icon: '🔨',
    color: 'purple',
    order: 4,
    moderators: []
  },
  {
    name: 'Feature Requests',
    description: 'Suggest new features and improvements',
    icon: '💡',
    color: 'yellow',
    order: 5,
    moderators: []
  },
  {
    name: 'Announcements',
    description: 'Official platform announcements',
    icon: '📢',
    color: 'orange',
    order: 6,
    moderators: []
  }
]

// Get category color class
export function getCategoryColor(color: string): string {
  const colors: Record<string, string> = {
    blue: 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
    red: 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400',
    green: 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400',
    purple: 'bg-purple-100 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400',
    yellow: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400',
    orange: 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400'
  }
  return colors[color] || colors.blue
}

// Get thread status badge
export function getThreadStatusBadge(status: ThreadStatus): {
  label: string
  color: string
} {
  const badges: Record<ThreadStatus, { label: string; color: string }> = {
    active: { label: 'Active', color: 'bg-green-100 text-green-700' },
    locked: { label: 'Locked', color: 'bg-red-100 text-red-700' },
    pinned: { label: 'Pinned', color: 'bg-blue-100 text-blue-700' },
    archived: { label: 'Archived', color: 'bg-slate-100 text-slate-700' }
  }
  return badges[status] || badges.active
}

// Format time ago
export function getTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000)
  
  if (seconds < 60) return 'Just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`
  if (seconds < 2592000) return `${Math.floor(seconds / 604800)}w ago`
  return new Date(date).toLocaleDateString()
}

// Format message time
export function formatMessageTime(date: Date): string {
  const now = new Date()
  const messageDate = new Date(date)
  const diffDays = Math.floor((now.getTime() - messageDate.getTime()) / (1000 * 60 * 60 * 24))

  if (diffDays === 0) {
    // Today - show time
    return messageDate.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    })
  } else if (diffDays === 1) {
    return 'Yesterday'
  } else if (diffDays < 7) {
    return messageDate.toLocaleDateString('en-US', { weekday: 'short' })
  } else {
    return messageDate.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    })
  }
}

// Check if user is online (last seen within 5 minutes)
export function isUserOnline(lastSeenAt?: Date): boolean {
  if (!lastSeenAt) return false
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000)
  return new Date(lastSeenAt) > fiveMinutesAgo
}

// Get chat display name
export function getChatDisplayName(chat: Chat, currentUserId: string): string {
  if (chat.type === 'group') {
    return chat.name || 'Group Chat'
  }
  
  // Private chat - return other participant's name
  const otherParticipant = chat.participants.find(p => p.userId !== currentUserId)
  return otherParticipant?.userName || 'Unknown User'
}

// Get chat avatar
export function getChatAvatar(chat: Chat, currentUserId: string): string {
  if (chat.type === 'group') {
    return chat.avatar || ''
  }
  
  // Private chat - return other participant's avatar
  const otherParticipant = chat.participants.find(p => p.userId !== currentUserId)
  return otherParticipant?.userAvatar || ''
}

// Format file size
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes'
  
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i]
}

// Validate message content
export function validateMessage(content: string): { valid: boolean; error?: string } {
  if (!content.trim()) {
    return { valid: false, error: 'Message cannot be empty' }
  }
  
  if (content.length > 5000) {
    return { valid: false, error: 'Message is too long (max 5000 characters)' }
  }
  
  return { valid: true }
}

// Sort threads
export function sortThreads(
  threads: ForumThread[],
  sortBy: 'latest' | 'popular' | 'oldest' | 'replies'
): ForumThread[] {
  const sorted = [...threads]
  
  // Always keep pinned threads at top
  const pinned = sorted.filter(t => t.isPinned)
  const regular = sorted.filter(t => !t.isPinned)
  
  switch (sortBy) {
    case 'latest':
      regular.sort((a, b) => 
        new Date(b.lastReplyAt || b.createdAt).getTime() - 
        new Date(a.lastReplyAt || a.createdAt).getTime()
      )
      break
    case 'popular':
      regular.sort((a, b) => (b.views + b.likes * 10) - (a.views + a.likes * 10))
      break
    case 'oldest':
      regular.sort((a, b) => 
        new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      )
      break
    case 'replies':
      regular.sort((a, b) => b.replies - a.replies)
      break
  }
  
  return [...pinned, ...regular]
}

// Search threads
export function searchThreads(threads: ForumThread[], query: string): ForumThread[] {
  const lowerQuery = query.toLowerCase()
  return threads.filter(thread =>
    thread.title.toLowerCase().includes(lowerQuery) ||
    thread.content.toLowerCase().includes(lowerQuery) ||
    thread.tags.some(tag => tag.toLowerCase().includes(lowerQuery)) ||
    thread.authorName.toLowerCase().includes(lowerQuery)
  )
}

// Group messages by date
export function groupMessagesByDate(messages: ChatMessage[]): Map<string, ChatMessage[]> {
  const grouped = new Map<string, ChatMessage[]>()
  
  messages.forEach(message => {
    const date = new Date(message.createdAt).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
    
    if (!grouped.has(date)) {
      grouped.set(date, [])
    }
    grouped.get(date)!.push(message)
  })
  
  return grouped
}
