"use client"

import { products as seedProducts } from "@/lib/mock-data"
import { listBookings } from "@/lib/bookings"

export function exportProductsCSV(): string {
  const header = ["id", "sku", "name", "category", "price", "onHand"]
  const lines = seedProducts.map((p) => {
    const onHand = Object.values(p.stockByWarehouse).reduce((a, b) => a + b, 0)
    return [p.id, p.sku, p.name, p.category ?? "", p.price, onHand].join(",")
  })
  return [header.join(","), ...lines].join("\n")
}

export function exportBookingsCSV(start?: string, end?: string): string {
  const header = ["id", "type", "title", "startDate", "endDate", "subtotal", "discount", "total"]
  const rows = listBookings().filter((b) => {
    if (start && b.startDate < start) return false
    if (end && b.endDate > end) return false
    return true
  })
  const lines = rows.map((b) => [b.id, b.type, b.title, b.startDate, b.endDate, b.subtotal ?? 0, b.discount ?? 0, b.total ?? 0].join(","))
  return [header.join(","), ...lines].join("\n")
}

export function downloadFile(filename: string, content: string, type = "text/csv;charset=utf-8;") {
  const blob = new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}


