export type AuditEvent = {
  id: string
  ts: string // ISO
  actor: string
  action: string
  meta?: Record<string, any>
}

import { load, save } from "./storage"

const KEY = "audit-log"

export function getAuditLog(): AuditEvent[] {
  return load<AuditEvent[]>(KEY, [])
}

export function addAuditEvent(e: Omit<AuditEvent, "id" | "ts" | "actor"> & { actor?: string }) {
  const log = getAuditLog()
  const entry: AuditEvent = {
    id: crypto.randomUUID(),
    ts: new Date().toISOString(),
    actor: e.actor ?? "user",
    action: e.action,
    meta: e.meta,
  }
  log.unshift(entry)
  save(KEY, log.slice(0, 500)) // cap
  return entry
}

export function clearAuditLog() {
  save<AuditEvent[]>(KEY, [])
}
