"use client"

import React, { createContext, useContext, useState, useEffect } from 'react'

interface Notification {
  id: string
  title: string
  message: string
  type?: 'info' | 'success' | 'error' | 'warning'
  read?: boolean
  timestamp: number
  action?: { label: string; onClick?: () => void }
}

interface NotificationsContextType {
  notifications: Notification[]
  unreadCount: number
  pushNotification: (n: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void
  markAsRead: (id: string) => void
  markAllAsRead: () => void
  clearNotification: (id: string) => void
  clearAll: () => void
}

const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined)

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    // Seed with a small sample notification for dev
    setNotifications(prev => {
      if (prev.length === 0) {
        return [
          {
            id: 'welcome-1',
            title: 'Welcome to MultiStock',
            message: 'Your dashboard is ready',
            type: 'success',
            read: false,
            timestamp: Date.now(),
          }
        ]
      }
      return prev
    })
  }, [])

  const pushNotification = (n: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      id: `n_${Math.random().toString(36).slice(2, 9)}`,
      timestamp: Date.now(),
      read: false,
      ...n,
    }
    setNotifications(prev => [newNotification, ...prev])
  }

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))
  }

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
  }

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  const clearAll = () => setNotifications([])

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <NotificationsContext.Provider value={{
      notifications,
      unreadCount,
      pushNotification,
      markAsRead,
      markAllAsRead,
      clearNotification,
      clearAll
    }}>
      {children}
    </NotificationsContext.Provider>
  )
}

export function useNotifications() {
  const ctx = useContext(NotificationsContext)
  if (!ctx) throw new Error('useNotifications must be used within NotificationProvider')
  return ctx
}
