// Review and Rating System Types and Utilities

export interface Review {
  id: string
  productId: string
  userId: string
  userName: string
  userAvatar?: string
  rating: number // 1-5
  title: string
  comment: string
  images?: string[]
  verifiedPurchase: boolean
  helpful: number
  notHelpful: number
  status: 'pending' | 'approved' | 'rejected'
  moderatedBy?: string
  moderationNote?: string
  createdAt: Date
  updatedAt: Date
}

export interface ReviewStats {
  averageRating: number
  totalReviews: number
  distribution: {
    5: number
    4: number
    3: number
    2: number
    1: number
  }
  verifiedPurchaseCount: number
}

export interface ReviewFilters {
  rating?: number
  verifiedOnly?: boolean
  sortBy?: 'recent' | 'helpful' | 'rating-high' | 'rating-low'
  withImages?: boolean
}

// Calculate review statistics
export function calculateReviewStats(reviews: Review[]): ReviewStats {
  const approvedReviews = reviews.filter(r => r.status === 'approved')
  
  const distribution = {
    5: approvedReviews.filter(r => r.rating === 5).length,
    4: approvedReviews.filter(r => r.rating === 4).length,
    3: approvedReviews.filter(r => r.rating === 3).length,
    2: approvedReviews.filter(r => r.rating === 2).length,
    1: approvedReviews.filter(r => r.rating === 1).length,
  }

  const totalReviews = approvedReviews.length
  const averageRating = totalReviews > 0
    ? approvedReviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
    : 0

  const verifiedPurchaseCount = approvedReviews.filter(r => r.verifiedPurchase).length

  return {
    averageRating: Math.round(averageRating * 10) / 10, // Round to 1 decimal
    totalReviews,
    distribution,
    verifiedPurchaseCount
  }
}

// Filter and sort reviews
export function filterReviews(reviews: Review[], filters: ReviewFilters): Review[] {
  let filtered = reviews.filter(r => r.status === 'approved')

  // Filter by rating
  if (filters.rating) {
    filtered = filtered.filter(r => r.rating === filters.rating)
  }

  // Filter by verified purchase
  if (filters.verifiedOnly) {
    filtered = filtered.filter(r => r.verifiedPurchase)
  }

  // Filter by images
  if (filters.withImages) {
    filtered = filtered.filter(r => r.images && r.images.length > 0)
  }

  // Sort reviews
  switch (filters.sortBy) {
    case 'helpful':
      filtered.sort((a, b) => b.helpful - a.helpful)
      break
    case 'rating-high':
      filtered.sort((a, b) => b.rating - a.rating)
      break
    case 'rating-low':
      filtered.sort((a, b) => a.rating - b.rating)
      break
    case 'recent':
    default:
      filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      break
  }

  return filtered
}

// Get rating color
export function getRatingColor(rating: number): string {
  if (rating >= 4.5) return 'text-green-600'
  if (rating >= 3.5) return 'text-blue-600'
  if (rating >= 2.5) return 'text-yellow-600'
  if (rating >= 1.5) return 'text-orange-600'
  return 'text-red-600'
}

// Get rating badge color
export function getRatingBadgeColor(rating: number): string {
  if (rating >= 4.5) return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
  if (rating >= 3.5) return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300'
  if (rating >= 2.5) return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300'
  if (rating >= 1.5) return 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300'
  return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
}

// Format time ago
export function getTimeAgo(date: Date): string {
  const now = new Date()
  const diffInMs = now.getTime() - new Date(date).getTime()
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24))

  if (diffInDays === 0) return 'Today'
  if (diffInDays === 1) return 'Yesterday'
  if (diffInDays < 7) return `${diffInDays} days ago`
  if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`
  if (diffInDays < 365) return `${Math.floor(diffInDays / 30)} months ago`
  return `${Math.floor(diffInDays / 365)} years ago`
}

// Validate review content
export function validateReview(rating: number, title: string, comment: string): {
  valid: boolean
  errors: string[]
} {
  const errors: string[] = []

  if (rating < 1 || rating > 5) {
    errors.push('Rating must be between 1 and 5 stars')
  }

  if (!title || title.trim().length < 3) {
    errors.push('Review title must be at least 3 characters')
  }

  if (title.length > 100) {
    errors.push('Review title must be less than 100 characters')
  }

  if (!comment || comment.trim().length < 10) {
    errors.push('Review comment must be at least 10 characters')
  }

  if (comment.length > 2000) {
    errors.push('Review comment must be less than 2000 characters')
  }

  return {
    valid: errors.length === 0,
    errors
  }
}
